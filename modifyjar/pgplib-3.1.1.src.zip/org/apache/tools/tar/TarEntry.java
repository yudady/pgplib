package org.apache.tools.tar;

import java.io.File;
import java.util.Date;
import java.util.Locale;

public class TarEntry
  implements TarConstants
{
  private StringBuffer a = new StringBuffer();
  private int b;
  private int c;
  private int d;
  private long e;
  private long f;
  private byte g;
  private StringBuffer h = new StringBuffer();
  private StringBuffer i = new StringBuffer("ustar  ");
  private StringBuffer j;
  private StringBuffer k;
  private File l;
  public static final int MAX_NAMELEN = 31;
  public static final int DEFAULT_DIR_MODE = 16877;
  public static final int DEFAULT_FILE_MODE = 33188;
  public static final int MILLIS_PER_SECOND = 1000;

  private TarEntry()
  {
    String str;
    if ((str = "").length() > 31)
      str = str.substring(0, 31);
    c = 0;
    d = 0;
    j = new StringBuffer(str);
    k = new StringBuffer("");
    l = null;
  }

  public TarEntry(String paramString)
  {
    this(paramString, false);
  }

  public TarEntry(String paramString, boolean paramBoolean)
  {
    this();
    paramBoolean = (paramString = a(paramString, paramBoolean)).endsWith("/");
    a = new StringBuffer(paramString);
    b = (paramBoolean ? 16877 : 33188);
    g = (paramBoolean ? 53 : 48);
    c = 0;
    d = 0;
    e = 0L;
    f = (new Date().getTime() / 1000L);
    h = new StringBuffer("");
    j = new StringBuffer("");
    k = new StringBuffer("");
  }

  public TarEntry(String paramString1, String paramString2)
  {
    this();
    paramString2 = (paramString1 = a(l.getAbsolutePath(), false)).endsWith("/");
    a = new StringBuffer(paramString1);
    b = (paramString2 != 0 ? 16877 : 33188);
    g = (paramString2 != 0 ? 53 : 48);
    c = 0;
    d = 0;
    e = 0L;
    f = (new Date().getTime() / 1000L);
    h = new StringBuffer("");
    j = new StringBuffer("");
    k = new StringBuffer("");
  }

  public TarEntry(String paramString, byte paramByte)
  {
    this(paramString);
    g = paramByte;
    if (paramByte == 76)
      i = new StringBuffer("ustar  ");
  }

  public TarEntry(File paramFile)
  {
    this(paramFile, "");
  }

  public TarEntry(File paramFile, String paramString)
  {
    this();
    l = paramFile;
    String str = (str = paramFile.getAbsolutePath().replace(File.separatorChar, '/')).substring(str.indexOf(paramString));
    if ("".equals(paramString))
      str = paramFile.getName();
    paramString = a(str, false);
    h = new StringBuffer("");
    a = new StringBuffer(paramString);
    if (paramFile.isDirectory())
    {
      b = 16877;
      g = 53;
      if (((paramString = a.length()) == 0) || (a.charAt(paramString - 1) != '/'))
        a.append("/");
      e = 0L;
    }
    else
    {
      b = 33188;
      g = 48;
      e = paramFile.length();
    }
    f = (paramFile.lastModified() / 1000L);
  }

  public TarEntry(byte[] paramArrayOfByte)
  {
    this();
    parseTarHeader(paramArrayOfByte);
  }

  public boolean equals(TarEntry paramTarEntry)
  {
    return getName().equals(paramTarEntry.getName());
  }

  public boolean equals(Object paramObject)
  {
    if ((paramObject == null) || (getClass() != paramObject.getClass()))
      return false;
    return equals((TarEntry)paramObject);
  }

  public int hashCode()
  {
    return getName().hashCode();
  }

  public boolean isDescendent(TarEntry paramTarEntry)
  {
    return paramTarEntry.getName().startsWith(getName());
  }

  public String getName()
  {
    return a.toString();
  }

  public void setName(String paramString)
  {
    a = new StringBuffer(a(paramString, false));
  }

  public void setMode(int paramInt)
  {
    b = paramInt;
  }

  public String getLinkName()
  {
    return h.toString();
  }

  public int getUserId()
  {
    return c;
  }

  public void setUserId(int paramInt)
  {
    c = paramInt;
  }

  public int getGroupId()
  {
    return d;
  }

  public void setGroupId(int paramInt)
  {
    d = paramInt;
  }

  public String getUserName()
  {
    return j.toString();
  }

  public void setUserName(String paramString)
  {
    j = new StringBuffer(paramString);
  }

  public String getGroupName()
  {
    return k.toString();
  }

  public void setGroupName(String paramString)
  {
    k = new StringBuffer(paramString);
  }

  public void setIds(int paramInt1, int paramInt2)
  {
    setUserId(paramInt1);
    setGroupId(paramInt2);
  }

  public void setNames(String paramString1, String paramString2)
  {
    setUserName(paramString1);
    setGroupName(paramString2);
  }

  public void setModTime(long paramLong)
  {
    f = (paramLong / 1000L);
  }

  public void setModTime(Date paramDate)
  {
    f = (paramDate.getTime() / 1000L);
  }

  public Date getModTime()
  {
    return new Date(f * 1000L);
  }

  public File getFile()
  {
    return l;
  }

  public int getMode()
  {
    return b;
  }

  public long getSize()
  {
    return e;
  }

  public void setSize(long paramLong)
  {
    e = paramLong;
  }

  public boolean isGNULongNameEntry()
  {
    return (g == 76) && (a.toString().equals("././@LongLink"));
  }

  public boolean isDirectory()
  {
    if (l != null)
      return l.isDirectory();
    if (g == 53)
      return true;
    return getName().endsWith("/");
  }

  public TarEntry[] getDirectoryEntries()
  {
    if ((l == null) || (!l.isDirectory()))
      return new TarEntry[0];
    String[] arrayOfString;
    TarEntry[] arrayOfTarEntry = new TarEntry[(arrayOfString = l.list()).length];
    for (int m = 0; m < arrayOfString.length; m++)
      arrayOfTarEntry[m] = new TarEntry(new File(l, arrayOfString[m]));
    return arrayOfTarEntry;
  }

  public void writeEntryHeader(byte[] paramArrayOfByte)
  {
    int m = TarUtils.getNameBytes(a, paramArrayOfByte, 0, 100);
    m = TarUtils.getOctalBytesUnix(438L, paramArrayOfByte, m, 8);
    m = TarUtils.getOctalBytesUnix(c, paramArrayOfByte, m, 8);
    m = TarUtils.getOctalBytesUnix(d, paramArrayOfByte, m, 8);
    m = TarUtils.getLongOctalBytesUnix(e, paramArrayOfByte, m, 12);
    int n = m = TarUtils.getLongOctalBytesUnix(f, paramArrayOfByte, m, 12);
    for (int i1 = 0; i1 < 8; i1++)
      paramArrayOfByte[(m++)] = 32;
    paramArrayOfByte[(m++)] = g;
    m = TarUtils.getNameBytes(h, paramArrayOfByte, m, 100);
    m = TarUtils.getNameBytes(i, paramArrayOfByte, m, i.length() + 1);
    m = TarUtils.getNameBytes(j, paramArrayOfByte, m, 32);
    m = TarUtils.getNameBytes(k, paramArrayOfByte, m, 32);
    m = TarUtils.getNameBytes(new StringBuffer(""), paramArrayOfByte, m, 8);
    m = TarUtils.getNameBytes(new StringBuffer(""), paramArrayOfByte, m, 8);
    while (m < paramArrayOfByte.length)
      paramArrayOfByte[(m++)] = 0;
    long l1;
    TarUtils.getCheckSumOctalBytesUnix(l1 = TarUtils.computeCheckSum(paramArrayOfByte), paramArrayOfByte, n, 8);
  }

  public void parseTarHeader(byte[] paramArrayOfByte)
  {
    a = TarUtils.parseName(paramArrayOfByte, 0, 100);
    b = ((int)TarUtils.parseOctal(paramArrayOfByte, 100, 8));
    c = ((int)TarUtils.parseOctal(paramArrayOfByte, 108, 8));
    d = ((int)TarUtils.parseOctal(paramArrayOfByte, 116, 8));
    e = TarUtils.parseOctal(paramArrayOfByte, 124, 12);
    f = TarUtils.parseOctal(paramArrayOfByte, 136, 12);
    g = paramArrayOfByte['\u009C'];
    h = TarUtils.parseName(paramArrayOfByte, 157, 100);
    i = TarUtils.parseName(paramArrayOfByte, 257, 8);
    j = TarUtils.parseName(paramArrayOfByte, 265, 32);
    k = TarUtils.parseName(paramArrayOfByte, 297, 32);
    TarUtils.parseOctal(paramArrayOfByte, 329, 8);
    TarUtils.parseOctal(paramArrayOfByte, 337, 8);
  }

  private static String a(String paramString, boolean paramBoolean)
  {
    String str;
    if ((str = System.getProperty("os.name").toLowerCase(Locale.ENGLISH)) != null)
    {
      int m;
      if (str.startsWith("windows"))
      {
        if (paramString.length() > 2)
        {
          m = paramString.charAt(0);
          int n;
          if (((n = paramString.charAt(1)) == ':') && (((m >= 97) && (m <= 122)) || ((m >= 65) && (m <= 90))))
            paramString = paramString.substring(2);
        }
      }
      else if ((m.indexOf("netware") >= 0) && ((m = paramString.indexOf(':')) != -1))
        paramString = paramString.substring(m + 1);
    }
    for (paramString = paramString.replace(File.separatorChar, '/'); (!paramBoolean) && (paramString.startsWith("/")); paramString = paramString.substring(1));
    return paramString;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     org.apache.tools.tar.TarEntry
 * JD-Core Version:    0.6.2
 */