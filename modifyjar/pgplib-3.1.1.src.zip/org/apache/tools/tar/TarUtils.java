package org.apache.tools.tar;

public class TarUtils
{
  public static long parseOctal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    long l = 0L;
    int i = 1;
    paramInt2 = paramInt1 + paramInt2;
    for (paramInt1 = paramInt1; (paramInt1 < paramInt2) && (paramArrayOfByte[paramInt1] != 0); paramInt1++)
      if ((paramArrayOfByte[paramInt1] == 32) || (paramArrayOfByte[paramInt1] == 48))
      {
        if (i == 0)
          if (paramArrayOfByte[paramInt1] == 32)
            break;
      }
      else
      {
        i = 0;
        l = (l << 3) + (paramArrayOfByte[paramInt1] - 48);
      }
    return l;
  }

  public static StringBuffer parseName(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    StringBuffer localStringBuffer = new StringBuffer(paramInt2);
    paramInt2 = paramInt1 + paramInt2;
    for (paramInt1 = paramInt1; (paramInt1 < paramInt2) && (paramArrayOfByte[paramInt1] != 0); paramInt1++)
      localStringBuffer.append((char)paramArrayOfByte[paramInt1]);
    return localStringBuffer;
  }

  public static int getNameBytes(StringBuffer paramStringBuffer, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    for (int i = 0; (i < paramInt2) && (i < paramStringBuffer.length()); i++)
      paramArrayOfByte[(paramInt1 + i)] = ((byte)paramStringBuffer.charAt(i));
    while (i < paramInt2)
    {
      paramArrayOfByte[(paramInt1 + i)] = 0;
      i++;
    }
    return paramInt1 + paramInt2;
  }

  public static int getOctalBytes(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = paramInt2 - 1;
    paramArrayOfByte[(paramInt1 + i)] = 0;
    i--;
    paramArrayOfByte[(paramInt1 + i)] = 32;
    i--;
    if (paramLong == 0L)
    {
      paramArrayOfByte[(paramInt1 + i)] = 48;
      i--;
    }
    else
    {
      long l = paramLong;
      while ((i >= 0) && (l > 0L))
      {
        paramArrayOfByte[(paramInt1 + i)] = ((byte)(48 + (byte)(int)(l & 0x7)));
        l >>= 3;
        i--;
      }
    }
    while (i >= 0)
    {
      paramArrayOfByte[(paramInt1 + i)] = 32;
      i--;
    }
    return paramInt1 + paramInt2;
  }

  public static int getOctalBytesUnix(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = paramInt2 - 1;
    paramArrayOfByte[(paramInt1 + i)] = 0;
    i--;
    if (paramLong == 0L)
    {
      paramArrayOfByte[(paramInt1 + i)] = 48;
      i--;
    }
    else
    {
      long l = paramLong;
      while ((i >= 0) && (l > 0L))
      {
        paramArrayOfByte[(paramInt1 + i)] = ((byte)(48 + (byte)(int)(l & 0x7)));
        l >>= 3;
        i--;
      }
    }
    while (i >= 0)
    {
      paramArrayOfByte[(paramInt1 + i)] = 48;
      i--;
    }
    return paramInt1 + paramInt2;
  }

  public static int getOctalCHKSumUnix(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = paramInt2 - 1;
    paramArrayOfByte[(paramInt1 + i)] = 0;
    i--;
    paramArrayOfByte[(paramInt1 + i)] = 32;
    i--;
    if (paramLong == 0L)
    {
      paramArrayOfByte[(paramInt1 + i)] = 48;
      i--;
    }
    else
    {
      long l = paramLong;
      while ((i >= 0) && (l > 0L))
      {
        paramArrayOfByte[(paramInt1 + i)] = ((byte)(48 + (byte)(int)(l & 0x7)));
        l >>= 3;
        i--;
      }
    }
    while (i >= 0)
    {
      paramArrayOfByte[(paramInt1 + i)] = 48;
      i--;
    }
    return paramInt1 + paramInt2;
  }

  public static int getLongOctalBytes(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[paramInt2 + 1];
    getOctalBytes(paramLong, arrayOfByte, 0, paramInt2 + 1);
    System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt1, paramInt2);
    return paramInt1 + paramInt2;
  }

  public static int getLongOctalBytesUnix(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[paramInt2];
    getOctalBytesUnix(paramLong, arrayOfByte, 0, paramInt2);
    System.arraycopy(arrayOfByte, 0, paramArrayOfByte, paramInt1, paramInt2);
    return paramInt1 + paramInt2;
  }

  public static int getCheckSumOctalBytes(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    getOctalBytes(paramLong, paramArrayOfByte, paramInt1, paramInt2);
    paramArrayOfByte[(paramInt1 + paramInt2 - 1)] = 32;
    paramArrayOfByte[(paramInt1 + paramInt2 - 2)] = 0;
    return paramInt1 + paramInt2;
  }

  public static int getCheckSumOctalBytesUnix(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    getOctalCHKSumUnix(paramLong, paramArrayOfByte, paramInt1, paramInt2);
    paramArrayOfByte[(paramInt1 + paramInt2 - 1)] = 32;
    paramArrayOfByte[(paramInt1 + paramInt2 - 2)] = 0;
    return paramInt1 + paramInt2;
  }

  public static long computeCheckSum(byte[] paramArrayOfByte)
  {
    long l = 0L;
    for (int i = 0; i < paramArrayOfByte.length; i++)
      l += (0xFF & paramArrayOfByte[i]);
    return l;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     org.apache.tools.tar.TarUtils
 * JD-Core Version:    0.6.2
 */