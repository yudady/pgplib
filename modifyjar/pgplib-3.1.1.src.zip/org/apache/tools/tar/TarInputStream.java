package org.apache.tools.tar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class TarInputStream extends FilterInputStream
{
  protected boolean debug;
  protected boolean hasHitEOF;
  protected long entrySize;
  protected long entryOffset;
  protected byte[] readBuf;
  protected TarBuffer buffer;
  protected TarEntry currEntry;
  protected byte[] oneBuf;

  public TarInputStream(InputStream paramInputStream)
  {
    this(paramInputStream, 10240, 512);
  }

  public TarInputStream(InputStream paramInputStream, int paramInt)
  {
    this(paramInputStream, paramInt, 512);
  }

  public TarInputStream(InputStream paramInputStream, int paramInt1, int paramInt2)
  {
    super(paramInputStream);
    buffer = new TarBuffer(paramInputStream, paramInt1, paramInt2);
    readBuf = null;
    oneBuf = new byte[1];
    debug = false;
    hasHitEOF = false;
  }

  public void setDebug(boolean paramBoolean)
  {
    debug = paramBoolean;
    buffer.setDebug(paramBoolean);
  }

  public void close()
    throws IOException
  {
    buffer.close();
  }

  public int getRecordSize()
  {
    return buffer.getRecordSize();
  }

  public int available()
    throws IOException
  {
    if (entrySize - entryOffset > 2147483647L)
      return 2147483647;
    return (int)(entrySize - entryOffset);
  }

  public long skip(long paramLong)
    throws IOException
  {
    byte[] arrayOfByte = new byte[8192];
    int i;
    for (long l = paramLong; l > 0L; l -= i)
    {
      i = (int)(l > arrayOfByte.length ? arrayOfByte.length : l);
      if ((i = read(arrayOfByte, 0, i)) == -1)
        break;
    }
    return paramLong - l;
  }

  public boolean markSupported()
  {
    return false;
  }

  public void mark(int paramInt)
  {
  }

  public void reset()
  {
  }

  public TarEntry getNextEntry()
    throws IOException
  {
    if (hasHitEOF)
      return null;
    if (currEntry != null)
    {
      long l1 = entrySize - entryOffset;
      if (debug)
        System.err.println("TarInputStream: SKIP currENTRY '" + currEntry.getName() + "' SZ " + entrySize + " OFF " + entryOffset + "  skipping " + l1 + " bytes");
      while (l1 > 0L)
      {
        long l2;
        if ((l2 = skip(l1)) <= 0L)
          throw new RuntimeException("failed to skip current tar entry");
        l1 -= l2;
      }
      readBuf = null;
    }
    byte[] arrayOfByte1;
    if ((arrayOfByte1 = buffer.readRecord()) == null)
    {
      if (debug)
        System.err.println("READ NULL RECORD");
      hasHitEOF = true;
    }
    else if (buffer.isEOFRecord(arrayOfByte1))
    {
      if (debug)
        System.err.println("READ EOF RECORD");
      hasHitEOF = true;
    }
    if (hasHitEOF)
    {
      currEntry = null;
    }
    else
    {
      currEntry = new TarEntry(arrayOfByte1);
      if (debug)
        System.err.println("TarInputStream: SET CURRENTRY '" + currEntry.getName() + "' size = " + currEntry.getSize());
      entryOffset = 0L;
      entrySize = currEntry.getSize();
    }
    if ((currEntry != null) && (currEntry.isGNULongNameEntry()))
    {
      StringBuffer localStringBuffer = new StringBuffer();
      byte[] arrayOfByte2 = new byte[256];
      int i;
      while ((i = read(arrayOfByte2)) >= 0)
        localStringBuffer.append(new String(arrayOfByte2, 0, i));
      getNextEntry();
      if (currEntry == null)
        return null;
      if ((localStringBuffer.length() > 0) && (localStringBuffer.charAt(localStringBuffer.length() - 1) == 0))
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      currEntry.setName(localStringBuffer.toString());
    }
    return currEntry;
  }

  public int read()
    throws IOException
  {
    int i;
    if ((i = read(oneBuf, 0, 1)) == -1)
      return -1;
    return oneBuf[0] & 0xFF;
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 0;
    if (entryOffset >= entrySize)
      return -1;
    if (paramInt2 + entryOffset > entrySize)
      paramInt2 = (int)(entrySize - entryOffset);
    int k;
    if (readBuf != null)
    {
      int j = paramInt2 > readBuf.length ? readBuf.length : paramInt2;
      System.arraycopy(readBuf, 0, paramArrayOfByte, paramInt1, j);
      if (j >= readBuf.length)
      {
        readBuf = null;
      }
      else
      {
        byte[] arrayOfByte2 = new byte[k = readBuf.length - j];
        System.arraycopy(readBuf, j, arrayOfByte2, 0, k);
        readBuf = arrayOfByte2;
      }
      i = j + 0;
      paramInt2 -= j;
      paramInt1 += j;
    }
    while (paramInt2 > 0)
    {
      byte[] arrayOfByte1;
      if ((arrayOfByte1 = buffer.readRecord()) == null)
        throw new IOException("unexpected EOF with " + paramInt2 + " bytes unread");
      k = paramInt2;
      int m;
      if ((m = arrayOfByte1.length) > k)
      {
        System.arraycopy(arrayOfByte1, 0, paramArrayOfByte, paramInt1, k);
        readBuf = new byte[m - k];
        System.arraycopy(arrayOfByte1, k, readBuf, 0, m - k);
      }
      else
      {
        k = m;
        System.arraycopy(arrayOfByte1, 0, paramArrayOfByte, paramInt1, m);
      }
      i += k;
      paramInt2 -= k;
      paramInt1 += k;
    }
    entryOffset += i;
    return i;
  }

  public void copyEntryContents(OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[32768];
    int i;
    while ((i = read(arrayOfByte, 0, arrayOfByte.length)) != -1)
      paramOutputStream.write(arrayOfByte, 0, i);
  }

  public String[] extractAll(String paramString)
    throws IOException
  {
    ArrayList localArrayList = new ArrayList();
    for (Object localObject = getNextEntry(); localObject != null; localObject = getNextEntry())
    {
      String str = ((TarEntry)localObject).getName();
      str = paramString + File.separator + str;
      if (((TarEntry)localObject).isDirectory())
      {
        if (!(localObject = new File(str.substring(0, str.length() - 1))).exists())
          ((File)localObject).mkdir();
        localArrayList.add(((File)localObject).getAbsolutePath());
      }
      else
      {
        if (!(localObject = new File(str.substring(0, str.lastIndexOf(File.separatorChar)))).exists())
          ((File)localObject).mkdir();
        localObject = new FileOutputStream(str);
        try
        {
          copyEntryContents((OutputStream)localObject);
          ((FileOutputStream)localObject).close();
        }
        finally
        {
          ((FileOutputStream)localObject).close();
        }
      }
    }
    return (String[])localArrayList.toArray(new String[localArrayList.size()]);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     org.apache.tools.tar.TarInputStream
 * JD-Core Version:    0.6.2
 */