package org.apache.tools.tar;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Arrays;

public class TarBuffer
{
  public static final int DEFAULT_RCDSIZE = 512;
  public static final int DEFAULT_BLKSIZE = 10240;
  private InputStream a;
  private OutputStream b;
  private byte[] c;
  private int d;
  private int e;
  private int f;
  private int g;
  private int h;
  private boolean i;

  public TarBuffer(InputStream paramInputStream)
  {
    this(paramInputStream, 10240);
  }

  public TarBuffer(InputStream paramInputStream, int paramInt)
  {
    this(paramInputStream, paramInt, 512);
  }

  public TarBuffer(InputStream paramInputStream, int paramInt1, int paramInt2)
  {
    a = paramInputStream;
    b = null;
    a(paramInt1, paramInt2);
  }

  public TarBuffer(OutputStream paramOutputStream)
  {
    this(paramOutputStream, 10240);
  }

  public TarBuffer(OutputStream paramOutputStream, int paramInt)
  {
    this(paramOutputStream, paramInt, 512);
  }

  public TarBuffer(OutputStream paramOutputStream, int paramInt1, int paramInt2)
  {
    a = null;
    b = paramOutputStream;
    a(paramInt1, paramInt2);
  }

  private void a(int paramInt1, int paramInt2)
  {
    i = false;
    f = paramInt1;
    g = paramInt2;
    h = (f / g);
    c = new byte[f];
    if (a != null)
    {
      d = -1;
      e = h;
      return;
    }
    d = 0;
    e = 0;
  }

  public int getBlockSize()
  {
    return f;
  }

  public int getRecordSize()
  {
    return g;
  }

  public void setDebug(boolean paramBoolean)
  {
    i = paramBoolean;
  }

  public boolean isEOFRecord(byte[] paramArrayOfByte)
  {
    int j = 0;
    int k = getRecordSize();
    while (j < k)
    {
      if (paramArrayOfByte[j] != 0)
        return false;
      j++;
    }
    return true;
  }

  public void skipRecord()
    throws IOException
  {
    if (i)
      System.err.println("SkipRecord: recIdx = " + e + " blkIdx = " + d);
    if (a == null)
      throw new IOException("reading (via skip) from an output buffer");
    if ((e >= h) && (!a()))
      return;
    e += 1;
  }

  public byte[] readRecord()
    throws IOException
  {
    if (i)
      System.err.println("ReadRecord: recIdx = " + e + " blkIdx = " + d);
    if (a == null)
      throw new IOException("reading from an output buffer");
    if ((e >= h) && (!a()))
      return null;
    byte[] arrayOfByte = new byte[g];
    System.arraycopy(c, e * g, arrayOfByte, 0, g);
    e += 1;
    return arrayOfByte;
  }

  private boolean a()
    throws IOException
  {
    if (i)
      System.err.println("ReadBlock: blkIdx = " + d);
    if (a == null)
      throw new IOException("reading from an output buffer");
    e = 0;
    int j = 0;
    int k = f;
    while (k > 0)
    {
      long l;
      if ((l = a.read(c, j, k)) == -1L)
      {
        if (j == 0)
          return false;
        Arrays.fill(c, j, j + k, (byte)0);
        break;
      }
      j = (int)(j + l);
      k = (int)(k - l);
      if ((l != f) && (i))
        System.err.println("ReadBlock: INCOMPLETE READ " + l + " of " + f + " bytes read.");
    }
    d += 1;
    return true;
  }

  public int getCurrentBlockNum()
  {
    return d;
  }

  public int getCurrentRecordNum()
  {
    return e - 1;
  }

  public void writeRecord(byte[] paramArrayOfByte)
    throws IOException
  {
    if (i)
      System.err.println("WriteRecord: recIdx = " + e + " blkIdx = " + d);
    if (b == null)
      throw new IOException("writing to an input buffer");
    if (paramArrayOfByte.length != g)
      throw new IOException("record to write has length '" + paramArrayOfByte.length + "' which is not the record size of '" + g + "'");
    if (e >= h)
      b();
    System.arraycopy(paramArrayOfByte, 0, c, e * g, g);
    e += 1;
  }

  public void writeRecord(byte[] paramArrayOfByte, int paramInt)
    throws IOException
  {
    if (i)
      System.err.println("WriteRecord: recIdx = " + e + " blkIdx = " + d);
    if (b == null)
      throw new IOException("writing to an input buffer");
    if (paramInt + g > paramArrayOfByte.length)
      throw new IOException("record has length '" + paramArrayOfByte.length + "' with offset '" + paramInt + "' which is less than the record size of '" + g + "'");
    if (e >= h)
      b();
    System.arraycopy(paramArrayOfByte, paramInt, c, e * g, g);
    e += 1;
  }

  private void b()
    throws IOException
  {
    if (i)
      System.err.println("WriteBlock: blkIdx = " + d);
    if (b == null)
      throw new IOException("writing to an input buffer");
    b.write(c, 0, f);
    b.flush();
    e = 0;
    d += 1;
    Arrays.fill(c, (byte)0);
  }

  public void close()
    throws IOException
  {
    if (i)
      System.err.println("TarBuffer.closeBuffer().");
    if (b != null)
    {
      TarBuffer localTarBuffer = this;
      if (i)
        System.err.println("TarBuffer.flushBlock() called.");
      if (localTarBuffer.b == null)
        throw new IOException("writing to an input buffer");
      if (localTarBuffer.e > 0)
        localTarBuffer.b();
      if ((b != System.out) && (b != System.err))
      {
        b.close();
        b = null;
      }
    }
    else if ((a != null) && (a != System.in))
    {
      a.close();
      a = null;
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     org.apache.tools.tar.TarBuffer
 * JD-Core Version:    0.6.2
 */