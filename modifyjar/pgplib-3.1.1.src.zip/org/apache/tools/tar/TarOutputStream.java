package org.apache.tools.tar;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TarOutputStream extends FilterOutputStream
{
  public static final int LONGFILE_ERROR = 0;
  public static final int LONGFILE_TRUNCATE = 1;
  public static final int LONGFILE_GNU = 2;
  protected boolean debug;
  protected long currSize;
  protected String currName;
  protected long currBytes;
  protected byte[] oneBuf;
  protected byte[] recordBuf;
  protected int assemLen;
  protected byte[] assemBuf;
  protected TarBuffer buffer;
  protected int longFileMode = 2;
  private boolean a = false;

  public TarOutputStream(OutputStream paramOutputStream)
  {
    this(paramOutputStream, 10240, 512);
  }

  public TarOutputStream(OutputStream paramOutputStream, int paramInt)
  {
    this(paramOutputStream, paramInt, 512);
  }

  public TarOutputStream(OutputStream paramOutputStream, int paramInt1, int paramInt2)
  {
    super(paramOutputStream);
    buffer = new TarBuffer(paramOutputStream, paramInt1, paramInt2);
    debug = false;
    assemLen = 0;
    assemBuf = new byte[paramInt2];
    recordBuf = new byte[paramInt2];
    oneBuf = new byte[1];
  }

  public void setLongFileMode(int paramInt)
  {
    longFileMode = paramInt;
  }

  public void setDebug(boolean paramBoolean)
  {
    debug = paramBoolean;
  }

  public void setBufferDebug(boolean paramBoolean)
  {
    buffer.setDebug(paramBoolean);
  }

  public void finish()
    throws IOException
  {
    TarOutputStream localTarOutputStream = this;
    for (int i = 0; i < localTarOutputStream.recordBuf.length; i++)
      localTarOutputStream.recordBuf[i] = 0;
    localTarOutputStream.buffer.writeRecord(localTarOutputStream.recordBuf);
  }

  public void close()
    throws IOException
  {
    if (!a)
    {
      finish();
      buffer.close();
      out.close();
      a = true;
    }
  }

  public int getRecordSize()
  {
    return buffer.getRecordSize();
  }

  public void putNextEntry(TarEntry paramTarEntry)
    throws IOException
  {
    if (paramTarEntry.getName().length() >= 100)
      if (longFileMode == 2)
      {
        TarEntry localTarEntry;
        (localTarEntry = new TarEntry("././@LongLink", (byte)76)).setSize(paramTarEntry.getName().length() + 1);
        putNextEntry(localTarEntry);
        write(paramTarEntry.getName().getBytes());
        write(0);
        closeEntry();
      }
      else if (longFileMode != 1)
      {
        throw new RuntimeException("file name '" + paramTarEntry.getName() + "' is too long ( > 100" + " bytes)");
      }
    paramTarEntry.writeEntryHeader(recordBuf);
    buffer.writeRecord(recordBuf);
    currBytes = 0L;
    if (paramTarEntry.isDirectory())
      currSize = 0L;
    else
      currSize = paramTarEntry.getSize();
    currName = paramTarEntry.getName();
  }

  public void closeEntry()
    throws IOException
  {
    if (assemLen > 0)
    {
      for (int i = assemLen; i < assemBuf.length; i++)
        assemBuf[i] = 0;
      buffer.writeRecord(assemBuf);
      currBytes += assemLen;
      assemLen = 0;
    }
    if (currBytes < currSize)
      throw new IOException("entry '" + currName + "' closed at '" + currBytes + "' before the '" + currSize + "' bytes specified in the header were written");
  }

  public void write(int paramInt)
    throws IOException
  {
    oneBuf[0] = ((byte)paramInt);
    write(oneBuf, 0, 1);
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (currBytes + paramInt2 > currSize)
      throw new IOException("request to write '" + paramInt2 + "' bytes exceeds size in header of '" + currSize + "' bytes for entry '" + currName + "'");
    int i;
    if (assemLen > 0)
      if (assemLen + paramInt2 >= recordBuf.length)
      {
        i = recordBuf.length - assemLen;
        System.arraycopy(assemBuf, 0, recordBuf, 0, assemLen);
        System.arraycopy(paramArrayOfByte, paramInt1, recordBuf, assemLen, i);
        buffer.writeRecord(recordBuf);
        currBytes += recordBuf.length;
        paramInt1 += i;
        paramInt2 -= i;
        assemLen = 0;
      }
      else
      {
        System.arraycopy(paramArrayOfByte, paramInt1, assemBuf, assemLen, paramInt2);
        paramInt1 += paramInt2;
        assemLen += paramInt2;
        paramInt2 = 0;
      }
    while (paramInt2 > 0)
    {
      if (paramInt2 < recordBuf.length)
      {
        System.arraycopy(paramArrayOfByte, paramInt1, assemBuf, assemLen, paramInt2);
        assemLen += paramInt2;
        return;
      }
      buffer.writeRecord(paramArrayOfByte, paramInt1);
      i = recordBuf.length;
      currBytes += i;
      paramInt2 -= i;
      paramInt1 += i;
    }
  }

  public void writeFileEntry(TarEntry paramTarEntry)
    throws IOException
  {
    writeFileEntry(paramTarEntry, "");
  }

  public void writeFileEntry(TarEntry paramTarEntry, String paramString)
    throws IOException
  {
    if (paramTarEntry.isDirectory())
    {
      putNextEntry(paramTarEntry);
      localObject = paramTarEntry.getFile().listFiles(new FileFilter()
      {
        public final boolean accept(File paramAnonymousFile)
        {
          return paramAnonymousFile.isDirectory();
        }
      });
      paramString = paramString + File.separatorChar + paramTarEntry.getFile().getName();
      for (int i = 0; i < localObject.length; i++)
      {
        TarEntry localTarEntry;
        if (!(localTarEntry = localObject[i]).getName().equals(".."))
        {
          localTarEntry = new TarEntry(localTarEntry.getAbsolutePath(), paramString);
          writeFileEntry(localTarEntry, paramString);
        }
      }
      File[] arrayOfFile = paramTarEntry.getFile().listFiles(new FileFilter()
      {
        public final boolean accept(File paramAnonymousFile)
        {
          return !paramAnonymousFile.isDirectory();
        }
      });
      for (int k = 0; k < arrayOfFile.length; k++)
        writeFileEntry(new TarEntry(arrayOfFile[k].getAbsolutePath(), paramString), paramString);
      closeEntry();
      return;
    }
    putNextEntry(paramTarEntry);
    Object localObject = null;
    try
    {
      localObject = new FileInputStream(paramTarEntry.getFile());
      paramString = new byte[102400];
      int j;
      while ((j = ((InputStream)localObject).read(paramString, 0, paramString.length)) > 0)
        write(paramString, 0, j);
      try
      {
        ((InputStream)localObject).close();
      }
      catch (IOException localIOException1)
      {
      }
    }
    finally
    {
      if (localObject != null)
        try
        {
          ((InputStream)localObject).close();
        }
        catch (IOException localIOException2)
        {
        }
    }
    closeEntry();
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     org.apache.tools.tar.TarOutputStream
 * JD-Core Version:    0.6.2
 */