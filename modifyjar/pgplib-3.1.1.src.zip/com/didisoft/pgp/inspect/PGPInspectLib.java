package com.didisoft.pgp.inspect;

import com.didisoft.pgp.KeyStore;
import com.didisoft.pgp.bc.BCFactory;
import com.didisoft.pgp.bc.BaseLib;
import com.didisoft.pgp.bc.IOUtil;
import com.didisoft.pgp.bc.PGP2xPBEEncryptedData;
import com.didisoft.pgp.bc.PGPObjectFactory2;
import com.didisoft.pgp.exceptions.FileIsEncryptedException;
import com.didisoft.pgp.exceptions.NonPGPDataException;
import com.didisoft.pgp.exceptions.WrongPasswordException;
import com.didisoft.pgp.exceptions.WrongPrivateKeyException;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.SignatureException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import lw.bouncycastle.openpgp.PGPCompressedData;
import lw.bouncycastle.openpgp.PGPEncryptedDataList;
import lw.bouncycastle.openpgp.PGPLiteralData;
import lw.bouncycastle.openpgp.PGPMarker;
import lw.bouncycastle.openpgp.PGPObjectFactory;
import lw.bouncycastle.openpgp.PGPOnePassSignature;
import lw.bouncycastle.openpgp.PGPOnePassSignatureList;
import lw.bouncycastle.openpgp.PGPPBEEncryptedData;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKey;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureList;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import lw.bouncycastle.openpgp.PGPUtil;
import org.apache.tools.tar.TarEntry;
import org.apache.tools.tar.TarInputStream;

public class PGPInspectLib extends BaseLib
{
  public boolean isPublicKeyEncrypted(String paramString)
    throws IOException, NonPGPDataException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString, "dataFile");
      paramString = isPublicKeyEncrypted(localInputStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString;
  }

  public boolean isPublicKeyEncrypted(InputStream paramInputStream)
    throws IOException, NonPGPDataException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    Object localObject;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException paramInputStream)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream.nextObject();
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream = (paramInputStream = (PGPEncryptedDataList)localObject).getEncryptedDataObjects();
      while (paramInputStream.hasNext())
        if (((localObject = paramInputStream.next()) instanceof PGPPublicKeyEncryptedData))
          return true;
    }
    return false;
  }

  public boolean isPBEEncrypted(String paramString)
    throws IOException, NonPGPDataException
  {
    paramString = new FileInputStream(paramString);
    return isPBEEncrypted(paramString);
  }

  public boolean isPBEEncrypted(InputStream paramInputStream)
    throws IOException, NonPGPDataException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory2(paramInputStream);
    Object localObject;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException paramInputStream)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream.nextObject();
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream = (paramInputStream = (PGPEncryptedDataList)localObject).getEncryptedDataObjects();
      while (paramInputStream.hasNext())
        if (((localObject = paramInputStream.next()) instanceof PGPPBEEncryptedData))
          return true;
    }
    else if ((localObject instanceof PGP2xPBEEncryptedData))
    {
      return true;
    }
    return false;
  }

  public long[] listEncryptionKeyIds(String paramString)
    throws IOException, NonPGPDataException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString, "dataFile");
      paramString = listEncryptionKeyIds(localInputStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString;
  }

  public long[] listEncryptionKeyIds(InputStream paramInputStream)
    throws IOException, NonPGPDataException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    try
    {
      localObject1 = paramInputStream.nextObject();
    }
    catch (IOException paramInputStream)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream);
    }
    if ((localObject1 instanceof PGPMarker))
      localObject1 = paramInputStream.nextObject();
    paramInputStream = new ArrayList();
    Object localObject2;
    Object localObject3;
    if ((localObject1 instanceof PGPEncryptedDataList))
    {
      localObject2 = (localObject1 = (PGPEncryptedDataList)localObject1).getEncryptedDataObjects();
      while (((Iterator)localObject2).hasNext())
        if (((localObject1 = ((Iterator)localObject2).next()) instanceof PGPPublicKeyEncryptedData))
        {
          localObject3 = (PGPPublicKeyEncryptedData)localObject1;
          paramInputStream.add(new Long(((PGPPublicKeyEncryptedData)localObject3).getKeyID()));
        }
    }
    else if ((localObject1 instanceof PGPPublicKeyRing))
    {
      localObject1 = (localObject2 = (PGPPublicKeyRing)localObject1).getPublicKeys();
      while (((Iterator)localObject1).hasNext())
        if ((localObject3 = (PGPPublicKey)((Iterator)localObject1).next()).isEncryptionKey())
          paramInputStream.add(new Long(((PGPPublicKey)localObject3).getKeyID()));
    }
    else if ((localObject1 instanceof PGPSecretKeyRing))
    {
      localObject1 = (PGPSecretKeyRing)localObject1;
      localObject2 = new ByteArrayOutputStream(10240);
      localObject1 = ((PGPSecretKeyRing)localObject1).getSecretKeys();
      while (((Iterator)localObject1).hasNext())
        if ((localObject3 = ((PGPSecretKey)((Iterator)localObject1).next()).getPublicKey()) != null)
          ((ByteArrayOutputStream)localObject2).write(((PGPPublicKey)localObject3).getEncoded());
      localObject1 = (localObject3 = staticBCFactory.CreatePGPPublicKeyRing(((ByteArrayOutputStream)localObject2).toByteArray())).getPublicKeys();
      while (((Iterator)localObject1).hasNext())
        if ((localObject2 = (PGPPublicKey)((Iterator)localObject1).next()).isEncryptionKey())
          paramInputStream.add(new Long(((PGPPublicKey)localObject2).getKeyID()));
    }
    Object localObject1 = new long[paramInputStream.size()];
    for (int i = 0; i < paramInputStream.size(); i++)
      localObject1[i] = ((Long)paramInputStream.get(i)).longValue();
    return localObject1;
  }

  public SignatureItem[] listDetachedSignatureFile(String paramString)
    throws IOException, NonPGPDataException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString);
      paramString = listDetachedSignatureStream(localFileInputStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString;
  }

  public SignatureItem[] listDetachedSignatureStream(InputStream paramInputStream)
    throws IOException, NonPGPDataException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    try
    {
      paramInputStream = paramInputStream.nextObject();
    }
    catch (IOException paramInputStream)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream);
    }
    if ((paramInputStream instanceof PGPSignatureList))
    {
      SignatureItem[] arrayOfSignatureItem = new SignatureItem[(paramInputStream = (PGPSignatureList)paramInputStream).size()];
      for (int i = 0; i < paramInputStream.size(); i++)
      {
        PGPSignature localPGPSignature = paramInputStream.get(i);
        arrayOfSignatureItem[i] = a(localPGPSignature);
      }
      return arrayOfSignatureItem;
    }
    throw new NonPGPDataException("Unknown message format: " + paramInputStream.getClass().getName());
  }

  public long[] listSigningKeyIds(String paramString)
    throws com.didisoft.pgp.PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString));
      paramString = listSigningKeyIds(localBufferedInputStream, null, null);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
    }
    throw paramString;
  }

  public long[] listSigningKeyIds(InputStream paramInputStream)
    throws com.didisoft.pgp.PGPException, IOException
  {
    return listSigningKeyIds(paramInputStream, null, null);
  }

  public long[] listSigningKeyIds(String paramString1, String paramString2, String paramString3)
    throws com.didisoft.pgp.PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString2);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      paramString1 = listSigningKeyIds(localBufferedInputStream, localFileInputStream, paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localBufferedInputStream);
    }
    throw paramString1;
  }

  public boolean isSignedOnly(String paramString)
    throws com.didisoft.pgp.PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString, "dataFile");
      paramString = isSignedOnly(localInputStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString;
  }

  public boolean isSignedOnly(InputStream paramInputStream)
    throws com.didisoft.pgp.PGPException, IOException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream = paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    Object localObject;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException paramInputStream)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream.nextObject();
    if ((localObject instanceof PGPOnePassSignatureList))
      return true;
    if ((localObject instanceof PGPSignatureList))
      return true;
    if ((localObject instanceof PGPCompressedData))
    {
      paramInputStream = (PGPCompressedData)localObject;
      try
      {
        paramInputStream = new BufferedInputStream(paramInputStream.getDataStream());
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        throw IOUtil.newPGPException(paramInputStream = localPGPException);
      }
      if (((paramInputStream = (paramInputStream = new PGPObjectFactory(paramInputStream)).nextObject()) instanceof PGPOnePassSignatureList))
        return true;
      if ((paramInputStream instanceof PGPSignatureList))
        return true;
    }
    return false;
  }

  public long[] listSigningKeyIds(InputStream paramInputStream1, InputStream paramInputStream2, String paramString)
    throws com.didisoft.pgp.PGPException, IOException
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    paramInputStream1 = new PGPObjectFactory(paramInputStream1);
    Object localObject;
    try
    {
      localObject = paramInputStream1.nextObject();
    }
    catch (IOException paramInputStream1)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream1);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream1.nextObject();
    paramInputStream1 = new ArrayList();
    if ((localObject instanceof PGPEncryptedDataList))
    {
      localObject = (PGPEncryptedDataList)localObject;
      try
      {
        if (paramInputStream2 == null)
          throw new FileIsEncryptedException("The data is encrypted.");
        return a((PGPEncryptedDataList)localObject, null, paramInputStream2, paramString);
      }
      catch (SignatureException localSignatureException1)
      {
      }
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      try
      {
        return a((PGPCompressedData)localObject);
      }
      catch (SignatureException localSignatureException2)
      {
      }
    }
    else
    {
      if ((localObject instanceof PGPOnePassSignatureList))
        return a((PGPOnePassSignatureList)localObject);
      if ((localObject instanceof PGPSignatureList))
        return a((PGPSignatureList)localObject);
      if ((localObject instanceof PGPPublicKeyRing))
      {
        paramString = (paramInputStream2 = (PGPPublicKeyRing)localObject).getPublicKeys();
        while (paramString.hasNext())
          if (isForVerification(localObject = (PGPPublicKey)paramString.next()))
            paramInputStream1.add(new Long(((PGPPublicKey)localObject).getKeyID()));
      }
      else if ((localObject instanceof PGPSecretKeyRing))
      {
        localObject = (PGPSecretKeyRing)localObject;
        paramInputStream2 = new ByteArrayOutputStream(10240);
        paramString = ((PGPSecretKeyRing)localObject).getSecretKeys();
        while (paramString.hasNext())
          if ((localObject = ((PGPSecretKey)paramString.next()).getPublicKey()) != null)
            paramInputStream2.write(((PGPPublicKey)localObject).getEncoded());
        paramInputStream2 = (localObject = staticBCFactory.CreatePGPPublicKeyRing(paramInputStream2.toByteArray())).getPublicKeys();
        while (paramInputStream2.hasNext())
          if (isForVerification(paramString = (PGPPublicKey)paramInputStream2.next()))
            paramInputStream1.add(new Long(paramString.getKeyID()));
      }
    }
    if (paramInputStream1.size() > 0)
    {
      localObject = new long[paramInputStream1.size()];
      for (paramInputStream2 = 0; paramInputStream2 < paramInputStream1.size(); paramInputStream2++)
        localObject[paramInputStream2] = ((Long)paramInputStream1.get(paramInputStream2)).longValue();
      return localObject;
    }
    return new long[0];
  }

  public SignatureItem[] listSignatures(String paramString)
    throws com.didisoft.pgp.PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString));
      paramString = listSignatures(localBufferedInputStream, null, null);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
    }
    throw paramString;
  }

  public SignatureItem[] listSignatures(String paramString1, String paramString2, String paramString3)
    throws com.didisoft.pgp.PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString2);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      paramString1 = listSignatures(localBufferedInputStream, localFileInputStream, paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localBufferedInputStream);
    }
    throw paramString1;
  }

  public SignatureItem[] listSignatures(InputStream paramInputStream)
    throws com.didisoft.pgp.PGPException, IOException
  {
    return listSignatures(paramInputStream, null, null);
  }

  public SignatureItem[] listSignatures(InputStream paramInputStream1, InputStream paramInputStream2, String paramString)
    throws com.didisoft.pgp.PGPException, IOException
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    paramInputStream1 = new PGPObjectFactory(paramInputStream1);
    Object localObject;
    try
    {
      localObject = paramInputStream1.nextObject();
    }
    catch (IOException paramInputStream1)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream1);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream1.nextObject();
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream1 = (PGPEncryptedDataList)localObject;
      try
      {
        if (paramInputStream2 == null)
          throw new FileIsEncryptedException("The data is encrypted.");
        return b(paramInputStream1, null, paramInputStream2, paramString);
      }
      catch (SignatureException localSignatureException1)
      {
      }
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      try
      {
        return b((PGPCompressedData)localObject);
      }
      catch (SignatureException localSignatureException2)
      {
      }
    }
    else
    {
      if ((localObject instanceof PGPOnePassSignatureList))
        return a(paramInputStream1);
      if ((localObject instanceof PGPSignatureList))
        return b((PGPSignatureList)localObject);
    }
    return new SignatureItem[0];
  }

  public ContentItem[] listOpenPGPFile(String paramString1, String paramString2, String paramString3)
    throws com.didisoft.pgp.PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString2);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      paramString1 = listOpenPGPStream(localBufferedInputStream, localFileInputStream, paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localBufferedInputStream);
    }
    throw paramString1;
  }

  public ContentItem[] listOpenPGPFile(String paramString)
    throws com.didisoft.pgp.PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString));
      paramString = listOpenPGPStream(localBufferedInputStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(null);
      IOUtil.closeStream(localBufferedInputStream);
    }
    throw paramString;
  }

  public ContentItem[] listOpenPGPStream(InputStream paramInputStream1, InputStream paramInputStream2, String paramString)
    throws com.didisoft.pgp.PGPException, IOException
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    paramInputStream1 = new PGPObjectFactory(paramInputStream1);
    Object localObject = null;
    try
    {
      localObject = paramInputStream1.nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream1.nextObject();
    ContentItem[] arrayOfContentItem = new ContentItem[0];
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream1 = (PGPEncryptedDataList)localObject;
      try
      {
        arrayOfContentItem = a(paramInputStream1, false, null, paramInputStream2, paramString, null);
      }
      catch (SignatureException localSignatureException1)
      {
      }
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      try
      {
        arrayOfContentItem = a((PGPCompressedData)localObject, false, null, null);
      }
      catch (SignatureException localSignatureException2)
      {
      }
    }
    else if ((localObject instanceof PGPOnePassSignatureList))
    {
      try
      {
        arrayOfContentItem = a((PGPOnePassSignatureList)localObject, paramInputStream1, null, null);
      }
      catch (SignatureException localSignatureException3)
      {
      }
    }
    else if ((localObject instanceof PGPSignatureList))
    {
      try
      {
        arrayOfContentItem = a((PGPSignatureList)localObject, paramInputStream1, null, null);
      }
      catch (SignatureException localSignatureException4)
      {
      }
    }
    else if ((localObject instanceof PGPLiteralData))
    {
      arrayOfContentItem = a((PGPLiteralData)localObject);
    }
    else
    {
      throw new com.didisoft.pgp.PGPException("Unknown message format: " + localObject);
    }
    return arrayOfContentItem;
  }

  public ContentItem[] listOpenPGPStream(InputStream paramInputStream)
    throws com.didisoft.pgp.PGPException, IOException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    Object localObject = null;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream.nextObject();
    ContentItem[] arrayOfContentItem = new ContentItem[0];
    if ((localObject instanceof PGPEncryptedDataList))
      throw new FileIsEncryptedException("The supplied data is encrypted. Use the overloaded version that accepts private decryption key instead.");
    if ((localObject instanceof PGPCompressedData))
      try
      {
        arrayOfContentItem = a((PGPCompressedData)localObject, false, null, null);
      }
      catch (SignatureException localSignatureException1)
      {
      }
    else if ((localObject instanceof PGPOnePassSignatureList))
      try
      {
        arrayOfContentItem = a((PGPOnePassSignatureList)localObject, paramInputStream, null, null);
      }
      catch (SignatureException localSignatureException2)
      {
      }
    else if ((localObject instanceof PGPSignatureList))
      try
      {
        arrayOfContentItem = a((PGPSignatureList)localObject, paramInputStream, null, null);
      }
      catch (SignatureException localSignatureException3)
      {
      }
    else if ((localObject instanceof PGPLiteralData))
      arrayOfContentItem = a((PGPLiteralData)localObject);
    else
      throw new com.didisoft.pgp.PGPException("Unknown message format: " + localObject);
    return arrayOfContentItem;
  }

  public SignatureItem[] listRevocationCertificate(String paramString)
    throws IOException, com.didisoft.pgp.PGPException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString);
      paramString = listRevocationCertificate(localFileInputStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString;
  }

  public SignatureItem[] listRevocationCertificate(InputStream paramInputStream)
    throws IOException, com.didisoft.pgp.PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory2(paramInputStream);
    Object localObject;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException paramInputStream)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream.nextObject();
    if ((localObject instanceof PGPSignatureList))
    {
      paramInputStream = (PGPSignatureList)localObject;
      localObject = new ArrayList();
      for (int i = 0; i != paramInputStream.size(); i++)
        if (paramInputStream.get(i).getSignatureType() == 32)
          ((ArrayList)localObject).add(a(paramInputStream.get(i)));
      return (SignatureItem[])((ArrayList)localObject).toArray(new SignatureItem[((ArrayList)localObject).size()]);
    }
    if (((localObject instanceof PGPSignature)) && (((paramInputStream = (PGPSignature)localObject).getSignatureType() == 32) || (paramInputStream.getSignatureType() == 40)))
      return new SignatureItem[] { new SignatureItem(paramInputStream.getKeyID(), paramInputStream.getCreationTime()) };
    return new SignatureItem[0];
  }

  private ContentItem[] a(PGPEncryptedDataList paramPGPEncryptedDataList, boolean paramBoolean, KeyStore paramKeyStore, InputStream paramInputStream1, String paramString, InputStream paramInputStream2)
    throws IOException, WrongPasswordException, WrongPrivateKeyException, com.didisoft.pgp.PGPException, SignatureException
  {
    paramBoolean = null;
    if (paramInputStream1 != null)
      paramKeyStore = createPGPSecretKeyRingCollection(paramInputStream1);
    else
      paramKeyStore = null.getRawSecretKeys();
    paramInputStream1 = null;
    paramPGPEncryptedDataList = paramPGPEncryptedDataList.getEncryptedDataObjects();
    do
    {
      if ((paramBoolean != null) || (!paramPGPEncryptedDataList.hasNext()))
        break label85;
      if (!((paramInputStream2 = paramPGPEncryptedDataList.next()) instanceof PGPPublicKeyEncryptedData))
        break;
      paramInputStream1 = (PGPPublicKeyEncryptedData)paramInputStream2;
    }
    while ((paramBoolean = getPrivateKey(paramKeyStore, paramInputStream1.getKeyID(), paramString)) == null);
    label85: if (paramBoolean == null)
      throw new WrongPrivateKeyException("secret key for message not found.");
    try
    {
      paramPGPEncryptedDataList = paramInputStream1.getDataStream(staticBCFactory.CreatePublicKeyDataDecryptorFactory(paramBoolean));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramInputStream2 = localPGPException);
    }
    if (((paramPGPEncryptedDataList = (paramInputStream2 = new PGPObjectFactory(paramPGPEncryptedDataList)).nextObject()) instanceof PGPCompressedData))
      return a((PGPCompressedData)paramPGPEncryptedDataList, false, null, null);
    if ((paramPGPEncryptedDataList instanceof PGPOnePassSignatureList))
      return a((PGPOnePassSignatureList)paramPGPEncryptedDataList, paramInputStream2, null, null);
    if ((paramPGPEncryptedDataList instanceof PGPLiteralData))
      return a((PGPLiteralData)paramPGPEncryptedDataList);
    throw new com.didisoft.pgp.PGPException("Unknown message format: " + paramPGPEncryptedDataList.getClass().getName());
  }

  private ContentItem[] a(PGPCompressedData paramPGPCompressedData, boolean paramBoolean, KeyStore paramKeyStore, InputStream paramInputStream)
    throws com.didisoft.pgp.PGPException, IOException, SignatureException
  {
    try
    {
      paramPGPCompressedData = new BufferedInputStream(paramPGPCompressedData.getDataStream());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramPGPCompressedData = localPGPException);
    }
    Object localObject;
    if (((localObject = (paramPGPCompressedData = new PGPObjectFactory(paramPGPCompressedData)).nextObject()) instanceof PGPLiteralData))
      return a((PGPLiteralData)localObject);
    if ((localObject instanceof PGPOnePassSignatureList))
    {
      if (paramBoolean)
        return a((PGPOnePassSignatureList)localObject, paramPGPCompressedData, paramKeyStore, paramInputStream);
      return a((PGPOnePassSignatureList)localObject, paramPGPCompressedData, null, null);
    }
    if ((localObject instanceof PGPSignatureList))
    {
      if (paramBoolean)
        return a((PGPSignatureList)localObject, paramPGPCompressedData, paramKeyStore, paramInputStream);
      return a((PGPSignatureList)localObject, paramPGPCompressedData, null, null);
    }
    throw new com.didisoft.pgp.PGPException("Unknown message format: " + localObject.getClass().getName());
  }

  private static ContentItem[] a(PGPLiteralData paramPGPLiteralData)
    throws IOException
  {
    Object localObject;
    if ((localObject = paramPGPLiteralData.getFileName()).toUpperCase().endsWith(".TAR"))
    {
      paramPGPLiteralData = new TarInputStream(paramPGPLiteralData.getInputStream());
      localObject = new ArrayList();
      for (TarEntry localTarEntry = paramPGPLiteralData.getNextEntry(); localTarEntry != null; localTarEntry = paramPGPLiteralData.getNextEntry())
        ((List)localObject).add(new ContentItem(localTarEntry.getName(), localTarEntry.getModTime(), localTarEntry.isDirectory()));
      return (ContentItem[])((List)localObject).toArray(new ContentItem[((List)localObject).size()]);
    }
    return new ContentItem[] { new ContentItem((String)localObject, paramPGPLiteralData.getModificationTime()) };
  }

  private ContentItem[] a(PGPOnePassSignatureList paramPGPOnePassSignatureList, PGPObjectFactory paramPGPObjectFactory, KeyStore paramKeyStore, InputStream paramInputStream)
    throws com.didisoft.pgp.PGPException, IOException, SignatureException
  {
    PGPOnePassSignature localPGPOnePassSignature = null;
    PGPPublicKey localPGPPublicKey = null;
    Object localObject;
    if ((paramInputStream != null) || (paramKeyStore != null))
    {
      for (int i = 0; i != paramPGPOnePassSignatureList.size(); i++)
      {
        localPGPOnePassSignature = paramPGPOnePassSignatureList.get(i);
        if (paramInputStream != null)
          localPGPPublicKey = readPublicVerificationKey(paramInputStream, localPGPOnePassSignature.getKeyID());
        else
          localPGPPublicKey = readPublicVerificationKey(paramKeyStore, localPGPOnePassSignature.getKeyID());
        if (localPGPPublicKey != null)
          break;
      }
      if (localPGPPublicKey == null)
        throw new com.didisoft.pgp.PGPException("No public key could be found for signature.");
      try
      {
        staticBCFactory.initVerify(localPGPOnePassSignature, localPGPPublicKey);
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        throw IOUtil.newPGPException(localObject = localPGPException);
      }
    }
    if (((localObject = paramPGPObjectFactory.nextObject()) instanceof PGPLiteralData))
      paramPGPOnePassSignatureList = a((PGPLiteralData)localObject);
    else
      throw new com.didisoft.pgp.PGPException("Unknown message format: " + localObject.getClass().getName());
    return paramPGPOnePassSignatureList;
  }

  private ContentItem[] a(PGPSignatureList paramPGPSignatureList, PGPObjectFactory paramPGPObjectFactory, KeyStore paramKeyStore, InputStream paramInputStream)
    throws com.didisoft.pgp.PGPException, IOException, SignatureException
  {
    PGPSignature localPGPSignature = null;
    Object localObject1;
    Object localObject2;
    if ((paramInputStream != null) || (paramKeyStore != null))
    {
      localObject1 = null;
      for (int i = 0; i < paramPGPSignatureList.size(); i++)
        if (((localPGPSignature = paramPGPSignatureList.get(i)).getSignatureType() == 0) || (localPGPSignature.getSignatureType() == 1) || (localPGPSignature.getSignatureType() == 16))
        {
          if (paramInputStream != null)
            localObject1 = readPublicVerificationKey(paramInputStream, localPGPSignature.getKeyID());
          else
            localObject1 = readPublicVerificationKey(paramKeyStore, localPGPSignature.getKeyID());
          if (localObject1 != null)
            break;
        }
      if (localObject1 == null)
        throw new com.didisoft.pgp.PGPException("No public key could be found for signature.");
      try
      {
        staticBCFactory.initVerify(localPGPSignature, (PGPPublicKey)localObject1);
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        throw IOUtil.newPGPException(localObject2 = localPGPException);
      }
    }
    if (((localObject1 = paramPGPObjectFactory.nextObject()) instanceof PGPLiteralData))
      localObject2 = a((PGPLiteralData)localObject1);
    else
      throw new com.didisoft.pgp.PGPException("Unknown message format: " + localObject1.getClass().getName());
    return localObject2;
  }

  private long[] a(PGPEncryptedDataList paramPGPEncryptedDataList, KeyStore paramKeyStore, InputStream paramInputStream, String paramString)
    throws IOException, WrongPasswordException, WrongPrivateKeyException, com.didisoft.pgp.PGPException, SignatureException
  {
    paramKeyStore = null;
    if (paramInputStream != null)
      paramInputStream = createPGPSecretKeyRingCollection(paramInputStream);
    else
      paramInputStream = null.getRawSecretKeys();
    PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = null;
    paramPGPEncryptedDataList = paramPGPEncryptedDataList.getEncryptedDataObjects();
    Object localObject;
    do
    {
      if ((paramKeyStore != null) || (!paramPGPEncryptedDataList.hasNext()))
        break label83;
      if (!((localObject = paramPGPEncryptedDataList.next()) instanceof PGPPublicKeyEncryptedData))
        break;
      localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localObject;
    }
    while ((paramKeyStore = getPrivateKey(paramInputStream, localPGPPublicKeyEncryptedData.getKeyID(), paramString)) == null);
    label83: if (paramKeyStore == null)
      throw new WrongPrivateKeyException("secret key for message not found.");
    try
    {
      paramPGPEncryptedDataList = localPGPPublicKeyEncryptedData.getDataStream(staticBCFactory.CreatePublicKeyDataDecryptorFactory(paramKeyStore));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(localObject = localPGPException);
    }
    if (((paramPGPEncryptedDataList = (localObject = new PGPObjectFactory(paramPGPEncryptedDataList)).nextObject()) instanceof PGPCompressedData))
      return a((PGPCompressedData)paramPGPEncryptedDataList);
    if ((paramPGPEncryptedDataList instanceof PGPOnePassSignatureList))
      return a((PGPOnePassSignatureList)paramPGPEncryptedDataList);
    return new long[0];
  }

  private static long[] a(PGPCompressedData paramPGPCompressedData)
    throws com.didisoft.pgp.PGPException, IOException, SignatureException
  {
    try
    {
      paramPGPCompressedData = new BufferedInputStream(paramPGPCompressedData.getDataStream());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramPGPCompressedData = localPGPException);
    }
    long[] arrayOfLong;
    int i;
    if (((paramPGPCompressedData = (paramPGPCompressedData = new PGPObjectFactory(paramPGPCompressedData)).nextObject()) instanceof PGPOnePassSignatureList))
    {
      arrayOfLong = new long[(paramPGPCompressedData = (PGPOnePassSignatureList)paramPGPCompressedData).size()];
      for (i = 0; i != paramPGPCompressedData.size(); i++)
        arrayOfLong[i] = paramPGPCompressedData.get(i).getKeyID();
      return arrayOfLong;
    }
    if ((paramPGPCompressedData instanceof PGPSignatureList))
    {
      arrayOfLong = new long[(paramPGPCompressedData = (PGPSignatureList)paramPGPCompressedData).size()];
      for (i = 0; i != paramPGPCompressedData.size(); i++)
        arrayOfLong[i] = paramPGPCompressedData.get(i).getKeyID();
      return arrayOfLong;
    }
    return new long[0];
  }

  private static long[] a(PGPOnePassSignatureList paramPGPOnePassSignatureList)
  {
    long[] arrayOfLong = new long[paramPGPOnePassSignatureList.size()];
    for (int i = 0; i != paramPGPOnePassSignatureList.size(); i++)
      arrayOfLong[i] = paramPGPOnePassSignatureList.get(i).getKeyID();
    return arrayOfLong;
  }

  private static long[] a(PGPSignatureList paramPGPSignatureList)
  {
    long[] arrayOfLong = new long[paramPGPSignatureList.size()];
    for (int i = 0; i != paramPGPSignatureList.size(); i++)
      arrayOfLong[i] = paramPGPSignatureList.get(i).getKeyID();
    return arrayOfLong;
  }

  private static SignatureItem a(PGPSignature paramPGPSignature)
  {
    SignatureItem localSignatureItem = new SignatureItem(paramPGPSignature.getKeyID(), paramPGPSignature.getCreationTime());
    if ((paramPGPSignature.getHashedSubPackets() != null) && (paramPGPSignature.getHashedSubPackets().getSignerUserID() != null))
      localSignatureItem.setUserId(paramPGPSignature.getHashedSubPackets().getSignerUserID());
    return localSignatureItem;
  }

  private SignatureItem[] b(PGPEncryptedDataList paramPGPEncryptedDataList, KeyStore paramKeyStore, InputStream paramInputStream, String paramString)
    throws IOException, WrongPasswordException, WrongPrivateKeyException, com.didisoft.pgp.PGPException, SignatureException
  {
    paramKeyStore = null;
    if (paramInputStream != null)
      paramInputStream = createPGPSecretKeyRingCollection(paramInputStream);
    else
      paramInputStream = null.getRawSecretKeys();
    PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = null;
    paramPGPEncryptedDataList = paramPGPEncryptedDataList.getEncryptedDataObjects();
    Object localObject;
    do
    {
      if ((paramKeyStore != null) || (!paramPGPEncryptedDataList.hasNext()))
        break label83;
      if (!((localObject = paramPGPEncryptedDataList.next()) instanceof PGPPublicKeyEncryptedData))
        break;
      localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localObject;
    }
    while ((paramKeyStore = getPrivateKey(paramInputStream, localPGPPublicKeyEncryptedData.getKeyID(), paramString)) == null);
    label83: if (paramKeyStore == null)
      throw new WrongPrivateKeyException("secret key for message not found.");
    try
    {
      paramPGPEncryptedDataList = localPGPPublicKeyEncryptedData.getDataStream(staticBCFactory.CreatePublicKeyDataDecryptorFactory(paramKeyStore));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(localObject = localPGPException);
    }
    if (((paramPGPEncryptedDataList = (localObject = new PGPObjectFactory(paramPGPEncryptedDataList)).nextObject()) instanceof PGPCompressedData))
      return b((PGPCompressedData)paramPGPEncryptedDataList);
    if ((paramPGPEncryptedDataList instanceof PGPOnePassSignatureList))
      return a((PGPObjectFactory)localObject);
    if ((paramPGPEncryptedDataList instanceof PGPSignatureList))
      return b((PGPSignatureList)paramPGPEncryptedDataList);
    return new SignatureItem[0];
  }

  private SignatureItem[] b(PGPCompressedData paramPGPCompressedData)
    throws com.didisoft.pgp.PGPException, IOException, SignatureException
  {
    try
    {
      paramPGPCompressedData = new BufferedInputStream(paramPGPCompressedData.getDataStream());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramPGPCompressedData = localPGPException);
    }
    Object localObject;
    if (((localObject = (paramPGPCompressedData = new PGPObjectFactory(paramPGPCompressedData)).nextObject()) instanceof PGPOnePassSignatureList))
      return a(paramPGPCompressedData);
    if ((localObject instanceof PGPSignatureList))
      return b((PGPSignatureList)localObject);
    return new SignatureItem[0];
  }

  private SignatureItem[] a(PGPObjectFactory paramPGPObjectFactory)
    throws IOException
  {
    paramPGPObjectFactory.nextObject();
    if ((paramPGPObjectFactory = paramPGPObjectFactory.nextObject()) != null)
    {
      SignatureItem[] arrayOfSignatureItem = new SignatureItem[(paramPGPObjectFactory = (PGPSignatureList)paramPGPObjectFactory).size()];
      for (int i = 0; i != paramPGPObjectFactory.size(); i++)
        arrayOfSignatureItem[i] = a(paramPGPObjectFactory.get(i));
      return arrayOfSignatureItem;
    }
    return new SignatureItem[0];
  }

  private SignatureItem[] b(PGPSignatureList paramPGPSignatureList)
  {
    SignatureItem[] arrayOfSignatureItem = new SignatureItem[paramPGPSignatureList.size()];
    for (int i = 0; i != paramPGPSignatureList.size(); i++)
      arrayOfSignatureItem[i] = a(paramPGPSignatureList.get(i));
    return arrayOfSignatureItem;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.inspect.PGPInspectLib
 * JD-Core Version:    0.6.2
 */