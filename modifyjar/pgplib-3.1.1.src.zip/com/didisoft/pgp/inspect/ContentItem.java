package com.didisoft.pgp.inspect;

import java.io.Serializable;
import java.util.Date;

public class ContentItem
  implements Serializable
{
  private static final long serialVersionUID = 590263891205390633L;
  private String a;
  private Date b;
  private boolean c;

  ContentItem(String paramString, Date paramDate)
  {
    this(paramString, paramDate, false);
  }

  ContentItem(String paramString, Date paramDate, boolean paramBoolean)
  {
    a = paramString;
    b = paramDate;
    c = paramBoolean;
  }

  public String getFileName()
  {
    return a;
  }

  public Date getModificationDate()
  {
    return b;
  }

  public boolean isDirectory()
  {
    return c;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.inspect.ContentItem
 * JD-Core Version:    0.6.2
 */