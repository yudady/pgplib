package com.didisoft.pgp.inspect;

import com.didisoft.pgp.KeyPairInformation;
import java.util.Date;

public class SignatureItem
{
  private long a;
  private Date b;
  private String c = "";

  public SignatureItem(long paramLong, Date paramDate)
  {
    a = paramLong;
    b = paramDate;
  }

  public long getKeyId()
  {
    return a;
  }

  public String getKeyIdHex()
  {
    return KeyPairInformation.keyId2Hex(getKeyId());
  }

  public Date getSignatureTime()
  {
    return b;
  }

  public String getUserId()
  {
    return c;
  }

  public void setUserId(String paramString)
  {
    c = paramString;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.inspect.SignatureItem
 * JD-Core Version:    0.6.2
 */