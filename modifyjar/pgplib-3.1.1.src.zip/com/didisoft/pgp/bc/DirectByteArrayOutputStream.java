package com.didisoft.pgp.bc;

import java.io.ByteArrayOutputStream;

public class DirectByteArrayOutputStream extends ByteArrayOutputStream
{
  public DirectByteArrayOutputStream(int paramInt)
  {
    super(paramInt);
  }

  public byte[] getArray()
  {
    return buf;
  }

  protected void finalize()
    throws Throwable
  {
    super.finalize();
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.DirectByteArrayOutputStream
 * JD-Core Version:    0.6.2
 */