package com.didisoft.pgp.bc;

import java.io.IOException;

public class UnknownKeyPacketsException extends IOException
{
  private static final long serialVersionUID = -277403260230069362L;

  public UnknownKeyPacketsException(String paramString)
  {
    super(paramString);
  }

  public UnknownKeyPacketsException(String paramString, Exception paramException)
  {
    super(paramString);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.UnknownKeyPacketsException
 * JD-Core Version:    0.6.2
 */