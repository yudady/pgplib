package com.didisoft.pgp.bc.elgamal;

import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalParams;
import java.math.BigInteger;
import java.security.InvalidParameterException;

public class GenericElGamalParameterSet
{
  private int[] a;
  private String[][] b;

  protected GenericElGamalParameterSet(int[] paramArrayOfInt, String[][] paramArrayOfString)
  {
    if (paramArrayOfString.length != paramArrayOfInt.length)
      throw new IllegalArgumentException("array lengths do not match");
    a = paramArrayOfInt;
    b = paramArrayOfString;
  }

  public ElGamalParams getParameters(int paramInt)
  {
    for (int i = 0; i < a.length; i++)
      if (paramInt == a[i])
        return new BaseElGamalParams(new BigInteger(b[i][0], 16), b[i][1] != null ? new BigInteger(b[i][1], 16) : null);
    return null;
  }

  public void checkSane()
    throws InvalidParameterException
  {
    for (int i = 0; i < a.length; i++)
    {
      BigInteger localBigInteger1;
      if ((localBigInteger1 = new BigInteger(b[i][0])).bitLength() < a[i])
        throw new InvalidParameterException(localBigInteger1 + " has incorrect bit length");
      BigInteger localBigInteger2 = new BigInteger(b[i][1]);
      if (!localBigInteger1.isProbablePrime(80))
        throw new InvalidParameterException(localBigInteger1 + " is not prime");
      if (localBigInteger2.compareTo(localBigInteger1) >= 0)
        throw new InvalidParameterException("g >= p");
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.GenericElGamalParameterSet
 * JD-Core Version:    0.6.2
 */