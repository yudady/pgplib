package com.didisoft.pgp.bc.elgamal.security;

import java.security.InvalidParameterException;

public abstract interface Parameterized
{
  public abstract void setParameter(String paramString, Object paramObject)
    throws NoSuchParameterException, InvalidParameterException, InvalidParameterTypeException;

  public abstract Object getParameter(String paramString)
    throws NoSuchParameterException, InvalidParameterException;
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.Parameterized
 * JD-Core Version:    0.6.2
 */