package com.didisoft.pgp.bc.elgamal.security;

import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;

abstract class d
{
  boolean a;
  private PrintWriter b;
  private static int c;
  private static boolean d;
  private static Hashtable e = new Hashtable();

  d(String paramString)
  {
    PrintWriter localPrintWriter;
    if ((localPrintWriter = (PrintWriter)e.get(getClass().getName())) == null)
      localPrintWriter = (PrintWriter)e.get(paramString);
    if (localPrintWriter != null)
    {
      localPrintWriter = localPrintWriter;
      paramString = this;
      if (localPrintWriter == null)
        throw new NullPointerException("out == null");
      paramString.b = localPrintWriter;
      paramString.a = true;
    }
  }

  final void a(String paramString)
  {
    try
    {
      a();
      b.println("<" + this + ">." + paramString);
      d = false;
      return;
    }
    catch (NullPointerException localNullPointerException)
    {
    }
  }

  final void b(String paramString)
  {
    try
    {
      a();
      b.print("<" + this + ">." + paramString + " ");
      b.flush();
      d = true;
      c += 1;
      return;
    }
    catch (NullPointerException localNullPointerException)
    {
    }
  }

  final void c(String paramString)
  {
    try
    {
      if (!d)
      {
        for (int i = 1; i < c; i++)
          b.print("    ");
        b.print("... ");
      }
      b.println("= " + paramString);
      d = false;
      c -= 1;
      return;
    }
    catch (NullPointerException localNullPointerException)
    {
    }
  }

  final void a(int paramInt)
  {
    c(Integer.toString(paramInt));
  }

  private void a()
  {
    if (d)
      b.println("...");
    for (int i = 0; i < c; i++)
      b.print("    ");
  }

  static
  {
    String str3;
    int i = (str3 = "Trace.").length();
    PrintWriter localPrintWriter = b.a();
    Enumeration localEnumeration = c.a();
    while (localEnumeration.hasMoreElements())
    {
      String str1;
      String str2;
      if (((str1 = (String)localEnumeration.nextElement()).startsWith(str3)) && ((str2 = c.a(str1)) != null) && (str2.equalsIgnoreCase("true")))
        e.put(str1.substring(i), localPrintWriter);
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.d
 * JD-Core Version:    0.6.2
 */