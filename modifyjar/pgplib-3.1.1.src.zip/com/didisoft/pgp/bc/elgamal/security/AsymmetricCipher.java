package com.didisoft.pgp.bc.elgamal.security;

public abstract interface AsymmetricCipher
{
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.AsymmetricCipher
 * JD-Core Version:    0.6.2
 */