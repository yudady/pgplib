package com.didisoft.pgp.bc.elgamal.security;

/** @deprecated */
public abstract interface Padding
{
  public abstract int pad(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract int unpad(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract int padLength(int paramInt);

  public abstract String paddingScheme();
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.Padding
 * JD-Core Version:    0.6.2
 */