package com.didisoft.pgp.bc.elgamal.security;

import java.io.PrintWriter;
import java.security.InvalidParameterException;
import java.security.Key;
import java.security.KeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;

public abstract class Cipher extends d
  implements Parameterized
{
  private static int b = b.c("Cipher");
  private static PrintWriter c = b.a();
  public static final int UNINITIALIZED = 0;
  public static final int ENCRYPT = 1;
  public static final int DECRYPT = 2;
  private boolean d;
  private byte[] e;
  private int f;
  private int g;
  private int h;
  private String i;
  private String j;
  private String k;
  private String l;
  private PaddingScheme m;
  private int n;

  private static void d(String paramString)
  {
    c.println("Cipher: " + paramString);
  }

  private static String a(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null)
      return "null";
    return paramArrayOfByte.toString();
  }

  /** @deprecated */
  protected Cipher()
  {
    super("Cipher");
  }

  protected Cipher(boolean paramBoolean1, boolean paramBoolean2, String paramString)
  {
    super("Cipher");
    if (paramBoolean2)
      throw new IllegalArgumentException("IJCE does not support ciphers for which implPadding == true");
    d = paramBoolean1;
    i = paramString;
  }

  protected Cipher(boolean paramBoolean, String paramString1, String paramString2)
  {
    super("Cipher");
    d = paramBoolean;
    i = paramString1;
    paramString1 = paramString2;
    paramBoolean = this;
    if ((paramString2 = paramString1.indexOf('/')) == -1)
    {
      paramBoolean.j = paramString1;
      return;
    }
    paramBoolean.j = paramString1.substring(0, paramString2);
    int i1;
    if ((i1 = paramString1.indexOf('/', paramString2 + 1)) == -1)
    {
      paramBoolean.k = paramString1.substring(paramString2 + 1);
      return;
    }
    paramBoolean.k = paramString1.substring(paramString2 + 1, i1);
    paramBoolean.l = paramString1.substring(i1 + 1);
  }

  private void a(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (j == null)
      j = paramString1;
    if (k == null)
      k = paramString2;
    if (l == null)
      l = paramString3;
    if (i == null)
      i = paramString4;
  }

  protected final PaddingScheme getPaddingScheme()
  {
    return m;
  }

  public static Cipher getInstance(String paramString)
    throws NoSuchAlgorithmException
  {
    try
    {
      return getInstance(paramString, null);
    }
    catch (NoSuchProviderException paramString)
    {
    }
    throw new NoSuchAlgorithmException(paramString.getMessage());
  }

  public static Cipher getInstance(String paramString1, String paramString2)
    throws NoSuchAlgorithmException, NoSuchProviderException
  {
    if (paramString1 == null)
      throw new NullPointerException("algorithm == null");
    String str1 = paramString1;
    String str2 = "ECB";
    String str3 = "NONE";
    int i1;
    if ((i1 = paramString1.indexOf('/')) != -1)
    {
      str1 = paramString1.substring(0, i1);
      int i2;
      if ((i2 = paramString1.indexOf('/', i1 + 1)) == -1)
      {
        str2 = paramString1.substring(i1 + 1);
      }
      else
      {
        str2 = paramString1.substring(i1 + 1, i2);
        str3 = paramString1.substring(i2 + 1);
      }
    }
    return b(str1, str2, str3, paramString2);
  }

  private static Cipher b(String paramString1, String paramString2, String paramString3, String paramString4)
    throws NoSuchAlgorithmException, NoSuchProviderException
  {
    if (b >= 3)
      d("Entered getInstance(\"" + paramString1 + "\", \"" + paramString2 + "\", \"" + paramString3 + "\", \"" + paramString4 + "\")");
    paramString1 = b.a(paramString1, "Cipher");
    paramString2 = b.a(paramString2, "Mode");
    paramString3 = b.a(paramString3, "PaddingScheme");
    Cipher localCipher2 = null;
    PaddingScheme localPaddingScheme = null;
    Cipher localCipher1;
    try
    {
      localCipher1 = (Cipher)b.a(paramString1 + "/" + paramString2 + "/" + paramString3, paramString4, "Cipher");
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException1)
    {
      if (paramString2.equals("ECB"))
        localCipher1 = (Cipher)b.a(paramString1, paramString4, "Cipher");
      else
        try
        {
          localCipher1 = (Cipher)b.a(paramString1 + "/" + paramString2, paramString4, "Cipher");
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException2)
        {
          (localCipher2 = (Cipher)b.a(paramString1, paramString4, "Cipher")).a(paramString1, "ECB", "NONE", paramString4);
          localCipher1 = (Cipher)b.a(paramString2, paramString4, "Mode");
        }
      if (!paramString3.equals("NONE"))
        localPaddingScheme = (PaddingScheme)b.a(paramString3, paramString4, "PaddingScheme");
    }
    localCipher1.a(paramString1, paramString2, paramString3, paramString4);
    if (localCipher2 != null)
      ((Mode)localCipher1).a(localCipher2);
    if (localPaddingScheme != null)
      localCipher1.engineSetPaddingScheme(localPaddingScheme);
    if (b >= 3)
      d("Created cipher [1]: " + localCipher1);
    return localCipher1;
  }

  public static Cipher getInstance(Cipher paramCipher, Mode paramMode, PaddingScheme paramPaddingScheme)
  {
    if (paramCipher == null)
      throw new NullPointerException("cipher == null");
    String str1 = paramCipher.getAlgorithm();
    String str2 = paramMode == null ? "ECB" : paramMode.getAlgorithm();
    String str3 = paramPaddingScheme == null ? "NONE" : paramPaddingScheme.a();
    String str4 = paramCipher.getProvider();
    Cipher localCipher = null;
    if (paramMode == null)
    {
      paramCipher = paramCipher;
    }
    else
    {
      localCipher = paramCipher;
      paramCipher = paramMode;
    }
    paramCipher.a(str1, str2, str3, str4);
    if (localCipher != null)
      ((Mode)paramCipher).a(localCipher);
    if (paramPaddingScheme != null)
      paramCipher.engineSetPaddingScheme(paramPaddingScheme);
    if (b >= 3)
      d("Created cipher [2]: " + paramCipher);
    return paramCipher;
  }

  public final int getState()
  {
    return n;
  }

  public final String getAlgorithm()
  {
    return j;
  }

  public final String getMode()
  {
    if (k == null)
      return "ECB";
    return k;
  }

  public final String getPadding()
  {
    if (l == null)
      return "NONE";
    return l;
  }

  public final String getProvider()
  {
    return i;
  }

  public final boolean isPaddingBlockCipher()
  {
    return (getPlaintextBlockSize() > 1) && (getPaddingScheme() != null);
  }

  public final int outBufferSize(int paramInt)
  {
    return a(paramInt, false);
  }

  public final int outBufferSizeFinal(int paramInt)
  {
    return a(paramInt, true);
  }

  public final int inBufferSize(int paramInt)
  {
    return b(paramInt, false);
  }

  public final int inBufferSizeFinal(int paramInt)
  {
    return b(paramInt, true);
  }

  public final int blockSize()
  {
    int i1;
    if ((i1 = enginePlaintextBlockSize()) != engineCiphertextBlockSize())
      throw new IllegalBlockSizeException("blockSize() called when plaintext and ciphertext block sizes differ");
    return i1;
  }

  public final int getInputBlockSize()
  {
    switch (getState())
    {
    case 1:
      return enginePlaintextBlockSize();
    case 2:
      return engineCiphertextBlockSize();
    default:
      b.b("invalid Cipher state: " + getState());
    case 0:
    }
    throw new Error("cipher uninitialized");
  }

  public final int getOutputBlockSize()
  {
    switch (getState())
    {
    case 1:
      return engineCiphertextBlockSize();
    case 2:
      return enginePlaintextBlockSize();
    default:
      b.b("invalid Cipher state: " + getState());
    case 0:
    }
    throw new Error("cipher uninitialized");
  }

  public final int getPlaintextBlockSize()
  {
    return enginePlaintextBlockSize();
  }

  public final int getCiphertextBlockSize()
  {
    return engineCiphertextBlockSize();
  }

  public final void initEncrypt(Key paramKey)
    throws KeyException
  {
    if (paramKey == null)
      throw new NullPointerException("key == null");
    if (a)
      a("engineInitEncrypt(<" + paramKey + ">)");
    engineInitEncrypt(paramKey);
    n = 1;
    g = enginePlaintextBlockSize();
    h = engineCiphertextBlockSize();
    if ((g <= 0) || (h <= 0))
    {
      n = 0;
      throw new Error("input or output block size < 1");
    }
    e = ((!d) && (g > 1) ? new byte[g] : null);
    f = 0;
    if (m != null)
      m.b(g);
  }

  public final void initDecrypt(Key paramKey)
    throws KeyException
  {
    if (paramKey == null)
      throw new NullPointerException("key == null");
    if (a)
      a("engineInitDecrypt(<" + paramKey + ">)");
    engineInitDecrypt(paramKey);
    n = 2;
    g = engineCiphertextBlockSize();
    h = enginePlaintextBlockSize();
    if ((g <= 0) || (h <= 0))
    {
      n = 0;
      throw new Error("input or output block size < 1");
    }
    e = ((!d) && (g > 1) ? new byte[g] : null);
    f = 0;
    if (m != null)
      m.b(h);
  }

  public final byte[] update(byte[] paramArrayOfByte)
  {
    return update(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public final byte[] update(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[a(paramInt2, false)];
    if ((paramArrayOfByte = a(paramArrayOfByte, paramInt1, paramInt2, arrayOfByte, 0, false)) != arrayOfByte.length)
    {
      paramInt1 = new byte[paramArrayOfByte];
      System.arraycopy(arrayOfByte, 0, paramInt1, 0, paramArrayOfByte);
      return paramInt1;
    }
    return arrayOfByte;
  }

  public final int update(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
  {
    return a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, 0, false);
  }

  public final int update(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    return a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3, false);
  }

  public final byte[] crypt(byte[] paramArrayOfByte)
    throws IllegalBlockSizeException
  {
    return crypt(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public final byte[] crypt(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IllegalBlockSizeException
  {
    byte[] arrayOfByte = new byte[a(paramInt2, true)];
    if ((paramArrayOfByte = a(paramArrayOfByte, paramInt1, paramInt2, arrayOfByte, 0, true)) != arrayOfByte.length)
    {
      paramInt1 = new byte[paramArrayOfByte];
      System.arraycopy(arrayOfByte, 0, paramInt1, 0, paramArrayOfByte);
      return paramInt1;
    }
    return arrayOfByte;
  }

  public final int crypt(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException
  {
    return a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3, true);
  }

  public final byte[] doFinal(byte[] paramArrayOfByte)
    throws IllegalBlockSizeException
  {
    return crypt(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public final byte[] doFinal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IllegalBlockSizeException
  {
    return crypt(paramArrayOfByte, paramInt1, paramInt2);
  }

  public final int doFinal(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
    throws IllegalBlockSizeException
  {
    return crypt(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, 0);
  }

  public final int doFinal(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException
  {
    return crypt(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }

  private int a(int paramInt, boolean paramBoolean)
  {
    if (paramInt < 0)
      throw new IllegalArgumentException("inLen < 0");
    if (!d)
    {
      i1 = (paramInt += f) % g;
      paramInt -= i1;
      if ((paramBoolean) && (n == 1) && ((m != null) || (i1 > 0)))
        paramInt += g;
    }
    if (paramInt < 0)
      b.b("inLen < 0");
    if (a)
      b("engineOutBufferSize(" + paramInt + ", " + paramBoolean + ")");
    int i1 = engineOutBufferSize(paramInt, paramBoolean);
    if (a)
      a(i1);
    return i1;
  }

  private int b(int paramInt, boolean paramBoolean)
  {
    if ((!d) && ((i1 = paramInt % h) > 0))
      paramInt += h - i1;
    if (a)
      b("engineInBufferSize(" + paramInt + ", " + paramBoolean + ")");
    int i1 = engineInBufferSize(paramInt, paramBoolean);
    if (a)
      a(i1);
    if (!d)
    {
      if ((paramBoolean) && (n == 1) && (m != null))
        i1 -= g;
      i1 -= f;
    }
    if (i1 < 0)
      i1 = 0;
    return i1;
  }

  private int a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3, boolean paramBoolean)
  {
    if ((b >= 5) && (a))
      b("updateInternal(<" + a(paramArrayOfByte1) + ">, " + paramInt1 + ", " + paramInt2 + ", <" + a(paramArrayOfByte2) + ">, " + paramInt3 + ", " + paramBoolean + ")");
    int i1 = 0;
    int i2 = paramInt3;
    try
    {
      if (n == 0)
        throw new IllegalStateException("cipher uninitialized");
      if (paramInt2 < 0)
        throw new IllegalArgumentException("inLen < 0");
      if ((paramInt1 < 0) || (paramInt3 < 0) || (paramInt1 + paramInt2 > paramArrayOfByte1.length))
      {
        if (b > 0)
          d("inOffset = " + paramInt1 + ", inLen = " + paramInt2 + ", outOffset = " + paramInt3 + ", in.length = " + paramArrayOfByte1.length);
        throw new ArrayIndexOutOfBoundsException("inOffset < 0  || outOffset < 0 || (long)inOffset+inLen > in.length");
      }
      if (paramArrayOfByte2 == null)
        throw new NullPointerException();
      if (e == null)
      {
        if (a)
        {
          b("engineUpdate(<" + a(paramArrayOfByte1) + ">, " + paramInt1 + ", " + paramInt2 + ", <" + a(paramArrayOfByte2) + ">, " + paramInt3 + ")");
          i3 = engineUpdate(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
          a(i3);
          paramInt3 += i3;
          if ((paramBoolean) && (d))
          {
            b("engineCrypt(<" + a(paramArrayOfByte2) + ">, " + paramInt3 + ")");
            i3 = engineCrypt(paramArrayOfByte2, paramInt3);
            a(i3);
            paramInt3 += i3;
          }
        }
        else
        {
          paramInt3 += engineUpdate(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
          if ((paramBoolean) && (d))
            paramInt3 += engineCrypt(paramArrayOfByte2, paramInt3);
        }
        int i3 = paramInt3 - i2;
        if ((b >= 5) && (a))
          a(paramInt3 - i2);
        return i3;
      }
      if ((paramArrayOfByte1 == paramArrayOfByte2) && (((paramInt3 >= paramInt1) && (paramInt3 < paramInt1 + paramInt2)) || ((paramInt1 >= paramInt3) && (paramInt1 < paramInt3 + a(paramInt2, paramBoolean)))))
      {
        byte[] arrayOfByte1 = new byte[paramInt2];
        System.arraycopy(paramArrayOfByte1, paramInt1, arrayOfByte1, 0, paramInt2);
        paramArrayOfByte1 = arrayOfByte1;
        paramInt1 = 0;
      }
      if (paramBoolean)
      {
        if (n == 1)
        {
          paramInt3 += a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3, false);
          if (m == null)
          {
            if (f > 0)
            {
              f = 0;
              throw new IllegalBlockSizeException(getAlgorithm() + ": Non-padding cipher in ENCRYPT state with an incomplete final block");
            }
            i4 = paramInt3 - i2;
            if ((b >= 5) && (a))
              a(paramInt3 - i2);
            return i4;
          }
          m.pad(e, 0, f);
          f = 0;
          if (a)
            b("engineUpdate(<" + a(e) + ">, 0, " + g + ", <" + a(paramArrayOfByte2) + ">, " + paramInt3 + ")");
          int i4 = engineUpdate(e, 0, g, paramArrayOfByte2, paramInt3);
          if (a)
            a(i4);
          paramBoolean = paramInt3 += i4 - i2;
          if ((b >= 5) && (a))
            a(paramInt3 - i2);
          return paramBoolean;
        }
        if (m != null)
        {
          if (paramInt2 == 0)
          {
            if ((b >= 5) && (a))
              a(0);
            return 0;
          }
          paramInt3 += a(paramArrayOfByte1, paramInt1, paramInt2 - 1, paramArrayOfByte2, paramInt3, false);
          if (f != g - 1)
          {
            f = 0;
            throw new IllegalBlockSizeException(getAlgorithm() + ": Cipher in DECRYPT state with an incomplete final block");
          }
          e[f] = paramArrayOfByte1[(paramInt1 + paramInt2 - 1)];
          f = 0;
          byte[] arrayOfByte2 = new byte[a(g, false)];
          if (a)
            b("engineUpdate(<" + a(e) + ">, 0, " + g + ", <" + a(arrayOfByte2) + ">, 0)");
          paramBoolean = engineUpdate(e, 0, g, arrayOfByte2, 0);
          if (a)
            a(paramBoolean);
          paramArrayOfByte1 = m.unpad(arrayOfByte2, 0, arrayOfByte2.length);
          System.arraycopy(arrayOfByte2, 0, paramArrayOfByte2, paramInt3, paramArrayOfByte1);
          paramArrayOfByte1 = paramInt3 += paramArrayOfByte1 - i2;
          if ((b >= 5) && (a))
            a(paramInt3 - i2);
          return paramArrayOfByte1;
        }
      }
      if (f > 0)
      {
        if (paramInt2 + f < g)
        {
          System.arraycopy(paramArrayOfByte1, paramInt1, e, f, paramInt2);
          f += paramInt2;
          if ((b >= 5) && (a))
            a(0);
          return 0;
        }
        i5 = g - f;
        System.arraycopy(paramArrayOfByte1, paramInt1, e, f, i5);
        paramInt1 += i5;
        paramInt2 -= i5;
        if (a)
          b("engineUpdate(<" + a(e) + ">, 0, " + g + ", <" + a(paramArrayOfByte2) + ">, " + paramInt3 + ")");
        paramBoolean = engineUpdate(e, 0, g, paramArrayOfByte2, paramInt3);
        if (a)
          a(paramBoolean);
        paramInt3 += paramBoolean;
      }
      f = (paramInt2 % g);
      if (f > 0)
      {
        System.arraycopy(paramArrayOfByte1, paramInt1 + paramInt2 - f, e, 0, f);
        paramInt2 -= f;
      }
      while (paramInt2 > 0)
      {
        if (a)
          b("engineUpdate(<" + a(paramArrayOfByte1) + ">, " + paramInt1 + ", " + g + ", <" + a(paramArrayOfByte2) + ">, " + paramInt3 + ")");
        i5 = engineUpdate(paramArrayOfByte1, paramInt1, g, paramArrayOfByte2, paramInt3);
        if (a)
          a(i5);
        paramInt3 += i5;
        paramInt1 += g;
        paramInt2 -= g;
      }
      int i5 = paramInt3 - i2;
      if ((b >= 5) && (a))
        a(paramInt3 - i2);
      return i5;
    }
    catch (RuntimeException localRuntimeException)
    {
      if (a)
        localRuntimeException.printStackTrace();
      i1 = 1;
      throw localRuntimeException;
    }
    finally
    {
      if ((b >= 5) && (a) && (i1 == 0))
        a(paramInt3 - i2);
    }
    throw paramArrayOfByte1;
  }

  public void setParameter(String paramString, Object paramObject)
    throws NoSuchParameterException, InvalidParameterException, InvalidParameterTypeException
  {
    if (paramString == null)
      throw new NullPointerException("param == null");
    if (a)
      a("engineSetParameter(\"" + paramString + "\", <" + paramObject + ">)");
    engineSetParameter(paramString, paramObject);
  }

  public Object getParameter(String paramString)
    throws NoSuchParameterException, InvalidParameterException
  {
    if (paramString == null)
      throw new NullPointerException("param == null");
    if (a)
      b("engineGetParameter(\"" + paramString + "\")");
    paramString = engineGetParameter(paramString);
    if (a)
      c("<" + paramString + ">");
    return paramString;
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    if ((this instanceof Cloneable))
      return super.clone();
    throw new CloneNotSupportedException();
  }

  public String toString()
  {
    return "Cipher [" + getProvider() + " " + getAlgorithm() + "/" + getMode() + "/" + getPadding() + "]";
  }

  protected void engineSetPaddingScheme(PaddingScheme paramPaddingScheme)
  {
    if (n != 0)
      throw new IllegalStateException("Cipher is already initialized");
    m = paramPaddingScheme;
  }

  protected int engineBlockSize()
  {
    throw new Error("cipher classes must implement either engineBlockSize, or enginePlaintextBlockSize and engineCiphertextBlockSize");
  }

  protected int enginePlaintextBlockSize()
  {
    return engineBlockSize();
  }

  protected int engineCiphertextBlockSize()
  {
    return engineBlockSize();
  }

  protected int engineOutBufferSize(int paramInt, boolean paramBoolean)
  {
    return paramInt / g * h;
  }

  protected int engineInBufferSize(int paramInt, boolean paramBoolean)
  {
    return paramInt / h * g;
  }

  protected abstract void engineInitEncrypt(Key paramKey)
    throws KeyException;

  protected abstract void engineInitDecrypt(Key paramKey)
    throws KeyException;

  protected abstract int engineUpdate(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3);

  protected int engineCrypt(byte[] paramArrayOfByte, int paramInt)
  {
    return 0;
  }

  protected void engineSetParameter(String paramString, Object paramObject)
    throws NoSuchParameterException, InvalidParameterException, InvalidParameterTypeException
  {
    throw new NoSuchParameterException(getAlgorithm() + ": " + paramString);
  }

  protected Object engineGetParameter(String paramString)
    throws NoSuchParameterException, InvalidParameterException
  {
    throw new NoSuchParameterException(getAlgorithm() + ": " + paramString);
  }

  public static String[] getAlgorithms(Provider paramProvider)
  {
    return b.a(paramProvider, "Cipher");
  }

  public static String[] getAlgorithms()
  {
    return b.a("Cipher");
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.Cipher
 * JD-Core Version:    0.6.2
 */