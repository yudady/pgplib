package com.didisoft.pgp.bc.elgamal.security;

import java.util.Enumeration;
import java.util.Properties;

final class c
{
  private static final Properties a = new Properties();

  static String a(String paramString)
  {
    return a.getProperty(paramString);
  }

  static Enumeration a()
  {
    return a.propertyNames();
  }

  static
  {
    new String[1][0] = "IJCE.properties";
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.c
 * JD-Core Version:    0.6.2
 */