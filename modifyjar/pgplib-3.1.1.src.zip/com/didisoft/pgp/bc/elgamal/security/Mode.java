package com.didisoft.pgp.bc.elgamal.security;

abstract class Mode extends Cipher
{
  public String toString()
  {
    return "Mode [" + getProvider() + " " + getAlgorithm() + "/" + getMode() + "/" + getPadding() + "]";
  }

  protected final void a(Cipher paramCipher)
  {
    if (paramCipher == null)
      throw new NullPointerException("cipher == null");
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.Mode
 * JD-Core Version:    0.6.2
 */