package com.didisoft.pgp.bc.elgamal.security;

import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

final class b
{
  private static final PrintWriter a = new PrintWriter(System.err, true);
  private static Hashtable b = new Hashtable();

  public static String[] a(Provider paramProvider, String paramString)
  {
    if (d(paramString) == null)
      return new String[0];
    paramString = paramString + ".";
    Vector localVector = new Vector();
    paramProvider = paramProvider.propertyNames();
    while (paramProvider.hasMoreElements())
      if ((localObject = (String)paramProvider.nextElement()).startsWith(paramString))
        localVector.addElement(((String)localObject).substring(paramString.length()));
    Object localObject = new String[localVector.size()];
    localVector.copyInto((Object[])localObject);
    return localObject;
  }

  public static String[] a(String paramString)
  {
    if (d(paramString) == null)
      return new String[0];
    String str1 = paramString + ".";
    Hashtable localHashtable = new Hashtable();
    if (paramString.equals("PaddingScheme"))
      localHashtable.put("NONE", "");
    else if (paramString.equals("Mode"))
      localHashtable.put("ECB", "");
    paramString = paramString = Security.getProviders();
    for (int i = 0; i < paramString.length; i++)
    {
      localEnumeration = paramString[i].propertyNames();
      while (localEnumeration.hasMoreElements())
      {
        String str2;
        if ((str2 = (String)localEnumeration.nextElement()).startsWith(str1))
          localHashtable.put(str2.substring(str1.length()), "");
      }
    }
    String[] arrayOfString = new String[localHashtable.size()];
    Enumeration localEnumeration = localHashtable.keys();
    int j = 0;
    while (localEnumeration.hasMoreElements())
      arrayOfString[(j++)] = ((String)localEnumeration.nextElement());
    return arrayOfString;
  }

  public static String a(String paramString1, String paramString2)
  {
    paramString2 = "Alias." + paramString2;
    if ((paramString2 = Security.getAlgorithmProperty(paramString1, paramString2)) != null)
      return paramString2;
    return paramString1;
  }

  // ERROR //
  public static Object a(String paramString1, String paramString2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: astore_3
    //   4: astore_1
    //   5: dup
    //   6: astore_0
    //   7: aload_3
    //   8: invokestatic 54\011com/didisoft/pgp/bc/elgamal/security/b:a\011(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   11: astore_0
    //   12: aload_3
    //   13: invokestatic 58\011com/didisoft/pgp/bc/elgamal/security/b:d\011(Ljava/lang/String;)Ljava/lang/Class;
    //   16: dup
    //   17: astore 4
    //   19: ifnonnull +30 -> 49
    //   22: new 44\011java/security/NoSuchAlgorithmException
    //   25: dup
    //   26: new 42\011java/lang/StringBuilder
    //   29: dup
    //   30: invokespecial 72\011java/lang/StringBuilder:<init>\011()V
    //   33: aload_3
    //   34: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: ldc 8
    //   39: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: invokevirtual 76\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   45: invokespecial 77\011java/security/NoSuchAlgorithmException:<init>\011(Ljava/lang/String;)V
    //   48: athrow
    //   49: aload_0
    //   50: aload_1
    //   51: aload_3
    //   52: invokestatic 56\011com/didisoft/pgp/bc/elgamal/security/b:b\011(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class;
    //   55: astore_0
    //   56: aload 4
    //   58: aload_0
    //   59: invokevirtual 64\011java/lang/Class:isAssignableFrom\011(Ljava/lang/Class;)Z
    //   62: ifeq +7 -> 69
    //   65: aload_0
    //   66: goto +52 -> 118
    //   69: new 44\011java/security/NoSuchAlgorithmException
    //   72: dup
    //   73: new 42\011java/lang/StringBuilder
    //   76: dup
    //   77: ldc 26
    //   79: invokespecial 73\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   82: aload_3
    //   83: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: ldc 13
    //   88: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: aload_0
    //   92: invokevirtual 63\011java/lang/Class:getName\011()Ljava/lang/String;
    //   95: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: ldc 9
    //   100: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: aload 4
    //   105: invokevirtual 63\011java/lang/Class:getName\011()Ljava/lang/String;
    //   108: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: invokevirtual 76\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   114: invokespecial 77\011java/security/NoSuchAlgorithmException:<init>\011(Ljava/lang/String;)V
    //   117: athrow
    //   118: astore_0
    //   119: aload_0
    //   120: invokevirtual 65\011java/lang/Class:newInstance\011()Ljava/lang/Object;
    //   123: areturn
    //   124: astore_1
    //   125: new 42\011java/lang/StringBuilder
    //   128: dup
    //   129: ldc 6
    //   131: invokespecial 73\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   134: aload_1
    //   135: invokevirtual 74\011java/lang/StringBuilder:append\011(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   138: invokevirtual 76\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   141: astore_1
    //   142: goto +42 -> 184
    //   145: astore_1
    //   146: new 42\011java/lang/StringBuilder
    //   149: dup
    //   150: ldc 5
    //   152: invokespecial 73\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   155: aload_1
    //   156: invokevirtual 74\011java/lang/StringBuilder:append\011(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   159: invokevirtual 76\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   162: astore_1
    //   163: goto +21 -> 184
    //   166: astore_1
    //   167: new 42\011java/lang/StringBuilder
    //   170: dup
    //   171: ldc 4
    //   173: invokespecial 73\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   176: aload_1
    //   177: invokevirtual 74\011java/lang/StringBuilder:append\011(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   180: invokevirtual 76\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   183: astore_1
    //   184: new 44\011java/security/NoSuchAlgorithmException
    //   187: dup
    //   188: new 42\011java/lang/StringBuilder
    //   191: dup
    //   192: ldc 26
    //   194: invokespecial 73\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   197: aload_2
    //   198: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   201: ldc 13
    //   203: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: aload_0
    //   207: invokevirtual 63\011java/lang/Class:getName\011()Ljava/lang/String;
    //   210: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   213: aload_1
    //   214: invokevirtual 75\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: invokevirtual 76\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   220: invokespecial 77\011java/security/NoSuchAlgorithmException:<init>\011(Ljava/lang/String;)V
    //   223: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   119\011123\011124\011java/lang/LinkageError
    //   119\011123\011145\011java/lang/InstantiationException
    //   119\011123\011166\011java/lang/IllegalAccessException
  }

  private static Class b(String paramString1, String paramString2, String paramString3)
    throws NoSuchAlgorithmException, NoSuchProviderException
  {
    String str = paramString3 + "." + paramString1;
    Object localObject2;
    Object localObject1;
    if (paramString2 == null)
    {
      localObject2 = paramString2 = Security.getProviders();
      for (paramString2 = 0; paramString2 < localObject2.length; paramString2++)
        if ((localObject1 = localObject2[paramString2].getProperty(str)) != null)
          try
          {
            if ((localObject1 = b((String)localObject1, paramString3)) != null)
              return localObject1;
          }
          catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
          {
          }
      throw new NoSuchAlgorithmException("algorithm " + paramString1 + " is not available.");
    }
    if ((localObject1 = localObject1 = Security.getProvider(localObject1 = paramString2)) == null)
      throw new NoSuchProviderException("provider " + paramString2 + " is not available.");
    if (((localObject1 = ((Provider)localObject1).getProperty(str)) != null) && ((localObject2 = b((String)localObject1, paramString3)) != null))
      return localObject2;
    throw new NoSuchAlgorithmException("algorithm " + paramString1 + " is not available from provider " + paramString2);
  }

  private static Class b(String paramString1, String paramString2)
    throws NoSuchAlgorithmException
  {
    String str2;
    try
    {
      return Class.forName(paramString1);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      return null;
    }
    catch (NoSuchMethodError localNoSuchMethodError)
    {
      String str1 = " does not have a zero-argument constructor.\n" + localNoSuchMethodError;
    }
    catch (LinkageError localLinkageError)
    {
      str2 = " could not be linked correctly.\n" + localLinkageError;
    }
    throw new NoSuchAlgorithmException("class configured for " + paramString2 + ": " + paramString1 + str2);
  }

  private static Class d(String paramString)
  {
    Object localObject;
    if ((localObject = (Class)b.get(paramString)) != null)
      return localObject;
    if ((localObject = c.a("Type." + paramString)) == null)
      return null;
    try
    {
      localObject = Class.forName((String)localObject);
    }
    catch (LinkageError localLinkageError)
    {
      paramString = "Error loading class for algorithm type " + paramString + ": " + localLinkageError;
      a.println(paramString);
      return null;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      paramString = "Error loading class for algorithm type " + paramString + ": " + localClassNotFoundException;
      a.println(paramString);
      return null;
    }
    b.put(paramString, localClassNotFoundException);
    return localClassNotFoundException;
  }

  static void b(String paramString)
  {
    a.println("\n" + paramString + "\n\nPlease report this as a bug to <david.hopwood@lmh.ox.ac.uk>, including\n" + "any other messages displayed on the console, and a description of what\nappeared to cause the error.\n");
    throw new InternalError(paramString);
  }

  static int c(String paramString)
  {
    if (((paramString = c.a("Debug.Level." + paramString)) == null) && ((paramString = c.a("Debug.Level.*")) == null))
      return 0;
    try
    {
      return Integer.parseInt(paramString);
    }
    catch (NumberFormatException localNumberFormatException)
    {
    }
    return 0;
  }

  static PrintWriter a()
  {
    return a;
  }

  static
  {
    c("IJCE");
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.b
 * JD-Core Version:    0.6.2
 */