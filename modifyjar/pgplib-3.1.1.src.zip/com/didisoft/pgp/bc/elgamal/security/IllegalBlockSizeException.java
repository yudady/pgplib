package com.didisoft.pgp.bc.elgamal.security;

public class IllegalBlockSizeException extends RuntimeException
{

  /** @deprecated */
  public int blockSize;

  /** @deprecated */
  public int dataSize;

  public int getBlockSize()
  {
    return blockSize;
  }

  public int getDataSize()
  {
    return dataSize;
  }

  public IllegalBlockSizeException(String paramString)
  {
    super(paramString);
  }

  public IllegalBlockSizeException(int paramInt1, int paramInt2)
  {
    super("blockSize = " + paramInt1 + ", dataSize = " + paramInt2);
    blockSize = paramInt1;
    dataSize = paramInt2;
  }

  public IllegalBlockSizeException(int paramInt1, int paramInt2, String paramString)
  {
    super(paramString);
    blockSize = paramInt1;
    dataSize = paramInt2;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.IllegalBlockSizeException
 * JD-Core Version:    0.6.2
 */