package com.didisoft.pgp.bc.elgamal.security;

abstract class PaddingScheme extends d
  implements Padding, Parameterized
{
  private int b;

  public final String a()
  {
    return null;
  }

  public final int pad(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt2 < 0))
      throw new ArrayIndexOutOfBoundsException("offset < 0 || length < 0");
    int i = b;
    int j = paramInt2 - paramInt2 % i;
    if (paramInt1 + j + i > paramArrayOfByte.length)
      throw new ArrayIndexOutOfBoundsException("(long)offset + length + padLength(length) > in.length");
    paramInt1 += j;
    paramInt2 -= j;
    if (a)
      b("enginePad(<" + paramArrayOfByte + ">, " + paramInt1 + ", " + paramInt2 + ")");
    paramArrayOfByte = b();
    if (a)
      a(paramArrayOfByte);
    return paramArrayOfByte;
  }

  public final int unpad(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
      return 0;
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 + paramInt2 > paramArrayOfByte.length))
      throw new ArrayIndexOutOfBoundsException("offset < 0 || length < 0 || (long)offset + length > in.length");
    if (a)
      b("engineUnpad(<" + paramArrayOfByte + ">, " + paramInt1 + ", " + paramInt2 + ")");
    paramArrayOfByte = c();
    if (a)
      a(paramArrayOfByte);
    return paramArrayOfByte;
  }

  public Object clone()
    throws CloneNotSupportedException
  {
    if ((this instanceof Cloneable))
      return super.clone();
    throw new CloneNotSupportedException();
  }

  public String toString()
  {
    PaddingScheme localPaddingScheme = this;
    return "PaddingScheme [" + null + "]";
  }

  protected final void b(int paramInt)
  {
    if (paramInt <= 0)
    {
      PaddingScheme localPaddingScheme = this;
      throw new IllegalBlockSizeException(null + ": " + paramInt + " is not a valid block size");
    }
    b = paramInt;
  }

  protected abstract int b();

  protected abstract int c();
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.security.PaddingScheme
 * JD-Core Version:    0.6.2
 */