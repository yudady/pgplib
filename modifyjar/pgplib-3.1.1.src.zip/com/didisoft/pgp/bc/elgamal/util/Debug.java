package com.didisoft.pgp.bc.elgamal.util;

import java.io.PrintWriter;

public class Debug
{
  public static final boolean GLOBAL_TRACE = true;
  public static final boolean GLOBAL_DEBUG = true;
  public static final boolean GLOBAL_DEBUG_SLOW = false;
  private static final PrintWriter a = new PrintWriter(System.err, true);

  public static boolean isTraceable(String paramString)
  {
    return false;
  }

  public static int getLevel(String paramString)
  {
    return 0;
  }

  public static int getLevel(String paramString1, String paramString2)
  {
    paramString1 = getLevel(paramString1);
    paramString2 = getLevel(paramString2);
    if (paramString1 > paramString2)
      return paramString1;
    return paramString2;
  }

  public static PrintWriter getOutput()
  {
    return a;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.Debug
 * JD-Core Version:    0.6.2
 */