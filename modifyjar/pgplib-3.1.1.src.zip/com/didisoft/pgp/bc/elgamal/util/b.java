package com.didisoft.pgp.bc.elgamal.util;

class b
{
  int[] a;
  int b;
  int c = 0;

  b()
  {
    a = new int[1];
    b = 0;
  }

  b(int paramInt)
  {
    a = new int[1];
    b = 1;
    a[0] = paramInt;
  }

  b(int[] paramArrayOfInt)
  {
    a = paramArrayOfInt;
    b = paramArrayOfInt.length;
  }

  b(BigInteger paramBigInteger)
  {
    a = ((int[])paramBigInteger.a.clone());
    b = a.length;
  }

  private b(b paramb)
  {
    b = paramb.b;
    a = new int[b];
    for (int i = 0; i < b; i++)
      a[i] = paramb.a[(paramb.c + i)];
  }

  private void a()
  {
    c = (this.b = 0);
    int i = 0;
    int j = a.length;
    while (i < j)
    {
      a[i] = 0;
      i++;
    }
  }

  private int e(b paramb)
  {
    if (b < paramb.b)
      return -1;
    if (b > paramb.b)
      return 1;
    for (int i = 0; i < b; i++)
    {
      int j = a[(c + i)] + -2147483648;
      int k = paramb.a[(paramb.c + i)] + -2147483648;
      if (j < k)
        return -1;
      if (j > k)
        return 1;
    }
    return 0;
  }

  private final int b()
  {
    if (b == 0)
      return -1;
    for (int i = b - 1; (i > 0) && (a[(i + c)] == 0); i--);
    int j;
    if ((j = a[(i + c)]) == 0)
      return -1;
    return (b - 1 - i << 5) + BigInteger.c(j);
  }

  private void c()
  {
    if (b == 0)
    {
      c = 0;
      return;
    }
    int i = c;
    if (a[i] != 0)
      return;
    int j = i + b;
    do
      i++;
    while ((i < j) && (a[i] == 0));
    i -= c;
    b -= i;
    c = (b == 0 ? 0 : c + i);
  }

  private void f(b paramb)
  {
    int i = paramb.b;
    if (a.length < i)
      a = new int[i];
    for (int j = 0; j < i; j++)
      a[j] = paramb.a[(paramb.c + j)];
    b = i;
    c = 0;
  }

  final void a(int[] paramArrayOfInt)
  {
    int i = paramArrayOfInt.length;
    if (a.length < i)
      a = new int[i];
    for (int j = 0; j < i; j++)
      a[j] = paramArrayOfInt[j];
    b = i;
    c = 0;
  }

  private boolean d()
  {
    return (b == 1) && (a[c] == 1);
  }

  private boolean e()
  {
    return (b == 0) || ((a[(c + b - 1)] & 0x1) == 0);
  }

  public String toString()
  {
    BigInteger localBigInteger;
    return (localBigInteger = new BigInteger(this, 1)).toString();
  }

  private void c(int paramInt)
  {
    if (b == 0)
      return;
    int i = paramInt >>> 5;
    paramInt &= 31;
    b -= i;
    if (paramInt == 0)
      return;
    i = BigInteger.b(a[c]);
    if (paramInt >= i)
    {
      e(32 - paramInt);
      b -= 1;
      return;
    }
    d(paramInt);
  }

  final void a(int paramInt)
  {
    if (b == 0)
      return;
    int i = paramInt >>> 5;
    int k = paramInt & 0x1F;
    int m = BigInteger.b(a[c]);
    if (paramInt <= 32 - m)
    {
      e(k);
      return;
    }
    paramInt = b + i + 1;
    if (k <= 32 - m)
      paramInt--;
    if (a.length < paramInt)
    {
      Object localObject1 = new int[paramInt];
      for (int n = 0; n < b; n++)
        localObject1[n] = a[(c + n)];
      int i1 = paramInt;
      Object localObject2 = localObject1;
      localObject1 = this;
      a = localObject2;
      ((b)localObject1).b = i1;
      ((b)localObject1).c = 0;
    }
    else
    {
      int j;
      if (a.length - c >= paramInt)
      {
        for (j = 0; j < paramInt - b; j++)
          a[(c + b + j)] = 0;
      }
      else
      {
        for (j = 0; j < b; j++)
          a[j] = a[(c + j)];
        for (j = b; j < paramInt; j++)
          a[j] = 0;
        c = 0;
      }
    }
    b = paramInt;
    if (k == 0)
      return;
    if (k <= 32 - m)
    {
      e(k);
      return;
    }
    d(32 - k);
  }

  private static int a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
  {
    long l1 = 0L;
    for (int i = paramArrayOfInt1.length - 1; i >= 0; i--)
    {
      long l2 = (paramArrayOfInt1[i] & 0xFFFFFFFF) + (paramArrayOfInt2[(i + paramInt)] & 0xFFFFFFFF) + l1;
      paramArrayOfInt2[(i + paramInt)] = ((int)l2);
      l1 = l2 >>> 32;
    }
    return (int)l1;
  }

  private static int a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt1, int paramInt2, int paramInt3)
  {
    long l1 = paramInt1 & 0xFFFFFFFF;
    long l2 = 0L;
    paramInt3 += paramInt2;
    for (paramInt1 = paramInt2 - 1; paramInt1 >= 0; paramInt1--)
    {
      long l3 = (paramArrayOfInt2[paramInt1] & 0xFFFFFFFF) * l1 + l2;
      long l4 = paramArrayOfInt1[paramInt3] - l3;
      paramArrayOfInt1[(paramInt3--)] = ((int)l4);
      l2 = (l3 >>> 32) + ((l4 & 0xFFFFFFFF) > (((int)l3 ^ 0xFFFFFFFF) & 0xFFFFFFFF) ? 1 : 0);
    }
    return (int)l2;
  }

  private final void d(int paramInt)
  {
    int[] arrayOfInt = a;
    int i = 32 - paramInt;
    int j = c + b - 1;
    int k = arrayOfInt[j];
    while (j > c)
    {
      int m = k;
      k = arrayOfInt[(j - 1)];
      arrayOfInt[j] = (k << i | m >>> paramInt);
      j--;
    }
    arrayOfInt[c] >>>= paramInt;
  }

  private final void e(int paramInt)
  {
    int[] arrayOfInt = a;
    int i = 32 - paramInt;
    int j = c;
    int k = arrayOfInt[j];
    int m = j + b - 1;
    while (j < m)
    {
      int n = k;
      k = arrayOfInt[(j + 1)];
      arrayOfInt[j] = (n << paramInt | k >>> i);
      j++;
    }
    arrayOfInt[(c + b - 1)] <<= paramInt;
  }

  final void a(b paramb)
  {
    int i = b;
    int j = paramb.b;
    int k = b > paramb.b ? b : paramb.b;
    Object localObject;
    int m = (localObject = a.length < k ? new int[k] : a).length - 1;
    long l = 0L;
    while ((i > 0) && (j > 0))
    {
      i--;
      j--;
      l = (a[(i + c)] & 0xFFFFFFFF) + (paramb.a[(j + paramb.c)] & 0xFFFFFFFF) + (l >>> 32);
      localObject[(m--)] = ((int)l);
    }
    while (i > 0)
    {
      i--;
      l = (a[(i + c)] & 0xFFFFFFFF) + (l >>> 32);
      localObject[(m--)] = ((int)l);
    }
    while (j > 0)
    {
      j--;
      l = (paramb.a[(j + paramb.c)] & 0xFFFFFFFF) + (l >>> 32);
      localObject[(m--)] = ((int)l);
    }
    if (l >>> 32 > 0L)
    {
      k++;
      if (localObject.length < k)
      {
        paramb = new int[k];
        for (i = k - 1; i > 0; i--)
          paramb[i] = localObject[(i - 1)];
        paramb[0] = 1;
        localObject = paramb;
      }
      else
      {
        localObject[m] = 1;
      }
    }
    a = ((int[])localObject);
    b = k;
    c = (localObject.length - k);
  }

  final int b(b paramb)
  {
    b localb1 = this;
    int[] arrayOfInt = a;
    int i;
    if ((i = localb1.e(paramb)) == 0)
    {
      paramb = this;
      c = (paramb.b = 0);
      return 0;
    }
    if (i < 0)
    {
      b localb2 = localb1;
      localb1 = paramb;
      paramb = localb2;
    }
    int j = localb1.b;
    if (arrayOfInt.length < j)
      arrayOfInt = new int[j];
    long l = 0L;
    int k = localb1.b;
    int m = paramb.b;
    int n = arrayOfInt.length - 1;
    while (m > 0)
    {
      k--;
      m--;
      l = (localb1.a[(k + localb1.c)] & 0xFFFFFFFF) - (paramb.a[(m + paramb.c)] & 0xFFFFFFFF) - (int)-(l >> 32);
      arrayOfInt[(n--)] = ((int)l);
    }
    while (k > 0)
    {
      k--;
      l = (localb1.a[(k + localb1.c)] & 0xFFFFFFFF) - (int)-(l >> 32);
      arrayOfInt[(n--)] = ((int)l);
    }
    a = arrayOfInt;
    b = j;
    c = (a.length - j);
    c();
    return i;
  }

  private void a(b paramb1, b paramb2)
  {
    int i = b;
    int j = paramb1.b;
    int k = i + j;
    if (paramb2.a.length < k)
      paramb2.a = new int[k];
    paramb2.c = 0;
    paramb2.b = k;
    long l1 = 0L;
    k = j - 1;
    for (int m = j + i - 1; k >= 0; m--)
    {
      long l2 = (paramb1.a[(k + paramb1.c)] & 0xFFFFFFFF) * (a[(i - 1 + c)] & 0xFFFFFFFF) + l1;
      paramb2.a[m] = ((int)l2);
      l1 = l2 >>> 32;
      k--;
    }
    paramb2.a[(i - 1)] = ((int)l1);
    for (k = i - 2; k >= 0; k--)
    {
      l1 = 0L;
      m = j - 1;
      for (int n = j + k; m >= 0; n--)
      {
        long l3 = (paramb1.a[(m + paramb1.c)] & 0xFFFFFFFF) * (a[(k + c)] & 0xFFFFFFFF) + (paramb2.a[n] & 0xFFFFFFFF) + l1;
        paramb2.a[n] = ((int)l3);
        l1 = l3 >>> 32;
        m--;
      }
      paramb2.a[k] = ((int)l1);
    }
    paramb2.c();
  }

  private void b(int paramInt, b paramb)
  {
    if (paramInt == 1)
    {
      paramb.f(this);
      return;
    }
    if (paramInt == 0)
    {
      paramb.a();
      return;
    }
    long l1 = paramInt & 0xFFFFFFFF;
    paramInt = paramb.a.length < b + 1 ? new int[b + 1] : paramb.a;
    long l2 = 0L;
    for (int i = b - 1; i >= 0; i--)
    {
      long l3 = l1 * (a[(i + c)] & 0xFFFFFFFF) + l2;
      paramInt[(i + 1)] = ((int)l3);
      l2 = l3 >>> 32;
    }
    if (l2 == 0L)
    {
      paramb.c = 1;
      paramb.b = b;
    }
    else
    {
      paramb.c = 0;
      b += 1;
      paramInt[0] = ((int)l2);
    }
    paramb.a = paramInt;
  }

  final void a(int paramInt, b paramb)
  {
    long l1 = paramInt & 0xFFFFFFFF;
    if (b == 1)
    {
      long l2 = a[c] & 0xFFFFFFFF;
      paramb.a[0] = ((int)(l2 / l1));
      paramb.b = (paramb.a[0] == 0 ? 0 : 1);
      paramb.c = 0;
      a[0] = ((int)(l2 - paramb.a[0] * l1));
      c = 0;
      b = (a[0] == 0 ? 0 : 1);
      return;
    }
    if (paramb.a.length < b)
      paramb.a = new int[b];
    paramb.c = 0;
    paramb.b = b;
    int i = 32 - BigInteger.b(paramInt);
    int j;
    long l3;
    if ((l3 = (j = a[c]) & 0xFFFFFFFF) < l1)
    {
      paramb.a[0] = 0;
    }
    else
    {
      paramb.a[0] = ((int)(l3 / l1));
      l3 = (j = (int)(l3 - paramb.a[0] * l1)) & 0xFFFFFFFF;
    }
    int k = b;
    int[] arrayOfInt = new int[2];
    while (true)
    {
      k--;
      if (k <= 0)
        break;
      long l4;
      if ((l4 = l3 << 32 | a[(c + b - k)] & 0xFFFFFFFF) >= 0L)
      {
        arrayOfInt[0] = ((int)(l4 / l1));
        arrayOfInt[1] = ((int)(l4 - arrayOfInt[0] * l1));
      }
      else
      {
        a(arrayOfInt, l4, paramInt);
      }
      paramb.a[(b - k)] = arrayOfInt[0];
      l3 = (j = arrayOfInt[1]) & 0xFFFFFFFF;
    }
    if (i > 0)
      a[0] = (j % paramInt);
    else
      a[0] = j;
    b = (a[0] == 0 ? 0 : 1);
    paramb.c();
  }

  final void a(b paramb1, b paramb2, b paramb3)
  {
    if (paramb1.b == 0)
      throw new ArithmeticException("BigInteger divide by zero");
    if (b == 0)
    {
      paramb2.b = (paramb2.c = paramb3.b = paramb3.c = 0);
      return;
    }
    int i;
    if ((i = e(paramb1)) < 0)
    {
      paramb2.b = (paramb2.c = 0);
      paramb3.f(this);
      return;
    }
    if (i == 0)
    {
      int tmp84_83 = 1;
      paramb2.b = tmp84_83;
      paramb2.a[0] = tmp84_83;
      paramb2.c = (paramb3.b = paramb3.c = 0);
      return;
    }
    paramb2.a();
    if (paramb1.b == 1)
    {
      paramb3.f(this);
      paramb3.a(paramb1.a[paramb1.c], paramb2);
      return;
    }
    int[] arrayOfInt1 = new int[paramb1.b];
    for (int j = 0; j < paramb1.b; j++)
      arrayOfInt1[j] = paramb1.a[(paramb1.c + j)];
    j = paramb1.b;
    if (paramb3.a.length < b + 1)
      paramb3.a = new int[b + 1];
    for (paramb1 = 0; paramb1 < b; paramb1++)
      paramb3.a[(paramb1 + 1)] = a[(paramb1 + c)];
    paramb3.b = b;
    paramb3.c = 1;
    int k = (paramb1 = paramb3.b) - j + 1;
    if (paramb2.a.length < k)
    {
      paramb2.a = new int[k];
      paramb2.c = 0;
    }
    paramb2.b = k;
    int[] arrayOfInt2 = paramb2.a;
    int m;
    if ((m = 32 - BigInteger.b(arrayOfInt1[0])) > 0)
    {
      BigInteger.a(arrayOfInt1, j, m);
      paramb3.a(m);
    }
    if (paramb3.b == paramb1)
    {
      paramb3.c = 0;
      paramb3.a[0] = 0;
      paramb3.b += 1;
    }
    long l1 = (paramb1 = arrayOfInt1[0]) & 0xFFFFFFFF;
    int n = arrayOfInt1[1];
    int[] arrayOfInt3 = new int[2];
    for (int i1 = 0; i1 < k; i1++)
    {
      int i4 = 0;
      b localb1;
      int i5 = (localb1 = paramb3.a[(i1 + paramb3.c)]) + -2147483648;
      b localb2 = paramb3.a[(i1 + 1 + paramb3.c)];
      int i2;
      int i3;
      long l2;
      if (localb1 == paramb1)
      {
        i2 = -1;
        i4 = i3 += localb2 + -2147483648 < i5 ? 1 : 0;
      }
      else if ((l2 = i3 << 32 | localb2 & 0xFFFFFFFF) >= 0L)
      {
        i2 = (int)(l2 / l1);
        i3 = (int)(l2 - i2 * l1);
      }
      else
      {
        a(arrayOfInt3, l2, paramb1);
        i2 = arrayOfInt3[0];
        i3 = arrayOfInt3[1];
      }
      if (i2 != 0)
      {
        if (i4 == 0)
        {
          l2 = paramb3.a[(i1 + 2 + paramb3.c)] & 0xFFFFFFFF;
          long l3 = (i3 & 0xFFFFFFFF) << 32 | l2;
          long l4;
          if (a(l4 = (n & 0xFFFFFFFF) * (i2 & 0xFFFFFFFF), l3))
          {
            i2--;
            if (((i3 = (int)((i3 & 0xFFFFFFFF) + l1)) & 0xFFFFFFFF) >= l1)
            {
              l4 = (n & 0xFFFFFFFF) * (i2 & 0xFFFFFFFF);
              l3 = (i3 & 0xFFFFFFFF) << 32 | l2;
              if (a(l4, l3))
                i2--;
            }
          }
        }
        paramb3.a[(i1 + paramb3.c)] = 0;
        int i6;
        if ((i6 = a(paramb3.a, arrayOfInt1, i2, j, i1 + paramb3.c)) + -2147483648 > i5)
        {
          a(arrayOfInt1, paramb3.a, i1 + 1 + paramb3.c);
          i2--;
        }
        arrayOfInt2[i1] = i2;
      }
    }
    if (m > 0)
      paramb3.c(m);
    paramb3.c();
    paramb2.c();
  }

  private static boolean a(long paramLong1, long paramLong2)
  {
    return paramLong1 + -9223372036854775808L > paramLong2 + -9223372036854775808L;
  }

  private static void a(int[] paramArrayOfInt, long paramLong, int paramInt)
  {
    long l1;
    if ((l1 = paramInt & 0xFFFFFFFF) == 1L)
    {
      paramArrayOfInt[0] = ((int)paramLong);
      paramArrayOfInt[1] = 0;
      return;
    }
    long l2 = (paramLong >>> 1) / (l1 >>> 1);
    long l3 = paramLong - l2 * l1;
    while (l3 < 0L)
    {
      l3 += l1;
      l2 -= 1L;
    }
    while (l3 >= l1)
    {
      l3 -= l1;
      l2 += 1L;
    }
    paramArrayOfInt[0] = ((int)l2);
    paramArrayOfInt[1] = ((int)l3);
  }

  final b c(b paramb)
  {
    Object localObject1 = this;
    b localb3 = new b();
    Object localObject3;
    b localb2;
    Object localObject2;
    for (b localb4 = new b(); paramb.b != 0; localObject2 = localObject3)
    {
      b localb1;
      int m;
      if (Math.abs(((b)localObject1).b - paramb.b) < 2)
      {
        localObject1 = paramb;
        paramb = paramb = localObject1;
        new b();
        localb3 = new b();
        int i = paramb.b();
        int n = ((b)localObject1).b();
        if ((n = i < n ? i : n) != 0)
        {
          paramb.c(n);
          ((b)localObject1).c(n);
        }
        b localb6 = (i = n == i ? 1 : 0) != 0 ? localObject1 : paramb;
        i = i != 0 ? -1 : 1;
        int i2;
        while ((i2 = localb6.b()) >= 0)
        {
          localb6.c(i2);
          if (i > 0)
            paramb = localb6;
          else
            localObject1 = localb6;
          int i5;
          if ((paramb.b < 2) && (((b)localObject1).b < 2))
          {
            paramb = paramb.a[paramb.c];
            localb1 = localObject1.a[localObject1.c];
            localb6 = localb1;
            int j = paramb;
            int k;
            for (i5 = 0; (i2 = j & 0xFF) == 0; i5 += 8)
              j >>>= 8;
            int i7 = BigInteger.b[i2];
            i5 += i7;
            k >>>= i7;
            int i3;
            int i1;
            for (int i8 = 0; (i3 = localb6 & 0xFF) == 0; i8 += 8)
              localb6 >>>= 8;
            i7 = BigInteger.b[i3];
            i8 += i7;
            i1 >>>= i7;
            i6 = i5 < i8 ? i5 : i8;
            while (k != i1)
            {
              int i4;
              if (k + -2147483648 > i1 + -2147483648)
              {
                k -= i1;
                while ((i4 = k & 0xFF) == 0)
                  k >>>= 8;
                k >>>= BigInteger.b[i4];
              }
              else
              {
                i1 -= k;
                while ((i4 = i1 & 0xFF) == 0)
                  i1 >>>= 8;
                i1 >>>= BigInteger.b[i4];
              }
            }
            paramb = j == 0 ? localb6 : localb6 == 0 ? j : k << i6;
            localb3.a[0] = paramb;
            localb3.b = 1;
            localb3.c = 0;
            if (n > 0)
              localb3.a(n);
            return localb3;
          }
          Object localObject4 = localb1;
          b localb5;
          Object localObject5;
          if (i5 < 0)
          {
            Object localObject6 = localObject5;
            localObject5 = localObject4;
            localObject4 = localObject6;
          }
          long l = 0L;
          int i6 = ((b)localObject5).b;
          m = localObject4.b;
          while (m > 0)
          {
            i6--;
            m--;
            l = (localObject5.a[(localObject5.c + i6)] & 0xFFFFFFFF) - (localObject4.a[(localObject4.c + m)] & 0xFFFFFFFF) - (int)-(l >> 32);
            ((b)localObject5).a[(localObject5.c + i6)] = ((int)l);
          }
          while (i6 > 0)
          {
            i6--;
            l = (localObject5.a[(localObject5.c + i6)] & 0xFFFFFFFF) - (int)-(l >> 32);
            ((b)localObject5).a[(localObject5.c + i6)] = ((int)l);
          }
          ((b)localObject5).c();
          if ((m = (i5 = (localObject5 = localb5 = paramb).e(localObject4)) == 0 ? 0 : i5) == 0)
            break;
          localObject4 = m >= 0 ? paramb : localb1;
        }
        if (n > 0)
          paramb.a(n);
        return paramb;
      }
      localb1.a(paramb, localb3, m);
      localObject3 = localb1;
      localb2 = paramb;
      paramb = m;
    }
    return localb2;
  }

  final b d(b paramb)
  {
    if ((((localObject = paramb).a[(localObject.c + localObject.b - 1)] & 0x1) == 1 ? 1 : 0) != 0)
      return g(paramb);
    if (e())
      throw new ArithmeticException("BigInteger not invertible.");
    int i = paramb.b();
    b localb1;
    (localb1 = new b(paramb)).c(i);
    if (localb1.d())
      return f(i);
    b localb2 = g(localb1);
    b localb3 = f(i);
    int j = i;
    Object localObject = localb1;
    localObject = a(new b(1), new b((b)localObject), j);
    b localb4 = localb1.f(i);
    b localb5 = new b();
    b localb6 = new b();
    b localb7 = new b();
    localb2.a(i);
    localb2.a((b)localObject, localb7);
    localb3.a(localb1, localb5);
    localb5.a(localb4, localb6);
    localb7.a(localb6);
    localb7.a(paramb, localb5, localb6);
    return localb6;
  }

  private b f(int paramInt)
  {
    if (e())
      throw new ArithmeticException("Non-invertible. (GCD != 1)");
    if (paramInt > 64)
      return g(paramInt);
    int i = b(a[(c + b - 1)]);
    if (paramInt < 33)
    {
      i = paramInt == 32 ? i : i & (1 << paramInt) - 1;
      return new b(i);
    }
    long l1 = a[(c + b - 1)] & 0xFFFFFFFF;
    if (b > 1)
      l1 |= a[(c + b - 2)] << 32;
    long l2 = (l2 = i & 0xFFFFFFFF) * (2L - l1 * l2);
    l2 = paramInt == 64 ? l2 : l2 & (1L << paramInt) - 1L;
    (paramInt = new b(new int[2])).a[0] = ((int)(l2 >>> 32));
    paramInt.a[1] = ((int)l2);
    paramInt.b = 2;
    paramInt.c();
    return paramInt;
  }

  static int b(int paramInt)
  {
    int i;
    return i = (i = (i = (i = paramInt * (2 - paramInt * paramInt)) * (2 - paramInt * i)) * (2 - paramInt * i)) * (2 - paramInt * i);
  }

  private b g(b paramb)
  {
    paramb = new b(paramb);
    Object localObject1 = new b(this);
    Object localObject2 = new b(paramb);
    Object localObject3 = new c(1);
    Object localObject4 = new c();
    int k = 0;
    if (((b)localObject1).e())
    {
      int i = ((b)localObject1).b();
      ((b)localObject1).c(i);
      ((c)localObject4).a(i);
      k = i;
    }
    Object localObject7;
    while (!((b)localObject1).d())
    {
      Object localObject5;
      if (((localObject5 = localObject1).b == 0 ? 1 : 0) != 0)
        throw new ArithmeticException("BigInteger not invertible.");
      if (((b)localObject1).e((b)localObject2) < 0)
      {
        localObject5 = localObject1;
        localObject1 = localObject2;
        localObject2 = localObject5;
        localObject5 = localObject4;
        localObject4 = localObject3;
        localObject3 = localObject5;
      }
      if (((localObject1.a[(localObject1.c + localObject1.b - 1)] ^ localObject2.a[(localObject2.c + localObject2.b - 1)]) & 0x3) == 0)
      {
        ((b)localObject1).b((b)localObject2);
        localObject7 = localObject4;
        if ((localObject5 = localObject3).d == ((c)localObject7).d)
          localObject5.d *= localObject5.b((b)localObject7);
        else
          localObject5.a((b)localObject7);
      }
      else
      {
        ((b)localObject1).a((b)localObject2);
        localObject7 = localObject4;
        if ((localObject5 = localObject3).d == ((c)localObject7).d)
          localObject5.a((b)localObject7);
        else
          localObject5.d *= localObject5.b((b)localObject7);
      }
      int j = ((b)localObject1).b();
      ((b)localObject1).c(j);
      ((c)localObject4).a(j);
      k += j;
    }
    while (((c)localObject3).d < 0)
    {
      localObject7 = paramb;
      Object localObject6;
      if ((localObject6 = localObject3).d == 1)
        localObject6.a((b)localObject7);
      else
        localObject6.d *= localObject6.b((b)localObject7);
    }
    return a((b)localObject3, paramb, k);
  }

  private static b a(b paramb1, b paramb2, int paramInt)
  {
    b localb = new b();
    int i = -b(paramb2.a[(paramb2.c + paramb2.b - 1)]);
    int j = 0;
    int k = paramInt >> 5;
    while (j < k)
    {
      int m = i * a[(c + b - 1)];
      paramb2.b(m, localb);
      paramb1.a(localb);
      b -= 1;
      j++;
    }
    if ((j = paramInt & 0x1F) != 0)
    {
      k = (k = i * a[(c + b - 1)]) & (1 << j) - 1;
      paramb2.b(k, localb);
      paramb1.a(localb);
      paramb1.c(j);
    }
    while (paramb1.e(paramb2) >= 0)
      paramb1.b(paramb2);
    return paramb1;
  }

  private b g(int paramInt)
  {
    (localObject1 = new b(1)).a(paramInt);
    paramInt = new b((b)localObject1);
    Object localObject2 = new b(this);
    Object localObject3 = new b();
    Object localObject4 = new b();
    ((b)localObject1).a((b)localObject2, (b)localObject3, (b)localObject4);
    Object localObject5 = localObject1;
    Object localObject1 = localObject4;
    localObject4 = localObject5;
    b localb1 = new b((b)localObject3);
    b localb2 = new b(1);
    Object localObject6 = new b();
    while (!((b)localObject1).d())
    {
      ((b)localObject2).a((b)localObject1, (b)localObject3, (b)localObject4);
      if (((b)localObject4).b == 0)
        throw new ArithmeticException("BigInteger not invertible.");
      localObject5 = localObject4;
      localObject4 = localObject2;
      localObject2 = localObject5;
      if (((b)localObject3).b == 1)
        localb1.b(localObject3.a[localObject3.c], (b)localObject6);
      else
        ((b)localObject3).a(localb1, (b)localObject6);
      localObject5 = localObject3;
      localObject3 = localObject6;
      localObject6 = localObject5;
      localb2.a((b)localObject3);
      if (((b)localObject2).d())
        return localb2;
      ((b)localObject1).a((b)localObject2, (b)localObject3, (b)localObject4);
      if (((b)localObject4).b == 0)
        throw new ArithmeticException("BigInteger not invertible.");
      localObject5 = localObject1;
      localObject1 = localObject4;
      localObject4 = localObject5;
      if (((b)localObject3).b == 1)
        localb2.b(localObject3.a[localObject3.c], (b)localObject6);
      else
        ((b)localObject3).a(localb2, (b)localObject6);
      localObject5 = localObject3;
      localObject3 = localObject6;
      localObject6 = localObject5;
      localb1.a((b)localObject3);
    }
    paramInt.b(localb1);
    return paramInt;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.b
 * JD-Core Version:    0.6.2
 */