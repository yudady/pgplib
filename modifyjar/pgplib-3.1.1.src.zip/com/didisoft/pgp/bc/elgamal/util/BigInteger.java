package com.didisoft.pgp.bc.elgamal.util;

import [I;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectInputStream.GetField;
import java.io.ObjectOutputStream;
import java.io.ObjectOutputStream.PutField;
import java.io.ObjectStreamField;
import java.io.StreamCorruptedException;
import java.util.Random;

public class BigInteger extends Number
  implements Comparable
{
  private int c;
  int[] a;
  private int d = -1;
  private int e = -1;
  private int f = -2;
  private int g = -2;
  private static long[] h = { 0L, 0L, 1024L, 1624L, 2048L, 2378L, 2648L, 2875L, 3072L, 3247L, 3402L, 3543L, 3672L, 3790L, 3899L, 4001L, 4096L, 4186L, 4271L, 4350L, 4426L, 4498L, 4567L, 4633L, 4696L, 4756L, 4814L, 4870L, 4923L, 4975L, 5025L, 5074L, 5120L, 5166L, 5210L, 5253L, 5295L };
  private static final BigInteger i = valueOf(152125131763605L);
  private static BigInteger[] j = new BigInteger[17];
  private static BigInteger[] k = new BigInteger[17];
  public static final BigInteger ZERO;
  public static final BigInteger ONE;
  private static final BigInteger l;
  private static int[] m;
  static final byte[] b;
  private static String[] n;
  private static int[] o = { 0, 0, 62, 39, 31, 27, 24, 22, 20, 19, 18, 18, 17, 17, 16, 16, 15, 15, 15, 14, 14, 14, 14, 13, 13, 13, 13, 13, 13, 12, 12, 12, 12, 12, 12, 12, 12 };
  private static BigInteger[] p = { null, null, valueOf(4611686018427387904L), valueOf(4052555153018976267L), valueOf(4611686018427387904L), valueOf(7450580596923828125L), valueOf(4738381338321616896L), valueOf(3909821048582988049L), valueOf(1152921504606846976L), valueOf(1350851717672992089L), valueOf(1000000000000000000L), valueOf(5559917313492231481L), valueOf(2218611106740436992L), valueOf(8650415919381337933L), valueOf(2177953337809371136L), valueOf(6568408355712890625L), valueOf(1152921504606846976L), valueOf(2862423051509815793L), valueOf(6746640616477458432L), valueOf(799006685782884121L), valueOf(1638400000000000000L), valueOf(3243919932521508681L), valueOf(6221821273427820544L), valueOf(504036361936467383L), valueOf(876488338465357824L), valueOf(1490116119384765625L), valueOf(2481152873203736576L), valueOf(4052555153018976267L), valueOf(6502111422497947648L), valueOf(353814783205469041L), valueOf(531441000000000000L), valueOf(787662783788549761L), valueOf(1152921504606846976L), valueOf(1667889514952984961L), valueOf(2386420683693101056L), valueOf(3379220508056640625L), valueOf(4738381338321616896L) };
  private static int[] q = { 0, 0, 30, 19, 15, 13, 11, 11, 10, 9, 9, 8, 8, 8, 8, 7, 7, 7, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 5 };
  private static int[] r = { 0, 0, 1073741824, 1162261467, 1073741824, 1220703125, 362797056, 1977326743, 1073741824, 387420489, 1000000000, 214358881, 429981696, 815730721, 1475789056, 170859375, 268435456, 410338673, 612220032, 893871739, 1280000000, 1801088541, 113379904, 148035889, 191102976, 244140625, 308915776, 387420489, 481890304, 594823321, 729000000, 887503681, 1073741824, 1291467969, 1544804416, 1838265625, 60466176 };
  private static final long serialVersionUID = -8287574255936472291L;
  private static final ObjectStreamField[] serialPersistentFields = { new ObjectStreamField("signum", Integer.TYPE), new ObjectStreamField("magnitude", [B.class), new ObjectStreamField("bitCount", Integer.TYPE), new ObjectStreamField("bitLength", Integer.TYPE), new ObjectStreamField("firstNonzeroByteNum", Integer.TYPE), new ObjectStreamField("lowestSetBit", Integer.TYPE) };

  public BigInteger(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length == 0)
      throw new NumberFormatException("Zero length BigInteger");
    a = b(paramArrayOfByte);
    a = a(paramArrayOfByte);
    c = (a.length == 0 ? 0 : paramArrayOfByte[0] < 0 ? -1 : 1);
  }

  private BigInteger(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt.length == 0)
      throw new NumberFormatException("Zero length BigInteger");
    a = d(paramArrayOfInt);
    a = c(paramArrayOfInt);
    c = (a.length == 0 ? 0 : paramArrayOfInt[0] < 0 ? -1 : 1);
  }

  public BigInteger(int paramInt, byte[] paramArrayOfByte)
  {
    a = a(paramArrayOfByte);
    if ((paramInt < -1) || (paramInt > 1))
      throw new NumberFormatException("Invalid signum value");
    if (a.length == 0)
    {
      c = 0;
      return;
    }
    if (paramInt == 0)
      throw new NumberFormatException("signum-magnitude mismatch");
    c = paramInt;
  }

  private BigInteger(int paramInt, int[] paramArrayOfInt)
  {
    a = b(paramArrayOfInt);
    if (a.length == 0)
    {
      c = 0;
      return;
    }
    c = 1;
  }

  public BigInteger(String paramString, int paramInt)
  {
    int i1 = 0;
    int i2 = paramString.length();
    if ((paramInt < 2) || (paramInt > 36))
      throw new NumberFormatException("Radix out of range");
    if (paramString.length() == 0)
      throw new NumberFormatException("Zero length BigInteger");
    c = 1;
    if ((i4 = paramString.indexOf('-')) != -1)
      if (i4 == 0)
      {
        if (paramString.length() == 1)
          throw new NumberFormatException("Zero length BigInteger");
        c = -1;
        i1 = 1;
      }
      else
      {
        throw new NumberFormatException("Illegal embedded minus sign");
      }
    while ((i1 < i2) && (Character.digit(paramString.charAt(i1), paramInt) == 0))
      i1++;
    if (i1 == i2)
    {
      c = 0;
      a = ZERO.a;
      return;
    }
    int i4 = ((i4 = (int)(((i2 -= i1) * h[paramInt] >>> 10) + 1L)) + 31) / 32;
    a = new int[i4];
    if (i2 %= q[paramInt] == 0)
      i2 = q[paramInt];
    String str = paramString.substring(i1, i1 += i2);
    a[(a.length - 1)] = Integer.parseInt(str, paramInt);
    if (a[(a.length - 1)] < 0)
      throw new NumberFormatException("Illegal digit");
    i4 = r[paramInt];
    while (i1 < paramString.length())
    {
      int i3;
      if ((i3 = Integer.parseInt(str = paramString.substring(i1, i1 += q[paramInt]), paramInt)) < 0)
        throw new NumberFormatException("Illegal digit");
      b(a, i4, i3);
    }
    a = c(a);
  }

  BigInteger(char[] paramArrayOfChar)
  {
    int i1 = 0;
    int i3 = paramArrayOfChar.length;
    c = 1;
    if (paramArrayOfChar[0] == '-')
    {
      if (i3 == 1)
        throw new NumberFormatException("Zero length BigInteger");
      c = -1;
    }
    for (i1 = 1; (i1 < i3) && (Character.digit(paramArrayOfChar[i1], 10) == 0); i1++);
    if (i1 == i3)
    {
      c = 0;
      a = ZERO.a;
      return;
    }
    int i2 = i3 - i1;
    int i4;
    if (i3 < 10)
      i4 = 1;
    else
      i4 = ((i4 = (int)((i2 * h[10] >>> 10) + 1L)) + 31) / 32;
    a = new int[i4];
    if ((i4 = i2 % q[10]) == 0)
      i4 = q[10];
    int tmp204_203 = (i1 + i4);
    i1 = tmp204_203;
    a[(a.length - 1)] = a(paramArrayOfChar, i1, tmp204_203);
    while (i1 < i3)
    {
      i2 = a(paramArrayOfChar, i1, i1 += q[10]);
      b(a, r[10], i2);
    }
    a = c(a);
  }

  private static int a(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    int i1;
    if ((i1 = Character.digit(paramArrayOfChar[(paramInt1++)], 10)) == -1)
      throw new NumberFormatException(new String(paramArrayOfChar));
    for (paramInt1 = paramInt1; paramInt1 < paramInt2; paramInt1++)
    {
      int i2;
      if ((i2 = Character.digit(paramArrayOfChar[paramInt1], 10)) == -1)
        throw new NumberFormatException(new String(paramArrayOfChar));
      i1 = i1 * 10 + i2;
    }
    return i1;
  }

  private static void b(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    long l1 = paramInt1 & 0xFFFFFFFF;
    long l2 = paramInt2 & 0xFFFFFFFF;
    paramInt1 = paramArrayOfInt.length;
    long l4 = 0L;
    for (int i1 = paramInt1 - 1; i1 >= 0; i1--)
    {
      long l3 = l1 * (paramArrayOfInt[i1] & 0xFFFFFFFF) + l4;
      paramArrayOfInt[i1] = ((int)l3);
      l4 = l3 >>> 32;
    }
    long l5 = (paramArrayOfInt[(paramInt1 - 1)] & 0xFFFFFFFF) + l2;
    paramArrayOfInt[(paramInt1 - 1)] = ((int)l5);
    l4 = l5 >>> 32;
    paramInt1 -= 2;
    while (paramInt1 >= 0)
    {
      l5 = (paramArrayOfInt[paramInt1] & 0xFFFFFFFF) + l4;
      paramArrayOfInt[paramInt1] = ((int)l5);
      l4 = l5 >>> 32;
      paramInt1--;
    }
  }

  public BigInteger(String paramString)
  {
    this(paramString, 10);
  }

  public BigInteger(int paramInt, Random paramRandom)
  {
    this(1, arrayOfByte);
  }

  public BigInteger(int paramInt1, int paramInt2, Random paramRandom)
  {
    if (paramInt1 < 2)
      throw new ArithmeticException("bitLength < 2");
    paramInt1 = paramInt1 < 95 ? a(paramInt1, paramInt2, paramRandom) : b(paramInt1, paramInt2, paramRandom);
    c = 1;
    a = paramInt1.a;
  }

  public static BigInteger probablePrime(int paramInt, Random paramRandom)
  {
    if (paramInt < 2)
      throw new ArithmeticException("bitLength < 2");
    if (paramInt < 95)
      return a(paramInt, 100, paramRandom);
    return b(paramInt, 100, paramRandom);
  }

  private static BigInteger a(int paramInt1, int paramInt2, Random paramRandom)
  {
    int i1;
    int[] arrayOfInt = new int[i1 = paramInt1 + 31 >>> 5];
    int i2;
    int i3 = ((i2 = 1 << (paramInt1 + 31 & 0x1F)) << 1) - 1;
    while (true)
    {
      for (int i4 = 0; i4 < i1; i4++)
        arrayOfInt[i4] = paramRandom.nextInt();
      arrayOfInt[0] = (arrayOfInt[0] & i3 | i2);
      if (paramInt1 > 2)
        arrayOfInt[(i1 - 1)] |= 1;
      BigInteger localBigInteger = new BigInteger(arrayOfInt, 1);
      long l1;
      if ((paramInt1 <= 6) || (((l1 = localBigInteger.remainder(i).longValue()) % 3L != 0L) && (l1 % 5L != 0L) && (l1 % 7L != 0L) && (l1 % 11L != 0L) && (l1 % 13L != 0L) && (l1 % 17L != 0L) && (l1 % 19L != 0L) && (l1 % 23L != 0L) && (l1 % 29L != 0L) && (l1 % 31L != 0L) && (l1 % 37L != 0L) && (l1 % 41L != 0L)))
      {
        if (paramInt1 < 4)
          return localBigInteger;
        if (localBigInteger.a(paramInt2))
          return localBigInteger;
      }
    }
  }

  private static BigInteger b(int paramInt1, int paramInt2, Random paramRandom)
  {
    BigInteger localBigInteger;
    (localBigInteger = new BigInteger(paramInt1, paramRandom).setBit(paramInt1 - 1)).a[(localBigInteger.a.length - 1)] &= -2;
    int i1 = paramInt1 / 20 << 6;
    for (Object localObject = (localObject = new a(localBigInteger, i1)).a(localBigInteger, paramInt2); (localObject == null) || (((BigInteger)localObject).bitLength() != paramInt1); localObject = (localObject = new a(localBigInteger, i1)).a(localBigInteger, paramInt2))
    {
      if ((localBigInteger = localBigInteger.add(valueOf(2 * i1))).bitLength() != paramInt1)
        localBigInteger = new BigInteger(paramInt1, paramRandom).setBit(paramInt1 - 1);
      localBigInteger.a[(localBigInteger.a.length - 1)] &= -2;
    }
    return localObject;
  }

  final boolean a(int paramInt)
  {
    int i1 = (Math.min(paramInt, 2147483646) + 1) / 2;
    if ((paramInt = bitLength()) < 100)
    {
      paramInt = i1 < 50 ? i1 : 50;
      return d(paramInt);
    }
    if (paramInt < 256)
      paramInt = 27;
    else if (paramInt < 512)
      paramInt = 15;
    else if (paramInt < 768)
      paramInt = 8;
    else if (paramInt < 1024)
      paramInt = 4;
    else
      paramInt = 2;
    paramInt = i1 < paramInt ? i1 : paramInt;
    return d(paramInt);
  }

  private boolean d(int paramInt)
  {
    BigInteger localBigInteger1;
    int i1 = (localBigInteger2 = localBigInteger1 = subtract(ONE)).getLowestSetBit();
    BigInteger localBigInteger2 = localBigInteger2.shiftRight(i1);
    Random localRandom = new Random();
    for (int i2 = 0; i2 < paramInt; i2++)
    {
      while (((localBigInteger3 = new BigInteger(bitLength(), localRandom)).compareTo(ONE) <= 0) || (localBigInteger3.compareTo(this) >= 0));
      int i3 = 0;
      for (BigInteger localBigInteger3 = localBigInteger3.modPow(localBigInteger2, this); ((i3 != 0) || (!localBigInteger3.equals(ONE))) && (!localBigInteger3.equals(localBigInteger1)); localBigInteger3 = localBigInteger3.modPow(l, this))
        if ((i3 <= 0) || (!localBigInteger3.equals(ONE)))
        {
          i3++;
          if (i3 != i1);
        }
        else
        {
          return false;
        }
    }
    return true;
  }

  private BigInteger(int[] paramArrayOfInt, int paramInt)
  {
    c = (paramArrayOfInt.length == 0 ? 0 : paramInt);
    a = paramArrayOfInt;
  }

  BigInteger(b paramb, int paramInt)
  {
    if ((paramb.c > 0) || (paramb.a.length != paramb.b))
    {
      a = new int[paramb.b];
      for (int i1 = 0; i1 < paramb.b; i1++)
        a[i1] = paramb.a[(paramb.c + i1)];
    }
    else
    {
      a = paramb.a;
    }
    c = (paramb.b == 0 ? 0 : paramInt);
  }

  public static BigInteger valueOf(long paramLong)
  {
    if (paramLong == 0L)
      return ZERO;
    if ((paramLong > 0L) && (paramLong <= 16L))
      return j[((int)paramLong)];
    if ((paramLong < 0L) && (paramLong >= -16L))
      return k[((int)-paramLong)];
    return new BigInteger(paramLong);
  }

  private BigInteger(long paramLong)
  {
    if (paramLong < 0L)
    {
      c = -1;
      paramLong = -paramLong;
    }
    else
    {
      c = 1;
    }
    int i1;
    if ((i1 = (int)(paramLong >>> 32)) == 0)
    {
      a = new int[1];
      a[0] = ((int)paramLong);
      return;
    }
    a = new int[2];
    a[0] = i1;
    a[1] = ((int)paramLong);
  }

  private static BigInteger a(int[] paramArrayOfInt)
  {
    if (paramArrayOfInt[0] > 0)
      return new BigInteger(paramArrayOfInt, 1);
    return new BigInteger(paramArrayOfInt);
  }

  public BigInteger add(BigInteger paramBigInteger)
  {
    if (paramBigInteger.c == 0)
      return this;
    if (c == 0)
      return paramBigInteger;
    if (paramBigInteger.c == c)
      return new BigInteger(a(a, paramBigInteger.a), c);
    int i1;
    if ((i1 = c(a, paramBigInteger.a)) == 0)
      return ZERO;
    paramBigInteger = c(paramBigInteger = i1 > 0 ? b(a, paramBigInteger.a) : b(paramBigInteger.a, a));
    return new BigInteger(paramBigInteger, i1 * c);
  }

  private static int[] a(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    if (paramArrayOfInt1.length < paramArrayOfInt2.length)
    {
      int[] arrayOfInt1 = paramArrayOfInt1;
      paramArrayOfInt1 = paramArrayOfInt2;
      paramArrayOfInt2 = arrayOfInt1;
    }
    int[] arrayOfInt2 = paramArrayOfInt1.length;
    int i1 = paramArrayOfInt2.length;
    int[] arrayOfInt3 = new int[arrayOfInt2];
    long l1 = 0L;
    while (i1 > 0)
    {
      l1 = (paramArrayOfInt1[(--arrayOfInt2)] & 0xFFFFFFFF) + (paramArrayOfInt2[(--i1)] & 0xFFFFFFFF) + (l1 >>> 32);
      arrayOfInt3[arrayOfInt2] = ((int)l1);
    }
    for (paramArrayOfInt2 = l1 >>> 32 != 0L ? 1 : 0; (arrayOfInt2 > 0) && (paramArrayOfInt2 != 0); paramArrayOfInt2 = (arrayOfInt3[(--arrayOfInt2)] = paramArrayOfInt1[arrayOfInt2] + 1) == 0 ? 1 : 0);
    while (arrayOfInt2 > 0)
      arrayOfInt3[(--arrayOfInt2)] = paramArrayOfInt1[arrayOfInt2];
    if (paramArrayOfInt2 != 0)
    {
      paramArrayOfInt2 = new int[paramArrayOfInt1 = arrayOfInt3.length + 1];
      for (arrayOfInt2 = 1; arrayOfInt2 < paramArrayOfInt1; arrayOfInt2++)
        paramArrayOfInt2[arrayOfInt2] = arrayOfInt3[(arrayOfInt2 - 1)];
      paramArrayOfInt2[0] = 1;
      arrayOfInt3 = paramArrayOfInt2;
    }
    return arrayOfInt3;
  }

  public BigInteger subtract(BigInteger paramBigInteger)
  {
    if (paramBigInteger.c == 0)
      return this;
    if (c == 0)
      return paramBigInteger.negate();
    if (paramBigInteger.c != c)
      return new BigInteger(a(a, paramBigInteger.a), c);
    int i1;
    if ((i1 = c(a, paramBigInteger.a)) == 0)
      return ZERO;
    paramBigInteger = c(paramBigInteger = i1 > 0 ? b(a, paramBigInteger.a) : b(paramBigInteger.a, a));
    return new BigInteger(paramBigInteger, i1 * c);
  }

  private static int[] b(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i1;
    int[] arrayOfInt = new int[i1 = paramArrayOfInt1.length];
    int i2 = paramArrayOfInt2.length;
    long l1 = 0L;
    while (i2 > 0)
    {
      l1 = (paramArrayOfInt1[(--i1)] & 0xFFFFFFFF) - (paramArrayOfInt2[(--i2)] & 0xFFFFFFFF) + (l1 >> 32);
      arrayOfInt[i1] = ((int)l1);
    }
    for (paramArrayOfInt2 = l1 >> 32 != 0L ? 1 : 0; (i1 > 0) && (paramArrayOfInt2 != 0); paramArrayOfInt2 = (arrayOfInt[(--i1)] = paramArrayOfInt1[i1] - 1) == -1 ? 1 : 0);
    while (i1 > 0)
      arrayOfInt[(--i1)] = paramArrayOfInt1[i1];
    return arrayOfInt;
  }

  public BigInteger multiply(BigInteger paramBigInteger)
  {
    if ((c == 0) || (paramBigInteger.c == 0))
      return ZERO;
    int[] arrayOfInt = c(arrayOfInt = a(a, a.length, paramBigInteger.a, paramBigInteger.a.length, null));
    return new BigInteger(arrayOfInt, c * paramBigInteger.c);
  }

  private static int[] a(int[] paramArrayOfInt1, int paramInt1, int[] paramArrayOfInt2, int paramInt2, int[] paramArrayOfInt3)
  {
    int i1 = paramInt1 - 1;
    int i2 = paramInt2 - 1;
    if ((paramArrayOfInt3 == null) || (paramArrayOfInt3.length < paramInt1 + paramInt2))
      paramArrayOfInt3 = new int[paramInt1 + paramInt2];
    long l1 = 0L;
    paramInt1 = i2;
    for (paramInt2 = i2 + 1 + i1; paramInt1 >= 0; paramInt2--)
    {
      long l2 = (paramArrayOfInt2[paramInt1] & 0xFFFFFFFF) * (paramArrayOfInt1[i1] & 0xFFFFFFFF) + l1;
      paramArrayOfInt3[paramInt2] = ((int)l2);
      l1 = l2 >>> 32;
      paramInt1--;
    }
    paramArrayOfInt3[i1] = ((int)l1);
    for (paramInt1 = i1 - 1; paramInt1 >= 0; paramInt1--)
    {
      l1 = 0L;
      paramInt2 = i2;
      for (int i3 = i2 + 1 + paramInt1; paramInt2 >= 0; i3--)
      {
        long l3 = (paramArrayOfInt2[paramInt2] & 0xFFFFFFFF) * (paramArrayOfInt1[paramInt1] & 0xFFFFFFFF) + (paramArrayOfInt3[i3] & 0xFFFFFFFF) + l1;
        paramArrayOfInt3[i3] = ((int)l3);
        l1 = l3 >>> 32;
        paramInt2--;
      }
      paramArrayOfInt3[paramInt1] = ((int)l1);
    }
    return paramArrayOfInt3;
  }

  private static final int[] a(int[] paramArrayOfInt1, int paramInt, int[] paramArrayOfInt2)
  {
    int i1 = paramInt << 1;
    if ((paramArrayOfInt2 == null) || (paramArrayOfInt2.length < i1))
      paramArrayOfInt2 = new int[i1];
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    while (i3 < paramInt)
    {
      long l1;
      long l2 = (l1 = paramArrayOfInt1[i3] & 0xFFFFFFFF) * l1;
      paramArrayOfInt2[(i4++)] = (i2 << 31 | (int)(l2 >>> 33));
      paramArrayOfInt2[(i4++)] = ((int)(l2 >>> 1));
      i2 = (int)l2;
      i3++;
    }
    i3 = paramInt;
    for (i4 = 1; i3 > 0; i4 += 2)
    {
      int i5 = paramArrayOfInt1[(i3 - 1)];
      i5 = a(paramArrayOfInt2, paramArrayOfInt1, i4, i3 - 1, i5);
      a(paramArrayOfInt2, i4 - 1, i3, i5);
      i3--;
    }
    a(paramArrayOfInt2, i1, 1);
    paramArrayOfInt2[(i1 - 1)] |= paramArrayOfInt1[(paramInt - 1)] & 0x1;
    return paramArrayOfInt2;
  }

  public BigInteger divide(BigInteger paramBigInteger)
  {
    b localb1 = new b();
    b localb2 = new b();
    b localb3 = new b(a);
    b localb4 = new b(paramBigInteger.a);
    localb3.a(localb4, localb1, localb2);
    return new BigInteger(localb1, c * paramBigInteger.c);
  }

  public BigInteger[] divideAndRemainder(BigInteger paramBigInteger)
  {
    BigInteger[] arrayOfBigInteger = new BigInteger[2];
    b localb1 = new b();
    b localb2 = new b();
    b localb3 = new b(a);
    b localb4 = new b(paramBigInteger.a);
    localb3.a(localb4, localb1, localb2);
    arrayOfBigInteger[0] = new BigInteger(localb1, c * paramBigInteger.c);
    arrayOfBigInteger[1] = new BigInteger(localb2, c);
    return arrayOfBigInteger;
  }

  public BigInteger remainder(BigInteger paramBigInteger)
  {
    b localb1 = new b();
    b localb2 = new b();
    b localb3 = new b(a);
    paramBigInteger = new b(paramBigInteger.a);
    localb3.a(paramBigInteger, localb1, localb2);
    return new BigInteger(localb2, c);
  }

  public BigInteger pow(int paramInt)
  {
    if (paramInt < 0)
      throw new ArithmeticException("Negative exponent");
    if (c == 0)
    {
      if (paramInt == 0)
        return ONE;
      return this;
    }
    int i1 = (c < 0) && ((paramInt & 0x1) == 1) ? -1 : 1;
    int[] arrayOfInt1 = a;
    int[] arrayOfInt2 = { 1 };
    while (paramInt != 0)
    {
      if ((paramInt & 0x1) == 1)
        arrayOfInt2 = c(arrayOfInt2 = a(arrayOfInt2, arrayOfInt2.length, arrayOfInt1, arrayOfInt1.length, null));
      if (paramInt >>>= 1 != 0)
        arrayOfInt1 = c(arrayOfInt1 = a(arrayOfInt1, arrayOfInt1.length, null));
    }
    return new BigInteger(arrayOfInt2, i1);
  }

  public BigInteger gcd(BigInteger paramBigInteger)
  {
    if (paramBigInteger.c == 0)
      return abs();
    if (c == 0)
      return paramBigInteger.abs();
    b localb = new b(this);
    paramBigInteger = new b(paramBigInteger);
    paramBigInteger = localb.c(paramBigInteger);
    return new BigInteger(paramBigInteger, 1);
  }

  static void a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0))
      return;
    int i1 = 32 - paramInt2;
    int i2 = 0;
    int i3 = paramArrayOfInt[0];
    int i4 = paramInt1 + 0 - 1;
    while (i2 < i4)
    {
      int i5 = i3;
      i3 = paramArrayOfInt[(i2 + 1)];
      paramArrayOfInt[i2] = (i5 << paramInt2 | i3 >>> i1);
      i2++;
    }
    paramArrayOfInt[(paramInt1 - 1)] <<= paramInt2;
  }

  public BigInteger abs()
  {
    if (c >= 0)
      return this;
    return negate();
  }

  public BigInteger negate()
  {
    return new BigInteger(a, -c);
  }

  public int signum()
  {
    return c;
  }

  public BigInteger mod(BigInteger paramBigInteger)
  {
    if (paramBigInteger.c <= 0)
      throw new ArithmeticException("BigInteger: modulus not positive");
    BigInteger localBigInteger;
    if ((localBigInteger = remainder(paramBigInteger)).c >= 0)
      return localBigInteger;
    return localBigInteger.add(paramBigInteger);
  }

  public BigInteger modPow(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    if (paramBigInteger2.c <= 0)
      throw new ArithmeticException("BigInteger: modulus not positive");
    if (paramBigInteger1.c == 0)
    {
      if (paramBigInteger2.equals(ONE))
        return ZERO;
      return ONE;
    }
    if (equals(ONE))
    {
      if (paramBigInteger2.equals(ONE))
        return ZERO;
      return ONE;
    }
    if ((equals(ZERO)) && (paramBigInteger1.c >= 0))
      return ZERO;
    if ((equals(k[1])) && (!paramBigInteger1.testBit(0)))
    {
      if (paramBigInteger2.equals(ONE))
        return ZERO;
      return ONE;
    }
    int i1;
    if ((i1 = paramBigInteger1.c < 0 ? 1 : 0) != 0)
      paramBigInteger1 = paramBigInteger1.negate();
    BigInteger localBigInteger1 = (c < 0) || (compareTo(paramBigInteger2) >= 0) ? mod(paramBigInteger2) : this;
    if (paramBigInteger2.testBit(0))
    {
      paramBigInteger1 = localBigInteger1.a(paramBigInteger1, paramBigInteger2);
    }
    else
    {
      int i2 = paramBigInteger2.getLowestSetBit();
      BigInteger localBigInteger3 = paramBigInteger2.shiftRight(i2);
      BigInteger localBigInteger4 = ONE.shiftLeft(i2);
      BigInteger localBigInteger5 = (c < 0) || (compareTo(localBigInteger3) >= 0) ? mod(localBigInteger3) : this;
      localBigInteger5 = localBigInteger3.equals(ONE) ? ZERO : localBigInteger5.a(paramBigInteger1, localBigInteger3);
      paramBigInteger1 = localBigInteger1.a(paramBigInteger1, i2);
      localBigInteger1 = localBigInteger4.modInverse(localBigInteger3);
      BigInteger localBigInteger2 = localBigInteger3.modInverse(localBigInteger4);
      paramBigInteger1 = localBigInteger5.multiply(localBigInteger4).multiply(localBigInteger1).add(paramBigInteger1.multiply(localBigInteger3).multiply(localBigInteger2)).mod(paramBigInteger2);
    }
    if (i1 != 0)
      return paramBigInteger1.modInverse(paramBigInteger2);
    return paramBigInteger1;
  }

  private BigInteger a(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    if (paramBigInteger1.equals(ONE))
      return this;
    if (c == 0)
      return ZERO;
    int[] arrayOfInt = (int[])a.clone();
    paramBigInteger1 = paramBigInteger1.a;
    int i3 = (paramBigInteger2 = paramBigInteger2.a).length;
    int i4 = 0;
    Object localObject4 = paramBigInteger1.length;
    Object localObject2 = paramBigInteger1;
    int i5 = localObject4 == 0 ? 0 : (localObject4 - 1 << 5) + b(localObject2[0]);
    while (i5 > m[i4])
      i4++;
    int i6;
    int[][] arrayOfInt1 = new int[i6 = 1 << i4][];
    for (int i7 = 0; i7 < i6; i7++)
      arrayOfInt1[i7] = new int[i3];
    i7 = -b.b(paramBigInteger2[(i3 - 1)]);
    Object localObject6 = i3 << 5;
    localObject4 = arrayOfInt.length;
    localObject2 = arrayOfInt;
    int i1 = localObject6 >>> 5;
    int i12 = localObject6 & 0x1F;
    int i14 = b(localObject2[0]);
    a((int[])localObject2, localObject4, i12);
    Object localObject1 = new int[i1 + localObject4];
    for (localObject6 = 0; localObject6 < localObject4; localObject6++)
      localObject1[localObject6] = localObject2[localObject6];
    a((int[])localObject1, localObject1.length, i12);
    localObject1 = new int[localObject1 + localObject4 + 1];
    for (Object localObject7 = 0; localObject7 < localObject4; localObject7++)
      localObject1[localObject7] = localObject2[localObject7];
    int i10 = 32 - i12;
    int i9 = localObject1.length;
    localObject2 = localObject1;
    i12 = 32 - i10;
    i9 -= 1;
    i14 = localObject2[i9];
    while (i9 > 0)
    {
      i15 = i14;
      i14 = localObject2[(i9 - 1)];
      localObject2[i9] = (i14 << i12 | i15 >>> i10);
      i9--;
    }
    localObject2[0] >>>= i10;
    localObject1 = i12 <= 32 - i14 ? localObject1 : localObject6 <= 32 - i14 ? localObject2 : localObject1;
    localObject2 = new b();
    Object localObject5 = new b();
    b localb = new b((int[])localObject1);
    Object localObject8 = new b(paramBigInteger2);
    localb.a((b)localObject8, (b)localObject2, (b)localObject5);
    localObject5 = new int[(localObject2 = localObject5).b];
    int i11 = 0;
    localObject5[i11] = localObject2.a[(localObject2.c + i11)];
    arrayOfInt1[0] = localObject5;
    if (arrayOfInt1[0].length < i3)
    {
      int i8 = i3 - arrayOfInt1[0].length;
      localObject5 = new int[i3];
      for (i11 = 0; i11 < arrayOfInt1[0].length; i11++)
        localObject5[(i11 + i8)] = arrayOfInt1[0][i11];
      arrayOfInt1[0] = localObject5;
    }
    Object localObject3 = a(localObject3 = a(arrayOfInt1[0], i3, null), paramBigInteger2, i3, i7);
    localObject5 = new int[i3];
    for (i11 = 0; i11 < i3; i11++)
      localObject5[i11] = localObject3[i11];
    for (i11 = 1; i11 < i6; i11++)
    {
      localObject8 = a((int[])localObject5, i3, arrayOfInt1[(i11 - 1)], i3, null);
      arrayOfInt1[i11] = a((int[])localObject8, paramBigInteger2, i3, i7);
    }
    i11 = 1 << (i5 - 1 & 0x1F);
    int i13 = 0;
    i14 = paramBigInteger1.length;
    int i15 = 0;
    for (int i16 = 0; i16 <= i4; i16++)
    {
      i13 = i13 << 1 | ((paramBigInteger1[i15] & i11) != 0 ? 1 : 0);
      if (i11 >>>= 1 == 0)
      {
        i15++;
        i11 = -2147483648;
        i14--;
      }
    }
    i5--;
    int i17 = 1;
    for (i16 = i5 - i4; (i13 & 0x1) == 0; i16++)
      i13 >>>= 1;
    [I local[I = arrayOfInt1[(i13 >>> 1)];
    i13 = 0;
    if (i16 == i5)
      i17 = 0;
    while (true)
    {
      i5--;
      i13 <<= 1;
      if (i14 != 0)
      {
        i13 |= ((paramBigInteger1[i15] & i11) != 0 ? 1 : 0);
        if (i11 >>>= 1 == 0)
        {
          i15++;
          i11 = -2147483648;
          i14--;
        }
      }
      if ((i13 & i6) != 0)
      {
        for (i16 = i5 - i4; (i13 & 0x1) == 0; i16++)
          i13 >>>= 1;
        local[I = arrayOfInt1[(i13 >>> 1)];
        i13 = 0;
      }
      if (i5 == i16)
        if (i17 != 0)
        {
          localObject3 = (int[])local[I.clone();
          i17 = 0;
        }
        else
        {
          localObject5 = localObject1 = a(localObject1 = a(localObject5 = localObject3, i3, local[I, i3, (int[])localObject1), paramBigInteger2, i3, i7);
          localObject1 = localObject3;
          localObject3 = localObject5;
        }
      if (i5 == 0)
        break;
      if (i17 == 0)
      {
        localObject5 = localObject1 = a(localObject1 = a(localObject5 = localObject3, i3, (int[])localObject1), paramBigInteger2, i3, i7);
        localObject1 = localObject3;
        localObject3 = localObject5;
      }
    }
    paramBigInteger1 = new int[2 * i3];
    for (int i2 = 0; i2 < i3; i2++)
      paramBigInteger1[(i2 + i3)] = localObject3[i2];
    localObject3 = a(paramBigInteger1, paramBigInteger2, i3, i7);
    paramBigInteger1 = new int[i3];
    for (i2 = 0; i2 < i3; i2++)
      paramBigInteger1[i2] = localObject3[i2];
    return new BigInteger(1, paramBigInteger1);
  }

  private static int[] a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt1, int paramInt2)
  {
    int i1 = 0;
    int i2 = paramInt1;
    int i3 = 0;
    do
    {
      int i4 = paramArrayOfInt1[(paramArrayOfInt1.length - 1 - i3)];
      i4 = a(paramArrayOfInt1, paramArrayOfInt2, i3, paramInt1, paramInt2 * i4);
      i1 += a(paramArrayOfInt1, i3, paramInt1, i4);
      i3++;
      i2--;
    }
    while (i2 > 0);
    while (i1 > 0)
      i1 += a(paramArrayOfInt1, paramArrayOfInt2, paramInt1);
    while (true)
    {
      i2 = paramInt1;
      int[] arrayOfInt = paramArrayOfInt2;
      paramInt2 = paramArrayOfInt1;
      long l1;
      long l2;
      for (i3 = 0; i3 < i2; i3++)
      {
        l1 = paramInt2[i3] & 0xFFFFFFFF;
        l2 = arrayOfInt[i3] & 0xFFFFFFFF;
      }
      if ((l1 > l2 ? 1 : l1 < l2 ? -1 : 0) < 0)
        break;
      a(paramArrayOfInt1, paramArrayOfInt2, paramInt1);
    }
    return paramArrayOfInt1;
  }

  private static int a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
  {
    long l1 = 0L;
    while (true)
    {
      paramInt--;
      if (paramInt < 0)
        break;
      l1 = (paramArrayOfInt1[paramInt] & 0xFFFFFFFF) - (paramArrayOfInt2[paramInt] & 0xFFFFFFFF) + (l1 >> 32);
      paramArrayOfInt1[paramInt] = ((int)l1);
    }
    return (int)(l1 >> 32);
  }

  private static int a(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt1, int paramInt2, int paramInt3)
  {
    long l1 = paramInt3 & 0xFFFFFFFF;
    long l2 = 0L;
    paramInt1 = paramArrayOfInt1.length - paramInt1 - 1;
    paramInt2 -= 1;
    while (paramInt2 >= 0)
    {
      long l3 = (paramArrayOfInt2[paramInt2] & 0xFFFFFFFF) * l1 + (paramArrayOfInt1[paramInt1] & 0xFFFFFFFF) + l2;
      paramArrayOfInt1[(paramInt1--)] = ((int)l3);
      l2 = l3 >>> 32;
      paramInt2--;
    }
    return (int)l2;
  }

  private static int a(int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3)
  {
    paramInt1 = paramArrayOfInt.length - 1 - paramInt2 - paramInt1;
    long l1 = (paramArrayOfInt[paramInt1] & 0xFFFFFFFF) + (paramInt3 & 0xFFFFFFFF);
    paramArrayOfInt[paramInt1] = ((int)l1);
    if (l1 >>> 32 == 0L)
      return 0;
    do
    {
      paramInt2--;
      if (paramInt2 < 0)
        break;
      paramInt1--;
      if (paramInt1 < 0)
        return 1;
      paramArrayOfInt[paramInt1] += 1;
    }
    while (paramArrayOfInt[paramInt1] == 0);
    return 0;
    return 1;
  }

  private BigInteger a(BigInteger paramBigInteger, int paramInt)
  {
    BigInteger localBigInteger = valueOf(1L);
    Object localObject = e(paramInt);
    int i1 = 0;
    int i2 = paramBigInteger.bitLength();
    if (testBit(0))
      i2 = paramInt - 1 < i2 ? paramInt - 1 : i2;
    while (i1 < i2)
    {
      if (paramBigInteger.testBit(i1))
        localBigInteger = localBigInteger.multiply((BigInteger)localObject).e(paramInt);
      i1++;
      if (i1 < i2)
      {
        localObject = a(((BigInteger)localObject).a, ((BigInteger)localObject).a.length, null);
        localObject = ((localObject = localObject).c == 0 ? ZERO : new BigInteger(c((int[])localObject), 1)).e(paramInt);
      }
    }
    return localBigInteger;
  }

  private BigInteger e(int paramInt)
  {
    if (bitLength() <= paramInt)
      return this;
    int i1;
    int[] arrayOfInt = new int[i1 = (paramInt + 31) / 32];
    for (int i2 = 0; i2 < i1; i2++)
      arrayOfInt[i2] = a[(i2 + (a.length - i1))];
    i2 = (i1 << 5) - paramInt;
    int tmp65_64 = 0;
    int[] tmp65_63 = arrayOfInt;
    tmp65_63[tmp65_64] = ((int)(tmp65_63[tmp65_64] & (1L << 32 - i2) - 1L));
    if (arrayOfInt[0] == 0)
      return new BigInteger(1, arrayOfInt);
    return new BigInteger(arrayOfInt, 1);
  }

  public BigInteger modInverse(BigInteger paramBigInteger)
  {
    if (paramBigInteger.c != 1)
      throw new ArithmeticException("BigInteger: modulus not positive");
    if (paramBigInteger.equals(ONE))
      return ZERO;
    Object localObject = this;
    if ((c < 0) || (c(a, paramBigInteger.a) >= 0))
      localObject = mod(paramBigInteger);
    if (((BigInteger)localObject).equals(ONE))
      return ONE;
    localObject = new b((BigInteger)localObject);
    paramBigInteger = new b(paramBigInteger);
    paramBigInteger = ((b)localObject).d(paramBigInteger);
    return new BigInteger(paramBigInteger, 1);
  }

  public BigInteger shiftLeft(int paramInt)
  {
    if (c == 0)
      return ZERO;
    if (paramInt == 0)
      return this;
    if (paramInt < 0)
      return shiftRight(-paramInt);
    int i1 = paramInt >>> 5;
    paramInt &= 31;
    int[] arrayOfInt2 = a.length;
    int[] arrayOfInt1;
    if (paramInt == 0)
    {
      arrayOfInt1 = new int[arrayOfInt2 + i1];
      for (int[] arrayOfInt3 = 0; arrayOfInt3 < arrayOfInt2; arrayOfInt3++)
        arrayOfInt1[arrayOfInt3] = a[arrayOfInt3];
    }
    else
    {
      int i2 = 0;
      int i3 = 32 - paramInt;
      if ((i4 = a[0] >>> i3) != 0)
      {
        i2++;
        (arrayOfInt1 = new int[arrayOfInt2 + arrayOfInt1 + 1])[0] = i4;
      }
      else
      {
        arrayOfInt1 = new int[arrayOfInt2 + arrayOfInt1];
      }
      int i4 = 0;
      while (i4 < arrayOfInt2 - 1)
        arrayOfInt1[(i2++)] = (a[(i4++)] << paramInt | a[i4] >>> i3);
      arrayOfInt1[i2] = (a[i4] << paramInt);
    }
    return new BigInteger(arrayOfInt1, c);
  }

  public BigInteger shiftRight(int paramInt)
  {
    if (paramInt == 0)
      return this;
    if (paramInt < 0)
      return shiftLeft(-paramInt);
    int i1 = paramInt >>> 5;
    paramInt &= 31;
    int i2 = a.length;
    if (i1 >= i2)
    {
      if (c >= 0)
        return ZERO;
      return k[1];
    }
    int i3;
    Object localObject;
    int i4;
    int i5;
    if (paramInt == 0)
    {
      localObject = new int[i3 = i2 - i1];
      for (i4 = 0; i4 < i3; i4++)
        localObject[i4] = a[i4];
    }
    else
    {
      i3 = 0;
      if ((i4 = a[0] >>> paramInt) != 0)
      {
        i3++;
        (localObject = new int[i2 - i1])[0] = i4;
      }
      else
      {
        localObject = new int[i2 - i1 - 1];
      }
      i5 = 32 - paramInt;
      i4 = 0;
      while (i4 < i2 - i1 - 1)
        localObject[(i3++)] = (a[(i4++)] << i5 | a[i4] >>> paramInt);
    }
    if (c < 0)
    {
      i3 = 0;
      i4 = i2 - 1;
      i5 = i2 - i1;
      while ((i4 >= i5) && (i3 == 0))
      {
        i3 = a[i4] != 0 ? 1 : 0;
        i4--;
      }
      if ((i3 == 0) && (paramInt != 0))
        i3 = a[(i5 - 1)] << 32 - paramInt != 0 ? 1 : 0;
      if (i3 != 0)
      {
        paramInt = (int)localObject;
        i1 = 0;
        for (i2 = paramInt.length - 1; (i2 >= 0) && (i1 == 0); i2--)
          i1 = paramInt[i2] += 1;
        if (i1 == 0)
          (paramInt = new int[paramInt.length + 1])[0] = 1;
        localObject = paramInt;
      }
    }
    return new BigInteger((int[])localObject, c);
  }

  public BigInteger and(BigInteger paramBigInteger)
  {
    int[] arrayOfInt = new int[Math.max(a(), paramBigInteger.a())];
    for (int i1 = 0; i1 < arrayOfInt.length; i1++)
      arrayOfInt[i1] = (g(arrayOfInt.length - i1 - 1) & paramBigInteger.g(arrayOfInt.length - i1 - 1));
    return a(arrayOfInt);
  }

  public BigInteger or(BigInteger paramBigInteger)
  {
    int[] arrayOfInt = new int[Math.max(a(), paramBigInteger.a())];
    for (int i1 = 0; i1 < arrayOfInt.length; i1++)
      arrayOfInt[i1] = (g(arrayOfInt.length - i1 - 1) | paramBigInteger.g(arrayOfInt.length - i1 - 1));
    return a(arrayOfInt);
  }

  public BigInteger xor(BigInteger paramBigInteger)
  {
    int[] arrayOfInt = new int[Math.max(a(), paramBigInteger.a())];
    for (int i1 = 0; i1 < arrayOfInt.length; i1++)
      arrayOfInt[i1] = (g(arrayOfInt.length - i1 - 1) ^ paramBigInteger.g(arrayOfInt.length - i1 - 1));
    return a(arrayOfInt);
  }

  public BigInteger not()
  {
    int[] arrayOfInt = new int[a()];
    for (int i1 = 0; i1 < arrayOfInt.length; i1++)
      arrayOfInt[i1] = (g(arrayOfInt.length - i1 - 1) ^ 0xFFFFFFFF);
    return a(arrayOfInt);
  }

  public BigInteger andNot(BigInteger paramBigInteger)
  {
    int[] arrayOfInt = new int[Math.max(a(), paramBigInteger.a())];
    for (int i1 = 0; i1 < arrayOfInt.length; i1++)
      arrayOfInt[i1] = (g(arrayOfInt.length - i1 - 1) & (paramBigInteger.g(arrayOfInt.length - i1 - 1) ^ 0xFFFFFFFF));
    return a(arrayOfInt);
  }

  public boolean testBit(int paramInt)
  {
    if (paramInt < 0)
      throw new ArithmeticException("Negative bit address");
    return (g(paramInt / 32) & 1 << paramInt % 32) != 0;
  }

  public BigInteger setBit(int paramInt)
  {
    if (paramInt < 0)
      throw new ArithmeticException("Negative bit address");
    int i1 = paramInt / 32;
    int[] arrayOfInt = new int[Math.max(a(), i1 + 2)];
    for (int i2 = 0; i2 < arrayOfInt.length; i2++)
      arrayOfInt[(arrayOfInt.length - i2 - 1)] = g(i2);
    arrayOfInt[(arrayOfInt.length - i1 - 1)] |= 1 << paramInt % 32;
    return a(arrayOfInt);
  }

  public BigInteger clearBit(int paramInt)
  {
    if (paramInt < 0)
      throw new ArithmeticException("Negative bit address");
    int i1 = paramInt / 32;
    int[] arrayOfInt = new int[Math.max(a(), (paramInt + 1) / 32 + 1)];
    for (int i2 = 0; i2 < arrayOfInt.length; i2++)
      arrayOfInt[(arrayOfInt.length - i2 - 1)] = g(i2);
    arrayOfInt[(arrayOfInt.length - i1 - 1)] &= (1 << paramInt % 32 ^ 0xFFFFFFFF);
    return a(arrayOfInt);
  }

  public BigInteger flipBit(int paramInt)
  {
    if (paramInt < 0)
      throw new ArithmeticException("Negative bit address");
    int i1 = paramInt / 32;
    int[] arrayOfInt = new int[Math.max(a(), i1 + 2)];
    for (int i2 = 0; i2 < arrayOfInt.length; i2++)
      arrayOfInt[(arrayOfInt.length - i2 - 1)] = g(i2);
    arrayOfInt[(arrayOfInt.length - i1 - 1)] ^= 1 << paramInt % 32;
    return a(arrayOfInt);
  }

  public int getLowestSetBit()
  {
    if (f == -2)
      if (c == 0)
      {
        f = -1;
      }
      else
      {
        int i2;
        for (int i1 = 0; (i2 = g(i1)) == 0; i1++);
        f = ((i1 << 5) + c(i2));
      }
    return f;
  }

  public int bitLength()
  {
    if (e == -1)
      if (c == 0)
      {
        e = 0;
      }
      else
      {
        int i1 = (a.length - 1 << 5) + b(a[0]);
        if (c < 0)
        {
          int i2 = f(a[0]) == 1 ? 1 : 0;
          for (int i3 = 1; (i3 < a.length) && (i2 != 0); i3++)
            i2 = a[i3] == 0 ? 1 : 0;
          e = (i2 != 0 ? i1 - 1 : i1);
        }
        else
        {
          e = i1;
        }
      }
    return e;
  }

  static int b(int paramInt)
  {
    if (paramInt < 32768)
    {
      if (paramInt < 128)
      {
        if (paramInt < 8)
        {
          if (paramInt < 2)
          {
            if (paramInt <= 0)
            {
              if (paramInt < 0)
                return 32;
              return 0;
            }
            return 1;
          }
          if (paramInt < 4)
            return 2;
          return 3;
        }
        if (paramInt < 32)
        {
          if (paramInt < 16)
            return 4;
          return 5;
        }
        if (paramInt < 64)
          return 6;
        return 7;
      }
      if (paramInt < 2048)
      {
        if (paramInt < 512)
        {
          if (paramInt < 256)
            return 8;
          return 9;
        }
        if (paramInt < 1024)
          return 10;
        return 11;
      }
      if (paramInt < 8192)
      {
        if (paramInt < 4096)
          return 12;
        return 13;
      }
      if (paramInt < 16384)
        return 14;
      return 15;
    }
    if (paramInt < 8388608)
    {
      if (paramInt < 524288)
      {
        if (paramInt < 131072)
        {
          if (paramInt < 65536)
            return 16;
          return 17;
        }
        if (paramInt < 262144)
          return 18;
        return 19;
      }
      if (paramInt < 2097152)
      {
        if (paramInt < 1048576)
          return 20;
        return 21;
      }
      if (paramInt < 4194304)
        return 22;
      return 23;
    }
    if (paramInt < 134217728)
    {
      if (paramInt < 33554432)
      {
        if (paramInt < 16777216)
          return 24;
        return 25;
      }
      if (paramInt < 67108864)
        return 26;
      return 27;
    }
    if (paramInt < 536870912)
    {
      if (paramInt < 268435456)
        return 28;
      return 29;
    }
    if (paramInt < 1073741824)
      return 30;
    return 31;
  }

  public int bitCount()
  {
    if (d == -1)
    {
      int i1 = 0;
      for (int i2 = 0; i2 < a.length; i2++)
        i1 += f(a[i2]);
      if (c < 0)
      {
        i2 = 0;
        for (int i3 = a.length - 1; a[i3] == 0; i3--)
          i2 += 32;
        i2 += c(a[i3]);
        d = (i1 + i2 - 1);
      }
      else
      {
        d = i1;
      }
    }
    return d;
  }

  private static int f(int paramInt)
  {
    return (paramInt = (paramInt = (paramInt = (paramInt = (paramInt -= ((0xAAAAAAAA & paramInt) >>> 1) & 0x33333333) + (paramInt >>> 2 & 0x33333333)) + (paramInt >>> 4) & 0xF0F0F0F) + (paramInt >>> 8)) + (paramInt >>> 16)) & 0xFF;
  }

  static int c(int paramInt)
  {
    if ((i1 = paramInt & 0xFF) != 0)
      return b[i1];
    if ((i1 = paramInt >>> 8 & 0xFF) != 0)
      return b[i1] + 8;
    if ((i1 = paramInt >>> 16 & 0xFF) != 0)
      return b[i1] + 16;
    int i1 = paramInt >>> 24;
    return b[i1] + 24;
  }

  public boolean isProbablePrime(int paramInt)
  {
    if (paramInt <= 0)
      return true;
    BigInteger localBigInteger;
    if ((localBigInteger = abs()).equals(l))
      return true;
    if ((!localBigInteger.testBit(0)) || (localBigInteger.equals(ONE)))
      return false;
    return localBigInteger.a(paramInt);
  }

  public int compareTo(BigInteger paramBigInteger)
  {
    if (c == paramBigInteger.c)
      return c * c(a, paramBigInteger.a);
    if (c > paramBigInteger.c)
      return 1;
    return -1;
  }

  public int compareTo(Object paramObject)
  {
    return compareTo((BigInteger)paramObject);
  }

  private static int c(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    if (paramArrayOfInt1.length < paramArrayOfInt2.length)
      return -1;
    if (paramArrayOfInt1.length > paramArrayOfInt2.length)
      return 1;
    for (int i1 = 0; i1 < paramArrayOfInt1.length; i1++)
    {
      long l1 = paramArrayOfInt1[i1] & 0xFFFFFFFF;
      long l2 = paramArrayOfInt2[i1] & 0xFFFFFFFF;
      if (l1 < l2)
        return -1;
      if (l1 > l2)
        return 1;
    }
    return 0;
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof BigInteger))
      return false;
    if (((paramObject = (BigInteger)paramObject).c != c) || (paramObject.a.length != a.length))
      return false;
    for (int i1 = 0; i1 < a.length; i1++)
      if (paramObject.a[i1] != a[i1])
        return false;
    return true;
  }

  public BigInteger min(BigInteger paramBigInteger)
  {
    if (compareTo(paramBigInteger) < 0)
      return this;
    return paramBigInteger;
  }

  public BigInteger max(BigInteger paramBigInteger)
  {
    if (compareTo(paramBigInteger) > 0)
      return this;
    return paramBigInteger;
  }

  public int hashCode()
  {
    int i1 = 0;
    for (int i2 = 0; i2 < a.length; i2++)
      i1 = (int)(i1 * 31 + (a[i2] & 0xFFFFFFFF));
    return i1 * c;
  }

  public String toString(int paramInt)
  {
    if (c == 0)
      return "0";
    if ((paramInt < 2) || (paramInt > 36))
      paramInt = 10;
    int i1;
    String[] arrayOfString = new String[i1 = (4 * a.length + 6) / 7];
    Object localObject1 = abs();
    int i2 = 0;
    while (((BigInteger)localObject1).c != 0)
    {
      localObject2 = p[paramInt];
      Object localObject3 = new b();
      b localb1 = new b();
      b localb2 = new b(((BigInteger)localObject1).a);
      b localb3 = new b(((BigInteger)localObject2).a);
      localb2.a(localb3, (b)localObject3, localb1);
      localObject3 = new BigInteger((b)localObject3, ((BigInteger)localObject1).c * ((BigInteger)localObject2).c);
      localObject1 = new BigInteger(localb1, ((BigInteger)localObject1).c * ((BigInteger)localObject2).c);
      arrayOfString[(i2++)] = Long.toString(((BigInteger)localObject1).longValue(), paramInt);
      localObject1 = localObject3;
    }
    Object localObject2 = new StringBuffer(i2 * o[paramInt] + 1);
    if (c < 0)
      ((StringBuffer)localObject2).append('-');
    ((StringBuffer)localObject2).append(arrayOfString[(i2 - 1)]);
    for (int i3 = i2 - 2; i3 >= 0; i3--)
    {
      int i4;
      if ((i4 = o[paramInt] - arrayOfString[i3].length()) != 0)
        ((StringBuffer)localObject2).append(n[i4]);
      ((StringBuffer)localObject2).append(arrayOfString[i3]);
    }
    return ((StringBuffer)localObject2).toString();
  }

  public String toString()
  {
    return toString(10);
  }

  public byte[] toByteArray()
  {
    int i1;
    byte[] arrayOfByte = new byte[i1 = bitLength() / 8 + 1];
    i1 -= 1;
    int i2 = 4;
    int i3 = 0;
    int i4 = 0;
    while (i1 >= 0)
    {
      if (i2 == 4)
      {
        i3 = g(i4++);
        i2 = 1;
      }
      else
      {
        i3 >>>= 8;
        i2++;
      }
      arrayOfByte[i1] = ((byte)i3);
      i1--;
    }
    return arrayOfByte;
  }

  public int intValue()
  {
    int i1;
    return i1 = g(0);
  }

  public long longValue()
  {
    long l1 = 0L;
    for (int i1 = 1; i1 >= 0; i1--)
      l1 = (l1 << 32) + (g(i1) & 0xFFFFFFFF);
    return l1;
  }

  public float floatValue()
  {
    return Float.valueOf(toString()).floatValue();
  }

  public double doubleValue()
  {
    return Double.valueOf(toString()).doubleValue();
  }

  private static int[] b(int[] paramArrayOfInt)
  {
    for (int i1 = 0; (i1 < paramArrayOfInt.length) && (paramArrayOfInt[i1] == 0); i1++);
    int[] arrayOfInt = new int[paramArrayOfInt.length - i1];
    for (int i2 = 0; i2 < paramArrayOfInt.length - i1; i2++)
      arrayOfInt[i2] = paramArrayOfInt[(i1 + i2)];
    return arrayOfInt;
  }

  private static int[] c(int[] paramArrayOfInt)
  {
    for (int i1 = 0; (i1 < paramArrayOfInt.length) && (paramArrayOfInt[i1] == 0); i1++);
    if (i1 > 0)
    {
      int[] arrayOfInt = new int[paramArrayOfInt.length - i1];
      for (int i2 = 0; i2 < paramArrayOfInt.length - i1; i2++)
        arrayOfInt[i2] = paramArrayOfInt[(i1 + i2)];
      return arrayOfInt;
    }
    return paramArrayOfInt;
  }

  private static int[] a(byte[] paramArrayOfByte)
  {
    int i1 = paramArrayOfByte.length;
    for (int i2 = 0; (i2 < paramArrayOfByte.length) && (paramArrayOfByte[i2] == 0); i2++);
    int i3;
    int[] arrayOfInt = new int[i3 = (i1 - i2 + 3) / 4];
    i1 -= 1;
    i3 -= 1;
    while (i3 >= 0)
    {
      arrayOfInt[i3] = (paramArrayOfByte[(i1--)] & 0xFF);
      int i4 = i1 - i2 + 1;
      i4 = Math.min(3, i4);
      for (int i5 = 8; i5 <= i4 * 8; i5 += 8)
        arrayOfInt[i3] |= (paramArrayOfByte[(i1--)] & 0xFF) << i5;
      i3--;
    }
    return arrayOfInt;
  }

  private static int[] b(byte[] paramArrayOfByte)
  {
    int i3 = paramArrayOfByte.length;
    for (int i1 = 0; (i1 < i3) && (paramArrayOfByte[i1] == -1); i1++);
    for (int i2 = i1; (i2 < i3) && (paramArrayOfByte[i2] == 0); i2++);
    i2 = i2 == i3 ? 1 : 0;
    int[] arrayOfInt = new int[i2 = (i3 - i1 + i2 + 3) / 4];
    i3 -= 1;
    i2 -= 1;
    while (i2 >= 0)
    {
      arrayOfInt[i2] = (paramArrayOfByte[(i3--)] & 0xFF);
      int i4;
      if ((i4 = Math.min(3, i3 - i1 + 1)) < 0)
        i4 = 0;
      for (int i5 = 8; i5 <= i4 * 8; i5 += 8)
        arrayOfInt[i2] |= (paramArrayOfByte[(i3--)] & 0xFF) << i5;
      i5 = -1 >>> 8 * (3 - i4);
      arrayOfInt[i2] = ((arrayOfInt[i2] ^ 0xFFFFFFFF) & i5);
      i2--;
    }
    for (i2 = arrayOfInt.length - 1; i2 >= 0; i2--)
    {
      arrayOfInt[i2] = ((int)((arrayOfInt[i2] & 0xFFFFFFFF) + 1L));
      if (arrayOfInt[i2] != 0)
        break;
    }
    return arrayOfInt;
  }

  private static int[] d(int[] paramArrayOfInt)
  {
    for (int i1 = 0; (i1 < paramArrayOfInt.length) && (paramArrayOfInt[i1] == -1); i1++);
    for (int i2 = i1; (i2 < paramArrayOfInt.length) && (paramArrayOfInt[i2] == 0); i2++);
    i2 = i2 == paramArrayOfInt.length ? 1 : 0;
    int[] arrayOfInt = new int[paramArrayOfInt.length - i1 + i2];
    for (int i3 = i1; i3 < paramArrayOfInt.length; i3++)
      arrayOfInt[(i3 - i1 + i2)] = (paramArrayOfInt[i3] ^ 0xFFFFFFFF);
    for (i3 = arrayOfInt.length - 1; ; i3--)
      if (arrayOfInt[i3] += 1 != 0)
        break;
    return arrayOfInt;
  }

  private int a()
  {
    return bitLength() / 32 + 1;
  }

  private int g(int paramInt)
  {
    if (paramInt < 0)
      return 0;
    if (paramInt >= a.length)
    {
      paramInt = this;
      if (c < 0)
        return -1;
      return 0;
    }
    int i1 = a[(a.length - paramInt - 1)];
    if (c >= 0)
      return i1;
    paramInt = this;
    if (g == -2)
    {
      int i2 = paramInt.a.length - 1;
      paramInt.g = (paramInt.a.length - i2 - 1);
    }
    if (paramInt <= paramInt.g)
      return -i1;
    return i1 ^ 0xFFFFFFFF;
  }

  private void readObject(ObjectInputStream paramObjectInputStream)
    throws IOException, ClassNotFoundException
  {
    paramObjectInputStream = paramObjectInputStream.readFields();
    c = paramObjectInputStream.get("signum", -2);
    Object localObject = (byte[])paramObjectInputStream.get("magnitude", null);
    if ((c < -1) || (c > 1))
    {
      localObject = "BigInteger: Invalid signum value";
      if (paramObjectInputStream.defaulted("signum"))
        localObject = "BigInteger: Signum not present in stream";
      throw new StreamCorruptedException((String)localObject);
    }
    if ((localObject.length == 0 ? 1 : 0) != (c == 0 ? 1 : 0))
    {
      localObject = "BigInteger: signum-magnitude mismatch";
      if (paramObjectInputStream.defaulted("magnitude"))
        localObject = "BigInteger: Magnitude not present in stream";
      throw new StreamCorruptedException((String)localObject);
    }
    d = (this.e = -1);
    f = -2;
    a = a((byte[])localObject);
  }

  private void writeObject(ObjectOutputStream paramObjectOutputStream)
    throws IOException
  {
    ObjectOutputStream.PutField localPutField;
    (localPutField = paramObjectOutputStream.putFields()).put("signum", c);
    BigInteger localBigInteger = this;
    int i1;
    byte[] arrayOfByte = new byte[i1 = ((i1 = a.length == 0 ? 0 : (localBigInteger.a.length - 1 << 5) + b(localBigInteger.a[0])) + 7) / 8];
    i1 -= 1;
    int i2 = 4;
    int i3 = localBigInteger.a.length - 1;
    int i4 = 0;
    i4 = localBigInteger.a[(i3--)];
    i2 = 1;
    i4 >>>= 8;
    arrayOfByte[i1] = ((byte)i4);
    localPutField.put(i2 == 4 ? "magnitude" : ???++, arrayOfByte);
    localPutField.put("bitCount", -1);
    localPutField.put("bitLength", -1);
    localPutField.put("lowestSetBit", -2);
    localPutField.put("firstNonzeroByteNum", -2);
    paramObjectOutputStream.writeFields();
  }

  static
  {
    for (int i1 = 1; i1 <= 16; i1++)
    {
      int[] arrayOfInt;
      (arrayOfInt = new int[1])[0] = i1;
      j[i1] = new BigInteger(arrayOfInt, 1);
      k[i1] = new BigInteger(arrayOfInt, -1);
    }
    ZERO = new BigInteger(new int[0], 0);
    ONE = valueOf(1L);
    l = valueOf(2L);
    m = new int[] { 7, 25, 81, 241, 673, 1793, 2147483647 };
    b = new byte[] { -25, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 };
    (BigInteger.n = new String[64])[63] = "000000000000000000000000000000000000000000000000000000000000000";
    for (i1 = 0; i1 < 63; i1++)
      n[i1] = n[63].substring(0, i1);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.BigInteger
 * JD-Core Version:    0.6.2
 */