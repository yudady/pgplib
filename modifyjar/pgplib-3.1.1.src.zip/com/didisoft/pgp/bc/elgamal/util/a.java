package com.didisoft.pgp.bc.elgamal.util;

final class a
{
  private long[] a;
  private int b;
  private static a c = new a();

  private a()
  {
    b = 9600;
    a = new long[((i = b - 1) >>> 6) + 1];
    a(0);
    int i = 1;
    int j = 3;
    do
    {
      a(b, i + j, j);
      i = a(b, i + 1);
      j = 2 * i + 1;
    }
    while ((i > 0) && (j < b));
  }

  a(BigInteger paramBigInteger, int paramInt)
  {
    int i;
    a = new long[((i = paramInt - 1) >>> 6) + 1];
    b = paramInt;
    int j;
    int k = ((j = c.a(c.b, 0)) << 1) + 1;
    b localb1 = new b();
    b localb2 = new b();
    do
    {
      localb1.a(paramBigInteger.a);
      localb1.a(k, localb2);
      i = localb1.a[localb1.c];
      if ((i = k - i) % 2 == 0)
        i += k;
      a(paramInt, (i - 1) / 2, k);
      k = ((j = c.a(c.b, j + 1)) << 1) + 1;
    }
    while (j > 0);
  }

  private void a(int paramInt)
  {
    int i = (i = paramInt) >>> 6;
    i = paramInt;
    a[i] |= 1L << (i & 0x3F);
  }

  private int a(int paramInt1, int paramInt2)
  {
    if (paramInt2 >= paramInt1)
      return -1;
    paramInt2 = paramInt2;
    do
    {
      int i = paramInt2;
      a locala = this;
      int j = (j = i) >>> 6;
      j = i;
      if (((locala.a[j] & 1L << (j & 0x3F)) != 0L ? 1 : 0) == 0)
        return paramInt2;
      paramInt2++;
    }
    while (paramInt2 < paramInt1 - 1);
    return -1;
  }

  private void a(int paramInt1, int paramInt2, int paramInt3)
  {
    while (paramInt2 < paramInt1)
    {
      a(paramInt2);
      paramInt2 += paramInt3;
    }
  }

  final BigInteger a(BigInteger paramBigInteger, int paramInt)
  {
    int i = 1;
    for (int j = 0; j < a.length; j++)
    {
      long l = a[j] ^ 0xFFFFFFFF;
      for (int k = 0; k < 64; k++)
      {
        BigInteger localBigInteger;
        if (((l & 1L) == 1L) && ((localBigInteger = paramBigInteger.add(BigInteger.valueOf(i))).a(paramInt)))
          return localBigInteger;
        l >>>= 1;
        i += 2;
      }
    }
    return null;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.a
 * JD-Core Version:    0.6.2
 */