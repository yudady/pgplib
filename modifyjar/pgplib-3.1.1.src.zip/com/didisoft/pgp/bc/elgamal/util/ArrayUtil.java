package com.didisoft.pgp.bc.elgamal.util;

public class ArrayUtil
{
  private static byte[] a = new byte[500];

  public static void clear(byte[] paramArrayOfByte)
  {
    clear(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public static void clear(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if (paramInt2 <= 500)
    {
      System.arraycopy(a, 0, paramArrayOfByte, paramInt1, paramInt2);
      return;
    }
    System.arraycopy(a, 0, paramArrayOfByte, paramInt1, 500);
    int i = paramInt2 / 2;
    int j = 500;
    while (j < paramInt2)
    {
      System.arraycopy(paramArrayOfByte, paramInt1, paramArrayOfByte, paramInt1 + j, j <= i ? j : paramInt2 - j);
      j += j;
    }
  }

  public static int toInt(short paramShort1, short paramShort2)
  {
    return paramShort1 & 0xFFFF | paramShort2 << 16;
  }

  public static short toShort(byte paramByte1, byte paramByte2)
  {
    return (short)(paramByte1 & 0xFF | paramByte2 << 8);
  }

  public static byte[] toBytes(int paramInt)
  {
    byte[] arrayOfByte = new byte[4];
    for (int i = 3; i >= 0; i--)
    {
      arrayOfByte[i] = ((byte)paramInt);
      paramInt >>>= 8;
    }
    return arrayOfByte;
  }

  public static byte[] toBytes(short[] paramArrayOfShort, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[2 * paramInt2];
    int i = 0;
    for (int j = paramInt1; j < paramInt1 + paramInt2; j++)
    {
      arrayOfByte[(i++)] = ((byte)(paramArrayOfShort[j] >>> 8));
      arrayOfByte[(i++)] = ((byte)paramArrayOfShort[j]);
    }
    return arrayOfByte;
  }

  public static byte[] toBytes(short[] paramArrayOfShort)
  {
    return toBytes(paramArrayOfShort, 0, paramArrayOfShort.length);
  }

  public static short[] toShorts(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    short[] arrayOfShort = new short[paramInt2 / 2];
    int i = 0;
    for (int j = paramInt1; j < paramInt1 + paramInt2 - 1; j += 2)
      arrayOfShort[(i++)] = ((short)((paramArrayOfByte[j] & 0xFF) << 8 | paramArrayOfByte[(j + 1)] & 0xFF));
    return arrayOfShort;
  }

  public static short[] toShorts(byte[] paramArrayOfByte)
  {
    return toShorts(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public static boolean areEqual(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    int i;
    if ((i = paramArrayOfByte1.length) != paramArrayOfByte2.length)
      return false;
    for (int j = 0; j < i; j++)
      if (paramArrayOfByte1[j] != paramArrayOfByte2[j])
        return false;
    return true;
  }

  public static boolean areEqual(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i;
    if ((i = paramArrayOfInt1.length) != paramArrayOfInt2.length)
      return false;
    for (int j = 0; j < i; j++)
      if (paramArrayOfInt1[j] != paramArrayOfInt2[j])
        return false;
    return true;
  }

  public static int compared(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, boolean paramBoolean)
  {
    int i;
    if ((i = paramArrayOfByte1.length) < paramArrayOfByte2.length)
      return -1;
    if (i > paramArrayOfByte2.length)
      return 1;
    int j;
    if (paramBoolean)
      for (j = i - 1; j >= 0; j--)
      {
        paramBoolean = paramArrayOfByte1[j] & 0xFF;
        boolean bool1 = paramArrayOfByte2[j] & 0xFF;
        if (paramBoolean < bool1)
          return -1;
        if (paramBoolean > bool1)
          return 1;
      }
    else
      for (j = 0; j < i; j++)
      {
        paramBoolean = paramArrayOfByte1[j] & 0xFF;
        boolean bool2 = paramArrayOfByte2[j] & 0xFF;
        if (paramBoolean < bool2)
          return -1;
        if (paramBoolean > bool2)
          return 1;
      }
    return 0;
  }

  public static boolean isText(byte[] paramArrayOfByte)
  {
    int i;
    if ((i = paramArrayOfByte.length) == 0)
      return false;
    for (int j = 0; j < i; j++)
    {
      int k;
      if (((k = paramArrayOfByte[j] & 0xFF) < 32) || (k > 127))
        switch (k)
        {
        case 7:
        case 8:
        case 9:
        case 10:
        case 11:
        case 12:
        case 13:
        case 26:
        case 27:
        case 155:
          break;
        default:
          return false;
        }
    }
    return true;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.ArrayUtil
 * JD-Core Version:    0.6.2
 */