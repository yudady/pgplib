package com.didisoft.pgp.bc.elgamal.util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.StreamCorruptedException;

public class BigDecimal extends Number
  implements Comparable
{
  private BigInteger a;
  private int b = 0;
  private static final long serialVersionUID = 6108874887143696463L;
  public static final int ROUND_UP = 0;
  public static final int ROUND_DOWN = 1;
  public static final int ROUND_CEILING = 2;
  public static final int ROUND_FLOOR = 3;
  public static final int ROUND_HALF_UP = 4;
  public static final int ROUND_HALF_DOWN = 5;
  public static final int ROUND_HALF_EVEN = 6;
  public static final int ROUND_UNNECESSARY = 7;

  public BigDecimal(String paramString)
  {
    if (paramString.length() == 0)
      throw new NumberFormatException();
    if ((paramString.charAt(0) == '+') && (((paramString = paramString.substring(1)).length() == 0) || (paramString.charAt(0) == '-')))
      throw new NumberFormatException();
    int i = 0;
    int j;
    if ((j = paramString.indexOf('e')) == -1)
      j = paramString.indexOf('E');
    if (j != -1)
    {
      String str;
      if ((str = paramString.substring(j + 1)).length() == 0)
        throw new NumberFormatException();
      if ((str.charAt(0) == '+') && (((str = str.substring(1)).length() == 0) || (str.charAt(0) == '-')))
        throw new NumberFormatException();
      i = Integer.parseInt(str);
      if (j == 0)
        throw new NumberFormatException();
      paramString = paramString.substring(0, j);
    }
    int k;
    if ((k = paramString.indexOf('.')) == -1)
    {
      a = new BigInteger(paramString);
    }
    else if (k == paramString.length() - 1)
    {
      a = new BigInteger(paramString.substring(0, paramString.length() - 1));
    }
    else
    {
      if (paramString.charAt(k + 1) == '-')
        throw new NumberFormatException();
      char[] arrayOfChar = new char[paramString.length() - 1];
      paramString.getChars(0, k, arrayOfChar, 0);
      paramString.getChars(k + 1, paramString.length(), arrayOfChar, k);
      b = (paramString.length() - k - 1);
      a = new BigInteger(arrayOfChar);
    }
    long l;
    if ((l = b - i) > 2147483647L)
      throw new NumberFormatException("Final scale out of range");
    b = ((int)l);
    if (b < 0)
    {
      a = a(a, -b);
      b = 0;
    }
  }

  public BigDecimal(double paramDouble)
  {
    if ((Double.isInfinite(paramDouble)) || (Double.isNaN(paramDouble)))
      throw new NumberFormatException("Infinite or NaN");
    long l1;
    paramDouble = (l1 = Double.doubleToLongBits(paramDouble)) >> 63 == 0L ? 1 : -1;
    int i;
    long l2 = (i = (int)(l1 >> 52 & 0x7FF)) == 0 ? (l1 & 0xFFFFFFFF) << 1 : l1 & 0xFFFFFFFF | 0x0;
    i -= 1075;
    if (l2 == 0L)
    {
      a = BigInteger.ZERO;
      return;
    }
    while ((l2 & 1L) == 0L)
    {
      l2 >>= 1;
      i++;
    }
    a = BigInteger.valueOf(paramDouble * l2);
    if (i < 0)
    {
      a = a.multiply(BigInteger.valueOf(5L).pow(-i));
      b = (-i);
      return;
    }
    if (i > 0)
      a = a.multiply(BigInteger.valueOf(2L).pow(i));
  }

  public BigDecimal(BigInteger paramBigInteger)
  {
    a = paramBigInteger;
  }

  public BigDecimal(BigInteger paramBigInteger, int paramInt)
  {
    if (paramInt < 0)
      throw new NumberFormatException("Negative scale");
    a = paramBigInteger;
    b = paramInt;
  }

  public static BigDecimal valueOf(long paramLong, int paramInt)
  {
    return new BigDecimal(BigInteger.valueOf(paramLong), paramInt);
  }

  public static BigDecimal valueOf(long paramLong)
  {
    return valueOf(paramLong, 0);
  }

  public BigDecimal add(BigDecimal paramBigDecimal)
  {
    BigDecimal[] arrayOfBigDecimal;
    (arrayOfBigDecimal = new BigDecimal[2])[0] = this;
    arrayOfBigDecimal[1] = paramBigDecimal;
    a(arrayOfBigDecimal);
    return new BigDecimal(arrayOfBigDecimal[0].a.add(arrayOfBigDecimal[1].a), arrayOfBigDecimal[0].b);
  }

  public BigDecimal subtract(BigDecimal paramBigDecimal)
  {
    BigDecimal[] arrayOfBigDecimal;
    (arrayOfBigDecimal = new BigDecimal[2])[0] = this;
    arrayOfBigDecimal[1] = paramBigDecimal;
    a(arrayOfBigDecimal);
    return new BigDecimal(arrayOfBigDecimal[0].a.subtract(arrayOfBigDecimal[1].a), arrayOfBigDecimal[0].b);
  }

  public BigDecimal multiply(BigDecimal paramBigDecimal)
  {
    return new BigDecimal(a.multiply(paramBigDecimal.a), b + paramBigDecimal.b);
  }

  public BigDecimal divide(BigDecimal paramBigDecimal, int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
      throw new ArithmeticException("Negative scale");
    if ((paramInt2 < 0) || (paramInt2 > 7))
      throw new IllegalArgumentException("Invalid rounding mode");
    BigDecimal localBigDecimal;
    if (paramInt1 + paramBigDecimal.b >= b)
    {
      localBigDecimal = setScale(paramInt1 + paramBigDecimal.b);
      paramBigDecimal = paramBigDecimal;
    }
    else
    {
      localBigDecimal = this;
      paramBigDecimal = paramBigDecimal.setScale(b - paramInt1);
    }
    Object localObject;
    BigInteger localBigInteger = (localObject = localBigDecimal.a.divideAndRemainder(paramBigDecimal.a))[0];
    if ((localObject = localObject[1]).signum() == 0)
      return new BigDecimal(localBigInteger, paramInt1);
    if (paramInt2 == 7)
      throw new ArithmeticException("Rounding necessary");
    int i = localBigDecimal.signum() * paramBigDecimal.signum();
    if (paramInt2 == 0)
      paramBigDecimal = 1;
    else if (paramInt2 == 1)
      paramBigDecimal = 0;
    else if (paramInt2 == 2)
      paramBigDecimal = i > 0 ? 1 : 0;
    else if (paramInt2 == 3)
      paramBigDecimal = i < 0 ? 1 : 0;
    else if ((paramBigDecimal = ((BigInteger)localObject).abs().multiply(BigInteger.valueOf(2L)).compareTo(paramBigDecimal.a.abs())) < 0)
      paramBigDecimal = 0;
    else if (paramBigDecimal > 0)
      paramBigDecimal = 1;
    else if (paramInt2 == 4)
      paramBigDecimal = 1;
    else if (paramInt2 == 5)
      paramBigDecimal = 0;
    else
      paramBigDecimal = localBigInteger.testBit(0);
    if (paramBigDecimal != 0)
      return new BigDecimal(localBigInteger.add(BigInteger.valueOf(i)), paramInt1);
    return new BigDecimal(localBigInteger, paramInt1);
  }

  public BigDecimal divide(BigDecimal paramBigDecimal, int paramInt)
  {
    return divide(paramBigDecimal, b, paramInt);
  }

  public BigDecimal abs()
  {
    if (signum() < 0)
      return negate();
    return this;
  }

  public BigDecimal negate()
  {
    return new BigDecimal(a.negate(), b);
  }

  public int signum()
  {
    return a.signum();
  }

  public int scale()
  {
    return b;
  }

  public BigInteger unscaledValue()
  {
    return a;
  }

  public BigDecimal setScale(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
      throw new ArithmeticException("Negative scale");
    if ((paramInt2 < 0) || (paramInt2 > 7))
      throw new IllegalArgumentException("Invalid rounding mode");
    if (paramInt1 == b)
      return this;
    if (paramInt1 > b)
      return new BigDecimal(a(a, paramInt1 - b), paramInt1);
    return divide(valueOf(1L), paramInt1, paramInt2);
  }

  public BigDecimal setScale(int paramInt)
  {
    return setScale(paramInt, 7);
  }

  public BigDecimal movePointLeft(int paramInt)
  {
    if (paramInt >= 0)
      return new BigDecimal(a, b + paramInt);
    return movePointRight(-paramInt);
  }

  public BigDecimal movePointRight(int paramInt)
  {
    if (b >= paramInt)
      return new BigDecimal(a, b - paramInt);
    return new BigDecimal(a(a, paramInt - b), 0);
  }

  public int compareTo(BigDecimal paramBigDecimal)
  {
    int i;
    if ((i = signum() - paramBigDecimal.signum()) != 0)
    {
      if (i > 0)
        return 1;
      return -1;
    }
    BigDecimal[] arrayOfBigDecimal;
    (arrayOfBigDecimal = new BigDecimal[2])[0] = this;
    arrayOfBigDecimal[1] = paramBigDecimal;
    a(arrayOfBigDecimal);
    return arrayOfBigDecimal[0].a.compareTo(arrayOfBigDecimal[1].a);
  }

  public int compareTo(Object paramObject)
  {
    return compareTo((BigDecimal)paramObject);
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof BigDecimal))
      return false;
    paramObject = (BigDecimal)paramObject;
    return (b == paramObject.b) && (a.equals(paramObject.a));
  }

  public BigDecimal min(BigDecimal paramBigDecimal)
  {
    if (compareTo(paramBigDecimal) < 0)
      return this;
    return paramBigDecimal;
  }

  public BigDecimal max(BigDecimal paramBigDecimal)
  {
    if (compareTo(paramBigDecimal) > 0)
      return this;
    return paramBigDecimal;
  }

  public int hashCode()
  {
    return 31 * a.hashCode() + b;
  }

  public String toString()
  {
    if (b == 0)
      return a.toString();
    int j = b;
    String str = a.abs().toString();
    int i = signum();
    int k;
    if ((k = str.length() - j) == 0)
      return (i < 0 ? "-0." : "0.") + str;
    StringBuffer localStringBuffer;
    if (k > 0)
    {
      (localStringBuffer = new StringBuffer(str)).insert(k, '.');
      if (i < 0)
        localStringBuffer.insert(0, '-');
    }
    else
    {
      (localStringBuffer = new StringBuffer(3 - k + str.length())).append(i < 0 ? "-0." : "0.");
      for (i = 0; i < -k; i++)
        localStringBuffer.append('0');
      localStringBuffer.append(str);
    }
    return localStringBuffer.toString();
  }

  public BigInteger toBigInteger()
  {
    if (b == 0)
      return a;
    return a.divide(BigInteger.valueOf(10L).pow(b));
  }

  public int intValue()
  {
    return toBigInteger().intValue();
  }

  public long longValue()
  {
    return toBigInteger().longValue();
  }

  public float floatValue()
  {
    return Float.valueOf(toString()).floatValue();
  }

  public double doubleValue()
  {
    return Double.valueOf(toString()).doubleValue();
  }

  private static BigInteger a(BigInteger paramBigInteger, int paramInt)
  {
    return paramBigInteger.multiply(BigInteger.valueOf(10L).pow(paramInt));
  }

  private static void a(BigDecimal[] paramArrayOfBigDecimal)
  {
    if (paramArrayOfBigDecimal[0].b < paramArrayOfBigDecimal[1].b)
    {
      paramArrayOfBigDecimal[0] = paramArrayOfBigDecimal[0].setScale(paramArrayOfBigDecimal[1].b);
      return;
    }
    if (paramArrayOfBigDecimal[1].b < paramArrayOfBigDecimal[0].b)
      paramArrayOfBigDecimal[1] = paramArrayOfBigDecimal[1].setScale(paramArrayOfBigDecimal[0].b);
  }

  private synchronized void readObject(ObjectInputStream paramObjectInputStream)
    throws IOException, ClassNotFoundException
  {
    paramObjectInputStream.defaultReadObject();
    if (b < 0)
      throw new StreamCorruptedException("BigDecimal: Negative scale");
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.BigDecimal
 * JD-Core Version:    0.6.2
 */