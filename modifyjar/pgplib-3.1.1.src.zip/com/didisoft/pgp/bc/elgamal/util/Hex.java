package com.didisoft.pgp.bc.elgamal.util;

import java.io.PrintStream;
import java.io.PrintWriter;

public class Hex
{
  private static final char[] a = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

  public static String toString(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    char[] arrayOfChar = new char[paramInt2 << 1];
    int i = 0;
    for (int k = paramInt1; k < paramInt1 + paramInt2; k++)
    {
      int j = paramArrayOfByte[k];
      arrayOfChar[(i++)] = a[(j >>> 4 & 0xF)];
      arrayOfChar[(i++)] = a[(j & 0xF)];
    }
    return new String(arrayOfChar);
  }

  public static String toString(byte[] paramArrayOfByte)
  {
    return toString(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public static String toString(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    char[] arrayOfChar = new char[paramInt2 << 3];
    int i = 0;
    for (int k = paramInt1; k < paramInt1 + paramInt2; k++)
    {
      int j = paramArrayOfInt[k];
      arrayOfChar[(i++)] = a[(j >>> 28 & 0xF)];
      arrayOfChar[(i++)] = a[(j >>> 24 & 0xF)];
      arrayOfChar[(i++)] = a[(j >>> 20 & 0xF)];
      arrayOfChar[(i++)] = a[(j >>> 16 & 0xF)];
      arrayOfChar[(i++)] = a[(j >>> 12 & 0xF)];
      arrayOfChar[(i++)] = a[(j >>> 8 & 0xF)];
      arrayOfChar[(i++)] = a[(j >>> 4 & 0xF)];
      arrayOfChar[(i++)] = a[(j & 0xF)];
    }
    return new String(arrayOfChar);
  }

  public static String toString(int[] paramArrayOfInt)
  {
    return toString(paramArrayOfInt, 0, paramArrayOfInt.length);
  }

  public static String toReversedString(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    char[] arrayOfChar = new char[paramInt2 << 1];
    int i = 0;
    for (paramInt2 = paramInt1 + paramInt2 - 1; paramInt2 >= paramInt1; paramInt2--)
    {
      arrayOfChar[(i++)] = a[(paramArrayOfByte[paramInt2] >>> 4 & 0xF)];
      arrayOfChar[(i++)] = a[(paramArrayOfByte[paramInt2] & 0xF)];
    }
    return new String(arrayOfChar);
  }

  public static String toReversedString(byte[] paramArrayOfByte)
  {
    return toReversedString(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public static byte[] fromString(String paramString)
  {
    int i;
    byte[] arrayOfByte = new byte[((i = paramString.length()) + 1) / 2];
    int j = 0;
    int k = 0;
    if (i % 2 == 1)
      (k++)[paramString] = ((byte)fromDigit(0.charAt(j++)));
    arrayOfByte[(k++)] = ((byte)(fromDigit(paramString.charAt(j++)) << 4 | fromDigit(paramString.charAt(j++))));
    return arrayOfByte;
  }

  public static byte[] fromReversedString(String paramString)
  {
    int i;
    byte[] arrayOfByte = new byte[((i = paramString.length()) + 1) / 2];
    int j = 0;
    if (i % 2 == 1)
      throw new IllegalArgumentException("string must have an even number of digits");
    while (i > 0)
      arrayOfByte[(j++)] = ((byte)(fromDigit(paramString.charAt(--i)) | fromDigit(paramString.charAt(--i)) << 4));
    return arrayOfByte;
  }

  public static char toDigit(int paramInt)
  {
    try
    {
      return a[paramInt];
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
    {
    }
    throw new IllegalArgumentException(paramInt + " is out of range for a hex digit");
  }

  public static int fromDigit(char paramChar)
  {
    if ((paramChar >= '0') && (paramChar <= '9'))
      return paramChar - '0';
    if ((paramChar >= 'A') && (paramChar <= 'F'))
      return paramChar - 'A' + 10;
    if ((paramChar >= 'a') && (paramChar <= 'f'))
      return paramChar - 'a' + 10;
    throw new IllegalArgumentException("invalid hex digit '" + paramChar + "'");
  }

  public static String byteToString(int paramInt)
  {
    paramInt = new char[] { a[(paramInt >>> 4 & 0xF)], a[(paramInt & 0xF)] };
    return new String(paramInt);
  }

  public static String shortToString(int paramInt)
  {
    paramInt = new char[] { a[(paramInt >>> 12 & 0xF)], a[(paramInt >>> 8 & 0xF)], a[(paramInt >>> 4 & 0xF)], a[(paramInt & 0xF)] };
    return new String(paramInt);
  }

  public static String intToString(int paramInt)
  {
    char[] arrayOfChar = new char[8];
    for (int i = 7; i >= 0; i--)
    {
      arrayOfChar[i] = a[(paramInt & 0xF)];
      paramInt >>>= 4;
    }
    return new String(arrayOfChar);
  }

  public static String longToString(long paramLong)
  {
    char[] arrayOfChar = new char[16];
    for (int i = 15; i >= 0; i--)
    {
      arrayOfChar[i] = a[((int)paramLong & 0xF)];
      paramLong >>>= 4;
    }
    return new String(arrayOfChar);
  }

  public static String dumpString(byte[] paramArrayOfByte, int paramInt1, int paramInt2, String paramString)
  {
    if (paramArrayOfByte == null)
      return paramString + "null\n";
    StringBuffer localStringBuffer = new StringBuffer(paramInt2 * 3);
    if (paramInt2 > 32)
      localStringBuffer.append(paramString).append("Hexadecimal dump of ").append(paramInt2).append(" bytes...\n");
    int i = paramInt1 + paramInt2;
    int k;
    if ((k = Integer.toString(paramInt2).length()) < 4)
      k = 4;
    while (paramInt1 < i)
    {
      if (paramInt2 > 32)
      {
        String str = "         " + paramInt1;
        localStringBuffer.append(paramString).append(str.substring(str.length() - k)).append(": ");
      }
      for (int j = 0; (j < 32) && (paramInt1 + j + 7 < i); j += 8)
        localStringBuffer.append(toString(paramArrayOfByte, paramInt1 + j, 8)).append(' ');
      if (j < 32)
        while ((j < 32) && (paramInt1 + j < i))
        {
          localStringBuffer.append(byteToString(paramArrayOfByte[(paramInt1 + j)]));
          j++;
        }
      localStringBuffer.append('\n');
      paramInt1 += 32;
    }
    return localStringBuffer.toString();
  }

  public static String dumpString(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null)
      return "null\n";
    return dumpString(paramArrayOfByte, 0, paramArrayOfByte.length, "");
  }

  public static String dumpString(byte[] paramArrayOfByte, String paramString)
  {
    if (paramArrayOfByte == null)
      return "null\n";
    return dumpString(paramArrayOfByte, 0, paramArrayOfByte.length, paramString);
  }

  public static String dumpString(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return dumpString(paramArrayOfByte, paramInt1, paramInt2, "");
  }

  public static String dumpString(int[] paramArrayOfInt, int paramInt1, int paramInt2, String paramString)
  {
    if (paramArrayOfInt == null)
      return paramString + "null\n";
    StringBuffer localStringBuffer = new StringBuffer(paramInt2 * 3);
    if (paramInt2 > 8)
      localStringBuffer.append(paramString).append("Hexadecimal dump of ").append(paramInt2).append(" integers...\n");
    int i = paramInt1 + paramInt2;
    int k;
    if ((k = Integer.toString(paramInt2).length()) < 8)
      k = 8;
    while (paramInt1 < i)
    {
      if (paramInt2 > 8)
      {
        String str = "         " + paramInt1;
        localStringBuffer.append(paramString).append(str.substring(str.length() - k)).append(": ");
      }
      for (int j = 0; (j < 8) && (paramInt1 < i); j++)
        localStringBuffer.append(intToString(paramArrayOfInt[(paramInt1++)])).append(' ');
      localStringBuffer.append('\n');
    }
    return localStringBuffer.toString();
  }

  public static String dumpString(int[] paramArrayOfInt)
  {
    return dumpString(paramArrayOfInt, 0, paramArrayOfInt.length, "");
  }

  public static String dumpString(int[] paramArrayOfInt, String paramString)
  {
    return dumpString(paramArrayOfInt, 0, paramArrayOfInt.length, paramString);
  }

  public static String dumpString(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    return dumpString(paramArrayOfInt, paramInt1, paramInt2, "");
  }

  public static void main(String[] paramArrayOfString)
  {
    self_test(new PrintWriter(System.out, true));
  }

  public static void self_test(PrintWriter paramPrintWriter)
  {
    byte[] arrayOfByte = new byte[(localObject = "Hello. This is a test string with more than 32 characters.").length()];
    for (int i = 0; i < ((String)localObject).length(); i++)
      arrayOfByte[i] = ((byte)((String)localObject).charAt(i));
    String str = toString(arrayOfByte);
    paramPrintWriter.println("Hex.toString(buf) = " + str);
    Object localObject = fromString(str);
    if (!ArrayUtil.areEqual(arrayOfByte, (byte[])localObject))
      System.out.println("buf != buf2");
    str = toReversedString(arrayOfByte);
    paramPrintWriter.println("Hex.toReversedString(buf) = " + str);
    localObject = fromReversedString(str);
    if (!ArrayUtil.areEqual(arrayOfByte, (byte[])localObject))
      paramPrintWriter.println("buf != buf2");
    paramPrintWriter.print("Hex.dumpString(buf, 0, 28) =\n" + dumpString(arrayOfByte, 0, 28));
    paramPrintWriter.print("Hex.dumpString(null) =\n" + dumpString(null));
    paramPrintWriter.print(dumpString(arrayOfByte, "+++"));
    paramPrintWriter.flush();
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.Hex
 * JD-Core Version:    0.6.2
 */