package com.didisoft.pgp.bc.elgamal.util;

final class c extends b
{
  int d = 1;

  c()
  {
  }

  c(int paramInt)
  {
    super(1);
  }

  public final String toString()
  {
    BigInteger localBigInteger;
    return (localBigInteger = new BigInteger(this, d)).toString();
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.util.c
 * JD-Core Version:    0.6.2
 */