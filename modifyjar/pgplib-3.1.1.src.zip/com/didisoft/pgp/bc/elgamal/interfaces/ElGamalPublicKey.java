package com.didisoft.pgp.bc.elgamal.interfaces;

import java.security.PublicKey;

public abstract interface ElGamalPublicKey extends ElGamalKey, PublicKey
{
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.interfaces.ElGamalPublicKey
 * JD-Core Version:    0.6.2
 */