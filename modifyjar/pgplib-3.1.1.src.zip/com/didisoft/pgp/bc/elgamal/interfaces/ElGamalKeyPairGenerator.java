package com.didisoft.pgp.bc.elgamal.interfaces;

import java.math.BigInteger;
import java.security.InvalidParameterException;
import java.security.SecureRandom;

public abstract interface ElGamalKeyPairGenerator
{
  public abstract void initialize(ElGamalParams paramElGamalParams, SecureRandom paramSecureRandom)
    throws InvalidParameterException;

  public abstract void initialize(BigInteger paramBigInteger1, BigInteger paramBigInteger2, SecureRandom paramSecureRandom)
    throws InvalidParameterException;

  public abstract void initialize(int paramInt, boolean paramBoolean, SecureRandom paramSecureRandom)
    throws InvalidParameterException;

  public abstract ElGamalParams generateParams(int paramInt, SecureRandom paramSecureRandom)
    throws InvalidParameterException;

  public abstract void setWithLucasLehmerTest(boolean paramBoolean);
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.interfaces.ElGamalKeyPairGenerator
 * JD-Core Version:    0.6.2
 */