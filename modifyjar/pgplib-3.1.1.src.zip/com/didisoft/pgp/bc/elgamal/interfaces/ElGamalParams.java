package com.didisoft.pgp.bc.elgamal.interfaces;

import java.math.BigInteger;

public abstract interface ElGamalParams
{
  public abstract BigInteger getP();

  public abstract BigInteger getG();
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.interfaces.ElGamalParams
 * JD-Core Version:    0.6.2
 */