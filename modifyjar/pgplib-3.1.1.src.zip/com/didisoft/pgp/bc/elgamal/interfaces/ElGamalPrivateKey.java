package com.didisoft.pgp.bc.elgamal.interfaces;

import java.math.BigInteger;
import java.security.PrivateKey;

public abstract interface ElGamalPrivateKey extends ElGamalKey, PrivateKey
{
  public abstract BigInteger getX();
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.interfaces.ElGamalPrivateKey
 * JD-Core Version:    0.6.2
 */