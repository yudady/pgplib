package com.didisoft.pgp.bc.elgamal;

import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalPrivateKey;
import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalPublicKey;
import com.didisoft.pgp.bc.elgamal.security.AsymmetricCipher;
import com.didisoft.pgp.bc.elgamal.security.Cipher;
import com.didisoft.pgp.bc.elgamal.security.IllegalBlockSizeException;
import com.didisoft.pgp.bc.elgamal.util.ArrayUtil;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.InvalidParameterException;
import java.security.Key;
import java.security.KeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.util.Random;

public class RawElGamalCipher extends Cipher
  implements AsymmetricCipher, Cloneable
{
  private BigInteger b;
  private BigInteger c;
  private BigInteger d;
  private BigInteger e;
  private int f;
  private Random g;

  public RawElGamalCipher()
  {
    super(false, true, "Cryptix");
  }

  protected void engineInitEncrypt(Key paramKey)
    throws KeyException
  {
    if (!(paramKey instanceof ElGamalPublicKey))
      throw new InvalidKeyException("ElGamal: encryption key does not implement java.security.interfaces.ElGamalPublicKey");
    paramKey = (ElGamalPublicKey)paramKey;
    a(paramKey.getP(), paramKey.getG(), null, paramKey.getY());
    if (g == null)
      g = new SecureRandom();
  }

  protected void engineInitDecrypt(Key paramKey)
    throws KeyException
  {
    if (!(paramKey instanceof ElGamalPrivateKey))
      throw new InvalidKeyException("ElGamal: decryption key does not implement java.security.interfaces.ElGamalPrivateKey");
    BigInteger localBigInteger;
    if ((localBigInteger = (paramKey = (ElGamalPrivateKey)paramKey).getX()) == null)
      throw new InvalidKeyException("ElGamal: getX() == null");
    a(paramKey.getP(), paramKey.getG(), localBigInteger, paramKey.getY());
  }

  private void a(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, BigInteger paramBigInteger4)
    throws InvalidKeyException
  {
    if (paramBigInteger1 == null)
      throw new InvalidKeyException("ElGamal: getP() == null");
    if (paramBigInteger2 == null)
      throw new InvalidKeyException("ElGamal: getG() == null");
    if (paramBigInteger4 == null)
      throw new InvalidKeyException("ElGamal: getY() == null");
    b = paramBigInteger1;
    c = paramBigInteger2;
    d = paramBigInteger3;
    e = paramBigInteger4;
    f = ((b.bitLength() - 1) / 8);
  }

  protected int enginePlaintextBlockSize()
  {
    if (f == 0)
      throw new a("ElGamal: plaintext block size is not valid until key is set");
    return f;
  }

  protected int engineCiphertextBlockSize()
  {
    if (f == 0)
      throw new a("ElGamal: ciphertext block size is not valid until key is set");
    return f << 1;
  }

  protected void engineSetParameter(String paramString, Object paramObject)
  {
    if (paramString.equals("random"))
    {
      if (!(paramObject instanceof Random))
        throw new InvalidParameterException("value must be an instance of java.util.Random");
      g = ((Random)paramObject);
      return;
    }
    throw new InvalidParameterException(paramString);
  }

  protected Object engineGetParameter(String paramString)
  {
    if (paramString.equals("random"))
      return g;
    return null;
  }

  protected int engineUpdate(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    if (paramInt2 <= 0)
      return 0;
    if (getState() == 1)
    {
      if (paramInt2 != f)
        throw new IllegalBlockSizeException("inLen = " + paramInt2 + ", plaintext block size = " + f);
      paramInt2 = new byte[f];
      System.arraycopy(paramArrayOfByte1, paramInt1, paramInt2, 0, f);
      localObject = new BigInteger[2];
      ElGamalAlgorithm.encrypt(paramArrayOfByte1 = new BigInteger(1, paramInt2), (BigInteger[])localObject, b, c, e, g);
      paramArrayOfByte1 = localObject[0].toByteArray();
      paramInt1 = localObject[1].toByteArray();
      ArrayUtil.clear(paramArrayOfByte2, paramInt3, f << 1);
      System.arraycopy(paramArrayOfByte1, 0, paramArrayOfByte2, paramInt3 + f - paramArrayOfByte1.length, paramArrayOfByte1.length);
      System.arraycopy(paramInt1, 0, paramArrayOfByte2, paramInt3 + (f << 1) - paramInt1.length, paramInt1.length);
      ArrayUtil.clear(paramInt2);
      return f << 1;
    }
    if (paramInt2 != f << 1)
      throw new IllegalBlockSizeException("inLen = " + paramInt2 + ", ciphertext block size = " + (f << 1));
    paramInt2 = new byte[f];
    System.arraycopy(paramArrayOfByte1, paramInt1, paramInt2, 0, f);
    Object localObject = new BigInteger(1, paramInt2);
    System.arraycopy(paramArrayOfByte1, paramInt1 + f, paramInt2, 0, f);
    paramArrayOfByte1 = new BigInteger(1, paramInt2);
    paramInt1 = (paramArrayOfByte1 = ElGamalAlgorithm.decrypt((BigInteger)localObject, paramArrayOfByte1, b, c, d)).toByteArray();
    ArrayUtil.clear(paramArrayOfByte2, paramInt3, f - paramInt1.length);
    System.arraycopy(paramInt1, 0, paramArrayOfByte2, paramInt3 + f - paramInt1.length, paramInt1.length);
    return f;
  }

  public static final void main(String[] paramArrayOfString)
  {
    try
    {
      self_test(new PrintWriter(System.out, true));
      return;
    }
    catch (Exception localException)
    {
      (paramArrayOfString = localException).printStackTrace();
    }
  }

  public static void self_test(PrintWriter paramPrintWriter)
    throws KeyException
  {
    Object localObject1 = new BaseElGamalKeyPairGenerator();
    Object localObject2 = new SecureRandom();
    long l1 = System.currentTimeMillis();
    ((KeyPairGenerator)localObject1).initialize(385, (SecureRandom)localObject2);
    localObject1 = ((KeyPairGenerator)localObject1).generateKeyPair();
    long l2 = System.currentTimeMillis() - l1;
    paramPrintWriter.println("Keygen: " + (float)l2 / 1000.0F + " seconds");
    Object localObject3 = localObject2;
    localObject2 = localObject1;
    localObject1 = paramPrintWriter;
    paramPrintWriter = localObject3 = new RawElGamalCipher();
    ElGamalPrivateKey localElGamalPrivateKey = (ElGamalPrivateKey)((KeyPair)localObject2).getPrivate();
    localObject2 = (ElGamalPublicKey)((KeyPair)localObject2).getPublic();
    BigInteger localBigInteger = new BigInteger(localElGamalPrivateKey.getP().bitLength() - 1, (Random)localObject3);
    g = ((Random)localObject3);
    long l3 = System.currentTimeMillis();
    paramPrintWriter.initEncrypt((Key)localObject2);
    localObject2 = new BigInteger[2];
    ElGamalAlgorithm.encrypt(localBigInteger, (BigInteger[])localObject2, b, c, e, g);
    long l4 = System.currentTimeMillis();
    paramPrintWriter.initDecrypt(localElGamalPrivateKey);
    localObject3 = ElGamalAlgorithm.decrypt(localObject2[0], localObject2[1], b, c, d);
    long l5 = System.currentTimeMillis();
    ((PrintWriter)localObject1).println("p = " + b);
    ((PrintWriter)localObject1).println("g = " + c);
    ((PrintWriter)localObject1).println("x = " + d);
    ((PrintWriter)localObject1).println("y = " + e);
    ((PrintWriter)localObject1).println("M = " + localBigInteger);
    ((PrintWriter)localObject1).println("a = " + localObject2[0]);
    ((PrintWriter)localObject1).println("b = " + localObject2[1]);
    if (!localBigInteger.equals(localObject3))
    {
      ((PrintWriter)localObject1).println("DECRYPTION FAILED!");
      ((PrintWriter)localObject1).println("M' = " + localObject3);
    }
    ((PrintWriter)localObject1).println("Encrypt: " + (float)(l4 - l3) / 1000.0F + " seconds");
    ((PrintWriter)localObject1).println("Decrypt: " + (float)(l5 - l4) / 1000.0F + " seconds");
  }

  static
  {
    BigInteger.valueOf(1L);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.RawElGamalCipher
 * JD-Core Version:    0.6.2
 */