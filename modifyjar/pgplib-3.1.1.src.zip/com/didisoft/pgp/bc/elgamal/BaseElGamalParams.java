package com.didisoft.pgp.bc.elgamal;

import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalParams;
import java.math.BigInteger;

public class BaseElGamalParams
  implements ElGamalParams
{
  protected BigInteger p;
  protected BigInteger g;

  public BaseElGamalParams(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
  {
    p = paramBigInteger1;
    g = paramBigInteger2;
  }

  public BigInteger getP()
  {
    return p;
  }

  public BigInteger getG()
  {
    return g;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.BaseElGamalParams
 * JD-Core Version:    0.6.2
 */