package com.didisoft.pgp.bc.elgamal;

import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalKeyPairGenerator;
import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalParams;
import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalPrivateKey;
import com.didisoft.pgp.bc.elgamal.util.Debug;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.InvalidParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.SecureRandom;

public class BaseElGamalKeyPairGenerator extends KeyPairGenerator
  implements ElGamalKeyPairGenerator
{
  private static final int a = Debug.getLevel("ElGamal", "BaseElGamalKeyPairGenerator");
  private static final PrintWriter b = Debug.getOutput();
  private boolean c = true;
  private static final BigInteger d = BigInteger.valueOf(1L);
  private static GenericElGamalParameterSet e = new DefaultElGamalParameterSet();
  protected BigInteger p;
  protected BigInteger g;
  protected SecureRandom source;

  public BaseElGamalKeyPairGenerator()
  {
    super("ElGamal");
  }

  public void initialize(ElGamalParams paramElGamalParams, SecureRandom paramSecureRandom)
    throws InvalidParameterException
  {
    initialize(paramElGamalParams.getP(), paramElGamalParams.getG(), paramSecureRandom);
  }

  public void initialize(BigInteger paramBigInteger1, BigInteger paramBigInteger2, SecureRandom paramSecureRandom)
    throws InvalidParameterException
  {
    if (paramBigInteger1 == null)
      throw new NullPointerException("prime == null");
    if (paramBigInteger2 == null)
      throw new NullPointerException("base == null");
    if (paramSecureRandom == null)
      throw new NullPointerException("random == null");
    if (paramBigInteger2.compareTo(paramBigInteger1) >= 0)
      throw new InvalidParameterException("base >= prime");
    p = paramBigInteger1;
    g = paramBigInteger2;
    source = paramSecureRandom;
  }

  public void initialize(int paramInt, SecureRandom paramSecureRandom)
  {
    ElGamalParams localElGamalParams = null;
    if (e != null)
      localElGamalParams = e.getParameters(paramInt);
    if (localElGamalParams == null)
      localElGamalParams = generateParams(paramInt, paramSecureRandom);
    p = localElGamalParams.getP();
    g = localElGamalParams.getG();
    source = paramSecureRandom;
  }

  public void initialize(int paramInt, boolean paramBoolean, SecureRandom paramSecureRandom)
    throws InvalidParameterException
  {
    if (paramInt < 256)
      throw new InvalidParameterException("ElGamal: prime length " + paramInt + " is too short (< 256" + ")");
    if ((paramBoolean) || (e == null))
      paramBoolean = generateParams(paramInt, paramSecureRandom);
    else if ((paramBoolean = e.getParameters(paramInt)) == null)
      throw new InvalidParameterException("ElGamal: no pre-computed parameters for prime length " + paramInt);
    p = paramBoolean.getP();
    g = paramBoolean.getG();
    source = paramSecureRandom;
  }

  public KeyPair generateKeyPair()
  {
    if (p == null)
      throw new a("ElGamal: key pair generator not initialized");
    int i = p.bitLength() - 1;
    Object localObject = new BigInteger(i, source).setBit(i);
    localObject = new BaseElGamalPrivateKey(p, g, (BigInteger)localObject);
    BaseElGamalPublicKey localBaseElGamalPublicKey = new BaseElGamalPublicKey(p, g, ((ElGamalPrivateKey)localObject).getY());
    return new KeyPair(localBaseElGamalPublicKey, (PrivateKey)localObject);
  }

  public ElGamalParams generateParams(int paramInt, SecureRandom paramSecureRandom)
    throws InvalidParameterException
  {
    if (paramInt < 256)
      throw new InvalidParameterException("ElGamal: prime length " + paramInt + " is too short (< 256" + ")");
    if (c)
    {
      localBigInteger = (BigInteger)(paramInt = Prime.getElGamal(paramInt, 80, paramSecureRandom, 0))[0];
      paramInt = (BigInteger[])paramInt[1];
      paramInt = findG(localBigInteger, paramInt, paramSecureRandom);
      return new BaseElGamalParams(localBigInteger, paramInt);
    }
    BigInteger localBigInteger = (BigInteger)(paramInt = Prime.getElGamal(paramInt, 80, paramSecureRandom, 0, c))[0];
    paramInt = (BigInteger[])paramInt[1];
    paramInt = findG(localBigInteger, paramInt, paramSecureRandom);
    return new BaseElGamalParams(localBigInteger, paramInt);
  }

  public static BigInteger findG(BigInteger paramBigInteger, BigInteger[] paramArrayOfBigInteger, SecureRandom paramSecureRandom)
  {
    BigInteger localBigInteger = paramBigInteger.subtract(d);
    BigInteger[] arrayOfBigInteger = new BigInteger[paramArrayOfBigInteger.length];
    for (int i = 0; i < paramArrayOfBigInteger.length; i++)
      arrayOfBigInteger[i] = localBigInteger.divide(paramArrayOfBigInteger[i]);
    i = paramBigInteger.bitLength() - 1;
    while (!Prime.isGeneratorModP(paramArrayOfBigInteger = new BigInteger(i, paramSecureRandom).setBit(i), paramBigInteger, arrayOfBigInteger));
    if (a >= 4)
      b.println(" OK");
    return paramArrayOfBigInteger;
  }

  public boolean isWithLucasLehmerTest()
  {
    return c;
  }

  public void setWithLucasLehmerTest(boolean paramBoolean)
  {
    c = paramBoolean;
  }

  static
  {
    BigInteger.valueOf(0L);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.BaseElGamalKeyPairGenerator
 * JD-Core Version:    0.6.2
 */