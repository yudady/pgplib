package com.didisoft.pgp.bc.elgamal;

import com.didisoft.pgp.bc.elgamal.util.Debug;
import java.math.BigInteger;
import java.util.Random;

public final class ElGamalAlgorithm
{
  private static final BigInteger a = BigInteger.valueOf(0L);
  private static final BigInteger b = BigInteger.valueOf(1L);

  public static void encrypt(BigInteger paramBigInteger1, BigInteger[] paramArrayOfBigInteger, BigInteger paramBigInteger2, BigInteger paramBigInteger3, BigInteger paramBigInteger4, Random paramRandom)
  {
    BigInteger localBigInteger1 = paramBigInteger2.subtract(b);
    BigInteger localBigInteger2;
    do
      if (!(localBigInteger2 = new BigInteger(paramBigInteger2.bitLength() - 1, paramRandom)).testBit(0))
        localBigInteger2 = localBigInteger2.setBit(0);
    while (!localBigInteger2.gcd(localBigInteger1).equals(b));
    paramArrayOfBigInteger[0] = paramBigInteger3.modPow(localBigInteger2, paramBigInteger2);
    paramArrayOfBigInteger[1] = paramBigInteger4.modPow(localBigInteger2, paramBigInteger2).multiply(paramBigInteger1).mod(paramBigInteger2);
  }

  public static BigInteger decrypt(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, BigInteger paramBigInteger4, BigInteger paramBigInteger5)
  {
    try
    {
      return paramBigInteger2.multiply(paramBigInteger1.modPow(paramBigInteger5, paramBigInteger3).modInverse(paramBigInteger3)).mod(paramBigInteger3);
    }
    catch (ArithmeticException paramBigInteger1)
    {
    }
    throw new a("ElGamal: " + paramBigInteger1.getClass().getName() + " while calculating a.modPow(x, p).modInverse(p) - maybe key was not generated properly?");
  }

  public static void sign(BigInteger paramBigInteger1, BigInteger[] paramArrayOfBigInteger, BigInteger paramBigInteger2, BigInteger paramBigInteger3, BigInteger paramBigInteger4, Random paramRandom)
  {
    BigInteger localBigInteger1 = paramBigInteger2.subtract(b);
    BigInteger localBigInteger2;
    do
      if (!(localBigInteger2 = new BigInteger(paramBigInteger2.bitLength() - 1, paramRandom)).testBit(0))
        localBigInteger2 = localBigInteger2.setBit(0);
    while (!localBigInteger2.gcd(localBigInteger1).equals(b));
    paramBigInteger2 = paramBigInteger3.modPow(localBigInteger2, paramBigInteger2);
    paramArrayOfBigInteger[0] = paramBigInteger2;
    try
    {
      paramArrayOfBigInteger[1] = localBigInteger2.modInverse(localBigInteger1).multiply(paramBigInteger1.subtract(paramBigInteger4.multiply(paramBigInteger2)).mod(localBigInteger1)).mod(localBigInteger1);
      return;
    }
    catch (ArithmeticException localArithmeticException)
    {
    }
    throw new a("ElGamal: ArithmeticException while calculating k.modInverse(p-1)");
  }

  public static boolean verify(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, BigInteger paramBigInteger4, BigInteger paramBigInteger5, BigInteger paramBigInteger6)
  {
    BigInteger localBigInteger = paramBigInteger4.subtract(b);
    if ((paramBigInteger1.compareTo(a) < 0) || (paramBigInteger1.compareTo(localBigInteger) >= 0) || (paramBigInteger2.compareTo(a) < 0) || (paramBigInteger2.compareTo(localBigInteger) >= 0) || (paramBigInteger3.compareTo(a) < 0) || (paramBigInteger3.compareTo(localBigInteger) >= 0))
      return false;
    return paramBigInteger6.modPow(paramBigInteger2, paramBigInteger4).multiply(paramBigInteger2.modPow(paramBigInteger3, paramBigInteger4)).mod(paramBigInteger4).equals(paramBigInteger5.modPow(paramBigInteger1, paramBigInteger4));
  }

  static
  {
    Debug.getLevel("ElGamal", "ElGamalAlgorithm");
    Debug.getOutput();
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.ElGamalAlgorithm
 * JD-Core Version:    0.6.2
 */