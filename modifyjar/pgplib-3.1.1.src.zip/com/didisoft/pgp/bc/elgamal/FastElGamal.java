package com.didisoft.pgp.bc.elgamal;

import java.io.PrintStream;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Properties;

public class FastElGamal
{
  private int a = 31;
  private int b = a + 1;
  private int c = b << 3;
  private PublicKey d;
  private PrivateKey e;

  public FastElGamal(int paramInt)
  {
    setSize(paramInt);
  }

  public FastElGamal()
  {
  }

  public void setSize(int paramInt)
  {
    a = (paramInt - 1);
    b = (a + 1);
    c = (b << 3);
  }

  public void generateKeys()
  {
    int i = (int)System.currentTimeMillis();
    Object localObject2 = new BigInteger(c, 128, new SecureRandom());
    Object localObject3 = a(i, c);
    Object localObject1 = localObject2;
    if (((BigInteger)localObject3).compareTo((BigInteger)localObject2) >= 0)
    {
      localObject2 = localObject3;
      localObject3 = localObject1;
    }
    localObject1 = BigInteger.ONE;
    BigInteger localBigInteger = BigInteger.ONE;
    d = new PublicKey(localBigInteger, (BigInteger)localObject2, (BigInteger)localObject3);
    e = new PrivateKey((BigInteger)localObject1, (BigInteger)localObject2);
  }

  private static BigInteger a(int paramInt1, int paramInt2)
  {
    if (paramInt2 % 8 != 0)
      paramInt2 += 8 - paramInt2 % 8;
    byte[] arrayOfByte = new byte[paramInt2 / 8];
    BigInteger localBigInteger1 = new BigInteger("2147483647");
    BigInteger localBigInteger2 = new BigInteger("1073741823");
    if (paramInt1 <= 0)
      paramInt1 = (int)(Math.random() * 2147483647.0D);
    while (paramInt1 <= 65536)
      paramInt1 <<= 1;
    for (int i = 0; i < paramInt2 / 8; i++)
      arrayOfByte[i] = 0;
    for (i = 0; i < paramInt2; i++)
    {
      BigInteger localBigInteger3;
      if (((localBigInteger3 = new BigInteger((int)(Math.random() * 2147483647.0D)).add(new BigInteger(paramInt1)).mod(localBigInteger1)).compareTo(localBigInteger2) < 0) || (i == 0) || (i == paramInt2 - 1))
      {
        int tmp189_188 = (i / 8);
        byte[] tmp189_183 = arrayOfByte;
        tmp189_183[tmp189_188] = ((byte)(tmp189_183[tmp189_188] | 1 << 7 - i % 8));
      }
    }
    return new BigInteger(1, arrayOfByte);
  }

  public PublicKey getPublicKey()
  {
    return d;
  }

  public PrivateKey getPrivateKey()
  {
    return e;
  }

  public void setPublicKey(PublicKey paramPublicKey)
  {
    d = paramPublicKey;
  }

  public void setPrivateKey(PrivateKey paramPrivateKey)
  {
    if (paramPrivateKey == null)
      System.out.println("Private Key is null");
    else
      System.out.println("Private Key is not null");
    e = paramPrivateKey;
  }

  public byte[] encrypt(byte[] paramArrayOfByte)
  {
    int i = paramArrayOfByte.length;
    BigInteger localBigInteger1 = d.getG();
    BigInteger localBigInteger2 = d.getY();
    BigInteger localBigInteger3 = d.getP();
    BigInteger localBigInteger4 = new BigInteger("1");
    BigInteger localBigInteger5 = localBigInteger3.subtract(localBigInteger4);
    if (i % a != 0)
    {
      int j = i % a;
      i += a - j;
    }
    byte[] arrayOfByte1 = new byte[i / a * b << 1];
    byte[] arrayOfByte2 = new byte[a];
    for (int k = 0; k < i / a; k++)
    {
      while (((localObject1 = a((int)System.currentTimeMillis(), c)).compareTo(localBigInteger3) >= 0) || (!((BigInteger)localObject1).gcd(localBigInteger5).equals(localBigInteger4)));
      for (int m = 0; m < a; m++)
        if (k * a + m < paramArrayOfByte.length)
          arrayOfByte2[m] = paramArrayOfByte[(k * a + m)];
        else
          arrayOfByte2[m] = ((byte)(int)(Math.random() * 255.0D));
      Object localObject2 = new BigInteger(1, arrayOfByte2);
      BigInteger localBigInteger6 = localBigInteger1.modPow((BigInteger)localObject1, localBigInteger3);
      Object localObject1 = localBigInteger2.modPow((BigInteger)localObject1, localBigInteger3).multiply((BigInteger)localObject2).mod(localBigInteger3);
      localObject2 = localBigInteger6.toByteArray();
      localObject1 = ((BigInteger)localObject1).toByteArray();
      a(arrayOfByte1, (byte[])localObject2, localObject2.length - b, (k << 1) * b, b);
      a(arrayOfByte1, (byte[])localObject1, localObject1.length - b, (k << 1) * b + b, b);
    }
    return arrayOfByte1;
  }

  public byte[] sign(byte[] paramArrayOfByte)
  {
    int i = paramArrayOfByte.length;
    BigInteger localBigInteger1 = d.getG();
    d.getY();
    BigInteger localBigInteger2 = e.getX();
    BigInteger localBigInteger3 = e.getP();
    BigInteger localBigInteger4 = new BigInteger("1");
    BigInteger localBigInteger5 = localBigInteger3.subtract(localBigInteger4);
    if (i % a != 0)
    {
      int j = i % a;
      i += a - j;
    }
    byte[] arrayOfByte1 = new byte[i / a * b << 1];
    byte[] arrayOfByte2 = new byte[b + 1];
    for (int k = 0; k < i / a; k++)
    {
      while (((localObject1 = a((int)System.currentTimeMillis(), c)).compareTo(localBigInteger3) >= 0) || (!((BigInteger)localObject1).gcd(localBigInteger5).equals(localBigInteger4)));
      a(arrayOfByte2, paramArrayOfByte, k * a, 1, b);
      Object localObject2 = new BigInteger(1, arrayOfByte2);
      BigInteger localBigInteger6 = localBigInteger1.modPow((BigInteger)localObject1, localBigInteger3);
      Object localObject1 = ((BigInteger)localObject1).modInverse(localBigInteger5).multiply(((BigInteger)localObject2).subtract(localBigInteger2.multiply(localBigInteger6)).mod(localBigInteger5)).mod(localBigInteger5);
      localObject2 = localBigInteger6.toByteArray();
      localObject1 = ((BigInteger)localObject1).toByteArray();
      a(arrayOfByte1, (byte[])localObject2, localObject2.length - b, (k << 1) * b, b);
      a(arrayOfByte1, (byte[])localObject1, localObject1.length - b, (k << 1) * b + b, b);
    }
    return arrayOfByte1;
  }

  private static void a(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 < 0)
      paramInt1 = 0;
    int i = 0;
    if ((j = paramArrayOfByte2.length - paramInt1) < paramInt3)
    {
      i = paramInt3 - j;
      for (j = 0; j < i; j++)
        paramArrayOfByte1[(j + paramInt2)] = 0;
    }
    for (int j = i; j < paramInt3; j++)
      paramArrayOfByte1[(j + paramInt2)] = paramArrayOfByte2[(j + paramInt1 - i)];
  }

  public byte[] decrypt(byte[] paramArrayOfByte, int paramInt)
  {
    if (e == null)
      System.out.println("Private key i snull");
    byte[] arrayOfByte1 = new byte[paramInt];
    byte[] arrayOfByte2 = new byte[b + 1];
    byte[] arrayOfByte3 = new byte[a];
    BigInteger localBigInteger1 = e.getX();
    BigInteger localBigInteger2 = e.getP();
    int i = a;
    for (int j = 0; j < paramArrayOfByte.length / b / 2; j++)
    {
      a(arrayOfByte2, paramArrayOfByte, j * b << 1, 1, b);
      Object localObject = new BigInteger(1, arrayOfByte2);
      a(arrayOfByte2, paramArrayOfByte, (j * b << 1) + b, 1, b);
      BigInteger localBigInteger3;
      localObject = (localBigInteger3 = new BigInteger(1, arrayOfByte2)).multiply(((BigInteger)localObject).modInverse(localBigInteger2).modPow(localBigInteger1, localBigInteger2)).mod(localBigInteger2);
      if (j * a + i > paramInt)
        i = paramInt - j * a;
      if (j * a > paramInt)
        break;
      localObject = ((BigInteger)localObject).toByteArray();
      a(arrayOfByte3, (byte[])localObject, localObject.length - a, 0, a);
      a(arrayOfByte1, arrayOfByte3, 0, j * a, i);
    }
    return arrayOfByte1;
  }

  public boolean verify(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    byte[] arrayOfByte = new byte[b + 1];
    BigInteger localBigInteger1 = d.getG();
    BigInteger localBigInteger2 = d.getY();
    BigInteger localBigInteger3 = d.getP();
    int i = paramArrayOfByte1.length / b / 2 > 0 ? 1 : 0;
    boolean bool;
    for (int j = 0; (j < paramArrayOfByte1.length / b / 2) && (i != 0); j++)
    {
      a(arrayOfByte, paramArrayOfByte2, j * a, 1, b);
      BigInteger localBigInteger4 = new BigInteger(1, arrayOfByte);
      a(arrayOfByte, paramArrayOfByte1, j * b << 1, 1, b);
      BigInteger localBigInteger5 = new BigInteger(1, arrayOfByte);
      a(arrayOfByte, paramArrayOfByte1, (j * b << 1) + b, 1, b);
      BigInteger localBigInteger6 = new BigInteger(1, arrayOfByte);
      bool = localBigInteger2.modPow(localBigInteger5, localBigInteger3).multiply(localBigInteger5.modPow(localBigInteger6, localBigInteger3)).mod(localBigInteger3).equals(localBigInteger1.modPow(localBigInteger4, localBigInteger3));
    }
    return bool;
  }

  public static class PrivateKey
  {
    private BigInteger a;
    private BigInteger b;

    public PrivateKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2)
    {
      a = paramBigInteger1;
      b = paramBigInteger2;
    }

    public PrivateKey(Properties paramProperties)
    {
      String str1 = (String)paramProperties.get("x");
      String str2 = (String)paramProperties.get("p");
      if (str1 == null)
        str1 = (String)paramProperties.get("X");
      if (str2 == null)
        str2 = (String)paramProperties.get("P");
      a = new BigInteger(str1);
      b = new BigInteger(str2);
    }

    public BigInteger getX()
    {
      return a;
    }

    public BigInteger getP()
    {
      return b;
    }

    public Properties getProperties()
    {
      Properties localProperties;
      (localProperties = new Properties()).setProperty("x", a.toString());
      localProperties.setProperty("p", b.toString());
      return localProperties;
    }
  }

  public static class PublicKey
  {
    private BigInteger a;
    private BigInteger b;
    private BigInteger c;

    public PublicKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3)
    {
      a = paramBigInteger1;
      b = paramBigInteger2;
      c = paramBigInteger3;
    }

    public PublicKey(Properties paramProperties)
    {
      String str1 = (String)paramProperties.get("p");
      String str2 = (String)paramProperties.get("y");
      String str3 = (String)paramProperties.get("g");
      if (str1 == null)
        str1 = (String)paramProperties.get("P");
      if (str2 == null)
        str2 = (String)paramProperties.get("Y");
      if (str3 == null)
        str3 = (String)paramProperties.get("G");
      b = new BigInteger(str1);
      a = new BigInteger(str2);
      c = new BigInteger(str3);
    }

    public BigInteger getY()
    {
      return a;
    }

    public BigInteger getP()
    {
      return b;
    }

    public BigInteger getG()
    {
      return c;
    }

    public Properties getProperties()
    {
      Properties localProperties;
      (localProperties = new Properties()).setProperty("y", a.toString());
      localProperties.setProperty("p", b.toString());
      localProperties.setProperty("g", c.toString());
      return localProperties;
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.FastElGamal
 * JD-Core Version:    0.6.2
 */