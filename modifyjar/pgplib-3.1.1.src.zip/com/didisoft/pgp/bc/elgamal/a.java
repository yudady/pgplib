package com.didisoft.pgp.bc.elgamal;

import java.security.ProviderException;

final class a extends ProviderException
{
  public a(String paramString)
  {
    super(paramString);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.a
 * JD-Core Version:    0.6.2
 */