package com.didisoft.pgp.bc.elgamal;

import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalParams;
import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalPublicKey;
import java.math.BigInteger;

public class BaseElGamalPublicKey
  implements ElGamalPublicKey
{
  protected BigInteger p;
  protected BigInteger g;
  protected BigInteger y;

  public BaseElGamalPublicKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3)
  {
    if (paramBigInteger1 == null)
      throw new NullPointerException("p == null");
    if (paramBigInteger2 == null)
      throw new NullPointerException("g == null");
    if (paramBigInteger3 == null)
      throw new NullPointerException("y == null");
    p = paramBigInteger1;
    g = paramBigInteger2;
    y = paramBigInteger3;
  }

  public BaseElGamalPublicKey(ElGamalParams paramElGamalParams, BigInteger paramBigInteger)
  {
    this(paramElGamalParams.getP(), paramElGamalParams.getG(), paramBigInteger);
  }

  public BigInteger getP()
  {
    return p;
  }

  public BigInteger getG()
  {
    return g;
  }

  public BigInteger getY()
  {
    return y;
  }

  public String getAlgorithm()
  {
    return "ElGamal";
  }

  public String getFormat()
  {
    return null;
  }

  public byte[] getEncoded()
  {
    return null;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.BaseElGamalPublicKey
 * JD-Core Version:    0.6.2
 */