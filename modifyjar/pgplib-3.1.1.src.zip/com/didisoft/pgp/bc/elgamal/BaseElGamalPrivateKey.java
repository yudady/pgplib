package com.didisoft.pgp.bc.elgamal;

import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalParams;
import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalPrivateKey;
import java.math.BigInteger;

public class BaseElGamalPrivateKey extends BaseElGamalPublicKey
  implements ElGamalPrivateKey
{
  protected BigInteger x;

  public BaseElGamalPrivateKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3, BigInteger paramBigInteger4)
  {
    super(paramBigInteger1, paramBigInteger2, paramBigInteger4);
    if (paramBigInteger3 == null)
      throw new NullPointerException("x == null");
    x = paramBigInteger3;
  }

  public BaseElGamalPrivateKey(BigInteger paramBigInteger1, BigInteger paramBigInteger2, BigInteger paramBigInteger3)
  {
    this(paramBigInteger1, paramBigInteger2, paramBigInteger3, paramBigInteger2.modPow(paramBigInteger3, paramBigInteger1));
  }

  protected BaseElGamalPrivateKey(ElGamalParams paramElGamalParams, BigInteger paramBigInteger)
  {
    this(paramElGamalParams.getP(), paramElGamalParams.getG(), paramBigInteger);
  }

  public BigInteger getX()
  {
    return x;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.elgamal.BaseElGamalPrivateKey
 * JD-Core Version:    0.6.2
 */