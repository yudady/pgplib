package com.didisoft.pgp.bc;

import java.io.IOException;
import java.io.OutputStream;

public class DummyStream extends OutputStream
{
  public void write(int paramInt)
    throws IOException
  {
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.DummyStream
 * JD-Core Version:    0.6.2
 */