package com.didisoft.pgp.bc;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import lw.bouncycastle.bcpg.ArmoredOutputStream;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;

public class IOUtil
{
  public static void closeStream(InputStream paramInputStream)
  {
    if (paramInputStream != null)
      try
      {
        paramInputStream.close();
        return;
      }
      catch (IOException localIOException)
      {
      }
  }

  public static void closeStream(OutputStream paramOutputStream)
  {
    if (paramOutputStream != null)
      try
      {
        paramOutputStream.flush();
        paramOutputStream.close();
        return;
      }
      catch (IOException localIOException)
      {
      }
  }

  public static InputStream readFileOrAsciiString(String paramString1, String paramString2)
    throws IOException
  {
    if ((paramString1 != null) && (!"".equals(paramString1.trim())))
    {
      if ((paramString1.indexOf("BEGIN") == -1) || (paramString1.indexOf("PGP") == -1))
      {
        if (paramString1.length() >= 256)
        {
          paramString2 = paramString1;
          int j;
          for (int i = 0; i < paramString2.length(); i++);
          if ((((((j = paramString2.charAt(i)) >= 'A') && (j <= 90)) || ((j >= 97) && (j <= 122)) || ((j >= 48) && (j <= 57)) || (j == 43) || (j == 47) || (j == 13) || (j == 10) ? 1 : 0) == 0 ? 0 : (paramString1 == null) || ("".equals(paramString2.trim())) ? 0 : 1) == 0);
        }
      }
      else
        return new ByteArrayInputStream(paramString1.getBytes("ASCII"));
      if (new File(paramString1).exists())
        return new BufferedInputStream(new FileInputStream(paramString1));
      throw new FileNotFoundException("File not found at the specified location: " + paramString1);
    }
    throw new IllegalArgumentException(paramString2);
  }

  public static void exportPublicKeyRing(PGPPublicKeyRing paramPGPPublicKeyRing, String paramString1, boolean paramBoolean, String paramString2)
    throws IOException
  {
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = new FileOutputStream(paramString1);
      exportPublicKeyRing(paramPGPPublicKeyRing, localFileOutputStream, paramBoolean, paramString2);
      return;
    }
    finally
    {
      closeStream(localFileOutputStream);
    }
    throw paramPGPPublicKeyRing;
  }

  public static void exportPublicKeyRing(PGPPublicKeyRing paramPGPPublicKeyRing, OutputStream paramOutputStream, boolean paramBoolean, String paramString)
    throws IOException
  {
    try
    {
      if (paramBoolean)
      {
        OutputStream localOutputStream = paramOutputStream;
        ((ArmoredOutputStream)(paramOutputStream = new ArmoredOutputStream(localOutputStream))).setHeader("Version", paramString);
      }
      paramPGPPublicKeyRing.encode(paramOutputStream);
      return;
    }
    catch (IOException localIOException)
    {
    }
    finally
    {
      if (paramBoolean)
        closeStream(paramOutputStream);
    }
  }

  public static void exportPrivateKey(PGPSecretKeyRing paramPGPSecretKeyRing, String paramString1, boolean paramBoolean, String paramString2)
    throws IOException
  {
    Object localObject1 = null;
    Object localObject2 = null;
    try
    {
      localObject1 = new FileOutputStream(paramString1);
      if (paramBoolean)
      {
        localObject2 = localObject1;
        ((ArmoredOutputStream)(localObject1 = new ArmoredOutputStream(localObject2))).setHeader("Version", paramString2);
      }
      paramPGPSecretKeyRing.encode((OutputStream)localObject1);
      return;
    }
    catch (IOException localIOException)
    {
    }
    finally
    {
      closeStream((OutputStream)localObject1);
      closeStream(localObject2);
    }
    throw paramPGPSecretKeyRing;
  }

  public static void exportPrivateKey(PGPSecretKeyRing paramPGPSecretKeyRing, OutputStream paramOutputStream, boolean paramBoolean, String paramString)
    throws IOException
  {
    try
    {
      if (paramBoolean)
      {
        OutputStream localOutputStream = paramOutputStream;
        ((ArmoredOutputStream)(paramOutputStream = new ArmoredOutputStream(localOutputStream))).setHeader("Version", paramString);
      }
      paramPGPSecretKeyRing.encode(paramOutputStream);
      return;
    }
    catch (IOException localIOException)
    {
    }
    finally
    {
      if (paramBoolean)
        closeStream(paramOutputStream);
    }
  }

  public static com.didisoft.pgp.PGPException newPGPException(lw.bouncycastle.openpgp.PGPException paramPGPException)
  {
    if ((paramPGPException instanceof com.didisoft.pgp.PGPException))
      return (com.didisoft.pgp.PGPException)paramPGPException;
    return new com.didisoft.pgp.PGPException(paramPGPException.getMessage() + (paramPGPException.getUnderlyingException() != null ? " : " + paramPGPException.getUnderlyingException().getMessage() : ""), paramPGPException.getUnderlyingException());
  }

  public static SecureRandom getSecureRandom()
  {
    try
    {
      return SecureRandom.getInstance("SHA1PRNG");
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
    }
    return new SecureRandom();
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.IOUtil
 * JD-Core Version:    0.6.2
 */