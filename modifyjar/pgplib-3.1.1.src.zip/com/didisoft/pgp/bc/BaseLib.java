package com.didisoft.pgp.bc;

import com.didisoft.pgp.KeyStore;
import com.didisoft.pgp.exceptions.NoPublicKeyFoundException;
import com.didisoft.pgp.exceptions.WrongPasswordException;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lw.bouncycastle.bcpg.ArmoredInputStream;
import lw.bouncycastle.openpgp.PGPPrivateKey;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSecretKey;
import lw.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import lw.bouncycastle.openpgp.PGPUtil;

public class BaseLib
{
  protected static String version = "Didisoft OpenPGP Library for Java 3.0";
  protected static BCFactory staticBCFactory = new BCFactory(false);
  protected static final int DEFAULT_BUFFER_SIZE = 1048576;
  protected static final int QUARTER_DEFAULT_BUFFER_SIZE = 262144;
  protected static final String NOT_A_VALID_OPENPGP_MESSAGE = "The supplied data is not a valid OpenPGP message";
  protected static final String UNKNOWN_MESSAGE_FORMAT = "Unknown message format: ";
  public static final String BOUNCY_CASTLE_PROVIDER = "BC";
  private static final byte[] a = { 45, 45, 45, 45, 45, 66, 69, 71, 73, 78, 32, 80, 71, 80, 32 };
  private static final byte[] b = { 45, 45, 45, 45, 45, 69, 78, 68, 32, 80, 71, 80, 32 };
  private static final String c = System.getProperty("line.separator");
  private static final int[] d = { 19, 18, 17, 16 };
  private static Pattern e = Pattern.compile("^(0x)?[A-Fa-f0-9]{6,8}$");

  // ERROR //
  protected PGPSecretKeyRingCollection createPGPSecretKeyRingCollection(InputStream paramInputStream)
    throws IOException, com.didisoft.pgp.PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic 76\011com/didisoft/pgp/bc/BaseLib:cleanGnuPGBackupKeys\011(Ljava/io/InputStream;)Ljava/io/InputStream;
    //   4: dup
    //   5: astore_1
    //   6: invokestatic 163\011lw/bouncycastle/openpgp/PGPUtil:getDecoderStream\011(Ljava/io/InputStream;)Ljava/io/InputStream;
    //   9: dup
    //   10: astore_1
    //   11: instanceof 49
    //   14: ifeq +35 -> 49
    //   17: aload_1
    //   18: checkcast 49\011lw/bouncycastle/bcpg/ArmoredInputStream
    //   21: astore_1
    //   22: aload_1
    //   23: invokevirtual 140\011lw/bouncycastle/bcpg/ArmoredInputStream:isEndOfStream\011()Z
    //   26: ifne +20 -> 46
    //   29: aload_1
    //   30: invokestatic 72\011com/didisoft/pgp/bc/BaseLib:a\011(Ljava/io/InputStream;)Llw/bouncycastle/openpgp/PGPSecretKeyRingCollection;
    //   33: dup
    //   34: astore_2
    //   35: invokevirtual 158\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection:size\011()I
    //   38: ifle +5 -> 43
    //   41: aload_2
    //   42: areturn
    //   43: goto -21 -> 22
    //   46: goto +8 -> 54
    //   49: aload_1
    //   50: invokestatic 72\011com/didisoft/pgp/bc/BaseLib:a\011(Ljava/io/InputStream;)Llw/bouncycastle/openpgp/PGPSecretKeyRingCollection;
    //   53: areturn
    //   54: new 57\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection
    //   57: dup
    //   58: new 41\011java/util/ArrayList
    //   61: dup
    //   62: invokespecial 133\011java/util/ArrayList:<init>\011()V
    //   65: invokespecial 156\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection:<init>\011(Ljava/util/Collection;)V
    //   68: areturn
    //   69: dup
    //   70: astore_1
    //   71: invokestatic 91\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   74: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   54\01168\01169\011lw/bouncycastle/openpgp/PGPException
  }

  // ERROR //
  private static PGPSecretKeyRingCollection a(InputStream paramInputStream)
    throws IOException, com.didisoft.pgp.PGPException
  {
    // Byte code:
    //   0: new 51\011lw/bouncycastle/openpgp/PGPObjectFactory
    //   3: dup
    //   4: aload_0
    //   5: invokespecial 143\011lw/bouncycastle/openpgp/PGPObjectFactory:<init>\011(Ljava/io/InputStream;)V
    //   8: astore_0
    //   9: new 43\011java/util/HashMap
    //   12: dup
    //   13: invokespecial 135\011java/util/HashMap:<init>\011()V
    //   16: astore_2
    //   17: aload_0
    //   18: invokevirtual 144\011lw/bouncycastle/openpgp/PGPObjectFactory:nextObject\011()Ljava/lang/Object;
    //   21: astore_1
    //   22: goto +15 -> 37
    //   25: astore_3
    //   26: new 26\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException
    //   29: dup
    //   30: ldc 10
    //   32: aload_3
    //   33: invokespecial 96\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException:<init>\011(Ljava/lang/String;Ljava/lang/Exception;)V
    //   36: athrow
    //   37: aload_1
    //   38: instanceof 56
    //   41: ifeq +34 -> 75
    //   44: aload_1
    //   45: checkcast 56\011lw/bouncycastle/openpgp/PGPSecretKeyRing
    //   48: astore_3
    //   49: new 36\011java/lang/Long
    //   52: dup
    //   53: aload_3
    //   54: invokevirtual 155\011lw/bouncycastle/openpgp/PGPSecretKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   57: invokevirtual 146\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   60: invokespecial 111\011java/lang/Long:<init>\011(J)V
    //   63: astore 4
    //   65: aload_2
    //   66: aload 4
    //   68: aload_3
    //   69: invokeinterface 166 3 0
    //   74: pop
    //   75: aload_1
    //   76: ifnonnull -59 -> 17
    //   79: new 57\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection
    //   82: dup
    //   83: aload_2
    //   84: invokeinterface 167 1 0
    //   89: invokespecial 156\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection:<init>\011(Ljava/util/Collection;)V
    //   92: areturn
    //   93: dup
    //   94: astore_3
    //   95: invokestatic 91\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   98: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   17\01122\01125\011java/io/IOException
    //   79\01192\01193\011lw/bouncycastle/openpgp/PGPException
  }

  protected PGPPrivateKey getPrivateKey(PGPSecretKeyRingCollection paramPGPSecretKeyRingCollection, long paramLong, String paramString)
    throws WrongPasswordException, com.didisoft.pgp.PGPException
  {
    if (paramString == null)
      paramString = "";
    try
    {
      paramPGPSecretKeyRingCollection = paramPGPSecretKeyRingCollection.getSecretKey(paramLong);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramPGPSecretKeyRingCollection = localPGPException);
    }
    return extractPrivateKey(paramPGPSecretKeyRingCollection, paramString);
  }

  public static PGPPrivateKey extractPrivateKey(PGPSecretKey paramPGPSecretKey, String paramString)
    throws WrongPasswordException, com.didisoft.pgp.PGPException
  {
    return extractPrivateKey(paramPGPSecretKey, paramString == null ? new char[0] : paramString.toCharArray());
  }

  public static PGPPrivateKey extractPrivateKey(PGPSecretKey paramPGPSecretKey, char[] paramArrayOfChar)
    throws WrongPasswordException, com.didisoft.pgp.PGPException
  {
    if (paramPGPSecretKey == null)
      return null;
    try
    {
      return paramPGPSecretKey.extractPrivateKey(staticBCFactory.CreatePBESecretKeyDecryptor(paramArrayOfChar));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      if ((paramPGPSecretKey = localPGPException).getMessage().toLowerCase().startsWith("checksum mismatch"))
        throw new WrongPasswordException(paramPGPSecretKey.getMessage(), paramPGPSecretKey.getUnderlyingException());
    }
    throw IOUtil.newPGPException(paramPGPSecretKey);
  }

  protected static InputStream readFileOrAsciiString(String paramString1, String paramString2)
    throws IOException
  {
    return IOUtil.readFileOrAsciiString(paramString1, paramString2);
  }

  private static byte[] b(InputStream paramInputStream)
    throws IOException
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i;
    while (((i = paramInputStream.read()) >= 0) && (i != 45))
      if (i >= 0)
        localStringBuffer.append((char)i);
      else
        return localStringBuffer.toString().getBytes("ASCII");
    while (((i = paramInputStream.read()) >= 0) && (i == 45))
      if (i >= 0)
        localStringBuffer.append((char)i);
      else
        return localStringBuffer.toString().getBytes("ASCII");
    localStringBuffer.append((char)i);
    return localStringBuffer.toString().getBytes("ASCII");
  }

  public static InputStream cleanGnuPGBackupKeys(InputStream paramInputStream)
    throws IOException
  {
    if (paramInputStream.markSupported())
      paramInputStream = paramInputStream;
    else
      paramInputStream = new BufferedInputStreamExtended(paramInputStream);
    paramInputStream.mark(4096);
    if (!(PGPUtil.getDecoderStream(paramInputStream) instanceof ArmoredInputStream))
      return paramInputStream;
    paramInputStream.reset();
    Object localObject = new DirectByteArrayOutputStream(4096);
    byte[] arrayOfByte1 = new byte[a.length];
    byte[] arrayOfByte2 = new byte[a.length];
    byte[] arrayOfByte3 = new byte[b.length];
    byte[] arrayOfByte4 = new byte[b.length];
    int j;
    while ((j = paramInputStream.read()) >= 0)
    {
      arrayOfByte2[(arrayOfByte2.length - 1)] = ((byte)j);
      while ((!Arrays.equals(a, arrayOfByte2)) && (j >= 0))
      {
        System.arraycopy(arrayOfByte2, 1, arrayOfByte1, 0, arrayOfByte1.length - 1);
        arrayOfByte2[(arrayOfByte2.length - 1)] = ((byte)j);
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length - 1);
        j = paramInputStream.read();
      }
      if (j == -1)
        break;
      ((DirectByteArrayOutputStream)localObject).write(arrayOfByte2);
      ((DirectByteArrayOutputStream)localObject).write(j);
      ((DirectByteArrayOutputStream)localObject).write(b(paramInputStream));
      j = paramInputStream.read();
      arrayOfByte4[(arrayOfByte4.length - 1)] = ((byte)j);
      while ((!Arrays.equals(b, arrayOfByte4)) && (j >= 0))
      {
        ((DirectByteArrayOutputStream)localObject).write(j);
        System.arraycopy(arrayOfByte4, 1, arrayOfByte3, 0, arrayOfByte3.length - 1);
        arrayOfByte4[(arrayOfByte4.length - 1)] = ((byte)j);
        System.arraycopy(arrayOfByte3, 0, arrayOfByte4, 0, arrayOfByte4.length - 1);
        j = paramInputStream.read();
      }
      if (j == -1)
        break;
      ((DirectByteArrayOutputStream)localObject).write(j);
      ((DirectByteArrayOutputStream)localObject).write(b(paramInputStream));
    }
    if (((DirectByteArrayOutputStream)localObject).size() == 0)
    {
      paramInputStream.reset();
      pipeAll(paramInputStream, (OutputStream)localObject);
    }
    replaceAll(paramInputStream = new StringBuffer(new String(((DirectByteArrayOutputStream)localObject).getArray(), 0, ((DirectByteArrayOutputStream)localObject).size(), "ASCII")), "\r\r\n", c);
    if ((paramInputStream.indexOf("Comment") != -1) || (paramInputStream.indexOf("Version") != -1))
      replaceAll(paramInputStream, "\r\n\r\n", c);
    localObject = new BufferedReader(new StringReader(paramInputStream.toString()));
    paramInputStream.setLength(0);
    String str;
    while ((str = ((BufferedReader)localObject).readLine()) != null)
      paramInputStream.append(str).append(c);
    for (int i = 0; (paramInputStream.indexOf("Comment", i) != -1) || (paramInputStream.indexOf("Version", i) != -1); i++)
    {
      int k;
      if ((paramInputStream.indexOf("Comment", i) > paramInputStream.indexOf("Version", i)) && (paramInputStream.indexOf("Comment", i) > paramInputStream.indexOf(c, paramInputStream.indexOf("Version", i)) + c.length()) && (paramInputStream.indexOf("Version", i) != -1))
      {
        k = paramInputStream.indexOf(c, paramInputStream.indexOf("Version", i) + 1);
        i = paramInputStream.indexOf("Version", i);
        if (!paramInputStream.substring(k + c.length(), k + 2 * c.length()).equals(c))
          paramInputStream.insert(k + c.length(), c);
      }
      else if (paramInputStream.indexOf("Comment", i) != -1)
      {
        k = paramInputStream.indexOf(c, paramInputStream.indexOf("Comment", i) + 1);
        i = paramInputStream.indexOf("Comment", i);
        if (!paramInputStream.substring(k + c.length(), k + 2 * c.length()).equals(c))
          paramInputStream.insert(k + c.length(), c);
      }
      else
      {
        k = paramInputStream.indexOf(c, paramInputStream.indexOf("Version", i) + 1);
        i = paramInputStream.indexOf("Version", i);
        if (!paramInputStream.substring(k + c.length(), k + 2 * c.length()).equals(c))
          paramInputStream.insert(k + c.length(), c);
      }
    }
    return new ByteArrayInputStream(paramInputStream.toString().getBytes("ASCII"));
  }

  public static void replaceAll(StringBuffer paramStringBuffer, String paramString1, String paramString2)
  {
    for (int i = paramStringBuffer.indexOf(paramString1); i != -1; i = paramStringBuffer.indexOf(paramString1, i))
    {
      paramStringBuffer.replace(i, i + paramString1.length(), paramString2);
      i += paramString2.length();
    }
  }

  // ERROR //
  protected PGPPublicKeyRingCollection createPGPPublicKeyRingCollection(InputStream paramInputStream)
    throws IOException, com.didisoft.pgp.PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic 76\011com/didisoft/pgp/bc/BaseLib:cleanGnuPGBackupKeys\011(Ljava/io/InputStream;)Ljava/io/InputStream;
    //   4: dup
    //   5: astore_1
    //   6: invokestatic 163\011lw/bouncycastle/openpgp/PGPUtil:getDecoderStream\011(Ljava/io/InputStream;)Ljava/io/InputStream;
    //   9: dup
    //   10: astore_1
    //   11: instanceof 49
    //   14: ifeq +51 -> 65
    //   17: aload_1
    //   18: checkcast 49\011lw/bouncycastle/bcpg/ArmoredInputStream
    //   21: astore_1
    //   22: aload_1
    //   23: invokevirtual 140\011lw/bouncycastle/bcpg/ArmoredInputStream:isEndOfStream\011()Z
    //   26: ifne +36 -> 62
    //   29: new 20\011com/didisoft/pgp/bc/BoolValue
    //   32: dup
    //   33: invokespecial 84\011com/didisoft/pgp/bc/BoolValue:<init>\011()V
    //   36: astore_2
    //   37: aload_1
    //   38: aload_2
    //   39: invokestatic 73\011com/didisoft/pgp/bc/BaseLib:a\011(Ljava/io/InputStream;Lcom/didisoft/pgp/bc/BoolValue;)Llw/bouncycastle/openpgp/PGPPublicKeyRingCollection;
    //   42: dup
    //   43: astore_3
    //   44: invokevirtual 153\011lw/bouncycastle/openpgp/PGPPublicKeyRingCollection:size\011()I
    //   47: ifle +5 -> 52
    //   50: aload_3
    //   51: areturn
    //   52: aload_2
    //   53: getfield 68\011com/didisoft/pgp/bc/BoolValue:value\011Z
    //   56: ifne +6 -> 62
    //   59: goto -37 -> 22
    //   62: goto +15 -> 77
    //   65: aload_1
    //   66: new 20\011com/didisoft/pgp/bc/BoolValue
    //   69: dup
    //   70: invokespecial 84\011com/didisoft/pgp/bc/BoolValue:<init>\011()V
    //   73: invokestatic 73\011com/didisoft/pgp/bc/BaseLib:a\011(Ljava/io/InputStream;Lcom/didisoft/pgp/bc/BoolValue;)Llw/bouncycastle/openpgp/PGPPublicKeyRingCollection;
    //   76: areturn
    //   77: new 54\011lw/bouncycastle/openpgp/PGPPublicKeyRingCollection
    //   80: dup
    //   81: new 41\011java/util/ArrayList
    //   84: dup
    //   85: invokespecial 133\011java/util/ArrayList:<init>\011()V
    //   88: invokespecial 151\011lw/bouncycastle/openpgp/PGPPublicKeyRingCollection:<init>\011(Ljava/util/Collection;)V
    //   91: areturn
    //   92: dup
    //   93: astore_1
    //   94: invokestatic 91\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   97: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   77\01191\01192\011lw/bouncycastle/openpgp/PGPException
  }

  private static PGPPublicKeyRingCollection a(InputStream paramInputStream, BoolValue paramBoolValue)
    throws IOException, com.didisoft.pgp.PGPException
  {
    (paramInputStream = new PGPObjectFactory2(paramInputStream)).setLoadingKey(true);
    HashMap localHashMap = new HashMap();
    try
    {
      Object localObject;
      while ((localObject = paramInputStream.nextObject()) != null)
        if ((localObject instanceof PGPPublicKeyRing))
        {
          localObject = (PGPPublicKeyRing)localObject;
          Long localLong = new Long(((PGPPublicKeyRing)localObject).getPublicKey().getKeyID());
          localHashMap.put(localLong, localObject);
        }
    }
    catch (UnknownKeyPacketsException localUnknownKeyPacketsException)
    {
      paramBoolValue.value = true;
    }
    catch (IOException localIOException)
    {
      throw new NoPublicKeyFoundException(localIOException.getMessage(), localIOException);
    }
    try
    {
      return new PGPPublicKeyRingCollection(localHashMap.values());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw new NoPublicKeyFoundException(localPGPException.getMessage(), localPGPException.getUnderlyingException());
    }
  }

  protected static PGPPublicKey readPublicVerificationKey(KeyStore paramKeyStore, long paramLong)
    throws IOException
  {
    return readPublicVerificationKey(paramKeyStore.getRawPublicKeys(), paramLong);
  }

  protected PGPPublicKey readPublicVerificationKey(InputStream paramInputStream, long paramLong)
    throws IOException, com.didisoft.pgp.PGPException
  {
    return readPublicVerificationKey(paramInputStream = createPGPPublicKeyRingCollection(paramInputStream), paramLong);
  }

  protected static PGPPublicKey readPublicVerificationKey(PGPPublicKeyRingCollection paramPGPPublicKeyRingCollection, long paramLong)
    throws IOException
  {
    Object localObject1 = null;
    paramPGPPublicKeyRingCollection = paramPGPPublicKeyRingCollection.getKeyRings();
    while ((localObject1 == null) && (paramPGPPublicKeyRingCollection.hasNext()))
    {
      Object localObject2 = (localObject2 = (PGPPublicKeyRing)paramPGPPublicKeyRingCollection.next()).getPublicKeys();
      while ((localObject1 == null) && (((Iterator)localObject2).hasNext()))
      {
        PGPPublicKey localPGPPublicKey;
        if ((isForVerification(localPGPPublicKey = (PGPPublicKey)((Iterator)localObject2).next())) && (paramLong == localPGPPublicKey.getKeyID()))
          localObject1 = localPGPPublicKey;
      }
    }
    return localObject1;
  }

  public static boolean isForVerification(PGPPublicKey paramPGPPublicKey)
  {
    if ((paramPGPPublicKey.getAlgorithm() == 18) || (paramPGPPublicKey.getAlgorithm() == 16) || (paramPGPPublicKey.getAlgorithm() == 20) || (paramPGPPublicKey.getAlgorithm() == 21) || (paramPGPPublicKey.getAlgorithm() == 2))
      return false;
    paramPGPPublicKey = 2;
    paramPGPPublicKey = paramPGPPublicKey;
    Object localObject;
    if (paramPGPPublicKey.isMasterKey())
    {
      for (int i = 0; i != d.length; i++)
      {
        localObject = paramPGPPublicKey.getSignaturesOfType(d[i]);
        while (((Iterator)localObject).hasNext())
        {
          PGPSignature localPGPSignature;
          if (!a(localPGPSignature = (PGPSignature)((Iterator)localObject).next(), 2))
            return false;
        }
      }
    }
    else
    {
      Iterator localIterator = paramPGPPublicKey.getSignaturesOfType(24);
      while (localIterator.hasNext())
        if (!a(localObject = (PGPSignature)localIterator.next(), 2))
          return false;
    }
    return true;
  }

  private static boolean a(PGPSignature paramPGPSignature, int paramInt)
  {
    return (!paramPGPSignature.hasSubpackets()) || (!(paramPGPSignature = paramPGPSignature.getHashedSubPackets()).hasSubpacket(27)) || ((paramPGPSignature.getKeyFlags() & paramInt) != 0);
  }

  protected static void pipeAll(InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException
  {
    byte[] arrayOfByte = new byte[1048576];
    int i;
    while ((i = paramInputStream.read(arrayOfByte)) > 0)
      paramOutputStream.write(arrayOfByte, 0, i);
  }

  public static boolean isHexId(String paramString)
  {
    return e.matcher(paramString).matches();
  }

  static
  {
    Logger.getLogger(BaseLib.class.getName());
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.BaseLib
 * JD-Core Version:    0.6.2
 */