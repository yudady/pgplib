package com.didisoft.pgp.bc;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import lw.bouncycastle.bcpg.BCPGInputStream;
import lw.bouncycastle.bcpg.ExperimentalPacket;
import lw.bouncycastle.openpgp.PGPCompressedData;
import lw.bouncycastle.openpgp.PGPEncryptedDataList;
import lw.bouncycastle.openpgp.PGPException;
import lw.bouncycastle.openpgp.PGPLiteralData;
import lw.bouncycastle.openpgp.PGPMarker;
import lw.bouncycastle.openpgp.PGPObjectFactory;
import lw.bouncycastle.openpgp.PGPOnePassSignature;
import lw.bouncycastle.openpgp.PGPOnePassSignatureList;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureList;

public class PGPObjectFactory2 extends PGPObjectFactory
{
  private BCPGInputStream a;
  private BCFactory b = new BCFactory(false);
  private boolean c = false;

  public PGPObjectFactory2(InputStream paramInputStream)
  {
    super(paramInputStream);
    a = new BCPGInputStream(paramInputStream);
  }

  public PGPObjectFactory2(byte[] paramArrayOfByte)
  {
    this(new ByteArrayInputStream(paramArrayOfByte));
  }

  public Object nextObject()
    throws IOException
  {
    try
    {
      switch (a.nextPacketTag())
      {
      case -1:
        return null;
      case 2:
        ArrayList localArrayList1 = new ArrayList();
        while (a.nextPacketTag() == 2)
          try
          {
            localArrayList1.add(ReflectionUtils.callPrivateConstrtuctor(PGPSignature.class, new Object[] { a }));
          }
          catch (Exception localException1)
          {
            throw new IOException("can't create signature object: " + localException1);
          }
        return new PGPSignatureList((PGPSignature[])localException1.toArray(new PGPSignature[localException1.size()]));
      case 5:
        try
        {
          return new PGPSecretKeyRing(a, b.a());
        }
        catch (PGPException localPGPException)
        {
          throw new IOException("can't create secret key object: " + localPGPException);
        }
      case 6:
        return new PGPPublicKeyRing(a, b.a());
      case 8:
        return new PGPCompressedData(a);
      case 11:
        return new PGPLiteralData(a);
      case 1:
      case 3:
        return new PGPEncryptedDataList(a);
      case 4:
        ArrayList localArrayList2 = new ArrayList();
        while (a.nextPacketTag() == 4)
          try
          {
            localArrayList2.add(ReflectionUtils.callPrivateConstrtuctor(PGPOnePassSignature.class, new Object[] { a }));
          }
          catch (Exception localException2)
          {
            if ((c) && ((localException2 instanceof IOException)))
              throw new UnknownKeyPacketsException("corrupted object in stream 4", localException2);
            throw new IOException("can't create one pass signature object: " + localException2);
          }
        return new PGPOnePassSignatureList((PGPOnePassSignature[])localException2.toArray(new PGPOnePassSignature[localException2.size()]));
      case 10:
        return new PGPMarker(a);
      case 60:
      case 61:
      case 62:
      case 63:
        return (ExperimentalPacket)a.readPacket();
      case 9:
        return new PGP2xPBEEncryptedData(a);
      case 0:
      case 7:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 39:
      case 40:
      case 41:
      case 42:
      case 43:
      case 44:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 59:
      }
    }
    catch (IOException localIOException)
    {
      if (c)
        throw new UnknownKeyPacketsException(localIOException.getMessage());
      throw localIOException;
    }
    if (c)
      throw new UnknownKeyPacketsException("unknown object in stream " + a.nextPacketTag());
    throw new IOException("unknown object in stream " + a.nextPacketTag());
  }

  public boolean isLoadingKey()
  {
    return c;
  }

  public void setLoadingKey(boolean paramBoolean)
  {
    c = paramBoolean;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.PGPObjectFactory2
 * JD-Core Version:    0.6.2
 */