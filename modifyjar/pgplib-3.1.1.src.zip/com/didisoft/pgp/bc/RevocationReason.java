package com.didisoft.pgp.bc;

import lw.bouncycastle.bcpg.SignatureSubpacket;
import lw.bouncycastle.util.Strings;

public class RevocationReason extends SignatureSubpacket
{
  public static final byte REASON_NO_REASON = 0;
  public static final byte REASON_KEY_SUPERSEDED = 1;
  public static final byte REASON_KEY_COMPROMISED = 2;
  public static final byte REASON_KEY_NO_LONGER_USED = 3;
  public static final byte REASON_USER_NO_LONGER_USED = 32;

  public RevocationReason(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(29, paramBoolean, paramArrayOfByte);
  }

  public RevocationReason(boolean paramBoolean, byte paramByte, String paramString)
  {
    super(29, paramBoolean, paramString);
  }

  public byte getRevocationReason()
  {
    return data[0];
  }

  public String getRevocationDescription()
  {
    if (data.length == 1)
      return "";
    byte[] arrayOfByte = new byte[data.length - 1];
    System.arraycopy(data, 1, arrayOfByte, 0, arrayOfByte.length);
    return Strings.fromUTF8ByteArray(arrayOfByte);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.RevocationReason
 * JD-Core Version:    0.6.2
 */