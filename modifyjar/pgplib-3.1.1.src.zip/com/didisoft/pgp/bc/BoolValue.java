package com.didisoft.pgp.bc;

public class BoolValue
{
  public boolean value = false;

  public BoolValue()
  {
    value = false;
  }

  public BoolValue(boolean paramBoolean)
  {
    value = paramBoolean;
  }

  public boolean isValue()
  {
    return value;
  }

  public void setValue(boolean paramBoolean)
  {
    value = paramBoolean;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.BoolValue
 * JD-Core Version:    0.6.2
 */