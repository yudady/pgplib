package com.didisoft.pgp.bc;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.security.Security;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import lw.bouncycastle.bcpg.BCPGInputStream;
import lw.bouncycastle.crypto.BufferedBlockCipher;
import lw.bouncycastle.crypto.StreamBlockCipher;
import lw.bouncycastle.crypto.digests.MD5Digest;
import lw.bouncycastle.crypto.engines.IDEAEngine;
import lw.bouncycastle.crypto.io.CipherInputStream;
import lw.bouncycastle.crypto.modes.CFBBlockCipher;
import lw.bouncycastle.crypto.params.KeyParameter;
import lw.bouncycastle.crypto.params.ParametersWithIV;
import lw.bouncycastle.openpgp.PGPDataValidationException;
import lw.bouncycastle.openpgp.PGPEncryptedDataList;
import lw.bouncycastle.openpgp.PGPException;

public class PGP2xPBEEncryptedData extends PGPEncryptedDataList
{
  private byte[] a;
  private int b = 8;
  private BCPGInputStream c;
  private InputStream d;

  public PGP2xPBEEncryptedData(BCPGInputStream paramBCPGInputStream)
    throws IOException
  {
    super(paramBCPGInputStream);
    c = paramBCPGInputStream;
    byte[] arrayOfByte = new byte[b + 2];
    paramBCPGInputStream.read(arrayOfByte, 0, b + 2);
    a = arrayOfByte;
  }

  public InputStream getInputStream()
  {
    return c;
  }

  public InputStream getDataStream(char[] paramArrayOfChar)
    throws PGPException
  {
    try
    {
      Object localObject2 = "BC";
      Object localObject1 = paramArrayOfChar;
      paramArrayOfChar = 1;
      Security.getProvider((String)localObject2);
      paramArrayOfChar = "IDEA";
      localObject2 = new byte[localObject1.length];
      for (int j = 0; j != localObject1.length; j++)
        localObject2[j] = ((byte)localObject1[j]);
      byte[] arrayOfByte2 = new byte[16];
      int m = 0;
      for (int n = 0; m < arrayOfByte2.length; n++)
      {
        localObject1 = new MD5Digest();
        for (int i1 = 0; i1 != n; i1++)
          ((MD5Digest)localObject1).update((byte)0);
        ((MD5Digest)localObject1).update((byte[])localObject2, 0, localObject2.length);
        byte[] arrayOfByte3 = new byte[((MD5Digest)localObject1).getByteLength()];
        ((MD5Digest)localObject1).doFinal(arrayOfByte3, 0);
        if (arrayOfByte3.length > arrayOfByte2.length - m)
          System.arraycopy(arrayOfByte3, 0, arrayOfByte2, m, arrayOfByte2.length - m);
        else
          System.arraycopy(arrayOfByte3, 0, arrayOfByte2, m, arrayOfByte3.length);
        m += arrayOfByte3.length;
      }
      for (int i2 = 0; i2 != localObject2.length; i2++)
        localObject2[i2] = 0;
      paramArrayOfChar = new SecretKeySpec(arrayOfByte2, paramArrayOfChar);
      (localObject1 = new CFBBlockCipher(new IDEAEngine(), 64)).init(false, new KeyParameter(paramArrayOfChar.getEncoded()));
      localObject2 = new byte[8];
      ((StreamBlockCipher)localObject1).processBytes(a, 0, 8, (byte[])localObject2, 0);
      arrayOfByte2 = new byte[2];
      ((StreamBlockCipher)localObject1).processBytes(a, 8, 2, arrayOfByte2, 0);
      if (2 < arrayOfByte2.length)
        throw new EOFException("unexpected end of stream.");
      int i = (localObject2[(localObject2.length - 2)] == arrayOfByte2[0]) && (localObject2[(localObject2.length - 1)] == arrayOfByte2[1]) ? 1 : 0;
      int k = (arrayOfByte2[0] == 0) && (arrayOfByte2[1] == 0) ? 1 : 0;
      if ((i == 0) && (k == 0))
        throw new PGPDataValidationException("quick check failed.");
      byte[] arrayOfByte1 = new byte[((StreamBlockCipher)localObject1).getBlockSize()];
      System.arraycopy(a, a.length - ((StreamBlockCipher)localObject1).getBlockSize(), arrayOfByte1, 0, ((StreamBlockCipher)localObject1).getBlockSize());
      (localObject1 = new BufferedBlockCipher(new CFBBlockCipher(new IDEAEngine(), 64))).init(false, new ParametersWithIV(new KeyParameter(paramArrayOfChar.getEncoded()), arrayOfByte1));
      d = new BCPGInputStream(new CipherInputStream(getInputStream(), (BufferedBlockCipher)localObject1));
      return d;
    }
    catch (PGPException localPGPException)
    {
      throw (paramArrayOfChar = localPGPException);
    }
    catch (Exception paramArrayOfChar)
    {
    }
    throw new PGPException("Exception creating cipher", paramArrayOfChar);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.PGP2xPBEEncryptedData
 * JD-Core Version:    0.6.2
 */