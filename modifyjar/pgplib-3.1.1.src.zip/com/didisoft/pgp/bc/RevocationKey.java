package com.didisoft.pgp.bc;

import lw.bouncycastle.bcpg.SignatureSubpacket;

public class RevocationKey extends SignatureSubpacket
{
  public static final byte CLASS_DEFAULT = -128;
  public static final byte CLASS_SENSITIVE = 64;

  public RevocationKey(boolean paramBoolean, byte[] paramArrayOfByte)
  {
    super(12, paramBoolean, paramArrayOfByte);
  }

  public RevocationKey(boolean paramBoolean, byte paramByte1, byte paramByte2, byte[] paramArrayOfByte)
  {
    super(12, paramBoolean, paramArrayOfByte);
  }

  public byte getSignatureClass()
  {
    return data[0];
  }

  public byte getAlgorithm()
  {
    return data[1];
  }

  public byte[] getFingerprint()
  {
    byte[] arrayOfByte = new byte[data.length - 2];
    System.arraycopy(data, 2, arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.RevocationKey
 * JD-Core Version:    0.6.2
 */