package com.didisoft.pgp.bc;

import java.io.IOException;
import java.security.SecureRandom;
import lw.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import lw.bouncycastle.openpgp.PGPException;
import lw.bouncycastle.openpgp.PGPPrivateKey;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPSignatureGenerator;
import lw.bouncycastle.openpgp.PGPV3SignatureGenerator;
import lw.bouncycastle.openpgp.operator.KeyFingerPrintCalculator;
import lw.bouncycastle.openpgp.operator.PBEDataDecryptorFactory;
import lw.bouncycastle.openpgp.operator.PBEKeyEncryptionMethodGenerator;
import lw.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import lw.bouncycastle.openpgp.operator.PBESecretKeyEncryptor;
import lw.bouncycastle.openpgp.operator.PGPContentSignerBuilder;
import lw.bouncycastle.openpgp.operator.PGPContentVerifierBuilderProvider;
import lw.bouncycastle.openpgp.operator.PGPDataEncryptorBuilder;
import lw.bouncycastle.openpgp.operator.PublicKeyDataDecryptorFactory;
import lw.bouncycastle.openpgp.operator.PublicKeyKeyEncryptionMethodGenerator;
import lw.bouncycastle.openpgp.operator.bc.BcKeyFingerprintCalculator;
import lw.bouncycastle.openpgp.operator.bc.BcPBEDataDecryptorFactory;
import lw.bouncycastle.openpgp.operator.bc.BcPBEKeyEncryptionMethodGenerator;
import lw.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder;
import lw.bouncycastle.openpgp.operator.bc.BcPBESecretKeyEncryptorBuilder;
import lw.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder;
import lw.bouncycastle.openpgp.operator.bc.BcPGPContentVerifierBuilderProvider;
import lw.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder;
import lw.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import lw.bouncycastle.openpgp.operator.bc.BcPublicKeyDataDecryptorFactory;
import lw.bouncycastle.openpgp.operator.bc.BcPublicKeyKeyEncryptionMethodGenerator;
import lw.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import lw.bouncycastle.openpgp.operator.jcajce.JcaPGPContentSignerBuilder;
import lw.bouncycastle.openpgp.operator.jcajce.JcaPGPContentVerifierBuilderProvider;
import lw.bouncycastle.openpgp.operator.jcajce.JcaPGPDigestCalculatorProviderBuilder;
import lw.bouncycastle.openpgp.operator.jcajce.JcePBEDataDecryptorFactoryBuilder;
import lw.bouncycastle.openpgp.operator.jcajce.JcePBEKeyEncryptionMethodGenerator;
import lw.bouncycastle.openpgp.operator.jcajce.JcePBESecretKeyDecryptorBuilder;
import lw.bouncycastle.openpgp.operator.jcajce.JcePBESecretKeyEncryptorBuilder;
import lw.bouncycastle.openpgp.operator.jcajce.JcePGPDataEncryptorBuilder;
import lw.bouncycastle.openpgp.operator.jcajce.JcePublicKeyDataDecryptorFactoryBuilder;
import lw.bouncycastle.openpgp.operator.jcajce.JcePublicKeyKeyEncryptionMethodGenerator;

public class BCFactory
{
  private boolean a = false;

  public BCFactory(boolean paramBoolean)
  {
    a = paramBoolean;
  }

  public PGPPublicKeyRing CreatePGPPublicKeyRing(byte[] paramArrayOfByte)
    throws IOException
  {
    return new PGPPublicKeyRing(paramArrayOfByte, a());
  }

  final KeyFingerPrintCalculator a()
  {
    if (a)
      return new JcaKeyFingerprintCalculator();
    return new BcKeyFingerprintCalculator();
  }

  public PBESecretKeyDecryptor CreatePBESecretKeyDecryptor(char[] paramArrayOfChar)
    throws PGPException
  {
    if (a)
      return new JcePBESecretKeyDecryptorBuilder().setProvider("BC").build(paramArrayOfChar);
    return new BcPBESecretKeyDecryptorBuilder(new BcPGPDigestCalculatorProvider()).build(paramArrayOfChar);
  }

  public PBESecretKeyDecryptor CreatePBESecretKeyDecryptor(String paramString)
    throws PGPException
  {
    if (a)
      return new JcePBESecretKeyDecryptorBuilder().setProvider("BC").build(paramString == null ? "".toCharArray() : paramString.toCharArray());
    return new BcPBESecretKeyDecryptorBuilder(new BcPGPDigestCalculatorProvider()).build(paramString == null ? "".toCharArray() : paramString.toCharArray());
  }

  public PBESecretKeyEncryptor CreatePBESecretKeyEncryptor(String paramString, int paramInt)
    throws PGPException
  {
    if (a)
      return new JcePBESecretKeyEncryptorBuilder(paramInt).setProvider("BC").build(paramString == null ? "".toCharArray() : paramString.toCharArray());
    return new BcPBESecretKeyEncryptorBuilder(paramInt).build(paramString == null ? "".toCharArray() : paramString.toCharArray());
  }

  public PBEDataDecryptorFactory CreatePBEDataDecryptorFactory(String paramString)
    throws PGPException
  {
    if (a)
      return new JcePBEDataDecryptorFactoryBuilder(new JcaPGPDigestCalculatorProviderBuilder().setProvider("BC").build()).build(paramString == null ? new char[0] : paramString.toCharArray());
    return new BcPBEDataDecryptorFactory(paramString == null ? new char[0] : paramString.toCharArray(), new BcPGPDigestCalculatorProvider());
  }

  public PGPSignatureGenerator CreatePGPSignatureGenerator(int paramInt1, int paramInt2)
  {
    return new PGPSignatureGenerator(CreatePGPContentSignerBuilder(paramInt1, paramInt2));
  }

  public PGPV3SignatureGenerator CreatePGPV3SignatureGenerator(int paramInt1, int paramInt2)
  {
    return new PGPV3SignatureGenerator(CreatePGPContentSignerBuilder(paramInt1, paramInt2));
  }

  public PGPContentSignerBuilder CreatePGPContentSignerBuilder(int paramInt1, int paramInt2)
  {
    if (a)
      return new JcaPGPContentSignerBuilder(paramInt1, paramInt2);
    return new BcPGPContentSignerBuilder(paramInt1, paramInt2);
  }

  // ERROR //
  public void initSign(PGPSignatureGenerator paramPGPSignatureGenerator, int paramInt, PGPPrivateKey paramPGPPrivateKey)
    throws com.didisoft.pgp.PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: iload_2
    //   2: aload_3
    //   3: invokevirtual 52\011lw/bouncycastle/openpgp/PGPSignatureGenerator:init\011(ILlw/bouncycastle/openpgp/PGPPrivateKey;)V
    //   6: return
    //   7: dup
    //   8: astore_1
    //   9: invokestatic 43\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   12: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   0\0116\0117\011lw/bouncycastle/openpgp/PGPException
  }

  // ERROR //
  public void initSign(PGPV3SignatureGenerator paramPGPV3SignatureGenerator, int paramInt, PGPPrivateKey paramPGPPrivateKey)
    throws com.didisoft.pgp.PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: iload_2
    //   2: aload_3
    //   3: invokevirtual 54\011lw/bouncycastle/openpgp/PGPV3SignatureGenerator:init\011(ILlw/bouncycastle/openpgp/PGPPrivateKey;)V
    //   6: return
    //   7: dup
    //   8: astore_1
    //   9: invokestatic 43\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   12: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   0\0116\0117\011lw/bouncycastle/openpgp/PGPException
  }

  public PublicKeyKeyEncryptionMethodGenerator CreatePublicKeyKeyEncryptionMethodGenerator(PGPPublicKey paramPGPPublicKey)
  {
    if (a)
      return new JcePublicKeyKeyEncryptionMethodGenerator(paramPGPPublicKey);
    return new BcPublicKeyKeyEncryptionMethodGenerator(paramPGPPublicKey);
  }

  // ERROR //
  public void initVerify(lw.bouncycastle.openpgp.PGPSignature paramPGPSignature, PGPPublicKey paramPGPPublicKey)
    throws com.didisoft.pgp.PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: invokevirtual 40\011com/didisoft/pgp/bc/BCFactory:CreatePGPContentVerifierBuilderProvider\011()Llw/bouncycastle/openpgp/operator/PGPContentVerifierBuilderProvider;
    //   5: aload_2
    //   6: invokevirtual 50\011lw/bouncycastle/openpgp/PGPSignature:init\011(Llw/bouncycastle/openpgp/operator/PGPContentVerifierBuilderProvider;Llw/bouncycastle/openpgp/PGPPublicKey;)V
    //   9: return
    //   10: dup
    //   11: astore_1
    //   12: invokestatic 43\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   15: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   0\0119\01110\011lw/bouncycastle/openpgp/PGPException
  }

  // ERROR //
  public void initVerify(lw.bouncycastle.openpgp.PGPOnePassSignature paramPGPOnePassSignature, PGPPublicKey paramPGPPublicKey)
    throws com.didisoft.pgp.PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: invokevirtual 40\011com/didisoft/pgp/bc/BCFactory:CreatePGPContentVerifierBuilderProvider\011()Llw/bouncycastle/openpgp/operator/PGPContentVerifierBuilderProvider;
    //   5: aload_2
    //   6: invokevirtual 48\011lw/bouncycastle/openpgp/PGPOnePassSignature:init\011(Llw/bouncycastle/openpgp/operator/PGPContentVerifierBuilderProvider;Llw/bouncycastle/openpgp/PGPPublicKey;)V
    //   9: return
    //   10: dup
    //   11: astore_1
    //   12: invokestatic 43\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   15: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   0\0119\01110\011lw/bouncycastle/openpgp/PGPException
  }

  public PGPContentVerifierBuilderProvider CreatePGPContentVerifierBuilderProvider()
  {
    if (a)
      return new JcaPGPContentVerifierBuilderProvider().setProvider("BC");
    return new BcPGPContentVerifierBuilderProvider();
  }

  public PBEKeyEncryptionMethodGenerator CreatePBEKeyEncryptionMethodGenerator(String paramString)
  {
    if (a)
      return new JcePBEKeyEncryptionMethodGenerator(paramString == null ? new char[0] : paramString.toCharArray());
    return new BcPBEKeyEncryptionMethodGenerator(paramString == null ? new char[0] : paramString.toCharArray());
  }

  public PBEKeyEncryptionMethodGenerator CreatePBEKeyEncryptionMethodGenerator(char[] paramArrayOfChar)
  {
    if (a)
      return new JcePBEKeyEncryptionMethodGenerator(paramArrayOfChar);
    return new BcPBEKeyEncryptionMethodGenerator(paramArrayOfChar);
  }

  public PGPEncryptedDataGenerator CreatePGPEncryptedDataGenerator(int paramInt, boolean paramBoolean1, SecureRandom paramSecureRandom, boolean paramBoolean2)
  {
    return new PGPEncryptedDataGenerator(CreatePGPDataEncryptorBuilder(paramInt, paramBoolean1, paramSecureRandom), paramBoolean2);
  }

  public PGPEncryptedDataGenerator CreatePGPEncryptedDataGenerator(int paramInt, boolean paramBoolean, SecureRandom paramSecureRandom)
  {
    return new PGPEncryptedDataGenerator(CreatePGPDataEncryptorBuilder(paramInt, paramBoolean, paramSecureRandom));
  }

  public PGPDataEncryptorBuilder CreatePGPDataEncryptorBuilder(int paramInt, boolean paramBoolean, SecureRandom paramSecureRandom)
  {
    if (a)
    {
      (paramInt = new JcePGPDataEncryptorBuilder(paramInt)).setSecureRandom(paramSecureRandom);
      paramInt.setWithIntegrityPacket(paramBoolean);
      paramInt.setProvider("BC");
      return paramInt;
    }
    (paramInt = new BcPGPDataEncryptorBuilder(paramInt)).setSecureRandom(paramSecureRandom);
    paramInt.setWithIntegrityPacket(paramBoolean);
    return paramInt;
  }

  public PublicKeyDataDecryptorFactory CreatePublicKeyDataDecryptorFactory(PGPPrivateKey paramPGPPrivateKey)
  {
    if (a)
      return new JcePublicKeyDataDecryptorFactoryBuilder().setProvider("BC").build(paramPGPPrivateKey);
    return new BcPublicKeyDataDecryptorFactory(paramPGPPrivateKey);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.BCFactory
 * JD-Core Version:    0.6.2
 */