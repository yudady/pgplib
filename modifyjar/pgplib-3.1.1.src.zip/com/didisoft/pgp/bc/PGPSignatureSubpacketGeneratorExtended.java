package com.didisoft.pgp.bc;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lw.bouncycastle.bcpg.SignatureSubpacket;
import lw.bouncycastle.bcpg.sig.EmbeddedSignature;
import lw.bouncycastle.bcpg.sig.Exportable;
import lw.bouncycastle.bcpg.sig.IssuerKeyID;
import lw.bouncycastle.bcpg.sig.KeyExpirationTime;
import lw.bouncycastle.bcpg.sig.KeyFlags;
import lw.bouncycastle.bcpg.sig.NotationData;
import lw.bouncycastle.bcpg.sig.PreferredAlgorithms;
import lw.bouncycastle.bcpg.sig.PrimaryUserID;
import lw.bouncycastle.bcpg.sig.Revocable;
import lw.bouncycastle.bcpg.sig.SignatureCreationTime;
import lw.bouncycastle.bcpg.sig.SignatureExpirationTime;
import lw.bouncycastle.bcpg.sig.SignerUserID;
import lw.bouncycastle.bcpg.sig.TrustSignature;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketVector;

public class PGPSignatureSubpacketGeneratorExtended extends PGPSignatureSubpacketGenerator
{
  private List a = new ArrayList();

  public void setRevocable(boolean paramBoolean1, boolean paramBoolean2)
  {
    a.add(new Revocable(paramBoolean1, paramBoolean2));
  }

  public void setExportable(boolean paramBoolean1, boolean paramBoolean2)
  {
    a.add(new Exportable(paramBoolean1, paramBoolean2));
  }

  public void setTrust(boolean paramBoolean, int paramInt1, int paramInt2)
  {
    a.add(new TrustSignature(paramBoolean, paramInt1, paramInt2));
  }

  public void setKeyExpirationTime(boolean paramBoolean, long paramLong)
  {
    a.add(new KeyExpirationTime(paramBoolean, paramLong));
  }

  public void setSignatureExpirationTime(boolean paramBoolean, long paramLong)
  {
    a.add(new SignatureExpirationTime(paramBoolean, paramLong));
  }

  public void setSignatureCreationTime(boolean paramBoolean, Date paramDate)
  {
    a.add(new SignatureCreationTime(paramBoolean, paramDate));
  }

  public void setPreferredHashAlgorithms(boolean paramBoolean, int[] paramArrayOfInt)
  {
    a.add(new PreferredAlgorithms(21, paramBoolean, paramArrayOfInt));
  }

  public void setPreferredSymmetricAlgorithms(boolean paramBoolean, int[] paramArrayOfInt)
  {
    a.add(new PreferredAlgorithms(11, paramBoolean, paramArrayOfInt));
  }

  public void setPreferredCompressionAlgorithms(boolean paramBoolean, int[] paramArrayOfInt)
  {
    a.add(new PreferredAlgorithms(22, paramBoolean, paramArrayOfInt));
  }

  public void setKeyFlags(boolean paramBoolean, int paramInt)
  {
    a.add(new KeyFlags(paramBoolean, paramInt));
  }

  public void setSignerUserID(boolean paramBoolean, String paramString)
  {
    if (paramString == null)
      throw new IllegalArgumentException("attempt to set null SignerUserID");
    a.add(new SignerUserID(paramBoolean, paramString));
  }

  public void setEmbeddedSignature(boolean paramBoolean, PGPSignature paramPGPSignature)
    throws IOException
  {
    byte[] arrayOfByte;
    if ((paramPGPSignature = paramPGPSignature.getEncoded()).length - 1 > 256)
      arrayOfByte = new byte[paramPGPSignature.length - 3];
    else
      arrayOfByte = new byte[paramPGPSignature.length - 2];
    System.arraycopy(paramPGPSignature, paramPGPSignature.length - arrayOfByte.length, arrayOfByte, 0, arrayOfByte.length);
    a.add(new EmbeddedSignature(paramBoolean, arrayOfByte));
  }

  public void setPrimaryUserID(boolean paramBoolean1, boolean paramBoolean2)
  {
    a.add(new PrimaryUserID(paramBoolean1, paramBoolean2));
  }

  public void setNotationData(boolean paramBoolean1, boolean paramBoolean2, String paramString1, String paramString2)
  {
    a.add(new NotationData(paramBoolean1, paramBoolean2, paramString1, paramString2));
  }

  public PGPSignatureSubpacketVector generate()
  {
    SignatureSubpacket[] arrayOfSignatureSubpacket = (SignatureSubpacket[])a.toArray(new SignatureSubpacket[a.size()]);
    Object localObject1 = null;
    try
    {
      Object localObject2 = PGPSignatureSubpacketVector.class;
      Object localObject3 = null;
      localObject2 = ((Class)localObject2).getDeclaredConstructors();
      for (int i = 0; i < localObject2.length; i++)
      {
        Class[] arrayOfClass;
        if (((arrayOfClass = localObject2[i].getParameterTypes()).length == 1) && (arrayOfClass[0].isArray()) && (arrayOfClass[0].getComponentType().equals(SignatureSubpacket.class)))
        {
          localObject3 = localObject2[i];
          break;
        }
      }
      localObject3.setAccessible(true);
      localObject1 = localObject3.newInstance(new Object[] { arrayOfSignatureSubpacket });
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
    }
    catch (InstantiationException localInstantiationException)
    {
    }
    return (PGPSignatureSubpacketVector)localObject1;
  }

  public void setRevocationReason(boolean paramBoolean, byte paramByte, String paramString)
  {
    a.add(new RevocationReason(paramBoolean, paramByte, paramString));
  }

  public void setRevocationKey(boolean paramBoolean, byte paramByte, byte[] paramArrayOfByte)
  {
    a.add(new RevocationKey(paramBoolean, (byte)-128, paramByte, paramArrayOfByte));
  }

  public void setIssuerKeyID(boolean paramBoolean, long paramLong)
  {
    a.add(new IssuerKeyID(paramBoolean, paramLong));
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.PGPSignatureSubpacketGeneratorExtended
 * JD-Core Version:    0.6.2
 */