package com.didisoft.pgp.bc;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

public class BufferedInputStreamExtended extends BufferedInputStream
{
  BufferedInputStreamExtended(InputStream paramInputStream)
  {
    super(paramInputStream);
  }

  public synchronized int available()
    throws IOException
  {
    int i;
    if ((i = super.available()) < 0)
      i = 2147483647;
    return i;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.BufferedInputStreamExtended
 * JD-Core Version:    0.6.2
 */