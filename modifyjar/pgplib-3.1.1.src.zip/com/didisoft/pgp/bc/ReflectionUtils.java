package com.didisoft.pgp.bc;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectionUtils
{
  public static Object callPrivateStaticMethod(Class paramClass, String paramString, Object[] paramArrayOfObject)
  {
    Class[] arrayOfClass;
    if (paramArrayOfObject.length == 0)
    {
      arrayOfClass = new Class[0];
    }
    else
    {
      arrayOfClass = new Class[paramArrayOfObject.length];
      for (int i = 0; i < paramArrayOfObject.length; i++)
        arrayOfClass[i] = paramArrayOfObject[i].getClass();
    }
    Object localObject = null;
    try
    {
      (paramClass = paramClass.getDeclaredMethod(paramString, arrayOfClass)).setAccessible(true);
      localObject = paramClass.invoke(null, paramArrayOfObject);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new Error("No such method: " + paramString);
    }
    return localObject;
  }

  public static Object callPrivateMethod(Class paramClass, String paramString, Object paramObject, Object[] paramArrayOfObject)
  {
    Class[] arrayOfClass;
    if (paramArrayOfObject.length == 0)
    {
      arrayOfClass = new Class[0];
    }
    else
    {
      arrayOfClass = new Class[paramArrayOfObject.length];
      for (int i = 0; i < paramArrayOfObject.length; i++)
        arrayOfClass[i] = paramArrayOfObject[i].getClass();
    }
    Object localObject = null;
    try
    {
      (paramClass = paramClass.getDeclaredMethod(paramString, arrayOfClass)).setAccessible(true);
      localObject = paramClass.invoke(paramObject, paramArrayOfObject);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new Error("No such method: " + paramString);
    }
    return localObject;
  }

  public static Object callPrivateConstrtuctor(Class paramClass, Object[] paramArrayOfObject)
  {
    Object localObject1;
    if (paramArrayOfObject.length == 0)
    {
      localObject1 = new Class[0];
    }
    else
    {
      localObject1 = new Class[paramArrayOfObject.length];
      for (int i = 0; i < paramArrayOfObject.length; i++)
        localObject1[i] = paramArrayOfObject[i].getClass();
    }
    Object localObject2 = null;
    try
    {
      (localObject1 = paramClass.getDeclaredConstructor((Class[])localObject1)).setAccessible(true);
      localObject2 = ((Constructor)localObject1).newInstance(paramArrayOfObject);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
    }
    catch (InstantiationException localInstantiationException)
    {
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new Error("No such method: " + paramClass.getName());
    }
    return localObject2;
  }

  public static void setPrivateFieldvalue(Object paramObject1, String paramString, Object paramObject2)
  {
    try
    {
      (paramString = (localObject = paramObject1.getClass()).getDeclaredField(paramString)).setAccessible(true);
      paramString.set(paramObject1, paramObject2);
      return;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      (localObject = localNoSuchFieldException).printStackTrace();
      return;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      (localObject = localIllegalArgumentException).printStackTrace();
      return;
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      Object localObject;
      (localObject = localIllegalAccessException).printStackTrace();
    }
  }

  public static Object getPrivateFieldvalue(Object paramObject, String paramString)
  {
    try
    {
      (paramString = (localObject = paramObject.getClass()).getDeclaredField(paramString)).setAccessible(true);
      return paramString.get(paramObject);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      (localObject = localNoSuchFieldException).printStackTrace();
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      (localObject = localIllegalArgumentException).printStackTrace();
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      Object localObject;
      (localObject = localIllegalAccessException).printStackTrace();
    }
    return null;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.bc.ReflectionUtils
 * JD-Core Version:    0.6.2
 */