package com.didisoft.pgp;

public abstract interface CypherAlgorithm
{
  public static final String TRIPLE_DES = "TRIPLE_DES";
  public static final String CAST5 = "CAST5";
  public static final String BLOWFISH = "BLOWFISH";
  public static final String AES_128 = "AES_128";
  public static final String AES_192 = "AES_192";
  public static final String AES_256 = "AES_256";
  public static final String TWOFISH = "TWOFISH";
  public static final String DES = "DES";
  public static final String SAFER = "SAFER";
  public static final String IDEA = "IDEA";

  public static enum Enum
  {
    public final Enum fromString(String paramString)
    {
      if ("TRIPLE_DES".equalsIgnoreCase(paramString))
        return TRIPLE_DES;
      if ("CAST5".equalsIgnoreCase(paramString))
        return CAST5;
      if ("BLOWFISH".equalsIgnoreCase(paramString))
        return BLOWFISH;
      if ("AES_128".equalsIgnoreCase(paramString))
        return AES_128;
      if ("AES_256".equalsIgnoreCase(paramString))
        return AES_256;
      if ("AES_192".equalsIgnoreCase(paramString))
        return AES_192;
      if ("TWOFISH".equalsIgnoreCase(paramString))
        return TWOFISH;
      if ("DES".equalsIgnoreCase(paramString))
        return DES;
      if ("SAFER".equalsIgnoreCase(paramString))
        return SAFER;
      if ("IDEA".equalsIgnoreCase(paramString))
        return IDEA;
      throw new IllegalArgumentException("The supplied cypher algorithm parameter is invalid");
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.CypherAlgorithm
 * JD-Core Version:    0.6.2
 */