package com.didisoft.pgp;

public abstract interface TrustLevel
{
  public static final byte TRUSTED = 120;
  public static final byte MARGINAL = 60;
  public static final byte NONE = 0;
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.TrustLevel
 * JD-Core Version:    0.6.2
 */