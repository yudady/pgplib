package com.didisoft.pgp;

public abstract interface KeyAlgorithm
{
  public static final String RSA = "RSA";
  public static final String ELGAMAL = "ELGAMAL";
  public static final String EC = "EC";

  public static enum Enum
  {
    public final Enum fromString(String paramString)
    {
      if ("RSA".equalsIgnoreCase(paramString))
        return RSA;
      if ("ELGAMAL".equalsIgnoreCase(paramString))
        return ELGAMAL;
      if ("EC".equalsIgnoreCase(paramString))
        return EC;
      throw new IllegalArgumentException("The supplied assymetric key algorithm is invalid");
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.KeyAlgorithm
 * JD-Core Version:    0.6.2
 */