package com.didisoft.pgp;

public abstract interface CompressionAlgorithm
{
  public static final String ZLIB = "ZLIB";
  public static final String ZIP = "ZIP";
  public static final String BZIP2 = "BZIP2";
  public static final String UNCOMPRESSED = "UNCOMPRESSED";

  public static enum Enum
  {
    public final Enum fromString(String paramString)
    {
      if ("ZIP".equalsIgnoreCase(paramString))
        return ZIP;
      if ("ZLIB".equalsIgnoreCase(paramString))
        return ZLIB;
      if ("BZIP2".equalsIgnoreCase(paramString))
        return BZIP2;
      if ("UNCOMPRESSED".equalsIgnoreCase(paramString))
        return UNCOMPRESSED;
      throw new IllegalArgumentException("The supplied compression parameter is invalid");
    }

    public final String toString()
    {
      switch (CompressionAlgorithm.1.a[ordinal()])
      {
      case 1:
        return "ZLIB";
      case 2:
        return "ZIP";
      case 3:
        return "BZIP2";
      case 4:
        return "UNCOMPRESSED";
      }
      return "";
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.CompressionAlgorithm
 * JD-Core Version:    0.6.2
 */