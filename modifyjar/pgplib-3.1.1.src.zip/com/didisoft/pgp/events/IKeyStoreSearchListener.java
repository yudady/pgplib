package com.didisoft.pgp.events;

import com.didisoft.pgp.KeyStore;

public abstract interface IKeyStoreSearchListener
{
  public abstract void onKeyNotFound(KeyStore paramKeyStore, boolean paramBoolean, long paramLong, String paramString1, String paramString2);
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.events.IKeyStoreSearchListener
 * JD-Core Version:    0.6.2
 */