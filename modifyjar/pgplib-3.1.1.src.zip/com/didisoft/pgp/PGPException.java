package com.didisoft.pgp;

public class PGPException extends lw.bouncycastle.openpgp.PGPException
{
  private static final long serialVersionUID = -7698669548427089832L;

  public PGPException(String paramString)
  {
    super(paramString);
  }

  public PGPException(String paramString, Exception paramException)
  {
    super(paramString + (paramException != null ? " : " + paramException.getMessage() : ""), paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.PGPException
 * JD-Core Version:    0.6.2
 */