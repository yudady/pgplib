package com.didisoft.pgp;

public abstract interface HashAlgorithm
{
  public static final String SHA1 = "SHA1";
  public static final String SHA256 = "SHA256";
  public static final String SHA384 = "SHA384";
  public static final String SHA512 = "SHA512";
  public static final String SHA224 = "SHA224";
  public static final String MD5 = "MD5";
  public static final String RIPEMD160 = "RIPEMD160";
  public static final String MD2 = "MD2";

  public static enum Enum
  {
    public final Enum fromString(String paramString)
    {
      if ("SHA1".equalsIgnoreCase(paramString))
        return SHA1;
      if ("SHA256".equalsIgnoreCase(paramString))
        return SHA256;
      if ("SHA384".equalsIgnoreCase(paramString))
        return SHA384;
      if ("SHA512".equalsIgnoreCase(paramString))
        return SHA512;
      if ("SHA224".equalsIgnoreCase(paramString))
        return SHA224;
      if ("MD5".equalsIgnoreCase(paramString))
        return MD5;
      if ("MD2".equalsIgnoreCase(paramString))
        return MD2;
      if ("RIPEMD160".equalsIgnoreCase(paramString))
        return RIPEMD160;
      throw new IllegalArgumentException("The supplied hash algorithm parameter is invalid");
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.HashAlgorithm
 * JD-Core Version:    0.6.2
 */