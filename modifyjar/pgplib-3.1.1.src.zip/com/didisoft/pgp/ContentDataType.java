package com.didisoft.pgp;

public abstract interface ContentDataType
{
  public static final char BINARY = 'b';
  public static final char TEXT = 't';
  public static final char UTF8 = 'u';
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.ContentDataType
 * JD-Core Version:    0.6.2
 */