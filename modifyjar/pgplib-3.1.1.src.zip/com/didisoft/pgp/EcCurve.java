package com.didisoft.pgp;

public abstract interface EcCurve
{
  public static final String P256 = "P256";
  public static final String P384 = "P384";
  public static final String P521 = "P521";

  public static enum Enum
  {
    public final Enum fromString(String paramString)
    {
      if ("P256".equalsIgnoreCase(paramString))
        return NIST_P_256;
      if ("P384".equalsIgnoreCase(paramString))
        return NIST_P_384;
      if ("P521".equalsIgnoreCase(paramString))
        return NIST_P_521;
      throw new IllegalArgumentException("The supplied EC Curve parameter is invalid");
    }

    public final String toString()
    {
      switch (EcCurve.1.a[ordinal()])
      {
      case 1:
        return "P-256";
      case 2:
        return "P-384";
      case 3:
        return "P-521";
      }
      return "";
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.EcCurve
 * JD-Core Version:    0.6.2
 */