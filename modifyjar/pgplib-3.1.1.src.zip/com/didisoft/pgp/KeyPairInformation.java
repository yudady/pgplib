package com.didisoft.pgp;

import com.didisoft.pgp.bc.BCFactory;
import com.didisoft.pgp.bc.BaseLib;
import com.didisoft.pgp.bc.IOUtil;
import com.didisoft.pgp.bc.ReflectionUtils;
import com.didisoft.pgp.exceptions.NoPrivateKeyFoundException;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import lw.bouncycastle.bcpg.ArmoredOutputStream;
import lw.bouncycastle.openpgp.PGPException;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKey;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import lw.bouncycastle.util.encoders.Hex;

public class KeyPairInformation
  implements Serializable
{
  private static final long serialVersionUID = -4750279241178352641L;
  BCFactory a = new BCFactory(false);
  private PGPPublicKeyRing b;
  private PGPSecretKeyRing c;
  private long d;
  private String e;
  private String f;
  private String[] g = new String[0];
  private int h = 0;
  private int i = 0;
  private String j;
  private Date k;
  private int l;
  private long m;
  private int n;
  private boolean o;
  private boolean p;
  private boolean q;
  private int[] r = new int[0];
  private int[] s = new int[0];
  private int[] t = new int[0];
  private long[] u = new long[0];
  private List v = new ArrayList();
  private List w = new ArrayList();
  protected String asciiVersionHeader = null;

  KeyPairInformation()
  {
    ArmoredOutputStream localArmoredOutputStream = new ArmoredOutputStream(new ByteArrayOutputStream());
    asciiVersionHeader = ((String)ReflectionUtils.getPrivateFieldvalue(localArmoredOutputStream, "version"));
  }

  KeyPairInformation(String paramString)
  {
    asciiVersionHeader = paramString;
  }

  public void setPublicKeyRing(PGPPublicKeyRing paramPGPPublicKeyRing)
  {
    b = paramPGPPublicKeyRing;
    Object localObject2 = (localObject1 = paramPGPPublicKeyRing).getPublicKeys();
    while (((Iterator)localObject2).hasNext());
    Object localObject1 = (localObject3 = (PGPPublicKey)((Iterator)localObject2).next()).isMasterKey() ? localObject3 : ((PGPPublicKeyRing)localObject1).getPublicKey();
    d = ((PGPPublicKey)localObject1).getKeyID();
    e = keyId2Hex(((PGPPublicKey)localObject1).getKeyID());
    f = new String(Hex.encode(((PGPPublicKey)localObject1).getFingerprint()));
    localObject2 = new ArrayList();
    Object localObject3 = ((PGPPublicKey)localObject1).getUserIDs();
    while (((Iterator)localObject3).hasNext())
      ((List)localObject2).add((String)((Iterator)localObject3).next());
    g = ((String[])((List)localObject2).toArray(new String[((List)localObject2).size()]));
    k = ((PGPPublicKey)localObject1).getCreationTime();
    h = ((PGPPublicKey)localObject1).getBitStrength();
    j = KeyStore.getKeyAlgorithm(((PGPPublicKey)localObject1).getAlgorithm());
    l = ((PGPPublicKey)localObject1).getValidDays();
    m = ((PGPPublicKey)localObject1).getValidSeconds();
    n = ((PGPPublicKey)localObject1).getVersion();
    o = ((PGPPublicKey)localObject1).isRevoked();
    p = ((PGPPublicKey)localObject1).isEncryptionKey();
    q = BaseLib.isForVerification((PGPPublicKey)localObject1);
    localObject3 = paramPGPPublicKeyRing.getPublicKeys();
    while (((Iterator)localObject3).hasNext())
    {
      if ((localObject1 = (PGPPublicKey)((Iterator)localObject3).next()).isEncryptionKey())
        i = ((PGPPublicKey)localObject1).getBitStrength();
      if (!((PGPPublicKey)localObject1).isMasterKey())
      {
        localObject1 = new SubKey((PGPPublicKey)localObject1);
        w.add(localObject1);
      }
    }
    if ((getEncryptionKeySize() == 0) && (paramPGPPublicKeyRing.getPublicKey().isEncryptionKey()))
      i = paramPGPPublicKeyRing.getPublicKey().getBitStrength();
    c();
    a();
    b();
    d();
  }

  private void a()
  {
    Iterator localIterator = b.getPublicKey().getSignatures();
    while (localIterator.hasNext())
    {
      Object localObject;
      if (((localObject = (PGPSignature)localIterator.next()).getHashedSubPackets() != null) && (((PGPSignature)localObject).getHashedSubPackets().getPreferredCompressionAlgorithms() != null))
      {
        localObject = ((PGPSignature)localObject).getHashedSubPackets().getPreferredCompressionAlgorithms();
        r = ((int[])localObject);
      }
    }
  }

  private void b()
  {
    Iterator localIterator = b.getPublicKey().getSignatures();
    while (localIterator.hasNext())
    {
      Object localObject;
      if (((localObject = (PGPSignature)localIterator.next()).getHashedSubPackets() != null) && (((PGPSignature)localObject).getHashedSubPackets().getPreferredHashAlgorithms() != null))
      {
        localObject = ((PGPSignature)localObject).getHashedSubPackets().getPreferredHashAlgorithms();
        t = ((int[])localObject);
      }
    }
  }

  private void c()
  {
    Iterator localIterator = b.getPublicKey().getSignatures();
    while (localIterator.hasNext())
    {
      Object localObject;
      if (((localObject = (PGPSignature)localIterator.next()).getHashedSubPackets() != null) && (((PGPSignature)localObject).getHashedSubPackets().getPreferredSymmetricAlgorithms() != null))
      {
        localObject = ((PGPSignature)localObject).getHashedSubPackets().getPreferredSymmetricAlgorithms();
        s = ((int[])localObject);
      }
    }
  }

  private void d()
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = b.getPublicKeys();
    while (localIterator1.hasNext())
    {
      PGPPublicKey localPGPPublicKey;
      Iterator localIterator2 = (localPGPPublicKey = (PGPPublicKey)localIterator1.next()).getSignaturesOfType(16);
      PGPSignature localPGPSignature;
      while (localIterator2.hasNext())
        if ((localPGPSignature = (PGPSignature)localIterator2.next()).getKeyID() != localPGPPublicKey.getKeyID())
          localArrayList.add(localPGPSignature);
      localIterator2 = localPGPPublicKey.getSignaturesOfType(18);
      while (localIterator2.hasNext())
        if ((localPGPSignature = (PGPSignature)localIterator2.next()).getKeyID() != localPGPPublicKey.getKeyID())
          localArrayList.add(localPGPSignature);
      localIterator2 = localPGPPublicKey.getSignaturesOfType(19);
      while (localIterator2.hasNext())
        if ((localPGPSignature = (PGPSignature)localIterator2.next()).getKeyID() != localPGPPublicKey.getKeyID())
          localArrayList.add(localPGPSignature);
    }
    u = new long[localArrayList.size()];
    for (int i1 = 0; i1 < localArrayList.size(); i1++)
      u[i1] = ((PGPSignature)localArrayList.get(i1)).getKeyID();
  }

  public void setPrivateKeyRing(PGPSecretKeyRing paramPGPSecretKeyRing)
  {
    c = paramPGPSecretKeyRing;
    if (paramPGPSecretKeyRing == null)
      return;
    paramPGPSecretKeyRing = paramPGPSecretKeyRing.getSecretKeys();
    while (paramPGPSecretKeyRing.hasNext())
    {
      Object localObject;
      if (!(localObject = (PGPSecretKey)paramPGPSecretKeyRing.next()).isMasterKey())
      {
        localObject = new SubKey(((PGPSecretKey)localObject).getPublicKey());
        v.add(localObject);
      }
    }
  }

  public SubKey[] getPublicSubKeys()
  {
    return (SubKey[])w.toArray(new SubKey[w.size()]);
  }

  public SubKey[] getPrivateSubKeys()
  {
    return (SubKey[])v.toArray(new SubKey[v.size()]);
  }

  public boolean isExpired()
  {
    if (l <= 0)
      return false;
    Calendar localCalendar;
    (localCalendar = Calendar.getInstance()).setTime(k);
    localCalendar.add(5, l);
    return localCalendar.getTime().before(new Date());
  }

  public boolean isExpiredOnDate(Date paramDate)
  {
    if (l <= 0)
      return false;
    Calendar localCalendar;
    (localCalendar = Calendar.getInstance()).setTime(k);
    localCalendar.add(5, l);
    return localCalendar.getTime().before(paramDate);
  }

  public boolean isValidForever()
  {
    return l <= 0;
  }

  public Date getExpirationDate()
  {
    return getExpirationTime();
  }

  public boolean isRevoked()
  {
    return o;
  }

  public boolean isEncryptionKey()
  {
    return p;
  }

  public boolean isSigningKey()
  {
    return q;
  }

  public PGPPublicKeyRing getRawPublicKeyRing()
  {
    return b;
  }

  public PGPSecretKeyRing getRawPrivateKeyRing()
  {
    return c;
  }

  public boolean hasPrivateKey()
  {
    return c != null;
  }

  public static String keyId2Hex(long paramLong)
  {
    if ((paramLong = Long.toHexString(paramLong).toUpperCase()).length() < 8)
      return paramLong;
    return paramLong.substring(paramLong.length() - 8);
  }

  public long getKeyID()
  {
    return d;
  }

  public String getKeyIDHex()
  {
    return e;
  }

  public String getFingerprint()
  {
    return f;
  }

  public String getUserID()
  {
    if (g.length > 0)
      return g[0];
    return null;
  }

  public String[] getUserIDs()
  {
    return g;
  }

  public int getKeySize()
  {
    return h;
  }

  public String getAlgorithm()
  {
    return j;
  }

  public Date getCreationTime()
  {
    return k;
  }

  public int getValidDays()
  {
    return l;
  }

  public Date getExpirationTime()
  {
    if (l > 0)
    {
      long l1;
      long l2 = (l1 = k.getTime()) + m * 1000L;
      Calendar localCalendar;
      (localCalendar = Calendar.getInstance()).setTimeInMillis(l2);
      return localCalendar.getTime();
    }
    return new Date(9223372036854775807L);
  }

  public int getVersion()
  {
    return n;
  }

  public void exportPublicKey(String paramString, boolean paramBoolean)
    throws IOException
  {
    IOUtil.exportPublicKeyRing(getRawPublicKeyRing(), paramString, paramBoolean, asciiVersionHeader);
  }

  public void exportPrivateKey(String paramString, boolean paramBoolean)
    throws NoPrivateKeyFoundException, IOException
  {
    if (getRawPrivateKeyRing() == null)
      throw new NoPrivateKeyFoundException("No private key was loaded in this KeyPair object");
    IOUtil.exportPrivateKey(getRawPrivateKeyRing(), paramString, paramBoolean, asciiVersionHeader);
  }

  public void exportKeyRing(String paramString, boolean paramBoolean)
    throws IOException
  {
    paramString = new FileOutputStream(paramString);
    paramBoolean = new ArmoredOutputStream(paramString);
    Object localObject;
    if ((localObject = getRawPrivateKeyRing()) != null)
    {
      ((PGPSecretKeyRing)localObject).encode(paramBoolean);
      IOUtil.closeStream(paramBoolean);
    }
    paramBoolean = new ArmoredOutputStream(paramString);
    (localObject = getRawPublicKeyRing()).encode(paramBoolean);
    IOUtil.closeStream(paramBoolean);
    IOUtil.closeStream(paramString);
  }

  public boolean checkPassword(String paramString)
    throws NoPrivateKeyFoundException
  {
    if (c == null)
      throw new NoPrivateKeyFoundException("There is no private key in this key pair.");
    if (paramString == null)
      paramString = "";
    try
    {
      BaseLib.extractPrivateKey(c.getSecretKey(), paramString.toCharArray());
    }
    catch (PGPException localPGPException)
    {
      if ((paramString = localPGPException).getMessage().toLowerCase().startsWith("checksum mismatch at 0 of 2"))
        return false;
      throw new NoPrivateKeyFoundException(paramString.getMessage(), paramString);
    }
    return true;
  }

  public byte getTrust()
  {
    if (hasPrivateKey())
      return 120;
    byte[] arrayOfByte;
    if ((arrayOfByte = b.getPublicKey().getTrustData()) != null)
      return arrayOfByte[0];
    return 0;
  }

  public int[] getPreferredCompressions()
  {
    return r;
  }

  public int[] getPreferredCiphers()
  {
    return s;
  }

  public int[] getPreferredHashes()
  {
    return t;
  }

  public long[] getSignedWithKeyIds()
  {
    return u;
  }

  public int getEncryptionKeySize()
  {
    return i;
  }

  public class SubKey
    implements Serializable
  {
    private static final long serialVersionUID = -9122478708446314118L;
    private boolean a;
    private boolean b;
    private boolean c;
    private long d;
    private String e;
    private String f;
    private String[] g;
    private int h;
    private String i;
    private Date j;
    private int k;
    private int l;

    public SubKey(PGPPublicKey arg2)
    {
      PGPPublicKey localPGPPublicKey;
      d = localPGPPublicKey.getKeyID();
      e = KeyPairInformation.keyId2Hex(localPGPPublicKey.getKeyID());
      f = new String(Hex.encode(localPGPPublicKey.getFingerprint()));
      this$1 = new ArrayList();
      Iterator localIterator = localPGPPublicKey.getUserIDs();
      while (localIterator.hasNext())
        this$1.add((String)localIterator.next());
      g = ((String[])this$1.toArray(new String[this$1.size()]));
      j = localPGPPublicKey.getCreationTime();
      h = localPGPPublicKey.getBitStrength();
      i = KeyStore.getKeyAlgorithm(localPGPPublicKey.getAlgorithm());
      k = localPGPPublicKey.getValidDays();
      l = localPGPPublicKey.getVersion();
      c = localPGPPublicKey.isRevoked();
      a = localPGPPublicKey.isEncryptionKey();
      b = BaseLib.isForVerification(localPGPPublicKey);
    }

    public boolean isEncryptionKey()
    {
      return a;
    }

    public boolean isSigningKey()
    {
      return b;
    }

    public boolean isExpired()
    {
      if (k <= 0)
        return false;
      Calendar localCalendar;
      (localCalendar = Calendar.getInstance()).setTime(j);
      localCalendar.add(5, k);
      return localCalendar.getTime().before(new Date());
    }

    public boolean isExpiredOnDate(Date paramDate)
    {
      if (k <= 0)
        return false;
      Calendar localCalendar;
      (localCalendar = Calendar.getInstance()).setTime(j);
      localCalendar.add(5, k);
      return localCalendar.getTime().before(paramDate);
    }

    public boolean isRevoked()
    {
      return c;
    }

    public long getKeyID()
    {
      return d;
    }

    public String getKeyIDHex()
    {
      return e;
    }

    public String getFingerprint()
    {
      return f;
    }

    public String[] getUserIDs()
    {
      return g;
    }

    public int getKeySize()
    {
      return h;
    }

    public String getAlgorithm()
    {
      return i;
    }

    public Date getCreationTime()
    {
      return j;
    }

    public int getValidDays()
    {
      return k;
    }

    public int getVersion()
    {
      return l;
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.KeyPairInformation
 * JD-Core Version:    0.6.2
 */