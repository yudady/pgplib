package com.didisoft.pgp;

import com.didisoft.pgp.bc.BCFactory;
import com.didisoft.pgp.bc.BaseLib;
import com.didisoft.pgp.bc.IOUtil;
import com.didisoft.pgp.exceptions.NoPrivateKeyFoundException;
import com.didisoft.pgp.exceptions.NoPublicKeyFoundException;
import com.didisoft.pgp.exceptions.WrongPasswordException;
import com.didisoft.pgp.exceptions.WrongPrivateKeyException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.logging.Logger;
import lw.bouncycastle.bcpg.ArmoredInputStream;
import lw.bouncycastle.openpgp.PGPKeyRingGenerator;
import lw.bouncycastle.openpgp.PGPObjectFactory;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKey;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;
import lw.bouncycastle.openpgp.PGPUtil;

public class PGPKeyPair extends KeyPairInformation
  implements Serializable
{
  private static final long serialVersionUID = 2538773604623463978L;

  private PGPKeyPair()
  {
  }

  public PGPKeyPair(String paramString)
    throws NoPublicKeyFoundException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = IOUtil.readFileOrAsciiString(paramString, "keyFile");
      importKeyFile(localInputStream);
      return;
    }
    catch (PGPException paramString)
    {
      throw new NoPublicKeyFoundException("The specified file does not contain an OpenPGP key.", paramString);
    }
    catch (IOException paramString)
    {
      throw new NoPublicKeyFoundException("The specified file does not contain an OpenPGP key.", paramString);
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString;
  }

  public PGPKeyPair(String paramString1, String paramString2)
    throws NoPublicKeyFoundException, WrongPrivateKeyException
  {
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    try
    {
      localInputStream1 = IOUtil.readFileOrAsciiString(paramString1, "publicKeyFile");
      localInputStream2 = IOUtil.readFileOrAsciiString(paramString2, "privateKeyFile");
      importKeyFile(localInputStream1);
      importKeyFile(localInputStream2);
      if (getRawPrivateKeyRing().getPublicKey().getKeyID() != getRawPublicKeyRing().getPublicKey().getKeyID())
        throw new WrongPrivateKeyException("The specified private key does not belong to the public key");
      return;
    }
    catch (PGPException paramString1)
    {
      throw new NoPublicKeyFoundException("The specified file does not contain an OpenPGP key.", paramString1);
    }
    catch (IOException paramString1)
    {
      throw new NoPublicKeyFoundException("The specified file does not contain an OpenPGP key.", paramString1);
    }
    finally
    {
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
    }
    throw paramString1;
  }

  public String getAsciiVersionHeader()
  {
    return "Version: " + asciiVersionHeader;
  }

  public void setAsciiVersionHeader(String paramString)
  {
    asciiVersionHeader = paramString;
  }

  public static PGPKeyPair generateEccKeyPair(String paramString1, String paramString2, String paramString3)
    throws PGPException
  {
    if ("P256".equalsIgnoreCase(paramString1))
      paramString1 = 256;
    else if ("P384".equalsIgnoreCase(paramString1))
      paramString1 = 384;
    else if ("P521".equalsIgnoreCase(paramString1))
      paramString1 = 521;
    else
      throw new IllegalArgumentException("The supplied EC Curve parameter is invalid");
    return generateKeyPair(paramString1, paramString2, "EC", paramString3, new String[] { "ZIP", "ZLIB", "BZIP2", "UNCOMPRESSED" }, new String[] { "SHA512", "SHA384", "SHA256" }, new String[] { "AES_256", "AES_192", "AES_128" }, 0L);
  }

  public static PGPKeyPair generateEccKeyPair(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3)
    throws PGPException
  {
    if ("P256".equalsIgnoreCase(paramString1))
      paramString1 = 256;
    else if ("P384".equalsIgnoreCase(paramString1))
      paramString1 = 384;
    else if ("P521".equalsIgnoreCase(paramString1))
      paramString1 = 521;
    else
      throw new IllegalArgumentException("The supplied EC Curve parameter is invalid");
    return generateKeyPair(paramString1, paramString2, "EC", paramString3, paramArrayOfString1, paramArrayOfString2, paramArrayOfString3, 0L);
  }

  public static PGPKeyPair generateEccKeyPair(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, long paramLong)
    throws PGPException
  {
    if ("P256".equalsIgnoreCase(paramString1))
      paramString1 = 256;
    else if ("P384".equalsIgnoreCase(paramString1))
      paramString1 = 384;
    else if ("P521".equalsIgnoreCase(paramString1))
      paramString1 = 521;
    else
      throw new IllegalArgumentException("The supplied EC Curve parameter is invalid");
    return generateKeyPair(paramString1, paramString2, "EC", paramString3, paramArrayOfString1, paramArrayOfString2, paramArrayOfString3, paramLong);
  }

  public static PGPKeyPair generateRsaKeyPair(int paramInt, String paramString1, String paramString2)
    throws PGPException
  {
    return generateKeyPair(paramInt, paramString1, "RSA", paramString2, new String[] { "ZIP", "UNCOMPRESSED", "ZLIB", "BZIP2" }, new String[] { "SHA256", "SHA384", "SHA512", "SHA1", "MD5", "SHA256" }, new String[] { "CAST5", "TRIPLE_DES", "AES_128", "AES_192", "AES_256", "TWOFISH" }, 0L);
  }

  public static PGPKeyPair generateElGamalKeyPair(int paramInt, String paramString1, String paramString2)
    throws PGPException
  {
    return generateKeyPair(paramInt, paramString1, "ELGAMAL", paramString2, new String[] { "ZIP", "UNCOMPRESSED", "ZLIB", "BZIP2" }, new String[] { "SHA256", "SHA384", "SHA512", "SHA1", "MD5", "SHA256" }, new String[] { "CAST5", "TRIPLE_DES", "AES_128", "AES_192", "AES_256", "TWOFISH" }, 0L);
  }

  public static PGPKeyPair generateKeyPair(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, long paramLong)
    throws PGPException
  {
    PGPKeyPair localPGPKeyPair = new PGPKeyPair();
    String str1 = "";
    if (paramArrayOfString1.length > 0)
    {
      for (int i = 0; i < paramArrayOfString1.length - 1; i++)
        str1 = str1 + paramArrayOfString1[i] + ",";
      str1 = str1 + paramArrayOfString1[(paramArrayOfString1.length - 1)];
    }
    String str2 = "";
    if (paramArrayOfString3.length > 0)
    {
      for (paramArrayOfString1 = 0; paramArrayOfString1 < paramArrayOfString3.length - 1; paramArrayOfString1++)
        str2 = str2 + paramArrayOfString3[paramArrayOfString1] + ",";
      str2 = str2 + paramArrayOfString3[(paramArrayOfString3.length - 1)];
    }
    paramArrayOfString1 = "";
    if (paramArrayOfString2.length > 0)
    {
      for (paramArrayOfString3 = 0; paramArrayOfString3 < paramArrayOfString2.length - 1; paramArrayOfString3++)
        paramArrayOfString1 = paramArrayOfString1 + paramArrayOfString2[paramArrayOfString3] + ",";
      paramArrayOfString1 = paramArrayOfString1 + paramArrayOfString2[(paramArrayOfString2.length - 1)];
    }
    paramInt = (paramArrayOfString3 = KeyStore.a(paramInt, paramString1, paramString2, paramString3, str1, paramArrayOfString1, str2, paramLong, false, false, false)).generateSecretKeyRing();
    paramString1 = paramArrayOfString3.generatePublicKeyRing();
    localPGPKeyPair.setPublicKeyRing(paramString1);
    localPGPKeyPair.setPrivateKeyRing(paramInt);
    return localPGPKeyPair;
  }

  protected void importKeyFile(InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    try
    {
      if ((paramInputStream instanceof ArmoredInputStream))
      {
        ArmoredInputStream localArmoredInputStream = (ArmoredInputStream)paramInputStream;
        while (!localArmoredInputStream.isEndOfStream())
          if (!parseKeyStream(localArmoredInputStream))
            return;
      }
      else if (!parseKeyStream(paramInputStream))
      {
        return;
      }
      return;
    }
    finally
    {
      paramInputStream.close();
    }
  }

  protected boolean parseKeyStream(InputStream paramInputStream)
    throws PGPException, IOException
  {
    for (Object localObject = (paramInputStream = new PGPObjectFactory(paramInputStream)).nextObject(); localObject != null; localObject = paramInputStream.nextObject())
      if ((localObject instanceof PGPPublicKeyRing))
      {
        localObject = (PGPPublicKeyRing)localObject;
        setPublicKeyRing((PGPPublicKeyRing)localObject);
      }
      else if ((localObject instanceof PGPSecretKeyRing))
      {
        localObject = (PGPSecretKeyRing)localObject;
        setPrivateKeyRing((PGPSecretKeyRing)localObject);
        if (getRawPublicKeyRing() == null)
          setPublicKeyRing(a.CreatePGPPublicKeyRing(((PGPSecretKeyRing)localObject).getPublicKey().getEncoded()));
      }
      else
      {
        throw new PGPException("Unexpected object found in stream: " + localObject.getClass().getName());
      }
    return true;
  }

  public void changePrivateKeyPassword(String paramString1, String paramString2)
    throws WrongPasswordException, NoPrivateKeyFoundException, PGPException
  {
    PGPSecretKeyRing localPGPSecretKeyRing;
    if ((localPGPSecretKeyRing = getRawPrivateKeyRing()) == null)
      throw new NoPrivateKeyFoundException("This key pair has no private key component.");
    int i = localPGPSecretKeyRing.getSecretKey().getKeyEncryptionAlgorithm();
    try
    {
      localPGPSecretKeyRing = PGPSecretKeyRing.copyWithNewPassword(localPGPSecretKeyRing, a.CreatePBESecretKeyDecryptor(paramString1), a.CreatePBESecretKeyEncryptor(paramString2, i));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      if ((paramString1 = localPGPException).getMessage().startsWith("checksum mismatch at 0 of 2"))
        throw new WrongPasswordException(paramString1.getMessage(), paramString1.getUnderlyingException());
      throw IOUtil.newPGPException(paramString1);
    }
    setPrivateKeyRing(localPGPSecretKeyRing);
  }

  static
  {
    Logger.getLogger(BaseLib.class.getName());
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.PGPKeyPair
 * JD-Core Version:    0.6.2
 */