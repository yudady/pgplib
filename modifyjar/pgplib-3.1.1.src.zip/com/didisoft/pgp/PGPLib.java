package com.didisoft.pgp;

import com.didisoft.pgp.bc.BCFactory;
import com.didisoft.pgp.bc.BaseLib;
import com.didisoft.pgp.bc.DirectByteArrayOutputStream;
import com.didisoft.pgp.bc.DummyStream;
import com.didisoft.pgp.bc.IOUtil;
import com.didisoft.pgp.bc.PGP2xPBEEncryptedData;
import com.didisoft.pgp.bc.PGPObjectFactory2;
import com.didisoft.pgp.bc.ReflectionUtils;
import com.didisoft.pgp.exceptions.DetachedSignatureException;
import com.didisoft.pgp.exceptions.FileIsEncryptedException;
import com.didisoft.pgp.exceptions.FileIsPBEEncryptedException;
import com.didisoft.pgp.exceptions.IntegrityCheckException;
import com.didisoft.pgp.exceptions.KeyIsExpiredException;
import com.didisoft.pgp.exceptions.KeyIsRevokedException;
import com.didisoft.pgp.exceptions.NoPrivateKeyFoundException;
import com.didisoft.pgp.exceptions.NoPublicKeyFoundException;
import com.didisoft.pgp.exceptions.NonPGPDataException;
import com.didisoft.pgp.exceptions.WrongPasswordException;
import com.didisoft.pgp.exceptions.WrongPrivateKeyException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.InvalidParameterException;
import java.security.SignatureException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import lw.bouncycastle.bcpg.ArmoredInputStream;
import lw.bouncycastle.bcpg.ArmoredOutputStream;
import lw.bouncycastle.bcpg.BCPGOutputStream;
import lw.bouncycastle.openpgp.PGPCompressedData;
import lw.bouncycastle.openpgp.PGPCompressedDataGenerator;
import lw.bouncycastle.openpgp.PGPDataValidationException;
import lw.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import lw.bouncycastle.openpgp.PGPEncryptedDataList;
import lw.bouncycastle.openpgp.PGPLiteralData;
import lw.bouncycastle.openpgp.PGPLiteralDataGenerator;
import lw.bouncycastle.openpgp.PGPMarker;
import lw.bouncycastle.openpgp.PGPObjectFactory;
import lw.bouncycastle.openpgp.PGPOnePassSignature;
import lw.bouncycastle.openpgp.PGPOnePassSignatureList;
import lw.bouncycastle.openpgp.PGPPBEEncryptedData;
import lw.bouncycastle.openpgp.PGPPrivateKey;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSecretKey;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureGenerator;
import lw.bouncycastle.openpgp.PGPSignatureList;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import lw.bouncycastle.openpgp.PGPUtil;
import lw.bouncycastle.openpgp.PGPV3SignatureGenerator;
import org.apache.tools.tar.TarEntry;
import org.apache.tools.tar.TarInputStream;
import org.apache.tools.tar.TarOutputStream;

public class PGPLib extends BaseLib
{
  private BCFactory a = new BCFactory(false);
  private String b = "SHA1";
  private String c = "CAST5";
  private String d = "ZIP";
  private boolean e = false;
  private boolean f = false;
  private static final Logger g = Logger.getLogger(PGPLib.class.getName());
  private String h = null;
  private char i = 'b';
  private Level j = Level.FINE;
  private boolean k = false;
  private boolean l = true;
  private boolean m = false;

  public PGPLib()
  {
    ArmoredOutputStream localArmoredOutputStream = new ArmoredOutputStream(new ByteArrayOutputStream());
    h = ((String)ReflectionUtils.getPrivateFieldvalue(localArmoredOutputStream, "version"));
    h = h.replace("v@RELEASE_NAME@", version);
  }

  public char getContentType()
  {
    return i;
  }

  public void setContentType(char paramChar)
  {
    if (('b' != paramChar) && ('t' != paramChar) && ('u' != paramChar))
    {
      a("Invalid content type {0}", String.valueOf(paramChar));
      a("Content type remains {0}", String.valueOf(i));
      return;
    }
    i = paramChar;
    a("Content type set to {0}", String.valueOf(i));
  }

  public Level getDebugLevel()
  {
    return j;
  }

  public void setDebuglevel(Level paramLevel)
  {
    j = paramLevel;
  }

  public boolean isUseExpiredKeys()
  {
    return e;
  }

  public void setUseExpiredKeys(boolean paramBoolean)
  {
    e = paramBoolean;
  }

  public boolean isUseRevokedKeys()
  {
    return f;
  }

  public void setUseRevokedKeys(boolean paramBoolean)
  {
    f = paramBoolean;
  }

  public void setHash(String paramString)
  {
    if (KeyStore.a(paramString) < 0)
      throw new InvalidParameterException("Wrong value for parameter 'hash': " + paramString + ". Must be one of: SHA256, SHA384, SHA512, SHA224, SHA1, MD5, RIPEMD160, MD2");
    b = paramString;
    a("Preferred hash set to {0}", b);
  }

  public String getCypher()
  {
    return c;
  }

  public String getAsciiCommentHeader()
  {
    return "";
  }

  public String getAsciiVersionHeader()
  {
    return "Version: " + h;
  }

  public void setAsciiVersionHeader(String paramString)
  {
    a("ASCII version header set to " + paramString);
    h = paramString;
  }

  private void a(OutputStream paramOutputStream)
  {
    if ((paramOutputStream instanceof ArmoredOutputStream))
      ((ArmoredOutputStream)paramOutputStream).setHeader("Version", h);
  }

  public void setCypher(String paramString)
  {
    if (KeyStore.c(paramString) < 0)
      throw new InvalidParameterException("Wrong value for parameter 'cypher': " + paramString + ". Must be one of: TRIPLE_DES, CAST5, BLOWFISH, AES_128, AES_192, AES_256, TWOFISH, DES, IDEA, SAFER");
    c = paramString;
    a("Preferred cypher set to {0}", c);
  }

  public String getCompression()
  {
    return d;
  }

  public void setCompression(String paramString)
  {
    if (KeyStore.b(paramString) < 0)
      throw new InvalidParameterException("Wrong value for parameter 'compression': " + paramString + ". Must be one of: ZLIB, ZIP, UNCOMPRESSED, BZIP2");
    d = paramString;
    a("Preferred compression set to {0}", d);
  }

  public boolean detachedVerifyStream(InputStream paramInputStream1, InputStream paramInputStream2, InputStream paramInputStream3)
    throws PGPException, IOException
  {
    paramInputStream2 = PGPUtil.getDecoderStream(paramInputStream2);
    paramInputStream2 = new PGPObjectFactory2(paramInputStream2);
    try
    {
      paramInputStream2 = paramInputStream2.nextObject();
    }
    catch (IOException paramInputStream2)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream2);
    }
    if ((paramInputStream2 instanceof PGPSignatureList))
    {
      paramInputStream2 = (PGPSignatureList)paramInputStream2;
      PGPSignature localPGPSignature = null;
      PGPPublicKey localPGPPublicKey = null;
      for (int n = 0; n < paramInputStream2.size(); n++)
      {
        localPGPSignature = paramInputStream2.get(n);
        if ((localPGPPublicKey = readPublicVerificationKey(paramInputStream3, localPGPSignature.getKeyID())) != null)
          break;
      }
      if (localPGPPublicKey == null)
        return false;
      try
      {
        a.initVerify(localPGPSignature, localPGPPublicKey);
        localObject = new byte[1048576];
        while ((paramInputStream2 = paramInputStream1.read((byte[])localObject, 0, localObject.length)) > 0)
          localPGPSignature.update((byte[])localObject, 0, paramInputStream2);
        return localPGPSignature.verify();
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        Object localObject;
        throw IOUtil.newPGPException(localObject = localPGPException);
      }
    }
    throw new PGPException("Unknown message format: " + paramInputStream2.getClass().getName());
  }

  public boolean detachedVerifyStream(InputStream paramInputStream1, InputStream paramInputStream2, KeyStore paramKeyStore)
    throws PGPException, IOException
  {
    paramInputStream2 = PGPUtil.getDecoderStream(paramInputStream2);
    paramInputStream2 = new PGPObjectFactory2(paramInputStream2);
    try
    {
      paramInputStream2 = paramInputStream2.nextObject();
    }
    catch (IOException paramInputStream2)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream2);
    }
    if ((paramInputStream2 instanceof PGPSignatureList))
    {
      a("Detached signature found");
      paramInputStream2 = (PGPSignatureList)paramInputStream2;
      PGPSignature localPGPSignature = null;
      PGPPublicKey localPGPPublicKey = null;
      for (int n = 0; n < paramInputStream2.size(); n++)
      {
        localPGPSignature = paramInputStream2.get(n);
        a("Detached signature for key ID {0}", KeyPairInformation.keyId2Hex(localPGPSignature.getKeyID()));
        if ((localPGPPublicKey = readPublicVerificationKey(paramKeyStore, localPGPSignature.getKeyID())) != null)
          break;
      }
      if (localPGPPublicKey == null)
      {
        a("No matching public key found");
        return false;
      }
      try
      {
        a.initVerify(localPGPSignature, localPGPPublicKey);
        localObject = new byte[1048576];
        while ((paramInputStream2 = paramInputStream1.read((byte[])localObject, 0, localObject.length)) > 0)
          localPGPSignature.update((byte[])localObject, 0, paramInputStream2);
        if (localPGPSignature.verify())
        {
          a("Signature verified");
          return true;
        }
        a("Signature cannot be verified. Probably is tampered.");
        return false;
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        Object localObject;
        throw IOUtil.newPGPException(localObject = localPGPException);
      }
    }
    throw new PGPException("Unknown message format: " + paramInputStream2.getClass().getName());
  }

  public SignatureCheckResult detachedVerify(String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    InputStream localInputStream3 = null;
    try
    {
      localInputStream1 = readFileOrAsciiString(paramString1, "message");
      localInputStream2 = readFileOrAsciiString(paramString3, "publicKeyFile");
      localInputStream3 = readFileOrAsciiString(paramString2, "detachedSignature");
      paramString1 = detachedVerify(localInputStream1, localInputStream3, localInputStream2);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localInputStream3);
    }
    throw paramString1;
  }

  public SignatureCheckResult detachedVerify(String paramString1, String paramString2, KeyStore paramKeyStore)
    throws PGPException, IOException
  {
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    try
    {
      localInputStream1 = readFileOrAsciiString(paramString1, "message");
      localInputStream2 = readFileOrAsciiString(paramString2, "detachedSignature");
      paramString1 = detachedVerify(localInputStream1, localInputStream2, paramKeyStore);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
    }
    throw paramString1;
  }

  public SignatureCheckResult detachedVerify(InputStream paramInputStream1, InputStream paramInputStream2, InputStream paramInputStream3)
    throws PGPException, IOException
  {
    paramInputStream2 = PGPUtil.getDecoderStream(paramInputStream2);
    paramInputStream2 = new PGPObjectFactory2(paramInputStream2);
    try
    {
      paramInputStream2 = paramInputStream2.nextObject();
    }
    catch (IOException paramInputStream2)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream2);
    }
    if ((paramInputStream2 instanceof PGPSignatureList))
    {
      paramInputStream2 = (PGPSignatureList)paramInputStream2;
      PGPSignature localPGPSignature = null;
      PGPPublicKey localPGPPublicKey = null;
      for (int n = 0; n < paramInputStream2.size(); n++)
      {
        localPGPSignature = paramInputStream2.get(n);
        if ((localPGPPublicKey = readPublicVerificationKey(paramInputStream3, localPGPSignature.getKeyID())) != null)
          break;
      }
      if (localPGPPublicKey == null)
        return SignatureCheckResult.PublicKeyNotMatching;
      try
      {
        localPGPSignature.init(a.CreatePGPContentVerifierBuilderProvider(), localPGPPublicKey);
        localObject = new byte[1048576];
        while ((paramInputStream2 = paramInputStream1.read((byte[])localObject, 0, localObject.length)) > 0)
          localPGPSignature.update((byte[])localObject, 0, paramInputStream2);
        if (localPGPSignature.verify())
          return SignatureCheckResult.SignatureVerified;
        return SignatureCheckResult.SignatureBroken;
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        Object localObject;
        throw IOUtil.newPGPException(localObject = localPGPException);
      }
    }
    throw new PGPException("Unknown message format: " + paramInputStream2.getClass().getName());
  }

  public SignatureCheckResult detachedVerify(InputStream paramInputStream1, InputStream paramInputStream2, KeyStore paramKeyStore)
    throws PGPException, IOException
  {
    paramInputStream2 = PGPUtil.getDecoderStream(paramInputStream2);
    paramInputStream2 = new PGPObjectFactory2(paramInputStream2);
    try
    {
      paramInputStream2 = paramInputStream2.nextObject();
    }
    catch (IOException paramInputStream2)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", paramInputStream2);
    }
    if ((paramInputStream2 instanceof PGPSignatureList))
    {
      a("Detached signature found");
      paramInputStream2 = (PGPSignatureList)paramInputStream2;
      PGPSignature localPGPSignature = null;
      PGPPublicKey localPGPPublicKey = null;
      for (int n = 0; n < paramInputStream2.size(); n++)
      {
        localPGPSignature = paramInputStream2.get(n);
        a("Detached signature for key ID {0}", KeyPairInformation.keyId2Hex(localPGPSignature.getKeyID()));
        if ((localPGPPublicKey = readPublicVerificationKey(paramKeyStore, localPGPSignature.getKeyID())) != null)
          break;
      }
      if (localPGPPublicKey == null)
      {
        a("No matching public key found");
        return SignatureCheckResult.PublicKeyNotMatching;
      }
      try
      {
        localPGPSignature.init(a.CreatePGPContentVerifierBuilderProvider(), localPGPPublicKey);
        localObject = new byte[1048576];
        while ((paramInputStream2 = paramInputStream1.read((byte[])localObject, 0, localObject.length)) > 0)
          localPGPSignature.update((byte[])localObject, 0, paramInputStream2);
        if (localPGPSignature.verify())
        {
          a("Signature verified");
          return SignatureCheckResult.SignatureVerified;
        }
        a("Signature verified failed. Probably it was tampered.");
        return SignatureCheckResult.SignatureBroken;
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        Object localObject;
        throw IOUtil.newPGPException(localObject = localPGPException);
      }
    }
    throw new PGPException("Unknown message format: " + paramInputStream2.getClass().getName());
  }

  public void detachedSignFile(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
    throws PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    InputStream localInputStream = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localFileOutputStream = new FileOutputStream(paramString4);
      detachedSignStream(localFileInputStream, localInputStream, paramString3, localFileOutputStream, paramBoolean);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString4)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  // ERROR //
  public void detachedSignStream(InputStream paramInputStream1, InputStream paramInputStream2, String paramString, OutputStream paramOutputStream, boolean paramBoolean)
    throws PGPException, IOException
  {
    // Byte code:
    //   0: iload 5
    //   2: ifeq +18 -> 20
    //   5: aload 4
    //   7: astore 4
    //   9: new 224\011lw/bouncycastle/bcpg/ArmoredOutputStream
    //   12: dup
    //   13: aload 4
    //   15: invokespecial 549\011lw/bouncycastle/bcpg/ArmoredOutputStream:<init>\011(Ljava/io/OutputStream;)V
    //   18: astore 4
    //   20: aload_0
    //   21: aload_2
    //   22: invokespecial 328\011com/didisoft/pgp/PGPLib:b\011(Ljava/io/InputStream;)Llw/bouncycastle/openpgp/PGPSecretKey;
    //   25: dup
    //   26: astore_2
    //   27: aload_3
    //   28: invokestatic 373\011com/didisoft/pgp/PGPLib:extractPrivateKey\011(Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;)Llw/bouncycastle/openpgp/PGPPrivateKey;
    //   31: astore 6
    //   33: aload_0
    //   34: getfield 263\011com/didisoft/pgp/PGPLib:b\011Ljava/lang/String;
    //   37: invokestatic 285\011com/didisoft/pgp/KeyStore:a\011(Ljava/lang/String;)I
    //   40: istore_3
    //   41: aload_0
    //   42: getfield 272\011com/didisoft/pgp/PGPLib:k\011Z
    //   45: ifeq +5 -> 50
    //   48: iconst_1
    //   49: istore_3
    //   50: aload_0
    //   51: ldc 106
    //   53: aload 6
    //   55: invokevirtual 586\011lw/bouncycastle/openpgp/PGPPrivateKey:getKeyID\011()J
    //   58: invokestatic 282\011com/didisoft/pgp/KeyPairInformation:keyId2Hex\011(J)Ljava/lang/String;
    //   61: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   64: aload_0
    //   65: ldc 93
    //   67: aload_0
    //   68: getfield 263\011com/didisoft/pgp/PGPLib:b\011Ljava/lang/String;
    //   71: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   74: aload_0
    //   75: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   78: aload_2
    //   79: invokevirtual 606\011lw/bouncycastle/openpgp/PGPSecretKey:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   82: invokevirtual 587\011lw/bouncycastle/openpgp/PGPPublicKey:getAlgorithm\011()I
    //   85: iload_3
    //   86: invokevirtual 426\011com/didisoft/pgp/bc/BCFactory:CreatePGPV3SignatureGenerator\011(II)Llw/bouncycastle/openpgp/PGPV3SignatureGenerator;
    //   89: astore_3
    //   90: aload_0
    //   91: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   94: aload_3
    //   95: bipush 31
    //   97: aload 6
    //   99: invokevirtual 430\011com/didisoft/pgp/bc/BCFactory:initSign\011(Llw/bouncycastle/openpgp/PGPV3SignatureGenerator;ILlw/bouncycastle/openpgp/PGPPrivateKey;)V
    //   102: new 225\011lw/bouncycastle/bcpg/BCPGOutputStream
    //   105: dup
    //   106: aload 4
    //   108: invokespecial 551\011lw/bouncycastle/bcpg/BCPGOutputStream:<init>\011(Ljava/io/OutputStream;)V
    //   111: astore_2
    //   112: ldc 3
    //   114: newarray byte
    //   116: astore 6
    //   118: aload_1
    //   119: aload 6
    //   121: iconst_0
    //   122: aload 6
    //   124: arraylength
    //   125: invokevirtual 487\011java/io/InputStream:read\011([BII)I
    //   128: dup
    //   129: istore 7
    //   131: ifle +15 -> 146
    //   134: aload_3
    //   135: aload 6
    //   137: iconst_0
    //   138: iload 7
    //   140: invokevirtual 635\011lw/bouncycastle/openpgp/PGPV3SignatureGenerator:update\011([BII)V
    //   143: goto -25 -> 118
    //   146: aload_1
    //   147: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   150: aload_3
    //   151: ifnull +11 -> 162
    //   154: aload_3
    //   155: invokevirtual 634\011lw/bouncycastle/openpgp/PGPV3SignatureGenerator:generate\011()Llw/bouncycastle/openpgp/PGPSignature;
    //   158: aload_2
    //   159: invokevirtual 614\011lw/bouncycastle/openpgp/PGPSignature:encode\011(Ljava/io/OutputStream;)V
    //   162: aload_2
    //   163: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   166: aload 4
    //   168: invokevirtual 490\011java/io/OutputStream:flush\011()V
    //   171: iload 5
    //   173: ifeq +8 -> 181
    //   176: aload 4
    //   178: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   181: return
    //   182: dup
    //   183: astore_2
    //   184: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   187: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   20\011181\011182\011lw/bouncycastle/openpgp/PGPException
  }

  public void detachedSignStream(InputStream paramInputStream, KeyStore paramKeyStore, long paramLong, String paramString, OutputStream paramOutputStream, boolean paramBoolean)
    throws PGPException, IOException
  {
    paramKeyStore = d(paramKeyStore, paramLong);
    detachedSignStream(paramInputStream, paramKeyStore, paramString, paramOutputStream, paramBoolean);
  }

  public void detachedSignStream(InputStream paramInputStream, KeyStore paramKeyStore, String paramString1, String paramString2, OutputStream paramOutputStream, boolean paramBoolean)
    throws PGPException, IOException
  {
    paramKeyStore = b(paramKeyStore, paramString1);
    detachedSignStream(paramInputStream, paramKeyStore, paramString2, paramOutputStream, paramBoolean);
  }

  public void clearSignFile(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException, WrongPasswordException
  {
    a("Clear text signing file {0}", paramString1);
    a("Output file is {0}", paramString5);
    BufferedInputStream localBufferedInputStream = null;
    FileInputStream localFileInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    int i1;
    if ((i1 = KeyStore.a(paramString4)) < 0)
      throw new InvalidParameterException("Wrong value for parameter 'hashingAlgorithm': " + paramString4 + ". Must be one of: SHA256, SHA384, SHA512, SHA224, SHA1, MD5, RIPEMD160, MD2");
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localFileInputStream = new FileInputStream(paramString2);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString5), 1048576);
      paramString1 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      };
      paramString2 = b(localFileInputStream);
      paramString1.a(localBufferedInputStream, paramString2, paramString3, i1, localBufferedOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString5)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void clearSignFileVersion3(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException, WrongPasswordException
  {
    BufferedInputStream localBufferedInputStream = null;
    FileInputStream localFileInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    int i1;
    if ((i1 = KeyStore.a(paramString4)) < 0)
      throw new InvalidParameterException("Wrong value for parameter 'hashingAlgorithm': " + paramString4 + ". Must be one of: SHA256, SHA384, SHA512, SHA224, SHA1, MD5, RIPEMD160, MD2");
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localFileInputStream = new FileInputStream(paramString2);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString5), 1048576);
      paramString1 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      };
      paramString2 = b(localFileInputStream);
      paramString1.b(localBufferedInputStream, paramString2, paramString3, i1, localBufferedOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString5)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public String clearSignString(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException, WrongPasswordException
  {
    int n;
    if ((n = KeyStore.a(paramString4)) < 0)
      throw new InvalidParameterException("Wrong value for parameter 'hashingAlgorithm': " + paramString4 + ". Must be one of: SHA256, SHA384, SHA512, SHA224, SHA1, MD5, RIPEMD160, MD2");
    paramString4 = null;
    try
    {
      paramString4 = new FileInputStream(paramString2);
      paramString2 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      };
      PGPSecretKey localPGPSecretKey = b(paramString4);
      paramString1 = paramString2.a(paramString1, localPGPSecretKey, paramString3, n);
      return paramString1;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(paramString4);
    }
    throw paramString1;
  }

  public String clearSignStringVersion3(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException, WrongPasswordException
  {
    int n;
    if ((n = KeyStore.a(paramString4)) < 0)
      throw new InvalidParameterException("Wrong value for parameter 'hashingAlgorithm': " + paramString4 + ". Must be one of: SHA256, SHA384, SHA512, SHA224, SHA1, MD5, RIPEMD160, MD2");
    paramString4 = null;
    try
    {
      paramString4 = new FileInputStream(paramString2);
      paramString2 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      };
      PGPSecretKey localPGPSecretKey = b(paramString4);
      paramString1 = paramString2.b(paramString1, localPGPSecretKey, paramString3, n);
      return paramString1;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(paramString4);
    }
    throw paramString1;
  }

  public void signFile(KeyStore paramKeyStore, String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, WrongPasswordException, IOException
  {
    signFile(paramKeyStore, paramString1, paramKeyStore.getKeyIdForKeyIdHex(paramString2), paramString3, paramString4);
  }

  public void signFile(KeyStore paramKeyStore, String paramString1, long paramLong, String paramString2, String paramString3)
    throws PGPException, WrongPasswordException, IOException
  {
    FileInputStream localFileInputStream = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      File localFile = new File(paramString1);
      localFileInputStream = new FileInputStream(paramString1);
      localFileOutputStream = new FileOutputStream(paramString3);
      paramKeyStore = paramKeyStore.a.getSecretKey(paramLong);
      a(localFileInputStream, localFile.getName(), paramKeyStore, paramString2, localFileOutputStream, false);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      n = 1;
      throw IOUtil.newPGPException(localPGPException);
    }
    catch (IOException localIOException)
    {
      n = 1;
      throw localIOException;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramString1 = new File(paramString3)).exists()))
        paramString1.delete();
    }
    throw paramKeyStore;
  }

  public void signFile(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
    throws PGPException, WrongPasswordException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      localInputStream = b(paramKeyStore, paramString2);
      localFileOutputStream = new FileOutputStream(paramString4);
      paramKeyStore = b(localInputStream);
      paramString2 = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      a(localBufferedInputStream, paramString2.getName(), paramKeyStore, paramString3, localFileOutputStream, paramBoolean);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramKeyStore)
    {
      n = 1;
      throw IOUtil.newPGPException(paramKeyStore);
    }
    catch (IOException paramKeyStore)
    {
      n = 1;
      throw paramKeyStore;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString4)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void signFile(String paramString1, KeyStore paramKeyStore, long paramLong, String paramString2, String paramString3, boolean paramBoolean)
    throws PGPException, WrongPasswordException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      localInputStream = d(paramKeyStore, paramLong);
      localFileOutputStream = new FileOutputStream(paramString3);
      paramKeyStore = b(localInputStream);
      paramLong = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      a(localBufferedInputStream, paramLong.getName(), paramKeyStore, paramString2, localFileOutputStream, paramBoolean);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramKeyStore)
    {
      n = 1;
      throw IOUtil.newPGPException(paramKeyStore);
    }
    catch (IOException paramKeyStore)
    {
      n = 1;
      throw paramKeyStore;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString3)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void signFile(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    InputStream localInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString4), 1048576);
      signFile(paramString1, localInputStream, paramString3, localBufferedOutputStream, paramBoolean);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString4)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void signFile(String paramString1, InputStream paramInputStream, String paramString2, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    paramInputStream = b(paramInputStream);
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      a(localBufferedInputStream, new File(paramString1).getName(), paramInputStream, paramString2, paramOutputStream, paramBoolean);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(paramOutputStream);
    }
    throw paramString1;
  }

  public void signStream(InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    paramInputStream2 = b(paramInputStream2);
    try
    {
      a(paramInputStream1, paramString1, paramInputStream2, paramString2, paramOutputStream, paramBoolean);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(paramInputStream1);
      IOUtil.closeStream(paramOutputStream);
    }
    throw paramString1;
  }

  public void signStream(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = b(paramKeyStore, paramString2);
      paramKeyStore = b(localInputStream);
      a(paramInputStream, paramString1, paramKeyStore, paramString3, paramOutputStream, paramBoolean);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(paramInputStream);
      IOUtil.closeStream(paramOutputStream);
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public void signStream(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, long paramLong, String paramString2, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = d(paramKeyStore, paramLong);
      paramKeyStore = b(localInputStream);
      a(paramInputStream, paramString1, paramKeyStore, paramString2, paramOutputStream, paramBoolean);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(paramInputStream);
      IOUtil.closeStream(paramOutputStream);
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public void signFileVersion3(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString4), 1048576);
      signStreamVersion3(localBufferedInputStream, new File(paramString1).getName(), localInputStream, paramString3, localBufferedOutputStream, paramBoolean);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString4)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void signStreamVersion3(InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    if (paramBoolean)
    {
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
      a(paramOutputStream);
    }
    paramInputStream2 = b(paramInputStream2);
    a(paramInputStream2.getPublicKey());
    b(paramInputStream2.getPublicKey());
    paramString2 = extractPrivateKey(paramInputStream2, paramString2);
    int n = d(paramInputStream2.getPublicKey());
    Object localObject;
    try
    {
      localObject = a.CreatePGPSignatureGenerator(paramInputStream2.getPublicKey().getAlgorithm(), n);
      a.initSign((PGPSignatureGenerator)localObject, 0, paramString2);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
    {
      throw IOUtil.newPGPException(paramInputStream2 = localPGPException1);
    }
    if ((paramInputStream2 = paramInputStream2.getPublicKey().getUserIDs()).hasNext())
    {
      (paramString2 = new PGPSignatureSubpacketGenerator()).setSignerUserID(false, (String)paramInputStream2.next());
      ((PGPSignatureGenerator)localObject).setHashedSubpackets(paramString2.generate());
    }
    paramString2 = new PGPCompressedDataGenerator(2);
    paramInputStream2 = new BCPGOutputStream(paramString2.open(paramOutputStream));
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
    byte[] arrayOfByte = new byte[1048576];
    int i1;
    while ((i1 = paramInputStream1.read(arrayOfByte)) >= 0)
    {
      localDirectByteArrayOutputStream.write(arrayOfByte, 0, i1);
      ((PGPSignatureGenerator)localObject).update(arrayOfByte, 0, i1);
    }
    try
    {
      ((PGPSignatureGenerator)localObject).generate().encode(paramInputStream2);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
    {
      throw IOUtil.newPGPException(localObject = localPGPException2);
    }
    a("Signing content with file name label {0}. (version 3, old style signature)", paramString1);
    (paramString1 = (localObject = new PGPLiteralDataGenerator()).open(paramInputStream2, getContentType(), paramString1, localDirectByteArrayOutputStream.size(), new Date())).write(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size());
    ((PGPLiteralDataGenerator)localObject).close();
    paramString2.close();
    IOUtil.closeStream(paramInputStream1);
    IOUtil.closeStream(localDirectByteArrayOutputStream);
    IOUtil.closeStream(paramString1);
    IOUtil.closeStream(paramInputStream2);
    paramOutputStream.flush();
    if (paramBoolean)
      IOUtil.closeStream(paramOutputStream);
  }

  public void signAndEncryptFile(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean)
    throws PGPException, WrongPasswordException, IOException
  {
    signAndEncryptFile(paramString1, paramString2, paramString3, paramString4, paramString5, paramBoolean, false);
  }

  public void signAndEncryptFile(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, WrongPasswordException, IOException
  {
    a("Signing file {0}", paramString1);
    InputStream localInputStream1 = null;
    BufferedOutputStream localBufferedOutputStream = null;
    InputStream localInputStream2 = null;
    BufferedInputStream localBufferedInputStream = null;
    int n = 0;
    try
    {
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString5), 1048576);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFile");
      signAndEncryptStream(localBufferedInputStream, new File(paramString1).getName(), localInputStream1, paramString3, localInputStream2, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localBufferedInputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localBufferedInputStream);
      if ((n != 0) && ((paramString2 = new File(paramString5)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void signAndEncryptFile(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, String paramString4, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, WrongPasswordException, IOException
  {
    a("Signing file {0}", paramString1);
    InputStream localInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    InputStream[] arrayOfInputStream = new InputStream[paramArrayOfString.length];
    BufferedInputStream localBufferedInputStream = null;
    int n = 0;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString4), 1048576);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      for (paramString2 = 0; paramString2 < paramArrayOfString.length; paramString2++)
        arrayOfInputStream[paramString2] = readFileOrAsciiString(paramArrayOfString[paramString2], "publicKeyFiles: " + paramString2);
      signAndEncryptStream(localBufferedInputStream, new File(paramString1).getName(), localInputStream, paramString3, arrayOfInputStream, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      for (paramString2 = 0; paramString2 < arrayOfInputStream.length; paramString2++)
        IOUtil.closeStream(arrayOfInputStream[paramString2]);
      IOUtil.closeStream(localBufferedInputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString2)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString2);
    }
    catch (IOException paramString2)
    {
      n = 1;
      throw paramString2;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      for (paramString2 = 0; paramString2 < arrayOfInputStream.length; paramString2++)
        IOUtil.closeStream(arrayOfInputStream[paramString2]);
      IOUtil.closeStream(localBufferedInputStream);
      if ((n != 0) && ((paramString2 = new File(paramString4)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void signAndEncryptFile(String paramString1, InputStream paramInputStream1, String paramString2, InputStream paramInputStream2, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException, WrongPasswordException
  {
    BufferedInputStream localBufferedInputStream = null;
    File localFile = new File(paramString1);
    a("Signing file {0}", paramString1);
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(localFile));
      signAndEncryptStream(localBufferedInputStream, localFile.getName(), paramInputStream1, paramString2, paramInputStream2, paramOutputStream, paramBoolean1, paramBoolean2);
      return;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(paramOutputStream);
    }
    throw paramString1;
  }

  public void signAndEncryptStream(InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, InputStream paramInputStream3, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException, WrongPasswordException, NoPublicKeyFoundException, NoPrivateKeyFoundException
  {
    if (k)
    {
      new Date();
      a(paramInputStream1, paramString1, paramInputStream2, paramString2, new InputStream[] { paramInputStream3 }, paramOutputStream, paramBoolean1);
      return;
    }
    if (!(paramOutputStream instanceof BufferedOutputStream))
      paramOutputStream = new BufferedOutputStream(paramOutputStream, 1048576);
    if (!paramInputStream3.markSupported())
      paramInputStream3 = new BufferedInputStream(paramInputStream3);
    if (!paramInputStream2.markSupported())
      paramInputStream2 = new BufferedInputStream(paramInputStream2);
    paramInputStream3.mark(1048576);
    paramInputStream2.mark(1048576);
    Object localObject1 = a(paramInputStream3);
    Object localObject2 = b(paramInputStream2);
    if (((PGPPublicKey)localObject1).getVersion() == 3)
    {
      paramInputStream3.reset();
      paramInputStream2.reset();
      a("Swithcing to version 3 signatures");
      signAndEncryptStreamVersion3(paramInputStream1, paramString1, paramInputStream2, paramString2, paramInputStream3, paramOutputStream, paramBoolean1, paramBoolean2);
      return;
    }
    paramInputStream2 = null;
    try
    {
      if (paramBoolean1)
      {
        paramInputStream2 = paramOutputStream;
        paramOutputStream = new ArmoredOutputStream(paramInputStream2);
        a(paramOutputStream);
      }
      paramInputStream3 = c((PGPPublicKey)localObject1);
      a("Encrypting with cipher {0}", KeyStore.c(paramInputStream3));
      (paramInputStream3 = new PGPEncryptedDataGenerator(a.CreatePGPDataEncryptorBuilder(paramInputStream3, paramBoolean2, IOUtil.getSecureRandom()))).addMethod(a.CreatePublicKeyKeyEncryptionMethodGenerator((PGPPublicKey)localObject1));
      paramBoolean2 = paramInputStream3.open(paramOutputStream, new byte[65536]);
      paramString2 = extractPrivateKey((PGPSecretKey)localObject2, paramString2);
      int i1 = d(((PGPSecretKey)localObject2).getPublicKey());
      a("Signing with hash {0}", KeyStore.b(i1));
      PGPSignatureGenerator localPGPSignatureGenerator = a.CreatePGPSignatureGenerator(((PGPSecretKey)localObject2).getPublicKey().getAlgorithm(), i1);
      a.initSign(localPGPSignatureGenerator, 0, paramString2);
      paramString2 = ((PGPSecretKey)localObject2).getPublicKey().getUserIDs();
      while (paramString2.hasNext())
      {
        localObject2 = (String)paramString2.next();
        localObject3 = new PGPSignatureSubpacketGenerator();
        a("Signing with User ID {0}", (String)localObject2);
        ((PGPSignatureSubpacketGenerator)localObject3).setSignerUserID(false, (String)localObject2);
        localPGPSignatureGenerator.setHashedSubpackets(((PGPSignatureSubpacketGenerator)localObject3).generate());
      }
      int n = e((PGPPublicKey)localObject1);
      Object localObject3 = new PGPCompressedDataGenerator(n);
      paramString2 = null;
      localObject1 = new PGPLiteralDataGenerator();
      OutputStream localOutputStream;
      if (n == 0)
      {
        a("No compression.");
        localPGPSignatureGenerator.generateOnePassVersion(false).encode(paramBoolean2);
        localOutputStream = ((PGPLiteralDataGenerator)localObject1).open(paramBoolean2, 'b', paramString1, new Date(), new byte[1048576]);
      }
      else
      {
        a("Compression is {0}", KeyStore.a(localOutputStream));
        paramString2 = ((PGPCompressedDataGenerator)localObject3).open(paramBoolean2, new byte[65536]);
        localPGPSignatureGenerator.generateOnePassVersion(false).encode(paramString2);
        localOutputStream = ((PGPLiteralDataGenerator)localObject1).open(paramString2, 'b', paramString1, new Date(), new byte[1048576]);
      }
      a("Signing stream content with internal file name label: {0}", paramString1);
      paramString1 = new byte[65536];
      int i2;
      while ((i2 = paramInputStream1.read(paramString1, 0, paramString1.length)) != -1)
      {
        localOutputStream.write(paramString1, 0, i2);
        localPGPSignatureGenerator.update(paramString1, 0, i2);
      }
      IOUtil.closeStream(localOutputStream);
      ((PGPLiteralDataGenerator)localObject1).close();
      if (paramString2 == null)
        localPGPSignatureGenerator.generate().encode(paramBoolean2);
      else
        localPGPSignatureGenerator.generate().encode(paramString2);
      IOUtil.closeStream(paramString2);
      ((PGPCompressedDataGenerator)localObject3).close();
      IOUtil.closeStream(paramBoolean2);
      paramInputStream3.close();
      IOUtil.closeStream(paramInputStream1);
      if (paramBoolean1)
        paramOutputStream.close();
      if (paramBoolean1)
      {
        IOUtil.closeStream(paramOutputStream);
        paramInputStream2.flush();
        return;
      }
      paramOutputStream.flush();
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      if (paramBoolean1)
      {
        IOUtil.closeStream(paramOutputStream);
        paramInputStream2.flush();
      }
      else
      {
        paramOutputStream.flush();
      }
    }
    throw paramInputStream1;
  }

  // ERROR //
  public void signAndEncryptStream(InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, InputStream[] paramArrayOfInputStream, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException, WrongPasswordException, NoPublicKeyFoundException, NoPrivateKeyFoundException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 272\011com/didisoft/pgp/PGPLib:k\011Z
    //   4: ifeq +25 -> 29
    //   7: aload_0
    //   8: aload_1
    //   9: aload_2
    //   10: aload_3
    //   11: aload 4
    //   13: aload 5
    //   15: aload 6
    //   17: new 217\011java/util/Date
    //   20: invokespecial 540\011java/util/Date:<init>\011()V
    //   23: iload 7
    //   25: invokespecial 301\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/InputStream;Ljava/lang/String;Ljava/io/InputStream;Ljava/lang/String;[Ljava/io/InputStream;Ljava/io/OutputStream;Z)V
    //   28: return
    //   29: iload 7
    //   31: ifeq +20 -> 51
    //   34: new 224\011lw/bouncycastle/bcpg/ArmoredOutputStream
    //   37: dup
    //   38: aload 6
    //   40: invokespecial 549\011lw/bouncycastle/bcpg/ArmoredOutputStream:<init>\011(Ljava/io/OutputStream;)V
    //   43: astore 6
    //   45: aload_0
    //   46: aload 6
    //   48: invokespecial 306\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/OutputStream;)V
    //   51: aload_0
    //   52: getfield 264\011com/didisoft/pgp/PGPLib:c\011Ljava/lang/String;
    //   55: invokestatic 290\011com/didisoft/pgp/KeyStore:c\011(Ljava/lang/String;)I
    //   58: istore 9
    //   60: aload_0
    //   61: ldc 53
    //   63: iload 9
    //   65: invokestatic 289\011com/didisoft/pgp/KeyStore:c\011(I)Ljava/lang/String;
    //   68: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   71: new 229\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator
    //   74: dup
    //   75: aload_0
    //   76: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   79: iload 9
    //   81: iload 8
    //   83: invokestatic 445\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   86: invokevirtual 422\011com/didisoft/pgp/bc/BCFactory:CreatePGPDataEncryptorBuilder\011(IZLjava/security/SecureRandom;)Llw/bouncycastle/openpgp/operator/PGPDataEncryptorBuilder;
    //   89: invokespecial 560\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:<init>\011(Llw/bouncycastle/openpgp/operator/PGPDataEncryptorBuilder;)V
    //   92: astore 8
    //   94: iconst_0
    //   95: istore 9
    //   97: iload 9
    //   99: aload 5
    //   101: arraylength
    //   102: if_icmpge +48 -> 150
    //   105: aload_0
    //   106: aload 5
    //   108: iload 9
    //   110: aaload
    //   111: invokespecial 298\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/InputStream;)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   114: astore 10
    //   116: aload_0
    //   117: ldc 57
    //   119: aload 10
    //   121: invokevirtual 589\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   124: invokestatic 282\011com/didisoft/pgp/KeyPairInformation:keyId2Hex\011(J)Ljava/lang/String;
    //   127: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   130: aload 8
    //   132: aload_0
    //   133: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   136: aload 10
    //   138: invokevirtual 428\011com/didisoft/pgp/bc/BCFactory:CreatePublicKeyKeyEncryptionMethodGenerator\011(Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/operator/PublicKeyKeyEncryptionMethodGenerator;
    //   141: invokevirtual 561\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:addMethod\011(Llw/bouncycastle/openpgp/operator/PGPKeyEncryptionMethodGenerator;)V
    //   144: iinc 9 1
    //   147: goto -50 -> 97
    //   150: aload 8
    //   152: aload 6
    //   154: ldc 1
    //   156: newarray byte
    //   158: invokevirtual 564\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:open\011(Ljava/io/OutputStream;[B)Ljava/io/OutputStream;
    //   161: astore 9
    //   163: aload_0
    //   164: aload_3
    //   165: invokespecial 328\011com/didisoft/pgp/PGPLib:b\011(Ljava/io/InputStream;)Llw/bouncycastle/openpgp/PGPSecretKey;
    //   168: dup
    //   169: astore 10
    //   171: aload 4
    //   173: invokestatic 373\011com/didisoft/pgp/PGPLib:extractPrivateKey\011(Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;)Llw/bouncycastle/openpgp/PGPPrivateKey;
    //   176: astore_3
    //   177: aload_0
    //   178: aload 10
    //   180: invokevirtual 606\011lw/bouncycastle/openpgp/PGPSecretKey:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   183: invokespecial 336\011com/didisoft/pgp/PGPLib:d\011(Llw/bouncycastle/openpgp/PGPPublicKey;)I
    //   186: istore 4
    //   188: aload_0
    //   189: ldc 105
    //   191: iload 4
    //   193: invokestatic 286\011com/didisoft/pgp/KeyStore:b\011(I)Ljava/lang/String;
    //   196: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   199: aload_0
    //   200: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   203: aload 10
    //   205: invokevirtual 606\011lw/bouncycastle/openpgp/PGPSecretKey:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   208: invokevirtual 587\011lw/bouncycastle/openpgp/PGPPublicKey:getAlgorithm\011()I
    //   211: iload 4
    //   213: invokevirtual 425\011com/didisoft/pgp/bc/BCFactory:CreatePGPSignatureGenerator\011(II)Llw/bouncycastle/openpgp/PGPSignatureGenerator;
    //   216: astore 4
    //   218: aload_0
    //   219: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   222: aload 4
    //   224: iconst_0
    //   225: aload_3
    //   226: invokevirtual 429\011com/didisoft/pgp/bc/BCFactory:initSign\011(Llw/bouncycastle/openpgp/PGPSignatureGenerator;ILlw/bouncycastle/openpgp/PGPPrivateKey;)V
    //   229: aload 10
    //   231: invokevirtual 606\011lw/bouncycastle/openpgp/PGPSecretKey:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   234: invokevirtual 591\011lw/bouncycastle/openpgp/PGPPublicKey:getUserIDs\011()Ljava/util/Iterator;
    //   237: astore_3
    //   238: aload_3
    //   239: invokeinterface 642 1 0
    //   244: ifeq +43 -> 287
    //   247: aload_3
    //   248: invokeinterface 643 1 0
    //   253: checkcast 207\011java/lang/String
    //   256: astore 5
    //   258: new 250\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator
    //   261: dup
    //   262: invokespecial 627\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator:<init>\011()V
    //   265: dup
    //   266: astore 10
    //   268: iconst_0
    //   269: aload 5
    //   271: invokevirtual 629\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator:setSignerUserID\011(ZLjava/lang/String;)V
    //   274: aload 4
    //   276: aload 10
    //   278: invokevirtual 628\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator:generate\011()Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;
    //   281: invokevirtual 623\011lw/bouncycastle/openpgp/PGPSignatureGenerator:setHashedSubpackets\011(Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;)V
    //   284: goto -46 -> 238
    //   287: aload_0
    //   288: getfield 265\011com/didisoft/pgp/PGPLib:d\011Ljava/lang/String;
    //   291: invokestatic 288\011com/didisoft/pgp/KeyStore:b\011(Ljava/lang/String;)I
    //   294: istore 5
    //   296: new 227\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator
    //   299: dup
    //   300: iload 5
    //   302: invokespecial 555\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:<init>\011(I)V
    //   305: astore 10
    //   307: aconst_null
    //   308: astore_3
    //   309: new 233\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator
    //   312: dup
    //   313: invokespecial 571\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:<init>\011()V
    //   316: astore 11
    //   318: iload 5
    //   320: ifne +46 -> 366
    //   323: aload_0
    //   324: ldc 70
    //   326: invokespecial 308\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;)V
    //   329: aload 4
    //   331: iconst_0
    //   332: invokevirtual 622\011lw/bouncycastle/openpgp/PGPSignatureGenerator:generateOnePassVersion\011(Z)Llw/bouncycastle/openpgp/PGPOnePassSignature;
    //   335: aload 9
    //   337: invokevirtual 577\011lw/bouncycastle/openpgp/PGPOnePassSignature:encode\011(Ljava/io/OutputStream;)V
    //   340: aload 11
    //   342: aload 9
    //   344: bipush 98
    //   346: aload_2
    //   347: new 217\011java/util/Date
    //   350: dup
    //   351: invokespecial 540\011java/util/Date:<init>\011()V
    //   354: ldc 3
    //   356: newarray byte
    //   358: invokevirtual 575\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:open\011(Ljava/io/OutputStream;CLjava/lang/String;Ljava/util/Date;[B)Ljava/io/OutputStream;
    //   361: astore 5
    //   363: goto +58 -> 421
    //   366: aload_0
    //   367: ldc 28
    //   369: iload 5
    //   371: invokestatic 283\011com/didisoft/pgp/KeyStore:a\011(I)Ljava/lang/String;
    //   374: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   377: aload 10
    //   379: aload 9
    //   381: ldc 1
    //   383: newarray byte
    //   385: invokevirtual 558\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:open\011(Ljava/io/OutputStream;[B)Ljava/io/OutputStream;
    //   388: astore_3
    //   389: aload 4
    //   391: iconst_0
    //   392: invokevirtual 622\011lw/bouncycastle/openpgp/PGPSignatureGenerator:generateOnePassVersion\011(Z)Llw/bouncycastle/openpgp/PGPOnePassSignature;
    //   395: aload_3
    //   396: invokevirtual 577\011lw/bouncycastle/openpgp/PGPOnePassSignature:encode\011(Ljava/io/OutputStream;)V
    //   399: aload 11
    //   401: aload_3
    //   402: bipush 98
    //   404: aload_2
    //   405: new 217\011java/util/Date
    //   408: dup
    //   409: invokespecial 540\011java/util/Date:<init>\011()V
    //   412: ldc 3
    //   414: newarray byte
    //   416: invokevirtual 575\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:open\011(Ljava/io/OutputStream;CLjava/lang/String;Ljava/util/Date;[B)Ljava/io/OutputStream;
    //   419: astore 5
    //   421: aload_0
    //   422: ldc 103
    //   424: aload_2
    //   425: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   428: ldc 1
    //   430: newarray byte
    //   432: astore_2
    //   433: aload_1
    //   434: aload_2
    //   435: iconst_0
    //   436: aload_2
    //   437: arraylength
    //   438: invokevirtual 487\011java/io/InputStream:read\011([BII)I
    //   441: dup
    //   442: istore 12
    //   444: iconst_m1
    //   445: if_icmpeq +24 -> 469
    //   448: aload 5
    //   450: aload_2
    //   451: iconst_0
    //   452: iload 12
    //   454: invokevirtual 492\011java/io/OutputStream:write\011([BII)V
    //   457: aload 4
    //   459: aload_2
    //   460: iconst_0
    //   461: iload 12
    //   463: invokevirtual 624\011lw/bouncycastle/openpgp/PGPSignatureGenerator:update\011([BII)V
    //   466: goto -33 -> 433
    //   469: aload 5
    //   471: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   474: aload 11
    //   476: invokevirtual 573\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:close\011()V
    //   479: aload_3
    //   480: ifnonnull +16 -> 496
    //   483: aload 4
    //   485: invokevirtual 621\011lw/bouncycastle/openpgp/PGPSignatureGenerator:generate\011()Llw/bouncycastle/openpgp/PGPSignature;
    //   488: aload 9
    //   490: invokevirtual 614\011lw/bouncycastle/openpgp/PGPSignature:encode\011(Ljava/io/OutputStream;)V
    //   493: goto +12 -> 505
    //   496: aload 4
    //   498: invokevirtual 621\011lw/bouncycastle/openpgp/PGPSignatureGenerator:generate\011()Llw/bouncycastle/openpgp/PGPSignature;
    //   501: aload_3
    //   502: invokevirtual 614\011lw/bouncycastle/openpgp/PGPSignature:encode\011(Ljava/io/OutputStream;)V
    //   505: aload_3
    //   506: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   509: aload 10
    //   511: invokevirtual 556\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:close\011()V
    //   514: aload 9
    //   516: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   519: aload 8
    //   521: invokevirtual 562\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:close\011()V
    //   524: aload_1
    //   525: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   528: iload 7
    //   530: ifeq +8 -> 538
    //   533: aload 6
    //   535: invokevirtual 489\011java/io/OutputStream:close\011()V
    //   538: return
    //   539: dup
    //   540: astore 9
    //   542: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   545: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   29\011538\011539\011lw/bouncycastle/openpgp/PGPException
  }

  public void signAndEncryptFile(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException
  {
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    a("Signing and encrypting file {0}", paramString1);
    a("Output file is {0}", new File(paramString5).getAbsolutePath());
    try
    {
      localInputStream1 = a(paramKeyStore, paramString4);
      localInputStream2 = b(paramKeyStore, paramString2);
      paramKeyStore = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(new File(paramString5)), 1048576);
      signAndEncryptStream(localBufferedInputStream, paramKeyStore.getName(), localInputStream2, paramString3, localInputStream1, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localInputStream1);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramKeyStore)
    {
      n = 1;
      throw IOUtil.newPGPException(paramKeyStore);
    }
    catch (IOException paramKeyStore)
    {
      n = 1;
      throw paramKeyStore;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localInputStream1);
      if ((n != 0) && ((paramKeyStore = new File(paramString5)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void signAndEncryptFile(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, String[] paramArrayOfString, String paramString4, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException
  {
    InputStream[] arrayOfInputStream = new InputStream[paramArrayOfString.length];
    InputStream localInputStream = null;
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    a("Signing and encrypting file {0}", paramString1);
    a("Output file is {0}", new File(paramString4).getAbsolutePath());
    try
    {
      for (int i1 = 0; i1 < arrayOfInputStream.length; i1++)
        arrayOfInputStream[i1] = a(paramKeyStore, paramArrayOfString[i1]);
      localInputStream = b(paramKeyStore, paramString2);
      File localFile = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString4), 1048576);
      signAndEncryptStream(localBufferedInputStream, localFile.getName(), localInputStream, paramString3, arrayOfInputStream, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream);
      for (int i2 = 0; i2 < arrayOfInputStream.length; i2++)
        IOUtil.closeStream(arrayOfInputStream[i2]);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      n = 1;
      throw IOUtil.newPGPException(localPGPException);
    }
    catch (IOException localIOException)
    {
      n = 1;
      throw localIOException;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream);
      for (paramKeyStore = 0; paramKeyStore < arrayOfInputStream.length; paramKeyStore++)
        IOUtil.closeStream(arrayOfInputStream[paramKeyStore]);
      if ((n != 0) && ((paramKeyStore = new File(paramString4)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void signAndEncryptFile(String paramString1, KeyStore paramKeyStore, long paramLong, String paramString2, long[] paramArrayOfLong, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException
  {
    InputStream[] arrayOfInputStream = new InputStream[paramArrayOfLong.length];
    InputStream localInputStream = null;
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    a("Signing and encrypting file {0}", paramString1);
    a("Output file is {0}", new File(paramString3).getAbsolutePath());
    try
    {
      for (int i1 = 0; i1 < arrayOfInputStream.length; i1++)
        arrayOfInputStream[i1] = c(paramKeyStore, paramArrayOfLong[i1]);
      localInputStream = d(paramKeyStore, paramLong);
      File localFile = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3), 1048576);
      signAndEncryptStream(localBufferedInputStream, localFile.getName(), localInputStream, paramString2, arrayOfInputStream, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream);
      for (int i2 = 0; i2 < arrayOfInputStream.length; i2++)
        IOUtil.closeStream(arrayOfInputStream[i2]);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      n = 1;
      throw IOUtil.newPGPException(localPGPException);
    }
    catch (IOException localIOException)
    {
      n = 1;
      throw localIOException;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream);
      for (paramKeyStore = 0; paramKeyStore < arrayOfInputStream.length; paramKeyStore++)
        IOUtil.closeStream(arrayOfInputStream[paramKeyStore]);
      if ((n != 0) && ((paramKeyStore = new File(paramString3)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void signAndEncryptFile(String paramString1, KeyStore paramKeyStore, long paramLong1, String paramString2, long paramLong2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException
  {
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    a("Signing and encrypting file {0}", paramString1);
    a("Output file is {0}", new File(paramString3).getAbsolutePath());
    int n = 0;
    try
    {
      localInputStream1 = c(paramKeyStore, paramLong2);
      localInputStream2 = d(paramKeyStore, paramLong1);
      paramKeyStore = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3), 1048576);
      signAndEncryptStream(localBufferedInputStream, paramKeyStore.getName(), localInputStream2, paramString2, localInputStream1, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localInputStream1);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramKeyStore)
    {
      n = 1;
      throw IOUtil.newPGPException(paramKeyStore);
    }
    catch (IOException paramKeyStore)
    {
      n = 1;
      throw paramKeyStore;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localInputStream1);
      if ((n != 0) && ((paramKeyStore = new File(paramString3)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  // ERROR //
  public void signAndEncryptStream(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, String paramString4, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException
  {
    // Byte code:
    //   0: aload_3
    //   1: aload 6
    //   3: invokestatic 297\011com/didisoft/pgp/PGPLib:a\011(Lcom/didisoft/pgp/KeyStore;Ljava/lang/String;)Ljava/io/InputStream;
    //   6: astore 6
    //   8: aload_3
    //   9: aload 4
    //   11: invokestatic 327\011com/didisoft/pgp/PGPLib:b\011(Lcom/didisoft/pgp/KeyStore;Ljava/lang/String;)Ljava/io/InputStream;
    //   14: astore_3
    //   15: aload_0
    //   16: aload_1
    //   17: aload_2
    //   18: aload_3
    //   19: aload 5
    //   21: aload 6
    //   23: aload 7
    //   25: iload 8
    //   27: iload 9
    //   29: invokevirtual 381\011com/didisoft/pgp/PGPLib:signAndEncryptStream\011(Ljava/io/InputStream;Ljava/lang/String;Ljava/io/InputStream;Ljava/lang/String;Ljava/io/InputStream;Ljava/io/OutputStream;ZZ)V
    //   32: return
    //   33: dup
    //   34: astore 6
    //   36: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   39: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   0\01132\01133\011lw/bouncycastle/openpgp/PGPException
  }

  // ERROR //
  public void signAndEncryptStream(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, String[] paramArrayOfString, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException
  {
    // Byte code:
    //   0: aload 6
    //   2: arraylength
    //   3: anewarray 195\011java/io/InputStream
    //   6: astore 10
    //   8: aload_3
    //   9: aload 4
    //   11: invokestatic 327\011com/didisoft/pgp/PGPLib:b\011(Lcom/didisoft/pgp/KeyStore;Ljava/lang/String;)Ljava/io/InputStream;
    //   14: astore 4
    //   16: iconst_0
    //   17: istore 11
    //   19: iload 11
    //   21: aload 6
    //   23: arraylength
    //   24: if_icmpge +23 -> 47
    //   27: aload 10
    //   29: iload 11
    //   31: aload_3
    //   32: aload 6
    //   34: iload 11
    //   36: aaload
    //   37: invokestatic 297\011com/didisoft/pgp/PGPLib:a\011(Lcom/didisoft/pgp/KeyStore;Ljava/lang/String;)Ljava/io/InputStream;
    //   40: aastore
    //   41: iinc 11 1
    //   44: goto -25 -> 19
    //   47: aload_0
    //   48: aload_1
    //   49: aload_2
    //   50: aload 4
    //   52: aload 5
    //   54: aload 10
    //   56: aload 7
    //   58: iload 8
    //   60: iload 9
    //   62: invokevirtual 382\011com/didisoft/pgp/PGPLib:signAndEncryptStream\011(Ljava/io/InputStream;Ljava/lang/String;Ljava/io/InputStream;Ljava/lang/String;[Ljava/io/InputStream;Ljava/io/OutputStream;ZZ)V
    //   65: return
    //   66: dup
    //   67: astore 4
    //   69: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   72: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   8\01165\01166\011lw/bouncycastle/openpgp/PGPException
  }

  // ERROR //
  public void signAndEncryptStream(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, long[] paramArrayOfLong, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException
  {
    // Byte code:
    //   0: aload 6
    //   2: arraylength
    //   3: anewarray 195\011java/io/InputStream
    //   6: astore 10
    //   8: aload_3
    //   9: aload 4
    //   11: invokestatic 327\011com/didisoft/pgp/PGPLib:b\011(Lcom/didisoft/pgp/KeyStore;Ljava/lang/String;)Ljava/io/InputStream;
    //   14: astore 4
    //   16: iconst_0
    //   17: istore 11
    //   19: iload 11
    //   21: aload 6
    //   23: arraylength
    //   24: if_icmpge +23 -> 47
    //   27: aload 10
    //   29: iload 11
    //   31: aload_3
    //   32: aload 6
    //   34: iload 11
    //   36: laload
    //   37: invokestatic 331\011com/didisoft/pgp/PGPLib:c\011(Lcom/didisoft/pgp/KeyStore;J)Ljava/io/InputStream;
    //   40: aastore
    //   41: iinc 11 1
    //   44: goto -25 -> 19
    //   47: aload_0
    //   48: aload_1
    //   49: aload_2
    //   50: aload 4
    //   52: aload 5
    //   54: aload 10
    //   56: aload 7
    //   58: iload 8
    //   60: iload 9
    //   62: invokevirtual 382\011com/didisoft/pgp/PGPLib:signAndEncryptStream\011(Ljava/io/InputStream;Ljava/lang/String;Ljava/io/InputStream;Ljava/lang/String;[Ljava/io/InputStream;Ljava/io/OutputStream;ZZ)V
    //   65: return
    //   66: dup
    //   67: astore 4
    //   69: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   72: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   8\01165\01166\011lw/bouncycastle/openpgp/PGPException
  }

  public void signAndEncryptFileVersion3(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean)
    throws PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    a("Signing and encrypting file {0}", paramString1);
    a("Output file is {0}", new File(paramString5).getAbsolutePath());
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString5), 1048576);
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFile");
      signAndEncryptStreamVersion3(localBufferedInputStream, new File(paramString1).getName(), localInputStream1, paramString3, localInputStream2, localBufferedOutputStream, paramBoolean, false);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      if ((n != 0) && ((paramString2 = new File(paramString5)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void signAndEncryptFileVersion3(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    BufferedOutputStream localBufferedOutputStream = null;
    a("Signing and encrypting file {0}", paramString1);
    a("Output file is {0}", new File(paramString5).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString5), 1048576);
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFile");
      signAndEncryptStreamVersion3(localBufferedInputStream, new File(paramString1).getName(), localInputStream1, paramString3, localInputStream2, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream2);
      if ((n != 0) && ((paramString2 = new File(paramString5)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void signAndEncryptStreamVersion3(InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, InputStream paramInputStream3, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    signAndEncryptStreamVersion3(paramInputStream1, paramString1, paramInputStream2, paramString2, paramInputStream3, paramOutputStream, paramBoolean);
  }

  public void signAndEncryptStreamVersion3(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, String paramString4, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    paramString4 = a(paramKeyStore, paramString4);
    paramKeyStore = b(paramKeyStore, paramString2);
    signAndEncryptStreamVersion3(paramInputStream, paramString1, paramKeyStore, paramString3, paramString4, paramOutputStream, paramBoolean);
  }

  public void signAndEncryptStreamVersion3(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, long paramLong1, String paramString2, long paramLong2, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException, PGPException, WrongPasswordException
  {
    paramLong2 = c(paramKeyStore, paramLong2);
    paramKeyStore = d(paramKeyStore, paramLong1);
    signAndEncryptStreamVersion3(paramInputStream, paramString1, paramKeyStore, paramString2, paramLong2, paramOutputStream, paramBoolean);
  }

  public void signAndEncryptStreamVersion3(InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, InputStream paramInputStream3, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException, PGPException, WrongPasswordException
  {
    if (!(paramOutputStream instanceof BufferedOutputStream))
      paramOutputStream = new BufferedOutputStream(paramOutputStream, 262144);
    paramInputStream3 = a(paramInputStream3);
    paramInputStream2 = b(paramInputStream2);
    if (paramBoolean1)
    {
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
      a(paramOutputStream);
    }
    int n = c(paramInputStream3);
    a("Encrypting with cypher {0}", KeyStore.c(n));
    paramBoolean2 = new PGPEncryptedDataGenerator(a.CreatePGPDataEncryptorBuilder(n, paramBoolean2, IOUtil.getSecureRandom()));
    OutputStream localOutputStream;
    try
    {
      paramBoolean2.addMethod(a.CreatePublicKeyKeyEncryptionMethodGenerator(paramInputStream3));
      localOutputStream = paramBoolean2.open(paramOutputStream, new byte[65536]);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
    {
      throw IOUtil.newPGPException(paramInputStream3 = localPGPException1);
    }
    paramInputStream3 = e(paramInputStream3);
    PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(paramInputStream3);
    paramString2 = extractPrivateKey(paramInputStream2, paramString2);
    int i1 = d(paramInputStream2.getPublicKey());
    a("Signing with hash {0}", KeyStore.c(i1));
    PGPSignatureGenerator localPGPSignatureGenerator = a.CreatePGPSignatureGenerator(paramInputStream2.getPublicKey().getAlgorithm(), i1);
    a.initSign(localPGPSignatureGenerator, 0, paramString2);
    if ((paramInputStream2 = paramInputStream2.getPublicKey().getUserIDs()).hasNext())
    {
      paramInputStream2 = (String)paramInputStream2.next();
      (paramString2 = new PGPSignatureSubpacketGenerator()).setSignerUserID(false, paramInputStream2);
      localPGPSignatureGenerator.setHashedSubpackets(paramString2.generate());
    }
    paramInputStream2 = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(262144);
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator();
    try
    {
      byte[] arrayOfByte = new byte[262144];
      while ((paramString2 = paramInputStream1.read(arrayOfByte)) >= 0)
      {
        localDirectByteArrayOutputStream.write(arrayOfByte, 0, paramString2);
        localPGPSignatureGenerator.update(arrayOfByte, 0, paramString2);
      }
      a("Signing data with OpenPGP version 3 signature; internal file name {0}", paramString1);
      if (paramInputStream3 == 0)
      {
        a("No Compression.");
        localPGPSignatureGenerator.generate().encode(localOutputStream);
        paramString2 = localPGPLiteralDataGenerator.open(localOutputStream, 'b', paramString1, new Date(), new byte[65536]);
      }
      else
      {
        a("Compression is {0}", KeyStore.a(paramInputStream3));
        paramInputStream2 = localPGPCompressedDataGenerator.open(localOutputStream, new byte[65536]);
        localPGPSignatureGenerator.generate().encode(paramInputStream2);
        paramString2 = localPGPLiteralDataGenerator.open(paramInputStream2, 'b', paramString1, new Date(), new byte[65536]);
      }
      paramString2.write(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
    {
      throw IOUtil.newPGPException(paramString2 = localPGPException2);
    }
    IOUtil.closeStream(paramString2);
    localPGPLiteralDataGenerator.close();
    IOUtil.closeStream(paramInputStream2);
    localPGPCompressedDataGenerator.close();
    IOUtil.closeStream(localOutputStream);
    paramBoolean2.close();
    IOUtil.closeStream(localDirectByteArrayOutputStream);
    IOUtil.closeStream(paramInputStream1);
    paramOutputStream.flush();
    if (paramBoolean1)
      IOUtil.closeStream(paramOutputStream);
  }

  public String signAndEncryptString(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    return signAndEncryptString(paramString1, paramString2, paramString3, paramString4, "UTF-8");
  }

  public String signAndEncryptStringVersion3(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    return signAndEncryptStringVersion3(paramString1, paramString2, paramString3, paramString4, "UTF-8");
  }

  public String signAndEncryptString(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    try
    {
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFileName");
      paramString2 = new DirectByteArrayOutputStream(1048576);
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString5));
      signAndEncryptStream(localByteArrayInputStream, "message.txt", localInputStream1, paramString3, localInputStream2, paramString2, true, false);
      paramString1 = new String(paramString2.getArray(), 0, paramString2.size(), "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
    }
    throw paramString1;
  }

  public String signAndEncryptStringVersion3(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    FileInputStream localFileInputStream1 = null;
    FileInputStream localFileInputStream2 = null;
    try
    {
      localFileInputStream1 = new FileInputStream(paramString2);
      localFileInputStream2 = new FileInputStream(paramString4);
      paramString2 = new DirectByteArrayOutputStream(262144);
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString5));
      signAndEncryptStreamVersion3(localByteArrayInputStream, "message.txt", localFileInputStream1, paramString3, localFileInputStream2, paramString2, true, false);
      paramString1 = new String(paramString2.getArray(), 0, paramString2.size(), "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localFileInputStream1);
      IOUtil.closeStream(localFileInputStream2);
    }
    throw paramString1;
  }

  public String decryptString(String paramString1, String paramString2, String paramString3)
    throws IOException, PGPException
  {
    return decryptString(paramString1, paramString2, paramString3, "UTF-8");
  }

  public String decryptString(String paramString1, String paramString2, String paramString3, String paramString4)
    throws IOException, PGPException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFileName");
      paramString1 = decryptString(paramString1, localInputStream, paramString3, paramString4);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String decryptString(String paramString1, InputStream paramInputStream, String paramString2)
    throws IOException, PGPException
  {
    return decryptString(paramString1, paramInputStream, paramString2, "UTF-8");
  }

  public String decryptString(String paramString1, KeyStore paramKeyStore, String paramString2)
    throws IOException, PGPException
  {
    return decryptString(paramString1, paramKeyStore, paramString2, "UTF-8");
  }

  public String decryptString(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws IOException, PGPException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes("ASCII"));
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      decryptStream(localByteArrayInputStream, paramKeyStore, paramString2, localDirectByteArrayOutputStream);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  public String decryptString(String paramString1, InputStream paramInputStream, String paramString2, String paramString3)
    throws IOException, PGPException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes("ASCII"));
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      decryptStream(localByteArrayInputStream, paramInputStream, paramString2, localDirectByteArrayOutputStream);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  public String decryptStream(InputStream paramInputStream1, InputStream paramInputStream2, String paramString, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    paramInputStream1 = new PGPObjectFactory2(paramInputStream1);
    Object localObject;
    try
    {
      localObject = paramInputStream1.nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((localObject instanceof PGPMarker))
    {
      a("Skipping PGP marker.");
      localObject = paramInputStream1.nextObject();
    }
    a locala = new a((byte)0);
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream1 = (PGPEncryptedDataList)localObject;
      paramInputStream1 = a(paramInputStream1, false, locala, null, paramInputStream2, paramString, null, paramOutputStream);
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      paramInputStream1 = a((PGPCompressedData)localObject, false, locala, null, null, paramOutputStream);
    }
    else if ((localObject instanceof PGPOnePassSignatureList))
    {
      paramInputStream1 = a((PGPOnePassSignatureList)localObject, paramInputStream1, null, null, paramOutputStream, locala);
    }
    else if ((localObject instanceof PGPSignatureList))
    {
      paramInputStream1 = a((PGPSignatureList)localObject, paramInputStream1, null, null, paramOutputStream, locala);
    }
    else if ((localObject instanceof PGPLiteralData))
    {
      paramInputStream1 = a((PGPLiteralData)localObject, null, paramOutputStream);
    }
    else
    {
      throw new NonPGPDataException("Unknown message format: " + localObject);
    }
    return paramInputStream1;
  }

  public String[] decryptStreamTo(InputStream paramInputStream1, InputStream paramInputStream2, String paramString1, String paramString2)
    throws PGPException, IOException
  {
    return a(paramInputStream1, paramInputStream2, paramString1, paramString2, null);
  }

  private String[] a(InputStream paramInputStream1, InputStream paramInputStream2, String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    a("Decrypting stream to folder {0}", new File(paramString2).getAbsolutePath());
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    paramInputStream1 = new PGPObjectFactory2(paramInputStream1);
    Object localObject;
    try
    {
      localObject = paramInputStream1.nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((localObject instanceof PGPMarker))
    {
      a("Skipping PGP marker.");
      localObject = paramInputStream1.nextObject();
    }
    a locala = new a((byte)0);
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream1 = (PGPEncryptedDataList)localObject;
      paramInputStream1 = a(paramInputStream1, false, locala, null, paramInputStream2, paramString1, null, paramString2, paramString3);
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      paramInputStream1 = a((PGPCompressedData)localObject, false, locala, null, null, paramString2, paramString3);
    }
    else if ((localObject instanceof PGPOnePassSignatureList))
    {
      paramInputStream1 = a((PGPOnePassSignatureList)localObject, paramInputStream1, null, null, paramString2, paramString3, locala);
    }
    else if ((localObject instanceof PGPSignatureList))
    {
      paramInputStream1 = a((PGPSignatureList)localObject, paramInputStream1, null, null, paramString2, paramString3, locala);
    }
    else if ((localObject instanceof PGPLiteralData))
    {
      paramInputStream1 = a((PGPLiteralData)localObject, null, paramString2, paramString3);
    }
    else
    {
      throw new NonPGPDataException("Unknown message format: " + localObject);
    }
    return paramInputStream1;
  }

  public String[] decryptStreamTo(InputStream paramInputStream, KeyStore paramKeyStore, String paramString1, String paramString2)
    throws PGPException, IOException
  {
    return a(paramInputStream, paramKeyStore, paramString1, paramString2, null);
  }

  private String[] a(InputStream paramInputStream, KeyStore paramKeyStore, String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    a("Decrypting stream to folder {0}", new File(paramString2).getAbsolutePath());
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory2(paramInputStream);
    Object localObject;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((localObject instanceof PGPMarker))
    {
      a("Skipping PGP marker.");
      localObject = paramInputStream.nextObject();
    }
    a locala = new a((byte)0);
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream = (PGPEncryptedDataList)localObject;
      paramInputStream = a(paramInputStream, false, locala, paramKeyStore, null, paramString1, null, paramString2, paramString3);
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      paramInputStream = a((PGPCompressedData)localObject, false, locala, null, null, paramString2, paramString3);
    }
    else if ((localObject instanceof PGPOnePassSignatureList))
    {
      paramInputStream = a((PGPOnePassSignatureList)localObject, paramInputStream, null, null, paramString2, paramString3, locala);
    }
    else if ((localObject instanceof PGPSignatureList))
    {
      paramInputStream = a((PGPSignatureList)localObject, paramInputStream, null, null, paramString2, paramString3, locala);
    }
    else if ((localObject instanceof PGPLiteralData))
    {
      paramInputStream = a((PGPLiteralData)localObject, null, paramString2, paramString3);
    }
    else
    {
      throw new NonPGPDataException("Unknown message format: " + localObject);
    }
    return paramInputStream;
  }

  public String decryptStream(InputStream paramInputStream, KeyStore paramKeyStore, String paramString, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory2(paramInputStream);
    Object localObject;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((localObject instanceof PGPMarker))
    {
      a("Skipping PGP marker.");
      localObject = paramInputStream.nextObject();
    }
    a locala = new a((byte)0);
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream = (PGPEncryptedDataList)localObject;
      paramInputStream = a(paramInputStream, false, locala, paramKeyStore, null, paramString, null, paramOutputStream);
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      paramInputStream = a((PGPCompressedData)localObject, false, locala, null, null, paramOutputStream);
    }
    else if ((localObject instanceof PGPLiteralData))
    {
      paramInputStream = a((PGPLiteralData)localObject, null, paramOutputStream);
    }
    else if ((localObject instanceof PGPOnePassSignatureList))
    {
      paramInputStream = a((PGPOnePassSignatureList)localObject, paramInputStream, null, null, paramOutputStream, locala);
    }
    else if ((localObject instanceof PGPSignatureList))
    {
      paramInputStream = a((PGPSignatureList)localObject, paramInputStream, null, null, paramOutputStream, locala);
    }
    else
    {
      throw new NonPGPDataException("Unknown message format: " + localObject);
    }
    return paramInputStream;
  }

  public String decryptFile(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    FileOutputStream localFileOutputStream = null;
    a("Decrypting file {0}", paramString1);
    a("Decrypting to {0}", new File(paramString3).getAbsolutePath());
    int n = 0;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localFileOutputStream = new FileOutputStream(paramString3);
      paramString1 = decryptStream(localFileInputStream, paramKeyStore, paramString2, localFileOutputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return paramString1;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString3)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public String decryptFile(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    a("Decrypting file {0}", paramString1);
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFileName");
      paramString1 = decryptFile(paramString1, localInputStream, paramString3, paramString4);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String decryptFilePBE(String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    a("Decrypting password encrypted file {0}", paramString1);
    a("Decrypting to {0}", new File(paramString3).getAbsolutePath());
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3));
      paramString1 = decryptStreamPBE(localBufferedInputStream, paramString2, localBufferedOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return paramString1;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString3)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public String decryptStringPBE(String paramString1, String paramString2)
    throws IOException, PGPException
  {
    return decryptStringPBE(paramString1, paramString2, "UTF-8");
  }

  public String decryptStringPBE(String paramString1, String paramString2, String paramString3)
    throws IOException, PGPException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes("ASCII"));
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      decryptStreamPBE(localByteArrayInputStream, paramString2, localDirectByteArrayOutputStream);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  public String decryptStreamPBE(InputStream paramInputStream, String paramString, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory2(paramInputStream);
    Object localObject;
    try
    {
      localObject = paramInputStream.nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((localObject instanceof PGPMarker))
      localObject = paramInputStream.nextObject();
    a locala = new a((byte)0);
    if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream = (PGPEncryptedDataList)localObject;
      paramInputStream = a(paramInputStream, false, locala, paramString, null, null, paramOutputStream);
    }
    else if ((localObject instanceof PGPCompressedData))
    {
      paramInputStream = a((PGPCompressedData)localObject, false, locala, null, null, paramOutputStream);
    }
    else if ((localObject instanceof PGPOnePassSignatureList))
    {
      paramInputStream = a((PGPOnePassSignatureList)localObject, paramInputStream, null, null, paramOutputStream, locala);
    }
    else if ((localObject instanceof PGPSignatureList))
    {
      paramInputStream = a((PGPSignatureList)localObject, paramInputStream, null, null, paramOutputStream, locala);
    }
    else if ((localObject instanceof PGPLiteralData))
    {
      paramInputStream = a((PGPLiteralData)localObject, null, paramOutputStream);
    }
    else
    {
      throw new NonPGPDataException("Unknown message format: " + localObject);
    }
    return paramInputStream;
  }

  public String[] decryptFileTo(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    a("Decrypting file {0}", paramString1);
    FileInputStream localFileInputStream = null;
    InputStream localInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFileName");
      paramString1 = a(localFileInputStream, localInputStream, paramString3, paramString4, paramString1);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String[] decryptFileTo(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    a("Decrypting file {0}", paramString1);
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      paramString1 = a(localFileInputStream, paramKeyStore, paramString2, paramString3, paramString1);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString1;
  }

  public String decryptFile(String paramString1, InputStream paramInputStream, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    a("Decrypting file {0}", paramString1);
    a("Decrypting to {0}", new File(paramString3).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3), 1048576);
      paramString1 = decryptStream(localBufferedInputStream, paramInputStream, paramString2, localBufferedOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramInputStream = new File(paramString3)).exists()))
        paramInputStream.delete();
    }
    throw paramString1;
  }

  public String encryptString(String paramString1, String paramString2)
    throws PGPException, IOException
  {
    return encryptString(paramString1, paramString2, "UTF-8");
  }

  public String encryptString(String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "publicKeyFileName");
      paramString1 = encryptString(paramString1, localInputStream, paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String encryptString(String paramString1, KeyStore paramKeyStore, String paramString2)
    throws PGPException, IOException
  {
    return encryptString(paramString1, paramKeyStore, paramString2, "UTF-8");
  }

  public String encryptString(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = a(paramKeyStore, paramString2);
      paramString1 = encryptString(paramString1, localInputStream, paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String encryptString(String paramString, KeyStore paramKeyStore, long paramLong)
    throws PGPException, IOException
  {
    return encryptString(paramString, paramKeyStore, paramLong, "UTF-8");
  }

  public String encryptString(String paramString1, KeyStore paramKeyStore, long paramLong, String paramString2)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = c(paramKeyStore, paramLong);
      paramString1 = encryptString(paramString1, localInputStream, paramString2);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String encryptString(String paramString, InputStream paramInputStream)
    throws PGPException, IOException
  {
    return encryptString(paramString, paramInputStream, "UTF-8");
  }

  public String encryptString(String paramString1, InputStream paramInputStream, String paramString2)
    throws PGPException, IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString2));
      encryptStream(localByteArrayInputStream, "message.txt", paramInputStream, localDirectByteArrayOutputStream, true, false);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
    }
    throw paramString1;
  }

  public String signString(String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFile");
      paramString1 = signString(paramString1, localInputStream, paramString3, "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String signString(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "privateKeyFile");
      paramString1 = signString(paramString1, localInputStream, paramString3, paramString4);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public String signString(String paramString1, InputStream paramInputStream, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString3));
      signStream(localByteArrayInputStream, "message.txt", paramInputStream, paramString2, localDirectByteArrayOutputStream, true);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
    }
    throw paramString1;
  }

  public String signString(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString4));
      signStream(localByteArrayInputStream, "message.txt", paramKeyStore, paramString2, paramString3, localDirectByteArrayOutputStream, true);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
    }
    throw paramString1;
  }

  public String signString(String paramString1, KeyStore paramKeyStore, long paramLong, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString3));
      signStream(localByteArrayInputStream, "message.txt", paramKeyStore, paramLong, paramString2, localDirectByteArrayOutputStream, true);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
    }
    throw paramString1;
  }

  public void encryptStream(InputStream paramInputStream, String paramString1, long paramLong, String paramString2, OutputStream paramOutputStream, boolean paramBoolean)
    throws PGPException, IOException
  {
    encryptStream(paramInputStream, paramString1, paramLong, paramString2, paramOutputStream, paramBoolean, false);
  }

  public void encryptStream(InputStream paramInputStream, String paramString1, long paramLong, String paramString2, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(new File(paramString2));
      encryptStream(paramInputStream, paramString1, paramLong, localFileInputStream, paramOutputStream, paramBoolean1, paramBoolean2);
      return;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramInputStream;
  }

  public void encryptStream(InputStream paramInputStream, String paramString1, KeyStore paramKeyStore, String paramString2, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    paramKeyStore = a(paramKeyStore, paramString2);
    try
    {
      encryptStream(paramInputStream, paramString1, paramKeyStore, paramOutputStream, paramBoolean1, paramBoolean2);
      return;
    }
    finally
    {
      IOUtil.closeStream(paramKeyStore);
      IOUtil.closeStream(paramInputStream);
    }
    throw paramString1;
  }

  public void encryptStream(InputStream paramInputStream, String paramString, KeyStore paramKeyStore, long paramLong, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 9
    //   3: new 170\011com/didisoft/pgp/bc/DirectByteArrayOutputStream
    //   6: dup
    //   7: ldc 3
    //   9: invokespecial 435\011com/didisoft/pgp/bc/DirectByteArrayOutputStream:<init>\011(I)V
    //   12: astore 10
    //   14: aload_3
    //   15: lload 4
    //   17: invokevirtual 287\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   20: astore_3
    //   21: aload_3
    //   22: aload 10
    //   24: invokevirtual 600\011lw/bouncycastle/openpgp/PGPPublicKeyRing:encode\011(Ljava/io/OutputStream;)V
    //   27: new 189\011java/io/ByteArrayInputStream
    //   30: dup
    //   31: aload 10
    //   33: invokevirtual 436\011com/didisoft/pgp/bc/DirectByteArrayOutputStream:getArray\011()[B
    //   36: iconst_0
    //   37: aload 10
    //   39: invokevirtual 437\011com/didisoft/pgp/bc/DirectByteArrayOutputStream:size\011()I
    //   42: invokespecial 468\011java/io/ByteArrayInputStream:<init>\011([BII)V
    //   45: astore 9
    //   47: new 170\011com/didisoft/pgp/bc/DirectByteArrayOutputStream
    //   50: dup
    //   51: ldc 3
    //   53: invokespecial 435\011com/didisoft/pgp/bc/DirectByteArrayOutputStream:<init>\011(I)V
    //   56: astore_3
    //   57: ldc 3
    //   59: newarray byte
    //   61: astore 5
    //   63: aload_1
    //   64: aload 5
    //   66: invokevirtual 486\011java/io/InputStream:read\011([B)I
    //   69: dup
    //   70: istore 4
    //   72: ifle +15 -> 87
    //   75: aload_3
    //   76: aload 5
    //   78: iconst_0
    //   79: iload 4
    //   81: invokevirtual 440\011com/didisoft/pgp/bc/DirectByteArrayOutputStream:write\011([BII)V
    //   84: goto -21 -> 63
    //   87: aload_0
    //   88: aload_1
    //   89: aload_2
    //   90: aload_3
    //   91: invokevirtual 437\011com/didisoft/pgp/bc/DirectByteArrayOutputStream:size\011()I
    //   94: i2l
    //   95: aload 9
    //   97: aload 6
    //   99: iload 7
    //   101: iload 8
    //   103: invokevirtual 364\011com/didisoft/pgp/PGPLib:encryptStream\011(Ljava/io/InputStream;Ljava/lang/String;JLjava/io/InputStream;Ljava/io/OutputStream;ZZ)V
    //   106: aload 9
    //   108: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   111: aload_1
    //   112: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   115: return
    //   116: astore_2
    //   117: aload 9
    //   119: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   122: aload_1
    //   123: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   126: aload_2
    //   127: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   21\011106\011116\011finally
  }

  public void encryptStream(InputStream paramInputStream1, String paramString, long paramLong, InputStream paramInputStream2, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: aload 5
    //   3: invokespecial 298\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/InputStream;)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   6: astore 5
    //   8: aload_0
    //   9: aload_1
    //   10: aload_2
    //   11: lload_3
    //   12: iconst_1
    //   13: anewarray 240\011lw/bouncycastle/openpgp/PGPPublicKey
    //   16: dup
    //   17: iconst_0
    //   18: aload 5
    //   20: aastore
    //   21: aload 6
    //   23: iload 7
    //   25: iload 8
    //   27: iconst_0
    //   28: istore_1
    //   29: istore 7
    //   31: istore 6
    //   33: astore 5
    //   35: astore 4
    //   37: lstore 13
    //   39: astore_3
    //   40: astore_2
    //   41: dup
    //   42: astore_1
    //   43: getfield 272\011com/didisoft/pgp/PGPLib:k\011Z
    //   46: ifeq +16 -> 62
    //   49: aload_1
    //   50: aload_2
    //   51: aload_3
    //   52: aload 4
    //   54: aload 5
    //   56: iload 6
    //   58: invokespecial 305\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/InputStream;Ljava/lang/String;[Llw/bouncycastle/openpgp/PGPPublicKey;Ljava/io/OutputStream;Z)V
    //   61: return
    //   62: aload 5
    //   64: instanceof 188
    //   67: ifne +16 -> 83
    //   70: new 188\011java/io/BufferedOutputStream
    //   73: dup
    //   74: aload 5
    //   76: ldc 3
    //   78: invokespecial 466\011java/io/BufferedOutputStream:<init>\011(Ljava/io/OutputStream;I)V
    //   81: astore 5
    //   83: iload 6
    //   85: ifeq +30 -> 115
    //   88: aload_1
    //   89: ldc 77
    //   91: invokespecial 308\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;)V
    //   94: aload 5
    //   96: astore 5
    //   98: new 224\011lw/bouncycastle/bcpg/ArmoredOutputStream
    //   101: dup
    //   102: aload 5
    //   104: invokespecial 549\011lw/bouncycastle/bcpg/ArmoredOutputStream:<init>\011(Ljava/io/OutputStream;)V
    //   107: astore 5
    //   109: aload_1
    //   110: aload 5
    //   112: invokespecial 306\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/OutputStream;)V
    //   115: aload_1
    //   116: getfield 265\011com/didisoft/pgp/PGPLib:d\011Ljava/lang/String;
    //   119: invokestatic 288\011com/didisoft/pgp/KeyStore:b\011(Ljava/lang/String;)I
    //   122: istore 8
    //   124: aload_1
    //   125: getfield 264\011com/didisoft/pgp/PGPLib:c\011Ljava/lang/String;
    //   128: invokestatic 290\011com/didisoft/pgp/KeyStore:c\011(Ljava/lang/String;)I
    //   131: istore 9
    //   133: aload 4
    //   135: arraylength
    //   136: iconst_1
    //   137: if_icmpne +45 -> 182
    //   140: aload_1
    //   141: aload 4
    //   143: iconst_0
    //   144: aaload
    //   145: invokespecial 356\011com/didisoft/pgp/PGPLib:e\011(Llw/bouncycastle/openpgp/PGPPublicKey;)I
    //   148: istore 8
    //   150: aload_1
    //   151: aload 4
    //   153: iconst_0
    //   154: aaload
    //   155: invokespecial 332\011com/didisoft/pgp/PGPLib:c\011(Llw/bouncycastle/openpgp/PGPPublicKey;)I
    //   158: istore 9
    //   160: aload_1
    //   161: ldc 54
    //   163: iload 9
    //   165: invokestatic 289\011com/didisoft/pgp/KeyStore:c\011(I)Ljava/lang/String;
    //   168: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   171: aload_1
    //   172: ldc 28
    //   174: iload 8
    //   176: invokestatic 283\011com/didisoft/pgp/KeyStore:a\011(I)Ljava/lang/String;
    //   179: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   182: aconst_null
    //   183: astore 10
    //   185: aconst_null
    //   186: astore 11
    //   188: new 229\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator
    //   191: dup
    //   192: aload_1
    //   193: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   196: iload 9
    //   198: iload 7
    //   200: invokestatic 445\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   203: invokevirtual 422\011com/didisoft/pgp/bc/BCFactory:CreatePGPDataEncryptorBuilder\011(IZLjava/security/SecureRandom;)Llw/bouncycastle/openpgp/operator/PGPDataEncryptorBuilder;
    //   206: invokespecial 560\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:<init>\011(Llw/bouncycastle/openpgp/operator/PGPDataEncryptorBuilder;)V
    //   209: astore 7
    //   211: iconst_0
    //   212: istore 9
    //   214: iload 9
    //   216: aload 4
    //   218: arraylength
    //   219: if_icmpge +43 -> 262
    //   222: aload_1
    //   223: ldc 55
    //   225: aload 4
    //   227: iload 9
    //   229: aaload
    //   230: invokevirtual 589\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   233: invokestatic 282\011com/didisoft/pgp/KeyPairInformation:keyId2Hex\011(J)Ljava/lang/String;
    //   236: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   239: aload 7
    //   241: aload_1
    //   242: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   245: aload 4
    //   247: iload 9
    //   249: aaload
    //   250: invokevirtual 428\011com/didisoft/pgp/bc/BCFactory:CreatePublicKeyKeyEncryptionMethodGenerator\011(Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/operator/PublicKeyKeyEncryptionMethodGenerator;
    //   253: invokevirtual 561\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:addMethod\011(Llw/bouncycastle/openpgp/operator/PGPKeyEncryptionMethodGenerator;)V
    //   256: iinc 9 1
    //   259: goto -45 -> 214
    //   262: aload 7
    //   264: aload 5
    //   266: ldc 3
    //   268: newarray byte
    //   270: invokevirtual 564\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:open\011(Ljava/io/OutputStream;[B)Ljava/io/OutputStream;
    //   273: astore 11
    //   275: new 227\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator
    //   278: dup
    //   279: iload 8
    //   281: invokespecial 555\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:<init>\011(I)V
    //   284: astore 9
    //   286: iload 8
    //   288: ifne +26 -> 314
    //   291: aload 11
    //   293: aload_1
    //   294: invokevirtual 374\011com/didisoft/pgp/PGPLib:getContentType\011()C
    //   297: aload_2
    //   298: aload_3
    //   299: lload 13
    //   301: new 217\011java/util/Date
    //   304: dup
    //   305: invokespecial 540\011java/util/Date:<init>\011()V
    //   308: invokestatic 307\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/OutputStream;CLjava/io/InputStream;Ljava/lang/String;JLjava/util/Date;)V
    //   311: goto +31 -> 342
    //   314: aload 9
    //   316: aload 11
    //   318: invokevirtual 557\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:open\011(Ljava/io/OutputStream;)Ljava/io/OutputStream;
    //   321: dup
    //   322: astore 10
    //   324: aload_1
    //   325: invokevirtual 374\011com/didisoft/pgp/PGPLib:getContentType\011()C
    //   328: aload_2
    //   329: aload_3
    //   330: lload 13
    //   332: new 217\011java/util/Date
    //   335: dup
    //   336: invokespecial 540\011java/util/Date:<init>\011()V
    //   339: invokestatic 307\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/OutputStream;CLjava/io/InputStream;Ljava/lang/String;JLjava/util/Date;)V
    //   342: aload 10
    //   344: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   347: aload 11
    //   349: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   352: aload 5
    //   354: invokevirtual 490\011java/io/OutputStream:flush\011()V
    //   357: iload 6
    //   359: ifeq +8 -> 367
    //   362: aload 5
    //   364: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   367: goto +42 -> 409
    //   370: dup
    //   371: astore 7
    //   373: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   376: athrow
    //   377: astore_1
    //   378: aload 10
    //   380: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   383: aload 11
    //   385: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   388: aload 5
    //   390: invokevirtual 490\011java/io/OutputStream:flush\011()V
    //   393: iload 6
    //   395: ifeq +8 -> 403
    //   398: aload 5
    //   400: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   403: aload_1
    //   404: athrow
    //   405: dup
    //   406: astore 5
    //   408: athrow
    //   409: return
    //
    // Exception table:
    //   from\011to\011target\011type
    //   188\011342\011370\011lw/bouncycastle/openpgp/PGPException
    //   188\011342\011377\011finally
    //   370\011378\011377\011finally
    //   62\011405\011405\011java/io/IOException
  }

  public void encryptStream(InputStream paramInputStream1, String paramString, InputStream paramInputStream2, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    try
    {
      paramInputStream2 = a(paramInputStream2);
      a(paramInputStream1, paramString, new PGPPublicKey[] { paramInputStream2 }, paramOutputStream, new Date(), paramBoolean1, paramBoolean2, false);
      return;
    }
    finally
    {
      IOUtil.closeStream(paramInputStream1);
    }
    throw paramString;
  }

  public void encryptStream(InputStream paramInputStream, String paramString, PGPKeyPair paramPGPKeyPair, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    try
    {
      Object localObject1 = paramPGPKeyPair.getRawPublicKeyRing();
      paramPGPKeyPair = this;
      Object localObject2 = null;
      localObject1 = ((PGPPublicKeyRing)localObject1).getPublicKeys();
      while ((localObject2 == null) && (((Iterator)localObject1).hasNext()))
      {
        PGPPublicKey localPGPPublicKey;
        if ((localPGPPublicKey = (PGPPublicKey)((Iterator)localObject1).next()).isEncryptionKey())
          localObject2 = localPGPPublicKey;
      }
      if (localObject2 == null)
        throw new NoPublicKeyFoundException("Can't find encryption key in key ring.");
      paramPGPKeyPair.a(localObject2);
      paramPGPKeyPair.b(localObject2);
      paramPGPKeyPair = localObject2;
      a(paramInputStream, paramString, new PGPPublicKey[] { paramPGPKeyPair }, paramOutputStream, new Date(), paramBoolean1, paramBoolean2, false);
      return;
    }
    finally
    {
      IOUtil.closeStream(paramInputStream);
    }
    throw paramString;
  }

  public String encryptStringPBE(String paramString1, String paramString2)
    throws PGPException, IOException
  {
    return encryptStringPBE(paramString1, paramString2, "UTF-8");
  }

  public String encryptStringPBE(String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString3));
      encryptStreamPBE(localByteArrayInputStream, "message.txt", paramString2, localDirectByteArrayOutputStream, true, false);
      paramString1 = new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), "UTF-8");
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
    }
    throw paramString1;
  }

  public void encryptStreamPBE(InputStream paramInputStream, String paramString1, String paramString2, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    try
    {
      a(paramInputStream, paramString1, paramString2, paramOutputStream, paramBoolean1, paramBoolean2);
      return;
    }
    finally
    {
      IOUtil.closeStream(paramInputStream);
    }
    throw paramString1;
  }

  public void encryptFilePBE(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    Object localObject = new File(paramString1);
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    a("Password encrypting file {0}", paramString1);
    a("Encrypting to {0}", new File(paramString4).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString4), 1048576);
      localInputStream = readFileOrAsciiString(paramString2, "publicKeyFileName");
      paramString1 = a(localInputStream);
      boolean bool2 = paramBoolean2;
      boolean bool1 = paramBoolean1;
      localObject = localBufferedOutputStream;
      paramBoolean2 = paramString3;
      paramBoolean1 = paramString1;
      long l1 = ((File)localObject).length();
      paramString3 = ((File)localObject).getName();
      paramString2 = localBufferedInputStream;
      paramString1 = this;
      if (!(localObject instanceof BufferedOutputStream))
        localObject = new BufferedOutputStream((OutputStream)localObject, 1048576);
      try
      {
        if (bool1)
        {
          localObject = localObject;
          localObject = new ArmoredOutputStream((OutputStream)localObject);
          paramString1.a((OutputStream)localObject);
        }
        OutputStream localOutputStream = null;
        try
        {
          int i1 = paramString1.e(paramBoolean1);
          PGPCompressedDataGenerator localPGPCompressedDataGenerator = new PGPCompressedDataGenerator(i1);
          int i2 = paramString1.c(paramBoolean1);
          PGPEncryptedDataGenerator localPGPEncryptedDataGenerator;
          (localPGPEncryptedDataGenerator = paramString1.a.CreatePGPEncryptedDataGenerator(i2, bool2, IOUtil.getSecureRandom())).addMethod(paramString1.a.CreatePublicKeyKeyEncryptionMethodGenerator(paramBoolean1));
          paramString1.a("Encrypting with key {0} ", KeyPairInformation.keyId2Hex(paramBoolean1.getKeyID()));
          localPGPEncryptedDataGenerator.addMethod(paramString1.a.CreatePBEKeyEncryptionMethodGenerator(paramBoolean2));
          paramString1.a("Encrypting with password");
          localOutputStream = localPGPEncryptedDataGenerator.open((OutputStream)localObject, new byte[1048576]);
          if (i1 == 0)
            a(localOutputStream, paramString1.getContentType(), paramString2, paramString3, l1, new Date());
          else
            a(localPGPCompressedDataGenerator.open(localOutputStream), paramString1.getContentType(), paramString2, paramString3, l1, new Date());
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
        {
        }
        finally
        {
          lw.bouncycastle.openpgp.PGPException localPGPException1;
          IOUtil.closeStream(null);
          IOUtil.closeStream(localOutputStream);
          ((OutputStream)localObject).flush();
          if (bool1)
            IOUtil.closeStream((OutputStream)localObject);
        }
      }
      catch (IOException localIOException)
      {
        throw new PGPException(localIOException.getMessage(), localIOException);
      }
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString4)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void encryptFilePBE(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    File localFile = new File(paramString1);
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    a("Password encrypting file {0}", paramString1);
    a("Encrypting to {0}", new File(paramString3).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3), 1048576);
      a(localBufferedInputStream, localFile.getName(), paramString2, localBufferedOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(null);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(null);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString3)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public void encryptFile(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
    throws PGPException, IOException
  {
    encryptFile(paramString1, paramString2, paramString3, paramBoolean, false);
  }

  public void encryptFile(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString2, "publicKeyFileName");
      encryptFile(paramString1, localInputStream, paramString3, paramBoolean1, paramBoolean2);
      return;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public void encryptFile(String paramString1, String[] paramArrayOfString, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting file {0}", paramString1);
    a("Encrypting to {0}", new File(paramString2).getAbsolutePath());
    LinkedList localLinkedList = new LinkedList();
    InputStream localInputStream = null;
    int i1 = 0;
    while (i1 < paramArrayOfString.length)
      try
      {
        localInputStream = readFileOrAsciiString(paramArrayOfString[i1], "publicKeysFileNames :" + i1);
        localObject = a(localInputStream);
        localLinkedList.add(localObject);
        IOUtil.closeStream(localInputStream);
      }
      finally
      {
        IOUtil.closeStream(localInputStream);
      }
    PGPPublicKey[] arrayOfPGPPublicKey = (PGPPublicKey[])localLinkedList.toArray(new PGPPublicKey[localLinkedList.size()]);
    Object localObject = null;
    paramArrayOfString = null;
    int n = 0;
    try
    {
      paramString1 = new File(paramString1);
      localObject = new FileInputStream(paramString1);
      paramArrayOfString = new FileOutputStream(paramString2);
      a((InputStream)localObject, paramString1.getName(), arrayOfPGPPublicKey, paramArrayOfString, new Date(paramString1.lastModified()), paramBoolean1, paramBoolean2, false);
      IOUtil.closeStream((InputStream)localObject);
      IOUtil.closeStream(paramArrayOfString);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      n = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream((InputStream)localObject);
      IOUtil.closeStream(paramArrayOfString);
      if ((n != 0) && ((paramArrayOfString = new File(paramString2)).exists()))
        paramArrayOfString.delete();
    }
    throw paramString1;
  }

  public void encryptFile(String paramString1, KeyStore paramKeyStore, String[] paramArrayOfString, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting file {0}", paramString1);
    a("Encrypting to {0}", new File(paramString2).getAbsolutePath());
    LinkedList localLinkedList = new LinkedList();
    InputStream localInputStream = null;
    int n = 0;
    while (n < paramArrayOfString.length)
      try
      {
        localInputStream = a(paramKeyStore, paramArrayOfString[n]);
        localObject = a(localInputStream);
        localLinkedList.add(localObject);
        IOUtil.closeStream(localInputStream);
      }
      finally
      {
        IOUtil.closeStream(localInputStream);
      }
    PGPPublicKey[] arrayOfPGPPublicKey = (PGPPublicKey[])localLinkedList.toArray(new PGPPublicKey[localLinkedList.size()]);
    Object localObject = null;
    paramKeyStore = null;
    paramArrayOfString = 0;
    try
    {
      paramString1 = new File(paramString1);
      localObject = new FileInputStream(paramString1);
      paramKeyStore = new FileOutputStream(paramString2);
      a((InputStream)localObject, paramString1.getName(), arrayOfPGPPublicKey, paramKeyStore, new Date(paramString1.lastModified()), paramBoolean1, paramBoolean2, false);
      IOUtil.closeStream((InputStream)localObject);
      IOUtil.closeStream(paramKeyStore);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      paramArrayOfString = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      paramArrayOfString = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream((InputStream)localObject);
      IOUtil.closeStream(paramKeyStore);
      if ((paramArrayOfString != 0) && ((paramKeyStore = new File(paramString2)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void encryptFile(String paramString1, KeyStore paramKeyStore, long[] paramArrayOfLong, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting file {0}", paramString1);
    a("Encrypting to {0}", new File(paramString2).getAbsolutePath());
    LinkedList localLinkedList = new LinkedList();
    InputStream localInputStream = null;
    int n = 0;
    while (n < paramArrayOfLong.length)
      try
      {
        localInputStream = c(paramKeyStore, paramArrayOfLong[n]);
        localObject = a(localInputStream);
        localLinkedList.add(localObject);
        IOUtil.closeStream(localInputStream);
      }
      finally
      {
        IOUtil.closeStream(localInputStream);
      }
    PGPPublicKey[] arrayOfPGPPublicKey = (PGPPublicKey[])localLinkedList.toArray(new PGPPublicKey[localLinkedList.size()]);
    Object localObject = null;
    paramKeyStore = null;
    paramArrayOfLong = 0;
    try
    {
      paramString1 = new File(paramString1);
      localObject = new FileInputStream(paramString1);
      paramKeyStore = new FileOutputStream(paramString2);
      a((InputStream)localObject, paramString1.getName(), arrayOfPGPPublicKey, paramKeyStore, new Date(paramString1.lastModified()), paramBoolean1, paramBoolean2, false);
      IOUtil.closeStream((InputStream)localObject);
      IOUtil.closeStream(paramKeyStore);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramString1)
    {
      paramArrayOfLong = 1;
      throw IOUtil.newPGPException(paramString1);
    }
    catch (IOException paramString1)
    {
      paramArrayOfLong = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream((InputStream)localObject);
      IOUtil.closeStream(paramKeyStore);
      if ((paramArrayOfLong != 0) && ((paramKeyStore = new File(paramString2)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void encryptFiles(String[] paramArrayOfString, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    encryptFiles(paramArrayOfString, new String[] { paramString1 }, paramString2, paramBoolean1, paramBoolean2);
  }

  public void encryptFiles(String[] paramArrayOfString1, String[] paramArrayOfString2, String paramString, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting multiple files");
    a("Encrypting to {0}", new File(paramString).getAbsolutePath());
    if (paramArrayOfString1.length == 0)
      throw new IllegalArgumentException("Please specify at least one file to be encrypted.");
    Object localObject1 = new LinkedList();
    Object localObject2 = null;
    int n = 0;
    while (n < paramArrayOfString2.length)
      try
      {
        localObject2 = readFileOrAsciiString(paramArrayOfString2[n], "publicKeysFileNames :" + n);
        localObject3 = a((InputStream)localObject2);
        ((List)localObject1).add(localObject3);
        IOUtil.closeStream((InputStream)localObject2);
      }
      finally
      {
        IOUtil.closeStream((InputStream)localObject2);
      }
    PGPPublicKey[] arrayOfPGPPublicKey = (PGPPublicKey[])((List)localObject1).toArray(new PGPPublicKey[((List)localObject1).size()]);
    Object localObject3 = null;
    paramArrayOfString2 = 0;
    localObject1 = paramArrayOfString1[0];
    if (paramArrayOfString1.length > 1)
    {
      localObject3 = a(paramArrayOfString1);
      paramArrayOfString2 = 1;
      localObject1 = ((File)localObject3).getAbsolutePath();
    }
    paramArrayOfString1 = null;
    localObject2 = null;
    int i1 = 0;
    char c1 = i;
    try
    {
      localObject1 = new File((String)localObject1);
      paramArrayOfString1 = new BufferedInputStream(new FileInputStream((File)localObject1), 1048576);
      localObject2 = new BufferedOutputStream(new FileOutputStream(paramString), 1048576);
      if (paramArrayOfString2 != 0)
        i = 'b';
      a(paramArrayOfString1, ((File)localObject1).getName(), arrayOfPGPPublicKey, (OutputStream)localObject2, new Date(((File)localObject1).lastModified()), paramBoolean1, paramBoolean2, paramArrayOfString2);
      i = c1;
      IOUtil.closeStream(paramArrayOfString1);
      IOUtil.closeStream((OutputStream)localObject2);
      if (localObject3 != null)
        ((File)localObject3).delete();
      return;
    }
    catch (PGPException paramArrayOfString2)
    {
      i1 = 1;
      throw paramArrayOfString2;
    }
    catch (IOException paramArrayOfString2)
    {
      i1 = 1;
      throw paramArrayOfString2;
    }
    finally
    {
      i = c1;
      IOUtil.closeStream(paramArrayOfString1);
      IOUtil.closeStream((OutputStream)localObject2);
      if (localObject3 != null)
        ((File)localObject3).delete();
      if ((i1 != 0) && ((paramArrayOfString1 = new File(paramString)).exists()))
        paramArrayOfString1.delete();
    }
    throw paramArrayOfString2;
  }

  public void encryptFiles(String[] paramArrayOfString1, KeyStore paramKeyStore, String[] paramArrayOfString2, String paramString, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting multiple files");
    a("Encrypting to {0}", new File(paramString).getAbsolutePath());
    if (paramArrayOfString1.length == 0)
      throw new IllegalArgumentException("please specify at least one file name to be encrypted.");
    Object localObject1 = new LinkedList();
    InputStream localInputStream = null;
    int i1 = 0;
    while (i1 < paramArrayOfString2.length)
      try
      {
        localInputStream = a(paramKeyStore, paramArrayOfString2[i1]);
        localObject2 = a(localInputStream);
        ((List)localObject1).add(localObject2);
        IOUtil.closeStream(localInputStream);
      }
      finally
      {
        IOUtil.closeStream(localInputStream);
      }
    PGPPublicKey[] arrayOfPGPPublicKey = (PGPPublicKey[])((List)localObject1).toArray(new PGPPublicKey[((List)localObject1).size()]);
    Object localObject2 = null;
    paramKeyStore = 0;
    paramArrayOfString2 = paramArrayOfString1[0];
    if (paramArrayOfString1.length > 1)
    {
      localObject2 = a(paramArrayOfString1);
      paramKeyStore = 1;
      paramArrayOfString2 = ((File)localObject2).getAbsolutePath();
    }
    paramArrayOfString1 = null;
    localObject1 = null;
    int n = 0;
    char c1 = i;
    try
    {
      paramArrayOfString2 = new File(paramArrayOfString2);
      paramArrayOfString1 = new BufferedInputStream(new FileInputStream(paramArrayOfString2), 1048576);
      localObject1 = new BufferedOutputStream(new FileOutputStream(paramString), 1048576);
      if (paramKeyStore != 0)
        i = 'b';
      a(paramArrayOfString1, paramArrayOfString2.getName(), arrayOfPGPPublicKey, (OutputStream)localObject1, new Date(paramArrayOfString2.lastModified()), paramBoolean1, paramBoolean2, paramKeyStore);
      i = c1;
      IOUtil.closeStream(paramArrayOfString1);
      IOUtil.closeStream((OutputStream)localObject1);
      if (localObject2 != null)
        ((File)localObject2).delete();
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramKeyStore)
    {
      n = 1;
      throw IOUtil.newPGPException(paramKeyStore);
    }
    catch (IOException paramKeyStore)
    {
      n = 1;
      throw paramKeyStore;
    }
    finally
    {
      i = c1;
      IOUtil.closeStream(paramArrayOfString1);
      IOUtil.closeStream((OutputStream)localObject1);
      if (localObject2 != null)
        ((File)localObject2).delete();
      if ((n != 0) && ((paramArrayOfString1 = new File(paramString)).exists()))
        paramArrayOfString1.delete();
    }
    throw paramKeyStore;
  }

  public void encryptFiles(String[] paramArrayOfString, KeyStore paramKeyStore, long[] paramArrayOfLong, String paramString, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting multiple files");
    a("Encrypting to {0}", new File(paramString).getAbsolutePath());
    if (paramArrayOfString.length == 0)
      throw new IllegalArgumentException("please specify at least one file name to be encrypted.");
    Object localObject1 = new LinkedList();
    InputStream localInputStream = null;
    int i1 = 0;
    while (i1 < paramArrayOfLong.length)
      try
      {
        localInputStream = c(paramKeyStore, paramArrayOfLong[i1]);
        localObject2 = a(localInputStream);
        ((List)localObject1).add(localObject2);
        IOUtil.closeStream(localInputStream);
      }
      finally
      {
        IOUtil.closeStream(localInputStream);
      }
    PGPPublicKey[] arrayOfPGPPublicKey = (PGPPublicKey[])((List)localObject1).toArray(new PGPPublicKey[((List)localObject1).size()]);
    Object localObject2 = null;
    paramKeyStore = 0;
    paramArrayOfLong = paramArrayOfString[0];
    if (paramArrayOfString.length > 1)
    {
      localObject2 = a(paramArrayOfString);
      paramKeyStore = 1;
      paramArrayOfLong = ((File)localObject2).getAbsolutePath();
    }
    paramArrayOfString = null;
    localObject1 = null;
    int n = 0;
    char c1 = i;
    try
    {
      paramArrayOfLong = new File(paramArrayOfLong);
      paramArrayOfString = new BufferedInputStream(new FileInputStream(paramArrayOfLong), 1048576);
      localObject1 = new BufferedOutputStream(new FileOutputStream(paramString), 1048576);
      if (paramKeyStore != 0)
        i = 'b';
      a(paramArrayOfString, paramArrayOfLong.getName(), arrayOfPGPPublicKey, (OutputStream)localObject1, new Date(paramArrayOfLong.lastModified()), paramBoolean1, paramBoolean2, paramKeyStore);
      i = c1;
      IOUtil.closeStream(paramArrayOfString);
      IOUtil.closeStream((OutputStream)localObject1);
      if (localObject2 != null)
        ((File)localObject2).delete();
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException paramKeyStore)
    {
      n = 1;
      throw IOUtil.newPGPException(paramKeyStore);
    }
    catch (IOException paramKeyStore)
    {
      n = 1;
      throw paramKeyStore;
    }
    finally
    {
      i = c1;
      IOUtil.closeStream(paramArrayOfString);
      IOUtil.closeStream((OutputStream)localObject1);
      if (localObject2 != null)
        ((File)localObject2).delete();
      if ((n != 0) && ((paramArrayOfString = new File(paramString)).exists()))
        paramArrayOfString.delete();
    }
    throw paramKeyStore;
  }

  public void encryptFile(String paramString1, InputStream paramInputStream, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting file {0}", paramString1);
    a("Encrypting to {0}", new File(paramString2).getAbsolutePath());
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    int n = 0;
    try
    {
      paramString1 = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString2), 1048576);
      paramInputStream = a(paramInputStream);
      a(localBufferedInputStream, paramString1.getName(), new PGPPublicKey[] { paramInputStream }, localBufferedOutputStream, new Date(paramString1.lastModified()), paramBoolean1, paramBoolean2, false);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return;
    }
    catch (PGPException paramInputStream)
    {
      n = 1;
      throw paramInputStream;
    }
    catch (IOException paramInputStream)
    {
      n = 1;
      throw paramInputStream;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramInputStream = new File(paramString2)).exists()))
        paramInputStream.delete();
    }
    throw paramString1;
  }

  /** @deprecated */
  public int encryptFileByUserId(KeyStore paramKeyStore, String paramString1, String paramString2, String paramString3)
  {
    try
    {
      encryptFile(paramString1, paramKeyStore, paramString2, paramString3);
    }
    catch (Exception localException)
    {
      return 1;
    }
    return 0;
  }

  public void encryptFile(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    a("Encrypting file {0}", paramString1);
    a("Encrypting to {0}", new File(paramString3).getAbsolutePath());
    paramKeyStore = a(paramKeyStore, paramString2);
    paramString2 = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      File localFile = new File(paramString1);
      paramString2 = new FileInputStream(paramString1);
      localFileOutputStream = new FileOutputStream(paramString3);
      encryptStream(paramString2, localFile.getName(), paramKeyStore, localFileOutputStream, paramBoolean1, paramBoolean2);
      IOUtil.closeStream(paramString2);
      IOUtil.closeStream(localFileOutputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      n = 1;
      throw IOUtil.newPGPException(localPGPException);
    }
    catch (IOException localIOException)
    {
      n = 1;
      throw localIOException;
    }
    finally
    {
      IOUtil.closeStream(paramString2);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString3)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void encryptFile(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    encryptFile(paramString1, paramKeyStore, paramString2, paramString3, false, false);
  }

  /** @deprecated */
  public int encryptFileByKeyId(KeyStore paramKeyStore, String paramString1, String paramString2, String paramString3)
  {
    try
    {
      encryptFile(paramString1, paramKeyStore, Long.decode(paramString2).longValue(), paramString3);
    }
    catch (Exception localException)
    {
      return 0;
    }
    return 1;
  }

  public void encryptFile(String paramString1, KeyStore paramKeyStore, long paramLong, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    InputStream localInputStream = null;
    a("Encrypting file {0}", new File(paramString1).getAbsolutePath());
    a("Encrypting to {0}", new File(paramString2).getAbsolutePath());
    int n = 0;
    try
    {
      File localFile = new File(paramString1);
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString2), 1048576);
      localInputStream = c(paramKeyStore, paramLong);
      paramString1 = a(localInputStream);
      a(localBufferedInputStream, localFile.getName(), new PGPPublicKey[] { paramString1 }, localBufferedOutputStream, new Date(localFile.lastModified()), paramBoolean1, paramBoolean2, false);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream);
      return;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      n = 1;
      throw IOUtil.newPGPException(localPGPException);
    }
    catch (IOException localIOException)
    {
      n = 1;
      throw localIOException;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      IOUtil.closeStream(localInputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString2)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public void encryptFile(String paramString1, KeyStore paramKeyStore, long paramLong, String paramString2)
    throws PGPException, IOException
  {
    encryptFile(paramString1, paramKeyStore, paramLong, paramString2, false, false);
  }

  /** @deprecated */
  public boolean verifyFile(String paramString1, String paramString2, String paramString3)
    throws PGPException, FileIsEncryptedException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    a("Signature verification of file {0}", paramString1);
    a("Extracting to {0}", new File(paramString3).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localInputStream = readFileOrAsciiString(paramString2, "publicKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3), 1048576);
      paramString1 = verifyStream(localBufferedInputStream, localInputStream, localBufferedOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString3)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean verifyFile(String paramString1, KeyStore paramKeyStore, String paramString2)
    throws PGPException, FileIsEncryptedException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    FileOutputStream localFileOutputStream = null;
    a("Signature verification of file {0}", paramString1);
    a("Extracting to {0}", new File(paramString2).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      localFileOutputStream = new FileOutputStream(paramString2);
      paramString1 = verifyStream(localBufferedInputStream, paramKeyStore, localFileOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString2)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean verifyFile(String paramString1, String paramString2)
    throws PGPException, FileIsEncryptedException, IOException
  {
    a("Signature verification of file {0}", paramString1);
    FileInputStream localFileInputStream = null;
    InputStream localInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localInputStream = readFileOrAsciiString(paramString2, "publicKeyFileName");
      paramString1 = verifyStream(localFileInputStream, localInputStream);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean verifyFile(InputStream paramInputStream1, InputStream paramInputStream2)
    throws PGPException, IOException
  {
    return verifyStream(paramInputStream1, paramInputStream2);
  }

  public SignatureCheckResult verifyWithoutExtracting(InputStream paramInputStream1, InputStream paramInputStream2)
    throws PGPException, FileIsEncryptedException, IOException
  {
    if ((((paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1)) instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream1).isClearText()))
      return (paramInputStream1 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject, null, paramInputStream2, new DummyStream());
    Object localObject = new PGPObjectFactory2(paramInputStream1);
    try
    {
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((paramInputStream1 instanceof PGPMarker))
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream1 instanceof PGPEncryptedDataList))
      throw new FileIsEncryptedException("This file is encrypted. Use the methods <decryptAndVerifySignature> or <decrypt> to open it.");
    if ((paramInputStream1 instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream1, true, locala, null, paramInputStream2, new DummyStream());
    else if ((paramInputStream1 instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream2, new DummyStream(), locala);
    else if ((paramInputStream1 instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream2, new DummyStream(), locala);
    else if ((paramInputStream1 instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream1, null, new DummyStream());
    else
      throw new NonPGPDataException("Unknown message format: " + paramInputStream1.getClass());
    return locala.a;
  }

  public SignatureCheckResult verifyWithoutExtracting(InputStream paramInputStream1, InputStream paramInputStream2, String paramString, InputStream paramInputStream3)
    throws PGPException, FileIsEncryptedException, IOException
  {
    if ((((paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1)) instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream1).isClearText()))
      return (paramInputStream1 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject, null, paramInputStream3, new DummyStream());
    Object localObject = new PGPObjectFactory2(paramInputStream1);
    try
    {
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((paramInputStream1 instanceof PGPMarker))
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream1 instanceof PGPEncryptedDataList))
      a((PGPEncryptedDataList)paramInputStream1, true, locala, null, paramInputStream2, paramString, paramInputStream3, new DummyStream());
    else if ((paramInputStream1 instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream1, true, locala, null, paramInputStream3, new DummyStream());
    else if ((paramInputStream1 instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream3, new DummyStream(), locala);
    else if ((paramInputStream1 instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream3, new DummyStream(), locala);
    else if ((paramInputStream1 instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream1, null, new DummyStream());
    else
      throw new NonPGPDataException("Unknown message format: " + paramInputStream1.getClass());
    return locala.a;
  }

  public SignatureCheckResult verifyWithoutExtracting(InputStream paramInputStream, KeyStore paramKeyStore, String paramString)
    throws PGPException, FileIsEncryptedException, IOException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    DummyStream localDummyStream = new DummyStream();
    if (((paramInputStream instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream).isClearText()))
      return (paramInputStream = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject, paramKeyStore, null, localDummyStream);
    Object localObject = new PGPObjectFactory2(paramInputStream);
    try
    {
      paramInputStream = ((PGPObjectFactory2)localObject).nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((paramInputStream instanceof PGPMarker))
      paramInputStream = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream instanceof PGPEncryptedDataList))
      a((PGPEncryptedDataList)paramInputStream, true, locala, paramKeyStore, null, paramString, null, localDummyStream);
    else if ((paramInputStream instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream, true, locala, paramKeyStore, null, localDummyStream);
    else if ((paramInputStream instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, localDummyStream, locala);
    else if ((paramInputStream instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, localDummyStream, locala);
    else if ((paramInputStream instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream, null, localDummyStream);
    else
      throw new NonPGPDataException("Unknown message format: " + paramInputStream.getClass());
    return locala.a;
  }

  public SignatureCheckResult verifyWithoutExtracting(InputStream paramInputStream, KeyStore paramKeyStore)
    throws PGPException, FileIsEncryptedException, IOException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    DummyStream localDummyStream = new DummyStream();
    if (((paramInputStream instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream).isClearText()))
      return (paramInputStream = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject, paramKeyStore, null, localDummyStream);
    Object localObject = new PGPObjectFactory2(paramInputStream);
    try
    {
      paramInputStream = ((PGPObjectFactory2)localObject).nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((paramInputStream instanceof PGPMarker))
      paramInputStream = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream instanceof PGPEncryptedDataList))
      throw new FileIsEncryptedException("This file is encrypted. Use <decryptAndVerify> or <decrypt> to open it.");
    if ((paramInputStream instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream, true, locala, paramKeyStore, null, localDummyStream);
    else if ((paramInputStream instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, localDummyStream, locala);
    else if ((paramInputStream instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, localDummyStream, locala);
    else if ((paramInputStream instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream, null, localDummyStream);
    else
      throw new NonPGPDataException("Unknown message format: " + paramInputStream.getClass());
    return locala.a;
  }

  public SignatureCheckResult verifyWithoutExtracting(String paramString1, String paramString2, String paramString3, String paramString4)
    throws IOException, PGPException, FileIsEncryptedException
  {
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    DummyStream localDummyStream = new DummyStream();
    try
    {
      localInputStream1 = readFileOrAsciiString(paramString1, "message");
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFile");
      paramString1 = readFileOrAsciiString(paramString2, "privateKeyFile");
      paramString1 = paramString1 = verifyWithoutExtracting(localInputStream1, paramString1, paramString3, localInputStream2);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localDummyStream);
    }
    throw paramString1;
  }

  public SignatureCheckResult verifyWithoutExtracting(String paramString1, String paramString2)
    throws IOException, PGPException, FileIsEncryptedException
  {
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    DummyStream localDummyStream = new DummyStream();
    try
    {
      localInputStream1 = readFileOrAsciiString(paramString1, "message");
      localInputStream2 = readFileOrAsciiString(paramString2, "publicKeyFile");
      paramString1 = paramString1 = verifyAndExtract(localInputStream1, localInputStream2, localDummyStream);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localDummyStream);
    }
    throw paramString1;
  }

  public SignatureCheckResult verifyWithoutExtracting(String paramString, KeyStore paramKeyStore)
    throws IOException, PGPException, FileIsEncryptedException
  {
    InputStream localInputStream = null;
    DummyStream localDummyStream = new DummyStream();
    try
    {
      localInputStream = readFileOrAsciiString(paramString, "message");
      paramString = paramString = verifyAndExtract(localInputStream, paramKeyStore, localDummyStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localDummyStream);
    }
    throw paramString;
  }

  public SignatureCheckResult verifyWithoutExtracting(String paramString1, KeyStore paramKeyStore, String paramString2)
    throws IOException, PGPException, FileIsEncryptedException
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString1, "message");
      paramString1 = paramString1 = verifyWithoutExtracting(localInputStream, paramKeyStore, paramString2);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public SignatureCheckResult verifyWithoutExtracting(File paramFile1, File paramFile2)
    throws PGPException, FileIsEncryptedException, IOException
  {
    return verifyWithoutExtracting(paramFile1.getAbsolutePath(), paramFile2.getAbsolutePath());
  }

  public SignatureCheckResult verifyWithoutExtracting(File paramFile1, File paramFile2, String paramString, File paramFile3)
    throws PGPException, FileIsEncryptedException, IOException
  {
    return verifyWithoutExtracting(paramFile1.getAbsolutePath(), paramFile2.getAbsolutePath(), paramString, paramFile3.getAbsolutePath());
  }

  public SignatureCheckResult verifyWithoutExtracting(File paramFile, KeyStore paramKeyStore)
    throws PGPException, FileIsEncryptedException, IOException
  {
    return verifyWithoutExtracting(paramFile.getAbsolutePath(), paramKeyStore);
  }

  public SignatureCheckResult verifyWithoutExtracting(File paramFile, KeyStore paramKeyStore, String paramString)
    throws PGPException, FileIsEncryptedException, IOException
  {
    return verifyWithoutExtracting(paramFile.getAbsolutePath(), paramKeyStore, paramString);
  }

  public SignatureCheckResult verifyAndExtract(InputStream paramInputStream1, InputStream paramInputStream2, OutputStream paramOutputStream)
    throws PGPException, FileIsEncryptedException, IOException
  {
    if ((((paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1)) instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream1).isClearText()))
      return (paramInputStream1 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject, null, paramInputStream2, paramOutputStream);
    Object localObject = new PGPObjectFactory2(paramInputStream1);
    try
    {
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((paramInputStream1 instanceof PGPMarker))
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream1 instanceof PGPEncryptedDataList))
      throw new FileIsEncryptedException("This file is encrypted. Use the methods <decryptAndVerifySignature> or <decrypt> to open it.");
    if ((paramInputStream1 instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream1, true, locala, null, paramInputStream2, paramOutputStream);
    else if ((paramInputStream1 instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream2, paramOutputStream, locala);
    else if ((paramInputStream1 instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream2, paramOutputStream, locala);
    else if ((paramInputStream1 instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream1, null, paramOutputStream);
    else
      throw new NonPGPDataException("Unknown message format: " + paramInputStream1.getClass());
    return locala.a;
  }

  public SignatureCheckResult verifyAndExtract(InputStream paramInputStream, KeyStore paramKeyStore, OutputStream paramOutputStream)
    throws PGPException, FileIsEncryptedException, IOException
  {
    if ((((paramInputStream = PGPUtil.getDecoderStream(paramInputStream)) instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream).isClearText()))
      return (paramInputStream = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject, paramKeyStore, null, paramOutputStream);
    Object localObject = new PGPObjectFactory2(paramInputStream);
    try
    {
      paramInputStream = ((PGPObjectFactory2)localObject).nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((paramInputStream instanceof PGPMarker))
      paramInputStream = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream instanceof PGPEncryptedDataList))
      throw new FileIsEncryptedException("This file is encrypted. Use <decryptAndVerify> or <decrypt> to open it.");
    if ((paramInputStream instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream, true, locala, paramKeyStore, null, paramOutputStream);
    else if ((paramInputStream instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, paramOutputStream, locala);
    else if ((paramInputStream instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, paramOutputStream, locala);
    else if ((paramInputStream instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream, null, paramOutputStream);
    else
      throw new NonPGPDataException("Unknown message format: " + paramInputStream.getClass());
    return locala.a;
  }

  public SignatureCheckResult verifyAndExtract(String paramString1, String paramString2, StringBuffer paramStringBuffer, String paramString3)
    throws IOException, PGPException, FileIsEncryptedException
  {
    if (paramStringBuffer == null)
      throw new IllegalArgumentException("The decryptedString parameter cannot be null");
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localInputStream1 = readFileOrAsciiString(paramString1, "message");
      localInputStream2 = readFileOrAsciiString(paramString2, "publicKeyFile");
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      paramString1 = verifyAndExtract(localInputStream1, localInputStream2, localDirectByteArrayOutputStream);
      paramStringBuffer.setLength(0);
      paramStringBuffer.append(new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString3));
      paramString1 = paramString1;
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  public SignatureCheckResult verifyAndExtract(String paramString1, String paramString2, StringBuffer paramStringBuffer)
    throws IOException, PGPException, FileIsEncryptedException
  {
    return verifyAndExtract(paramString1, paramString2, paramStringBuffer, "ASCII");
  }

  public SignatureCheckResult verifyAndExtract(String paramString1, KeyStore paramKeyStore, StringBuffer paramStringBuffer, String paramString2)
    throws IOException, PGPException, FileIsEncryptedException
  {
    if (paramStringBuffer == null)
      throw new IllegalArgumentException("The decryptedString parameter cannot be null");
    InputStream localInputStream = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localInputStream = readFileOrAsciiString(paramString1, "message");
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      paramString1 = verifyAndExtract(localInputStream, paramKeyStore, localDirectByteArrayOutputStream);
      paramStringBuffer.setLength(0);
      paramStringBuffer.append(new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString2));
      paramString1 = paramString1;
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  public SignatureCheckResult verifyAndExtract(String paramString, KeyStore paramKeyStore, StringBuffer paramStringBuffer)
    throws IOException, PGPException, FileIsEncryptedException
  {
    return verifyAndExtract(paramString, paramKeyStore, paramStringBuffer);
  }

  public SignatureCheckResult verifyAndExtract(String paramString1, String paramString2, String paramString3)
    throws PGPException, FileIsEncryptedException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    InputStream localInputStream = null;
    BufferedOutputStream localBufferedOutputStream = null;
    a("Signature verification of file {0}", paramString1);
    a("Extracting to {0}", new File(paramString3).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1), 1048576);
      localInputStream = readFileOrAsciiString(paramString2, "publicKeyFileName");
      localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString3), 1048576);
      paramString1 = verifyAndExtract(localBufferedInputStream, localInputStream, localBufferedOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localBufferedOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString3)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public SignatureCheckResult verifyAndExtract(File paramFile1, File paramFile2, File paramFile3)
    throws PGPException, FileIsEncryptedException, IOException
  {
    return verifyAndExtract(paramFile1.getAbsolutePath(), paramFile2.getAbsolutePath(), paramFile3.getAbsolutePath());
  }

  public SignatureCheckResult verifyAndExtract(File paramFile1, KeyStore paramKeyStore, File paramFile2)
    throws PGPException, FileIsEncryptedException, IOException
  {
    return verifyAndExtract(paramFile1.getAbsolutePath(), paramKeyStore, paramFile2.getAbsolutePath());
  }

  public SignatureCheckResult verifyAndExtract(String paramString1, KeyStore paramKeyStore, String paramString2)
    throws PGPException, FileIsEncryptedException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    FileOutputStream localFileOutputStream = null;
    a("Signature verification of file {0}", paramString1);
    a("Extracting to {0}", new File(paramString2).getAbsolutePath());
    int n = 0;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      localFileOutputStream = new FileOutputStream(paramString2);
      paramString1 = verifyAndExtract(localBufferedInputStream, paramKeyStore, localFileOutputStream);
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString2)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean verifyStream(InputStream paramInputStream1, InputStream paramInputStream2)
    throws PGPException, FileIsEncryptedException, IOException
  {
    paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1);
    return verifyStream(paramInputStream1, paramInputStream2, new DummyStream());
  }

  /** @deprecated */
  public boolean verifyStream(InputStream paramInputStream1, InputStream paramInputStream2, OutputStream paramOutputStream)
    throws PGPException, FileIsEncryptedException, IOException
  {
    if ((((paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1)) instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream1).isClearText()))
      return (paramInputStream1 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject, null, paramInputStream2, paramOutputStream) == SignatureCheckResult.SignatureVerified;
    Object localObject = new PGPObjectFactory2(paramInputStream1);
    try
    {
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    }
    catch (IOException localIOException)
    {
      throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
    }
    if ((paramInputStream1 instanceof PGPMarker))
      paramInputStream1 = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream1 instanceof PGPEncryptedDataList))
      throw new FileIsEncryptedException("This file is encrypted. Use <decryptAndVerify> or <decrypt> to open it.");
    if ((paramInputStream1 instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream1, true, locala, null, paramInputStream2, paramOutputStream);
    else if ((paramInputStream1 instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream2, paramOutputStream, locala);
    else if ((paramInputStream1 instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream1, (PGPObjectFactory)localObject, null, paramInputStream2, paramOutputStream, locala);
    else if ((paramInputStream1 instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream1, null, paramOutputStream);
    else
      throw new PGPException("Unknown message format: " + paramInputStream1.getClass());
    return locala.a == SignatureCheckResult.SignatureVerified;
  }

  /** @deprecated */
  public boolean verifyStream(InputStream paramInputStream, KeyStore paramKeyStore, OutputStream paramOutputStream)
    throws PGPException, FileIsEncryptedException, IOException
  {
    Object localObject;
    if ((((paramInputStream = PGPUtil.getDecoderStream(paramInputStream)) instanceof ArmoredInputStream)) && ((localObject = (ArmoredInputStream)paramInputStream).isClearText()))
    {
      paramInputStream = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      };
      try
      {
        return paramInputStream.a((ArmoredInputStream)localObject, paramKeyStore, null, paramOutputStream);
      }
      catch (SignatureException localSignatureException)
      {
        return false;
      }
    }
    if (((paramInputStream = (localObject = new PGPObjectFactory2(paramInputStream)).nextObject()) instanceof PGPMarker))
      paramInputStream = ((PGPObjectFactory2)localObject).nextObject();
    a locala = new a((byte)0);
    if ((paramInputStream instanceof PGPEncryptedDataList))
      throw new FileIsEncryptedException("This file is encrypted. Use <decryptAndVerify> or <decrypt> to open it.");
    if ((paramInputStream instanceof PGPCompressedData))
      a((PGPCompressedData)paramInputStream, true, locala, paramKeyStore, null, paramOutputStream);
    else if ((paramInputStream instanceof PGPOnePassSignatureList))
      a((PGPOnePassSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, paramOutputStream, locala);
    else if ((paramInputStream instanceof PGPSignatureList))
      a((PGPSignatureList)paramInputStream, (PGPObjectFactory)localObject, paramKeyStore, null, paramOutputStream, locala);
    else if ((paramInputStream instanceof PGPLiteralData))
      a((PGPLiteralData)paramInputStream, null, paramOutputStream);
    else
      throw new NonPGPDataException("Unknown message format: " + paramInputStream.getClass().getName());
    return locala.a == SignatureCheckResult.SignatureVerified;
  }

  /** @deprecated */
  public boolean verifyString(String paramString1, String paramString2, StringBuffer paramStringBuffer)
    throws IOException, PGPException, FileIsEncryptedException
  {
    return verifyString(paramString1, paramString2, paramStringBuffer, "UTF-8");
  }

  /** @deprecated */
  public boolean verifyString(String paramString1, String paramString2, StringBuffer paramStringBuffer, String paramString3)
    throws IOException, PGPException, FileIsEncryptedException
  {
    if (paramStringBuffer == null)
      throw new IllegalArgumentException("The decryptedString parameter cannot be null");
    ByteArrayInputStream localByteArrayInputStream = null;
    InputStream localInputStream = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes(paramString3));
      localInputStream = readFileOrAsciiString(paramString2, "publicKeyFileName");
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      paramString1 = verifyStream(localByteArrayInputStream, localInputStream, localDirectByteArrayOutputStream);
      paramStringBuffer.setLength(0);
      paramStringBuffer.append(new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString3));
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean decryptAndVerifyString(String paramString1, String paramString2, String paramString3, String paramString4, StringBuffer paramStringBuffer)
    throws IOException, PGPException, FileIsEncryptedException
  {
    return decryptAndVerifyString(paramString1, paramString2, paramString3, paramString4, paramStringBuffer, "UTF-8");
  }

  /** @deprecated */
  public boolean decryptAndVerifyString(String paramString1, String paramString2, String paramString3, String paramString4, StringBuffer paramStringBuffer, String paramString5)
    throws IOException, PGPException
  {
    if (paramStringBuffer == null)
      throw new IllegalArgumentException("The decryptedString parameter cannot be null");
    ByteArrayInputStream localByteArrayInputStream = null;
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes("ASCII"));
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFileName");
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      paramString1 = decryptAndVerifyStream(localByteArrayInputStream, localInputStream1, paramString3, localInputStream2, localDirectByteArrayOutputStream);
      paramStringBuffer.setLength(0);
      paramStringBuffer.append(new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString5));
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  public SignatureCheckResult decryptAndVerify(String paramString1, String paramString2, String paramString3, String paramString4, StringBuffer paramStringBuffer)
    throws IOException, PGPException, FileIsEncryptedException
  {
    return decryptAndVerify(paramString1, paramString2, paramString3, paramString4, paramStringBuffer, "UTF-8");
  }

  public SignatureCheckResult decryptAndVerify(String paramString1, String paramString2, String paramString3, String paramString4, StringBuffer paramStringBuffer, String paramString5)
    throws IOException, PGPException
  {
    if (paramStringBuffer == null)
      throw new IllegalArgumentException("The decryptedString parameter cannot be null");
    ByteArrayInputStream localByteArrayInputStream = null;
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramString1.getBytes("ASCII"));
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFileName");
      localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
      paramString1 = decryptAndVerify(localByteArrayInputStream, localInputStream1, paramString3, localInputStream2, localDirectByteArrayOutputStream);
      paramStringBuffer.setLength(0);
      paramStringBuffer.append(new String(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size(), paramString5));
      paramString1 = paramString1;
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localDirectByteArrayOutputStream);
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean decryptAndVerifyFile(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    a("Decrypting and verifying file {0}", new File(paramString1).getAbsolutePath());
    a("Extracting to {0}", new File(paramString3).getAbsolutePath());
    FileInputStream localFileInputStream = null;
    FileOutputStream localFileOutputStream = null;
    InputStream localInputStream = null;
    int n = 0;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localFileOutputStream = new FileOutputStream(paramString3);
      localInputStream = PGPUtil.getDecoderStream(localFileInputStream);
      Object localObject;
      if (((localObject = (paramString1 = new PGPObjectFactory2(localInputStream)).nextObject()) instanceof PGPMarker))
        localObject = paramString1.nextObject();
      a locala = new a((byte)0);
      if ((localObject instanceof PGPEncryptedDataList))
      {
        paramString1 = (PGPEncryptedDataList)localObject;
        a(paramString1, true, locala, paramKeyStore, null, paramString2, null, localFileOutputStream);
      }
      else if ((localObject instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject, true, locala, paramKeyStore, null, localFileOutputStream);
      }
      else
      {
        if (localObject == null)
          throw new NonPGPDataException("The supplied data is not a valid OpenPGP message");
        throw new PGPException("Unknown message format: " + localObject);
      }
      paramString1 = locala.a == SignatureCheckResult.SignatureVerified ? 1 : 0;
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localFileOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString3)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  public SignatureCheckResult decryptAndVerify(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying file {0}", paramString1);
    a("Extracting to {0}", new File(paramString5).getAbsolutePath());
    FileInputStream localFileInputStream = null;
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFile");
      localFileOutputStream = new FileOutputStream(paramString5);
      paramString1 = decryptAndVerify(localFileInputStream, localInputStream1, paramString3, localInputStream2, localFileOutputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localFileOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString5)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  public SignatureCheckResult decryptAndVerify(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    a("Decrypting and verifying file {0}", new File(paramString1).getAbsolutePath());
    a("Extracting to {0}", new File(paramString3).getAbsolutePath());
    FileInputStream localFileInputStream = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localFileOutputStream = new FileOutputStream(paramString3);
      paramString1 = decryptAndVerify(localFileInputStream, paramKeyStore, paramString2, localFileOutputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(null);
      IOUtil.closeStream(localFileOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(null);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramKeyStore = new File(paramString3)).exists()))
        paramKeyStore.delete();
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean decryptAndVerifyFileTo(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    InputStream localInputStream = null;
    a("Decrypting and verifying file {0}", new File(paramString1).getAbsolutePath());
    a("Extracting to {0}", new File(paramString3).getAbsolutePath());
    try
    {
      localInputStream = PGPUtil.getDecoderStream(localFileInputStream = new FileInputStream(paramString1));
      Object localObject1;
      Object localObject2;
      if (((localObject2 = (localObject1 = new PGPObjectFactory2(localInputStream)).nextObject()) instanceof PGPMarker))
        localObject2 = ((PGPObjectFactory2)localObject1).nextObject();
      a locala = new a((byte)0);
      if ((localObject2 instanceof PGPEncryptedDataList))
      {
        localObject1 = (PGPEncryptedDataList)localObject2;
        a((PGPEncryptedDataList)localObject1, true, locala, paramKeyStore, null, paramString2, null, paramString3, paramString1);
      }
      else if ((localObject2 instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject2, true, locala, paramKeyStore, null, paramString3, paramString1);
      }
      else if ((localObject2 instanceof PGPOnePassSignatureList))
      {
        a((PGPOnePassSignatureList)localObject2, (PGPObjectFactory)localObject1, paramKeyStore, null, paramString3, paramString1, locala);
      }
      else if ((localObject2 instanceof PGPSignatureList))
      {
        a((PGPSignatureList)localObject2, (PGPObjectFactory)localObject1, paramKeyStore, null, paramString3, paramString1, locala);
      }
      else if ((localObject2 instanceof PGPLiteralData))
      {
        a((PGPLiteralData)localObject2, null, paramString3, paramString1);
      }
      else
      {
        throw new NonPGPDataException("The supplied data is not a valid OpenPGP message");
      }
      paramString1 = locala.a == SignatureCheckResult.SignatureVerified ? 1 : 0;
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream);
    }
    throw paramString1;
  }

  public SignatureCheckResult decryptAndVerifyTo(String paramString1, KeyStore paramKeyStore, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    BufferedInputStream localBufferedInputStream = null;
    a("Decrypting and verifying file {0}", new File(paramString1).getAbsolutePath());
    a("Extracting to {0}", new File(paramString3).getAbsolutePath());
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramString1));
      paramString1 = decryptAndVerifyTo(localBufferedInputStream, paramKeyStore, paramString2, paramString3);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localBufferedInputStream);
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean decryptAndVerifyStream(InputStream paramInputStream, KeyStore paramKeyStore, String paramString, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      if ((((localInputStream = PGPUtil.getDecoderStream(paramInputStream)) instanceof ArmoredInputStream)) && ((paramInputStream = (ArmoredInputStream)localInputStream).isClearText()))
      {
        a("Clear text signed data found");
        Object local1 = new Object()
        {
          public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
            throws PGPException, IOException, SignatureException
          {
          }

          public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
            throws PGPException, IOException
          {
          }

          public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
            throws IOException, lw.bouncycastle.openpgp.PGPException
          {
          }

          public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
            throws IOException, lw.bouncycastle.openpgp.PGPException
          {
          }

          public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
            throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
          {
          }

          public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
            throws IOException, lw.bouncycastle.openpgp.PGPException
          {
          }

          private static byte[] a()
          {
          }

          private int a(byte[] arg1)
          {
          }

          private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
            throws lw.bouncycastle.openpgp.PGPException, IOException
          {
          }

          private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
            throws lw.bouncycastle.openpgp.PGPException, IOException
          {
          }

          private void a(PGPSignature arg1, byte[] arg2)
            throws IOException
          {
          }

          private int b(byte[] arg1)
          {
          }

          private static boolean a(byte arg0)
          {
          }

          private int a(ByteArrayOutputStream arg1, InputStream arg2)
            throws IOException
          {
          }

          private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
            throws IOException
          {
          }

          private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
            throws IOException
          {
          }
        };
        try
        {
          boolean bool = local1.a(paramInputStream, paramKeyStore, null, paramOutputStream);
          return bool;
        }
        catch (SignatureException localSignatureException)
        {
          a("Signature exception: " + localSignatureException);
          return false;
        }
      }
      paramInputStream = new PGPObjectFactory2(localInputStream);
      Object localObject;
      try
      {
        localObject = paramInputStream.nextObject();
      }
      catch (IOException localIOException)
      {
        throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
      }
      if ((localObject instanceof PGPMarker))
      {
        a("Skipping PGP marker.");
        localObject = paramInputStream.nextObject();
      }
      a locala = new a((byte)0);
      if ((localObject instanceof PGPEncryptedDataList))
      {
        localObject = (PGPEncryptedDataList)localObject;
        a((PGPEncryptedDataList)localObject, true, locala, paramKeyStore, null, paramString, null, paramOutputStream);
      }
      else if ((localObject instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject, true, locala, paramKeyStore, null, paramOutputStream);
      }
      else if ((localObject instanceof PGPOnePassSignatureList))
      {
        a((PGPOnePassSignatureList)localObject, paramInputStream, paramKeyStore, null, paramOutputStream, locala);
      }
      else if ((localObject instanceof PGPSignatureList))
      {
        a((PGPSignatureList)localObject, paramInputStream, paramKeyStore, null, paramOutputStream, locala);
      }
      else if ((localObject instanceof PGPLiteralData))
      {
        a((PGPLiteralData)localObject, null, paramOutputStream);
      }
      else
      {
        throw new NonPGPDataException("Unknown message format: " + localObject);
      }
      paramInputStream = locala.a == SignatureCheckResult.SignatureVerified ? 1 : 0;
      return paramInputStream;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramInputStream;
  }

  public SignatureCheckResult decryptAndVerify(InputStream paramInputStream, KeyStore paramKeyStore, String paramString, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    InputStream localInputStream = null;
    try
    {
      Object localObject;
      if ((((localInputStream = PGPUtil.getDecoderStream(paramInputStream)) instanceof ArmoredInputStream)) && ((paramInputStream = (ArmoredInputStream)localInputStream).isClearText()))
      {
        a("Clear text signed data found");
        localObject = (localObject = new Object()
        {
          public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
            throws PGPException, IOException, SignatureException
          {
          }

          public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
            throws PGPException, IOException
          {
          }

          public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
            throws IOException, lw.bouncycastle.openpgp.PGPException
          {
          }

          public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
            throws IOException, lw.bouncycastle.openpgp.PGPException
          {
          }

          public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
            throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
          {
          }

          public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
            throws IOException, lw.bouncycastle.openpgp.PGPException
          {
          }

          private static byte[] a()
          {
          }

          private int a(byte[] arg1)
          {
          }

          private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
            throws lw.bouncycastle.openpgp.PGPException, IOException
          {
          }

          private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
            throws lw.bouncycastle.openpgp.PGPException, IOException
          {
          }

          private void a(PGPSignature arg1, byte[] arg2)
            throws IOException
          {
          }

          private int b(byte[] arg1)
          {
          }

          private static boolean a(byte arg0)
          {
          }

          private int a(ByteArrayOutputStream arg1, InputStream arg2)
            throws IOException
          {
          }

          private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
            throws IOException
          {
          }

          private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
            throws IOException
          {
          }
        }).b(paramInputStream, paramKeyStore, null, paramOutputStream);
        return localObject;
      }
      paramInputStream = new PGPObjectFactory2(localInputStream);
      try
      {
        localObject = paramInputStream.nextObject();
      }
      catch (IOException localIOException)
      {
        throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
      }
      if ((localObject instanceof PGPMarker))
      {
        a("Skipping PGP marker.");
        localObject = paramInputStream.nextObject();
      }
      a locala = new a((byte)0);
      if ((localObject instanceof PGPEncryptedDataList))
      {
        localObject = (PGPEncryptedDataList)localObject;
        a((PGPEncryptedDataList)localObject, true, locala, paramKeyStore, null, paramString, null, paramOutputStream);
      }
      else if ((localObject instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject, true, locala, paramKeyStore, null, paramOutputStream);
      }
      else if ((localObject instanceof PGPOnePassSignatureList))
      {
        a((PGPOnePassSignatureList)localObject, paramInputStream, paramKeyStore, null, paramOutputStream, locala);
      }
      else if ((localObject instanceof PGPSignatureList))
      {
        a((PGPSignatureList)localObject, paramInputStream, paramKeyStore, null, paramOutputStream, locala);
      }
      else if ((localObject instanceof PGPLiteralData))
      {
        a((PGPLiteralData)localObject, null, paramOutputStream);
      }
      else
      {
        throw new NonPGPDataException("Unknown message format: " + localObject);
      }
      paramInputStream = locala.a;
      return paramInputStream;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramInputStream;
  }

  /** @deprecated */
  public boolean decryptAndVerifyFile(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying file {0}", paramString1);
    a("Extracting to {0}", new File(paramString5).getAbsolutePath());
    FileInputStream localFileInputStream = null;
    InputStream localInputStream1 = null;
    InputStream localInputStream2 = null;
    FileOutputStream localFileOutputStream = null;
    int n = 0;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localInputStream1 = readFileOrAsciiString(paramString2, "privateKeyFileName");
      localInputStream2 = readFileOrAsciiString(paramString4, "publicKeyFile");
      localFileOutputStream = new FileOutputStream(paramString5);
      paramString1 = decryptAndVerifyStream(localFileInputStream, localInputStream1, paramString3, localInputStream2, localFileOutputStream);
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localFileOutputStream);
      return paramString1;
    }
    catch (PGPException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    catch (IOException paramString1)
    {
      n = 1;
      throw paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
      IOUtil.closeStream(localInputStream1);
      IOUtil.closeStream(localInputStream2);
      IOUtil.closeStream(localFileOutputStream);
      if ((n != 0) && ((paramString2 = new File(paramString5)).exists()))
        paramString2.delete();
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean decryptAndVerifyFileTo(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying file {0}", paramString1);
    a("Extracting to {0}", new File(paramString5).getAbsolutePath());
    FileInputStream localFileInputStream1 = null;
    FileInputStream localFileInputStream2 = null;
    FileInputStream localFileInputStream3 = null;
    try
    {
      localFileInputStream1 = new FileInputStream(paramString1);
      localFileInputStream2 = new FileInputStream(paramString2);
      localFileInputStream3 = new FileInputStream(paramString4);
      paramString1 = decryptAndVerifyStreamTo(localFileInputStream1, localFileInputStream2, paramString3, localFileInputStream3, paramString5);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream1);
      IOUtil.closeStream(localFileInputStream2);
      IOUtil.closeStream(localFileInputStream3);
    }
    throw paramString1;
  }

  public SignatureCheckResult decryptAndVerifyTo(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying file {0}", paramString1);
    a("Extracting to {0}", new File(paramString5).getAbsolutePath());
    FileInputStream localFileInputStream1 = null;
    FileInputStream localFileInputStream2 = null;
    FileInputStream localFileInputStream3 = null;
    try
    {
      localFileInputStream1 = new FileInputStream(paramString1);
      localFileInputStream2 = new FileInputStream(paramString2);
      localFileInputStream3 = new FileInputStream(paramString4);
      paramString1 = decryptAndVerifyTo(localFileInputStream1, localFileInputStream2, paramString3, localFileInputStream3, paramString5);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream1);
      IOUtil.closeStream(localFileInputStream2);
      IOUtil.closeStream(localFileInputStream3);
    }
    throw paramString1;
  }

  /** @deprecated */
  public boolean decryptAndVerifyStream(InputStream paramInputStream1, InputStream paramInputStream2, String paramString, InputStream paramInputStream3, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    Object localObject1;
    if ((((paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1)) instanceof ArmoredInputStream)) && ((localObject1 = (ArmoredInputStream)paramInputStream1).isClearText()))
    {
      a("Clear text signed data found");
      Object local1 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      };
      try
      {
        return local1.a((ArmoredInputStream)localObject1, null, paramInputStream3, paramOutputStream);
      }
      catch (SignatureException localSignatureException)
      {
        a("Signature exception: " + localSignatureException);
        return false;
      }
    }
    try
    {
      localObject1 = new PGPObjectFactory2(paramInputStream1);
      Object localObject2;
      try
      {
        localObject2 = ((PGPObjectFactory2)localObject1).nextObject();
      }
      catch (IOException localIOException)
      {
        throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
      }
      if ((localObject2 instanceof PGPMarker))
      {
        a("Skipping marker packet.");
        localObject2 = ((PGPObjectFactory2)localObject1).nextObject();
      }
      a locala = new a((byte)0);
      if ((localObject2 instanceof PGPEncryptedDataList))
      {
        localObject2 = (PGPEncryptedDataList)localObject2;
        a((PGPEncryptedDataList)localObject2, true, locala, null, paramInputStream2, paramString, paramInputStream3, paramOutputStream);
      }
      else if ((localObject2 instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject2, true, locala, null, paramInputStream3, paramOutputStream);
      }
      else if ((localObject2 instanceof PGPOnePassSignatureList))
      {
        a((PGPOnePassSignatureList)localObject2, (PGPObjectFactory)localObject1, null, paramInputStream3, paramOutputStream, locala);
      }
      else if ((localObject2 instanceof PGPSignatureList))
      {
        a((PGPSignatureList)localObject2, (PGPObjectFactory)localObject1, null, paramInputStream3, paramOutputStream, locala);
      }
      else if ((localObject2 instanceof PGPLiteralData))
      {
        a((PGPLiteralData)localObject2, null, paramOutputStream);
      }
      else
      {
        throw new NonPGPDataException("Unknown message format: " + localObject2);
      }
      paramInputStream2 = locala.a == SignatureCheckResult.SignatureVerified ? 1 : 0;
      return paramInputStream2;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      a("PGPException " + localPGPException);
      throw IOUtil.newPGPException(localPGPException);
    }
    finally
    {
      IOUtil.closeStream(paramInputStream1);
    }
    throw paramInputStream2;
  }

  public SignatureCheckResult decryptAndVerify(InputStream paramInputStream1, InputStream paramInputStream2, String paramString, InputStream paramInputStream3, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    Object localObject1;
    Object localObject2;
    if ((((paramInputStream1 = PGPUtil.getDecoderStream(paramInputStream1)) instanceof ArmoredInputStream)) && ((localObject1 = (ArmoredInputStream)paramInputStream1).isClearText()))
    {
      a("Clear text signed data found");
      return (localObject2 = new Object()
      {
        public boolean a(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException, SignatureException
        {
        }

        public SignatureCheckResult b(ArmoredInputStream arg1, KeyStore arg2, InputStream arg3, OutputStream arg4)
          throws PGPException, IOException
        {
        }

        public String a(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public String b(String arg1, PGPSecretKey arg2, String arg3, int arg4)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        public void a(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException, WrongPasswordException
        {
        }

        public void b(InputStream arg1, PGPSecretKey arg2, String arg3, int arg4, OutputStream arg5)
          throws IOException, lw.bouncycastle.openpgp.PGPException
        {
        }

        private static byte[] a()
        {
        }

        private int a(byte[] arg1)
        {
        }

        private void a(OutputStream arg1, PGPSignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(OutputStream arg1, PGPV3SignatureGenerator arg2, byte[] arg3)
          throws lw.bouncycastle.openpgp.PGPException, IOException
        {
        }

        private void a(PGPSignature arg1, byte[] arg2)
          throws IOException
        {
        }

        private int b(byte[] arg1)
        {
        }

        private static boolean a(byte arg0)
        {
        }

        private int a(ByteArrayOutputStream arg1, InputStream arg2)
          throws IOException
        {
        }

        private int a(ByteArrayOutputStream arg1, int arg2, InputStream arg3)
          throws IOException
        {
        }

        private static int b(ByteArrayOutputStream arg0, int arg1, InputStream arg2)
          throws IOException
        {
        }
      }).b((ArmoredInputStream)localObject1, null, paramInputStream3, paramOutputStream);
    }
    try
    {
      localObject1 = new PGPObjectFactory2(paramInputStream1);
      try
      {
        localObject2 = ((PGPObjectFactory2)localObject1).nextObject();
      }
      catch (IOException localIOException)
      {
        throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
      }
      if ((localObject2 instanceof PGPMarker))
      {
        a("Skipping marker packet.");
        localObject2 = ((PGPObjectFactory2)localObject1).nextObject();
      }
      a locala = new a((byte)0);
      if ((localObject2 instanceof PGPEncryptedDataList))
      {
        localObject2 = (PGPEncryptedDataList)localObject2;
        a((PGPEncryptedDataList)localObject2, true, locala, null, paramInputStream2, paramString, paramInputStream3, paramOutputStream);
      }
      else if ((localObject2 instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject2, true, locala, null, paramInputStream3, paramOutputStream);
      }
      else if ((localObject2 instanceof PGPOnePassSignatureList))
      {
        a((PGPOnePassSignatureList)localObject2, (PGPObjectFactory)localObject1, null, paramInputStream3, paramOutputStream, locala);
      }
      else if ((localObject2 instanceof PGPSignatureList))
      {
        a((PGPSignatureList)localObject2, (PGPObjectFactory)localObject1, null, paramInputStream3, paramOutputStream, locala);
      }
      else if ((localObject2 instanceof PGPLiteralData))
      {
        a((PGPLiteralData)localObject2, null, paramOutputStream);
      }
      else
      {
        throw new NonPGPDataException("Unknown message format: " + localObject2);
      }
      paramInputStream2 = locala.a;
      return paramInputStream2;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      a("PGPException " + localPGPException);
      throw IOUtil.newPGPException(localPGPException);
    }
    finally
    {
      IOUtil.closeStream(paramInputStream1);
    }
    throw paramInputStream2;
  }

  /** @deprecated */
  public boolean decryptAndVerifyStreamTo(InputStream paramInputStream1, InputStream paramInputStream2, String paramString1, InputStream paramInputStream3, String paramString2)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying of stream data to {0}", new File(paramString2).getAbsolutePath());
    InputStream localInputStream = null;
    try
    {
      localInputStream = PGPUtil.getDecoderStream(paramInputStream1);
      paramInputStream1 = new PGPObjectFactory2(localInputStream);
      Object localObject;
      try
      {
        localObject = paramInputStream1.nextObject();
      }
      catch (IOException localIOException)
      {
        throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
      }
      if ((localObject instanceof PGPMarker))
      {
        a("Skipping marker packet.");
        localObject = paramInputStream1.nextObject();
      }
      a locala = new a((byte)0);
      if ((localObject instanceof PGPEncryptedDataList))
      {
        paramInputStream1 = (PGPEncryptedDataList)localObject;
        a(paramInputStream1, true, locala, null, paramInputStream2, paramString1, paramInputStream3, paramString2, null);
      }
      else if ((localObject instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject, true, locala, null, paramInputStream3, paramString2, null);
      }
      else if ((localObject instanceof PGPOnePassSignatureList))
      {
        a((PGPOnePassSignatureList)localObject, paramInputStream1, null, paramInputStream3, paramString2, null, locala);
      }
      else if ((localObject instanceof PGPSignatureList))
      {
        a((PGPSignatureList)localObject, paramInputStream1, null, paramInputStream3, paramString2, null, locala);
      }
      else if ((localObject instanceof PGPLiteralData))
      {
        a((PGPLiteralData)localObject, null, paramString2, null);
      }
      else
      {
        throw new NonPGPDataException("Unknown message format: " + localObject);
      }
      paramInputStream1 = locala.a == SignatureCheckResult.SignatureVerified ? 1 : 0;
      return paramInputStream1;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramInputStream1;
  }

  public SignatureCheckResult decryptAndVerifyTo(InputStream paramInputStream1, InputStream paramInputStream2, String paramString1, InputStream paramInputStream3, String paramString2)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying of stream data to {0}", new File(paramString2).getAbsolutePath());
    InputStream localInputStream = null;
    try
    {
      localInputStream = PGPUtil.getDecoderStream(paramInputStream1);
      paramInputStream1 = new PGPObjectFactory2(localInputStream);
      Object localObject;
      try
      {
        localObject = paramInputStream1.nextObject();
      }
      catch (IOException localIOException)
      {
        throw new NonPGPDataException("The supplied data is not a valid OpenPGP message", localIOException);
      }
      if ((localObject instanceof PGPMarker))
      {
        a("Skipping marker packet.");
        localObject = paramInputStream1.nextObject();
      }
      a locala = new a((byte)0);
      if ((localObject instanceof PGPEncryptedDataList))
      {
        paramInputStream1 = (PGPEncryptedDataList)localObject;
        a(paramInputStream1, true, locala, null, paramInputStream2, paramString1, paramInputStream3, paramString2, null);
      }
      else if ((localObject instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject, true, locala, null, paramInputStream3, paramString2, null);
      }
      else if ((localObject instanceof PGPOnePassSignatureList))
      {
        a((PGPOnePassSignatureList)localObject, paramInputStream1, null, paramInputStream3, paramString2, null, locala);
      }
      else if ((localObject instanceof PGPSignatureList))
      {
        a((PGPSignatureList)localObject, paramInputStream1, null, paramInputStream3, paramString2, null, locala);
      }
      else if ((localObject instanceof PGPLiteralData))
      {
        a((PGPLiteralData)localObject, null, paramString2, null);
      }
      else
      {
        throw new NonPGPDataException("Unknown message format: " + localObject);
      }
      paramInputStream1 = locala.a;
      return paramInputStream1;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramInputStream1;
  }

  /** @deprecated */
  public boolean decryptAndVerifyStreamTo(InputStream paramInputStream, KeyStore paramKeyStore, String paramString1, String paramString2)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying of stream data to {0}", new File(paramString2).getAbsolutePath());
    InputStream localInputStream = null;
    try
    {
      localInputStream = PGPUtil.getDecoderStream(paramInputStream);
      Object localObject;
      if (((localObject = (paramInputStream = new PGPObjectFactory2(localInputStream)).nextObject()) instanceof PGPMarker))
        localObject = paramInputStream.nextObject();
      a locala = new a((byte)0);
      if ((localObject instanceof PGPEncryptedDataList))
      {
        paramInputStream = (PGPEncryptedDataList)localObject;
        a(paramInputStream, true, locala, paramKeyStore, null, paramString1, null, paramString2, null);
      }
      else if ((localObject instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject, true, locala, paramKeyStore, null, paramString2, null);
      }
      else
      {
        if (localObject == null)
          throw new NonPGPDataException("The supplied data is not a valid OpenPGP message");
        throw new lw.bouncycastle.openpgp.PGPException("Unknown message format: " + localObject);
      }
      paramInputStream = locala.a == SignatureCheckResult.SignatureVerified ? 1 : 0;
      return paramInputStream;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramInputStream;
  }

  public SignatureCheckResult decryptAndVerifyTo(InputStream paramInputStream, KeyStore paramKeyStore, String paramString1, String paramString2)
    throws PGPException, IOException
  {
    a("Decrypting and signature verifying of stream data to {0}", new File(paramString2).getAbsolutePath());
    InputStream localInputStream = null;
    try
    {
      localInputStream = PGPUtil.getDecoderStream(paramInputStream);
      Object localObject;
      if (((localObject = (paramInputStream = new PGPObjectFactory2(localInputStream)).nextObject()) instanceof PGPMarker))
        localObject = paramInputStream.nextObject();
      a locala = new a((byte)0);
      if ((localObject instanceof PGPEncryptedDataList))
      {
        paramInputStream = (PGPEncryptedDataList)localObject;
        a(paramInputStream, true, locala, paramKeyStore, null, paramString1, null, paramString2, null);
      }
      else if ((localObject instanceof PGPCompressedData))
      {
        a((PGPCompressedData)localObject, true, locala, paramKeyStore, null, paramString2, null);
      }
      else
      {
        if (localObject == null)
          throw new NonPGPDataException("The supplied data is not a valid OpenPGP message");
        throw new lw.bouncycastle.openpgp.PGPException("Unknown message format: " + localObject);
      }
      paramInputStream = locala.a;
      return paramInputStream;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    throw paramInputStream;
  }

  // ERROR //
  private void a(InputStream paramInputStream, String paramString, PGPPublicKey[] paramArrayOfPGPPublicKey, OutputStream paramOutputStream, Date paramDate, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    throws PGPException, IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 272\011com/didisoft/pgp/PGPLib:k\011Z
    //   4: ifeq +15 -> 19
    //   7: aload_0
    //   8: aload_1
    //   9: aload_2
    //   10: aload_3
    //   11: aload 4
    //   13: iload 6
    //   15: invokespecial 305\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/InputStream;Ljava/lang/String;[Llw/bouncycastle/openpgp/PGPPublicKey;Ljava/io/OutputStream;Z)V
    //   18: return
    //   19: aload 4
    //   21: instanceof 188
    //   24: ifne +16 -> 40
    //   27: new 188\011java/io/BufferedOutputStream
    //   30: dup
    //   31: aload 4
    //   33: ldc 3
    //   35: invokespecial 466\011java/io/BufferedOutputStream:<init>\011(Ljava/io/OutputStream;I)V
    //   38: astore 4
    //   40: iload 6
    //   42: ifeq +24 -> 66
    //   45: aload 4
    //   47: astore 4
    //   49: new 224\011lw/bouncycastle/bcpg/ArmoredOutputStream
    //   52: dup
    //   53: aload 4
    //   55: invokespecial 549\011lw/bouncycastle/bcpg/ArmoredOutputStream:<init>\011(Ljava/io/OutputStream;)V
    //   58: astore 4
    //   60: aload_0
    //   61: aload 4
    //   63: invokespecial 306\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/OutputStream;)V
    //   66: aload_0
    //   67: getfield 265\011com/didisoft/pgp/PGPLib:d\011Ljava/lang/String;
    //   70: invokestatic 288\011com/didisoft/pgp/KeyStore:b\011(Ljava/lang/String;)I
    //   73: istore 9
    //   75: aload_0
    //   76: getfield 264\011com/didisoft/pgp/PGPLib:c\011Ljava/lang/String;
    //   79: invokestatic 290\011com/didisoft/pgp/KeyStore:c\011(Ljava/lang/String;)I
    //   82: istore 10
    //   84: aload_3
    //   85: arraylength
    //   86: iconst_1
    //   87: if_icmpne +43 -> 130
    //   90: aload_0
    //   91: aload_3
    //   92: iconst_0
    //   93: aaload
    //   94: invokespecial 356\011com/didisoft/pgp/PGPLib:e\011(Llw/bouncycastle/openpgp/PGPPublicKey;)I
    //   97: istore 9
    //   99: aload_0
    //   100: aload_3
    //   101: iconst_0
    //   102: aaload
    //   103: invokespecial 332\011com/didisoft/pgp/PGPLib:c\011(Llw/bouncycastle/openpgp/PGPPublicKey;)I
    //   106: istore 10
    //   108: aload_0
    //   109: ldc 54
    //   111: iload 10
    //   113: invokestatic 289\011com/didisoft/pgp/KeyStore:c\011(I)Ljava/lang/String;
    //   116: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   119: aload_0
    //   120: ldc 28
    //   122: iload 9
    //   124: invokestatic 283\011com/didisoft/pgp/KeyStore:a\011(I)Ljava/lang/String;
    //   127: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   130: iload 8
    //   132: ifeq +23 -> 155
    //   135: new 225\011lw/bouncycastle/bcpg/BCPGOutputStream
    //   138: dup
    //   139: aload 4
    //   141: invokespecial 551\011lw/bouncycastle/bcpg/BCPGOutputStream:<init>\011(Ljava/io/OutputStream;)V
    //   144: dup
    //   145: astore 8
    //   147: invokestatic 310\011com/didisoft/pgp/PGPLib:a\011(Llw/bouncycastle/bcpg/BCPGOutputStream;)V
    //   150: aload 8
    //   152: invokevirtual 552\011lw/bouncycastle/bcpg/BCPGOutputStream:flush\011()V
    //   155: new 229\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator
    //   158: dup
    //   159: aload_0
    //   160: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   163: iload 10
    //   165: iload 7
    //   167: invokestatic 445\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   170: invokevirtual 422\011com/didisoft/pgp/bc/BCFactory:CreatePGPDataEncryptorBuilder\011(IZLjava/security/SecureRandom;)Llw/bouncycastle/openpgp/operator/PGPDataEncryptorBuilder;
    //   173: invokespecial 560\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:<init>\011(Llw/bouncycastle/openpgp/operator/PGPDataEncryptorBuilder;)V
    //   176: astore 8
    //   178: iconst_0
    //   179: istore 7
    //   181: iload 7
    //   183: aload_3
    //   184: arraylength
    //   185: if_icmpge +41 -> 226
    //   188: aload_0
    //   189: ldc 55
    //   191: aload_3
    //   192: iload 7
    //   194: aaload
    //   195: invokevirtual 589\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   198: invokestatic 282\011com/didisoft/pgp/KeyPairInformation:keyId2Hex\011(J)Ljava/lang/String;
    //   201: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   204: aload 8
    //   206: aload_0
    //   207: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   210: aload_3
    //   211: iload 7
    //   213: aaload
    //   214: invokevirtual 428\011com/didisoft/pgp/bc/BCFactory:CreatePublicKeyKeyEncryptionMethodGenerator\011(Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/operator/PublicKeyKeyEncryptionMethodGenerator;
    //   217: invokevirtual 561\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:addMethod\011(Llw/bouncycastle/openpgp/operator/PGPKeyEncryptionMethodGenerator;)V
    //   220: iinc 7 1
    //   223: goto -42 -> 181
    //   226: aload 8
    //   228: aload 4
    //   230: ldc 3
    //   232: newarray byte
    //   234: invokevirtual 564\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:open\011(Ljava/io/OutputStream;[B)Ljava/io/OutputStream;
    //   237: astore_3
    //   238: goto +10 -> 248
    //   241: dup
    //   242: astore 7
    //   244: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   247: athrow
    //   248: new 227\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator
    //   251: dup
    //   252: iload 9
    //   254: invokespecial 555\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:<init>\011(I)V
    //   257: astore 7
    //   259: new 233\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator
    //   262: dup
    //   263: invokespecial 571\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:<init>\011()V
    //   266: astore 8
    //   268: aconst_null
    //   269: astore 10
    //   271: iload 9
    //   273: ifne +31 -> 304
    //   276: aload 8
    //   278: aload_3
    //   279: aload_0
    //   280: invokevirtual 374\011com/didisoft/pgp/PGPLib:getContentType\011()C
    //   283: aload_2
    //   284: aload 5
    //   286: ldc 3
    //   288: newarray byte
    //   290: invokevirtual 575\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:open\011(Ljava/io/OutputStream;CLjava/lang/String;Ljava/util/Date;[B)Ljava/io/OutputStream;
    //   293: astore 10
    //   295: aload_1
    //   296: aload 10
    //   298: invokestatic 376\011com/didisoft/pgp/PGPLib:pipeAll\011(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   301: goto +33 -> 334
    //   304: aload 8
    //   306: aload 7
    //   308: aload_3
    //   309: invokevirtual 557\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:open\011(Ljava/io/OutputStream;)Ljava/io/OutputStream;
    //   312: aload_0
    //   313: invokevirtual 374\011com/didisoft/pgp/PGPLib:getContentType\011()C
    //   316: aload_2
    //   317: aload 5
    //   319: ldc 3
    //   321: newarray byte
    //   323: invokevirtual 575\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:open\011(Ljava/io/OutputStream;CLjava/lang/String;Ljava/util/Date;[B)Ljava/io/OutputStream;
    //   326: astore 10
    //   328: aload_1
    //   329: aload 10
    //   331: invokestatic 376\011com/didisoft/pgp/PGPLib:pipeAll\011(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   334: aload 8
    //   336: invokevirtual 573\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:close\011()V
    //   339: aload 10
    //   341: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   344: aload_1
    //   345: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   348: aload 7
    //   350: invokevirtual 556\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:close\011()V
    //   353: goto +25 -> 378
    //   356: astore_2
    //   357: aload 8
    //   359: invokevirtual 573\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:close\011()V
    //   362: aload 10
    //   364: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   367: aload_1
    //   368: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   371: aload 7
    //   373: invokevirtual 556\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:close\011()V
    //   376: aload_2
    //   377: athrow
    //   378: aload_3
    //   379: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   382: aload 4
    //   384: invokevirtual 490\011java/io/OutputStream:flush\011()V
    //   387: iload 6
    //   389: ifeq +33 -> 422
    //   392: aload 4
    //   394: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   397: goto +30 -> 427
    //   400: astore_1
    //   401: aload_3
    //   402: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   405: aload 4
    //   407: invokevirtual 490\011java/io/OutputStream:flush\011()V
    //   410: iload 6
    //   412: ifeq +8 -> 420
    //   415: aload 4
    //   417: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   420: aload_1
    //   421: athrow
    //   422: return
    //   423: dup
    //   424: astore 4
    //   426: athrow
    //   427: return
    //
    // Exception table:
    //   from\011to\011target\011type
    //   178\011238\011241\011lw/bouncycastle/openpgp/PGPException
    //   271\011334\011356\011finally
    //   248\011378\011400\011finally
    //   40\011422\011423\011java/io/IOException
  }

  private void a(InputStream paramInputStream, String paramString, PGPPublicKey[] paramArrayOfPGPPublicKey, OutputStream paramOutputStream, boolean paramBoolean)
    throws PGPException, IOException
  {
    a("Encrypting in PGP 2.x compatibility mode");
    if ((paramString == null) || ("".equals(paramString.trim())))
    {
      a("No internal file name label was specified. Using {0} instead.", "_CONSOLE");
      paramString = "_CONSOLE";
    }
    paramOutputStream = paramOutputStream;
    if (paramBoolean)
    {
      a("Output is ASCII armored");
      paramOutputStream = paramOutputStream;
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
      a(paramOutputStream);
    }
    a("Cipher used is {0}", KeyStore.c(1));
    PGPEncryptedDataGenerator localPGPEncryptedDataGenerator = a.CreatePGPEncryptedDataGenerator(1, false, IOUtil.getSecureRandom(), true);
    for (int n = 0; n < paramArrayOfPGPPublicKey.length; n++)
    {
      localPGPEncryptedDataGenerator.addMethod(a.CreatePublicKeyKeyEncryptionMethodGenerator(paramArrayOfPGPPublicKey[n]));
      a("Encrypting for key Id {0}", String.valueOf(paramArrayOfPGPPublicKey[n].getKeyID()));
    }
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
    BaseLib.pipeAll(paramInputStream, localDirectByteArrayOutputStream);
    paramInputStream = new DirectByteArrayOutputStream(1048576);
    paramString = (paramArrayOfPGPPublicKey = new PGPLiteralDataGenerator(true)).open(paramInputStream, i, paramString, localDirectByteArrayOutputStream.size(), new Date());
    localDirectByteArrayOutputStream.writeTo(paramString);
    paramArrayOfPGPPublicKey.close();
    paramString.close();
    try
    {
      paramString = localPGPEncryptedDataGenerator.open(paramOutputStream, paramInputStream.size());
      paramInputStream.writeTo(paramString);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramInputStream = localPGPException);
    }
    IOUtil.closeStream(paramString);
    paramOutputStream.flush();
    if (paramBoolean)
      IOUtil.closeStream(paramOutputStream);
  }

  // ERROR //
  private void a(InputStream paramInputStream, String paramString1, String paramString2, OutputStream paramOutputStream, boolean paramBoolean1, boolean paramBoolean2)
    throws PGPException
  {
    // Byte code:
    //   0: iload 5
    //   2: ifeq +24 -> 26
    //   5: aload 4
    //   7: astore 4
    //   9: new 224\011lw/bouncycastle/bcpg/ArmoredOutputStream
    //   12: dup
    //   13: aload 4
    //   15: invokespecial 549\011lw/bouncycastle/bcpg/ArmoredOutputStream:<init>\011(Ljava/io/OutputStream;)V
    //   18: astore 4
    //   20: aload_0
    //   21: aload 4
    //   23: invokespecial 306\011com/didisoft/pgp/PGPLib:a\011(Ljava/io/OutputStream;)V
    //   26: aload_0
    //   27: getfield 265\011com/didisoft/pgp/PGPLib:d\011Ljava/lang/String;
    //   30: invokestatic 288\011com/didisoft/pgp/KeyStore:b\011(Ljava/lang/String;)I
    //   33: istore 7
    //   35: aload_0
    //   36: getfield 264\011com/didisoft/pgp/PGPLib:c\011Ljava/lang/String;
    //   39: invokestatic 290\011com/didisoft/pgp/KeyStore:c\011(Ljava/lang/String;)I
    //   42: istore 8
    //   44: aload_0
    //   45: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   48: iload 8
    //   50: iload 6
    //   52: invokestatic 445\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   55: invokevirtual 423\011com/didisoft/pgp/bc/BCFactory:CreatePGPEncryptedDataGenerator\011(IZLjava/security/SecureRandom;)Llw/bouncycastle/openpgp/PGPEncryptedDataGenerator;
    //   58: astore 6
    //   60: aload 6
    //   62: aload_0
    //   63: getfield 262\011com/didisoft/pgp/PGPLib:a\011Lcom/didisoft/pgp/bc/BCFactory;
    //   66: aload_3
    //   67: invokevirtual 420\011com/didisoft/pgp/bc/BCFactory:CreatePBEKeyEncryptionMethodGenerator\011(Ljava/lang/String;)Llw/bouncycastle/openpgp/operator/PBEKeyEncryptionMethodGenerator;
    //   70: invokevirtual 561\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:addMethod\011(Llw/bouncycastle/openpgp/operator/PGPKeyEncryptionMethodGenerator;)V
    //   73: aload_0
    //   74: ldc 56
    //   76: invokespecial 308\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;)V
    //   79: aload 6
    //   81: aload 4
    //   83: ldc 3
    //   85: newarray byte
    //   87: invokevirtual 564\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:open\011(Ljava/io/OutputStream;[B)Ljava/io/OutputStream;
    //   90: astore_3
    //   91: goto +10 -> 101
    //   94: dup
    //   95: astore 6
    //   97: invokestatic 446\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   100: athrow
    //   101: new 227\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator
    //   104: dup
    //   105: iload 7
    //   107: invokespecial 555\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:<init>\011(I)V
    //   110: astore 6
    //   112: new 233\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator
    //   115: dup
    //   116: invokespecial 571\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:<init>\011()V
    //   119: astore 8
    //   121: iload 7
    //   123: ifne +34 -> 157
    //   126: aload 8
    //   128: aload_3
    //   129: aload_0
    //   130: invokevirtual 374\011com/didisoft/pgp/PGPLib:getContentType\011()C
    //   133: aload_2
    //   134: new 217\011java/util/Date
    //   137: dup
    //   138: invokespecial 540\011java/util/Date:<init>\011()V
    //   141: ldc 3
    //   143: newarray byte
    //   145: invokevirtual 575\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:open\011(Ljava/io/OutputStream;CLjava/lang/String;Ljava/util/Date;[B)Ljava/io/OutputStream;
    //   148: astore_2
    //   149: aload_1
    //   150: aload_2
    //   151: invokestatic 376\011com/didisoft/pgp/PGPLib:pipeAll\011(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   154: goto +36 -> 190
    //   157: aload 8
    //   159: aload 6
    //   161: aload_3
    //   162: invokevirtual 557\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:open\011(Ljava/io/OutputStream;)Ljava/io/OutputStream;
    //   165: aload_0
    //   166: invokevirtual 374\011com/didisoft/pgp/PGPLib:getContentType\011()C
    //   169: aload_2
    //   170: new 217\011java/util/Date
    //   173: dup
    //   174: invokespecial 540\011java/util/Date:<init>\011()V
    //   177: ldc 3
    //   179: newarray byte
    //   181: invokevirtual 575\011lw/bouncycastle/openpgp/PGPLiteralDataGenerator:open\011(Ljava/io/OutputStream;CLjava/lang/String;Ljava/util/Date;[B)Ljava/io/OutputStream;
    //   184: astore_2
    //   185: aload_1
    //   186: aload_2
    //   187: invokestatic 376\011com/didisoft/pgp/PGPLib:pipeAll\011(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   190: aload_2
    //   191: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   194: aload 6
    //   196: invokevirtual 556\011lw/bouncycastle/openpgp/PGPCompressedDataGenerator:close\011()V
    //   199: aload_1
    //   200: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   203: aload_3
    //   204: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   207: aload 4
    //   209: invokevirtual 490\011java/io/OutputStream:flush\011()V
    //   212: iload 5
    //   214: ifeq +37 -> 251
    //   217: aload 4
    //   219: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   222: goto +47 -> 269
    //   225: astore_2
    //   226: aload_1
    //   227: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   230: aload_3
    //   231: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   234: aload 4
    //   236: invokevirtual 490\011java/io/OutputStream:flush\011()V
    //   239: iload 5
    //   241: ifeq +8 -> 249
    //   244: aload 4
    //   246: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   249: aload_2
    //   250: athrow
    //   251: return
    //   252: astore 4
    //   254: new 162\011com/didisoft/pgp/PGPException
    //   257: dup
    //   258: aload 4
    //   260: invokevirtual 483\011java/io/IOException:getMessage\011()Ljava/lang/String;
    //   263: aload 4
    //   265: invokespecial 295\011com/didisoft/pgp/PGPException:<init>\011(Ljava/lang/String;Ljava/lang/Exception;)V
    //   268: athrow
    //   269: return
    //
    // Exception table:
    //   from\011to\011target\011type
    //   60\01191\01194\011lw/bouncycastle/openpgp/PGPException
    //   101\011199\011225\011finally
    //   0\011251\011252\011java/io/IOException
  }

  private String a(PGPLiteralData paramPGPLiteralData, PGPSignature paramPGPSignature, OutputStream paramOutputStream)
    throws IOException
  {
    String str = paramPGPLiteralData.getFileName();
    a("Found literal data packet");
    a("Decrypted file original name is {0}", str);
    InputStream localInputStream = null;
    try
    {
      localInputStream = paramPGPLiteralData.getInputStream();
      paramPGPLiteralData = new byte[1048576];
      int n;
      while ((n = localInputStream.read(paramPGPLiteralData, 0, paramPGPLiteralData.length)) >= 0)
      {
        if (paramPGPSignature != null)
          paramPGPSignature.update(paramPGPLiteralData, 0, n);
        if (paramOutputStream != null)
          paramOutputStream.write(paramPGPLiteralData, 0, n);
      }
      IOUtil.closeStream(localInputStream);
    }
    finally
    {
      IOUtil.closeStream(localInputStream);
    }
    return str;
  }

  private String[] a(PGPLiteralData paramPGPLiteralData, PGPSignature paramPGPSignature, String paramString1, String paramString2)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: ldc 59
    //   3: invokespecial 308\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;)V
    //   6: aload_1
    //   7: invokevirtual 569\011lw/bouncycastle/openpgp/PGPLiteralData:getFileName\011()Ljava/lang/String;
    //   10: dup
    //   11: astore 5
    //   13: invokevirtual 512\011java/lang/String:toUpperCase\011()Ljava/lang/String;
    //   16: ldc 14
    //   18: invokevirtual 505\011java/lang/String:endsWith\011(Ljava/lang/String;)Z
    //   21: ifeq +35 -> 56
    //   24: aload_0
    //   25: getfield 273\011com/didisoft/pgp/PGPLib:l\011Z
    //   28: ifeq +28 -> 56
    //   31: aload_0
    //   32: ldc 60
    //   34: invokespecial 308\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;)V
    //   37: new 255\011org/apache/tools/tar/TarInputStream
    //   40: dup
    //   41: aload_1
    //   42: invokevirtual 570\011lw/bouncycastle/openpgp/PGPLiteralData:getInputStream\011()Ljava/io/InputStream;
    //   45: invokespecial 637\011org/apache/tools/tar/TarInputStream:<init>\011(Ljava/io/InputStream;)V
    //   48: dup
    //   49: astore 6
    //   51: aload_3
    //   52: invokevirtual 638\011org/apache/tools/tar/TarInputStream:extractAll\011(Ljava/lang/String;)[Ljava/lang/String;
    //   55: areturn
    //   56: aconst_null
    //   57: astore 6
    //   59: aload 5
    //   61: ifnull +13 -> 74
    //   64: ldc 4
    //   66: aload 5
    //   68: invokevirtual 506\011java/lang/String:equals\011(Ljava/lang/Object;)Z
    //   71: ifeq +63 -> 134
    //   74: aload 4
    //   76: ifnull +54 -> 130
    //   79: ldc 4
    //   81: aload 4
    //   83: invokevirtual 506\011java/lang/String:equals\011(Ljava/lang/Object;)Z
    //   86: ifne +44 -> 130
    //   89: new 191\011java/io/File
    //   92: dup
    //   93: aload 4
    //   95: invokespecial 470\011java/io/File:<init>\011(Ljava/lang/String;)V
    //   98: invokevirtual 475\011java/io/File:getName\011()Ljava/lang/String;
    //   101: dup
    //   102: astore 5
    //   104: ldc 10
    //   106: invokevirtual 508\011java/lang/String:lastIndexOf\011(Ljava/lang/String;)I
    //   109: ifle +25 -> 134
    //   112: aload 5
    //   114: iconst_0
    //   115: aload 5
    //   117: ldc 10
    //   119: invokevirtual 508\011java/lang/String:lastIndexOf\011(Ljava/lang/String;)I
    //   122: invokevirtual 510\011java/lang/String:substring\011(II)Ljava/lang/String;
    //   125: astore 5
    //   127: goto +7 -> 134
    //   130: ldc 145
    //   132: astore 5
    //   134: new 193\011java/io/FileOutputStream
    //   137: dup
    //   138: new 209\011java/lang/StringBuilder
    //   141: dup
    //   142: invokespecial 520\011java/lang/StringBuilder:<init>\011()V
    //   145: aload_3
    //   146: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: getstatic 280\011java/io/File:separator\011Ljava/lang/String;
    //   152: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: aload 5
    //   157: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: invokevirtual 526\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   163: invokespecial 481\011java/io/FileOutputStream:<init>\011(Ljava/lang/String;)V
    //   166: astore 6
    //   168: aload_0
    //   169: ldc 58
    //   171: new 209\011java/lang/StringBuilder
    //   174: dup
    //   175: invokespecial 520\011java/lang/StringBuilder:<init>\011()V
    //   178: aload_3
    //   179: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   182: getstatic 280\011java/io/File:separator\011Ljava/lang/String;
    //   185: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: aload 5
    //   190: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: invokevirtual 526\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   196: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   199: aload_1
    //   200: invokevirtual 570\011lw/bouncycastle/openpgp/PGPLiteralData:getInputStream\011()Ljava/io/InputStream;
    //   203: astore_1
    //   204: ldc 3
    //   206: newarray byte
    //   208: astore_3
    //   209: aload_1
    //   210: aload_3
    //   211: iconst_0
    //   212: aload_3
    //   213: arraylength
    //   214: invokevirtual 487\011java/io/InputStream:read\011([BII)I
    //   217: dup
    //   218: istore 4
    //   220: iflt +27 -> 247
    //   223: aload_2
    //   224: ifnull +11 -> 235
    //   227: aload_2
    //   228: aload_3
    //   229: iconst_0
    //   230: iload 4
    //   232: invokevirtual 619\011lw/bouncycastle/openpgp/PGPSignature:update\011([BII)V
    //   235: aload 6
    //   237: aload_3
    //   238: iconst_0
    //   239: iload 4
    //   241: invokevirtual 482\011java/io/FileOutputStream:write\011([BII)V
    //   244: goto -35 -> 209
    //   247: aload_1
    //   248: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   251: aload 6
    //   253: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   256: goto +11 -> 267
    //   259: astore_1
    //   260: aload 6
    //   262: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   265: aload_1
    //   266: athrow
    //   267: iconst_1
    //   268: anewarray 207\011java/lang/String
    //   271: dup
    //   272: iconst_0
    //   273: aload 5
    //   275: aastore
    //   276: areturn
    //
    // Exception table:
    //   from\011to\011target\011type
    //   59\011251\011259\011finally
  }

  private String a(PGPLiteralData paramPGPLiteralData, PGPOnePassSignature paramPGPOnePassSignature, OutputStream paramOutputStream)
    throws IOException
  {
    String str = paramPGPLiteralData.getFileName();
    paramPGPLiteralData = paramPGPLiteralData.getInputStream();
    a("Found literal data packet");
    a("Decrypted file original name is {0}", str);
    byte[] arrayOfByte = new byte[1048576];
    try
    {
      int n;
      while ((n = paramPGPLiteralData.read(arrayOfByte, 0, arrayOfByte.length)) >= 0)
      {
        if (paramPGPOnePassSignature != null)
          paramPGPOnePassSignature.update(arrayOfByte, 0, n);
        if (paramOutputStream != null)
          paramOutputStream.write(arrayOfByte, 0, n);
      }
      IOUtil.closeStream(paramPGPLiteralData);
    }
    finally
    {
      IOUtil.closeStream(paramPGPLiteralData);
    }
    return str;
  }

  private String[] a(PGPLiteralData paramPGPLiteralData, PGPOnePassSignature paramPGPOnePassSignature, String paramString1, String paramString2)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: ldc 59
    //   3: invokespecial 308\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;)V
    //   6: aload_1
    //   7: invokevirtual 569\011lw/bouncycastle/openpgp/PGPLiteralData:getFileName\011()Ljava/lang/String;
    //   10: dup
    //   11: astore 5
    //   13: invokevirtual 512\011java/lang/String:toUpperCase\011()Ljava/lang/String;
    //   16: ldc 14
    //   18: invokevirtual 505\011java/lang/String:endsWith\011(Ljava/lang/String;)Z
    //   21: ifeq +35 -> 56
    //   24: aload_0
    //   25: getfield 273\011com/didisoft/pgp/PGPLib:l\011Z
    //   28: ifeq +28 -> 56
    //   31: aload_0
    //   32: ldc 60
    //   34: invokespecial 308\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;)V
    //   37: new 255\011org/apache/tools/tar/TarInputStream
    //   40: dup
    //   41: aload_1
    //   42: invokevirtual 570\011lw/bouncycastle/openpgp/PGPLiteralData:getInputStream\011()Ljava/io/InputStream;
    //   45: invokespecial 637\011org/apache/tools/tar/TarInputStream:<init>\011(Ljava/io/InputStream;)V
    //   48: dup
    //   49: astore 6
    //   51: aload_3
    //   52: invokevirtual 638\011org/apache/tools/tar/TarInputStream:extractAll\011(Ljava/lang/String;)[Ljava/lang/String;
    //   55: areturn
    //   56: aload_1
    //   57: invokevirtual 570\011lw/bouncycastle/openpgp/PGPLiteralData:getInputStream\011()Ljava/io/InputStream;
    //   60: astore 6
    //   62: aload_0
    //   63: ldc 34
    //   65: aload_1
    //   66: invokevirtual 569\011lw/bouncycastle/openpgp/PGPLiteralData:getFileName\011()Ljava/lang/String;
    //   69: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   72: aload 5
    //   74: ifnull +13 -> 87
    //   77: ldc 4
    //   79: aload 5
    //   81: invokevirtual 506\011java/lang/String:equals\011(Ljava/lang/Object;)Z
    //   84: ifeq +63 -> 147
    //   87: aload 4
    //   89: ifnull +54 -> 143
    //   92: ldc 4
    //   94: aload 4
    //   96: invokevirtual 506\011java/lang/String:equals\011(Ljava/lang/Object;)Z
    //   99: ifne +44 -> 143
    //   102: new 191\011java/io/File
    //   105: dup
    //   106: aload 4
    //   108: invokespecial 470\011java/io/File:<init>\011(Ljava/lang/String;)V
    //   111: invokevirtual 475\011java/io/File:getName\011()Ljava/lang/String;
    //   114: dup
    //   115: astore 5
    //   117: ldc 10
    //   119: invokevirtual 508\011java/lang/String:lastIndexOf\011(Ljava/lang/String;)I
    //   122: ifle +25 -> 147
    //   125: aload 5
    //   127: iconst_0
    //   128: aload 5
    //   130: ldc 10
    //   132: invokevirtual 508\011java/lang/String:lastIndexOf\011(Ljava/lang/String;)I
    //   135: invokevirtual 510\011java/lang/String:substring\011(II)Ljava/lang/String;
    //   138: astore 5
    //   140: goto +7 -> 147
    //   143: ldc 145
    //   145: astore 5
    //   147: aload_0
    //   148: ldc 58
    //   150: new 209\011java/lang/StringBuilder
    //   153: dup
    //   154: invokespecial 520\011java/lang/StringBuilder:<init>\011()V
    //   157: aload_3
    //   158: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: getstatic 280\011java/io/File:separator\011Ljava/lang/String;
    //   164: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: aload 5
    //   169: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: invokevirtual 526\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   175: invokespecial 309\011com/didisoft/pgp/PGPLib:a\011(Ljava/lang/String;Ljava/lang/String;)V
    //   178: new 193\011java/io/FileOutputStream
    //   181: dup
    //   182: new 209\011java/lang/StringBuilder
    //   185: dup
    //   186: invokespecial 520\011java/lang/StringBuilder:<init>\011()V
    //   189: aload_3
    //   190: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: getstatic 280\011java/io/File:separator\011Ljava/lang/String;
    //   196: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   199: aload 5
    //   201: invokevirtual 525\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   204: invokevirtual 526\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   207: invokespecial 481\011java/io/FileOutputStream:<init>\011(Ljava/lang/String;)V
    //   210: astore_1
    //   211: ldc 3
    //   213: newarray byte
    //   215: astore_3
    //   216: aload 6
    //   218: aload_3
    //   219: iconst_0
    //   220: aload_3
    //   221: arraylength
    //   222: invokevirtual 487\011java/io/InputStream:read\011([BII)I
    //   225: dup
    //   226: istore 4
    //   228: iflt +26 -> 254
    //   231: aload_2
    //   232: ifnull +11 -> 243
    //   235: aload_2
    //   236: aload_3
    //   237: iconst_0
    //   238: iload 4
    //   240: invokevirtual 579\011lw/bouncycastle/openpgp/PGPOnePassSignature:update\011([BII)V
    //   243: aload_1
    //   244: aload_3
    //   245: iconst_0
    //   246: iload 4
    //   248: invokevirtual 482\011java/io/FileOutputStream:write\011([BII)V
    //   251: goto -35 -> 216
    //   254: aload 6
    //   256: invokestatic 443\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/InputStream;)V
    //   259: aload_1
    //   260: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   263: goto +10 -> 273
    //   266: astore_2
    //   267: aload_1
    //   268: invokestatic 444\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   271: aload_2
    //   272: athrow
    //   273: iconst_1
    //   274: anewarray 207\011java/lang/String
    //   277: dup
    //   278: iconst_0
    //   279: aload 5
    //   281: aastore
    //   282: areturn
    //
    // Exception table:
    //   from\011to\011target\011type
    //   216\011259\011266\011finally
  }

  private String a(PGPCompressedData paramPGPCompressedData, boolean paramBoolean, a parama, KeyStore paramKeyStore, InputStream paramInputStream, OutputStream paramOutputStream)
    throws PGPException, IOException
  {
    a("Decrypted data compression algorithm is {0}", KeyStore.a(paramPGPCompressedData.getAlgorithm()));
    Object localObject1;
    try
    {
      paramPGPCompressedData.getDataStream();
      paramPGPCompressedData = new BufferedInputStream(paramPGPCompressedData.getDataStream());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(localObject1 = localPGPException);
    }
    try
    {
      Object localObject2;
      if (((localObject2 = (localObject1 = new PGPObjectFactory2(paramPGPCompressedData)).nextObject()) instanceof PGPLiteralData))
      {
        paramBoolean = a((PGPLiteralData)localObject2, null, paramOutputStream);
        return paramBoolean;
      }
      if ((localObject2 instanceof PGPOnePassSignatureList))
      {
        if (paramBoolean)
        {
          paramBoolean = a((PGPOnePassSignatureList)localObject2, (PGPObjectFactory)localObject1, paramKeyStore, paramInputStream, paramOutputStream, parama);
          return paramBoolean;
        }
        paramBoolean = a((PGPOnePassSignatureList)localObject2, (PGPObjectFactory)localObject1, null, null, paramOutputStream, parama);
        return paramBoolean;
      }
      if ((localObject2 instanceof PGPSignatureList))
      {
        if (paramBoolean)
        {
          paramBoolean = a((PGPSignatureList)localObject2, (PGPObjectFactory)localObject1, paramKeyStore, paramInputStream, paramOutputStream, parama);
          return paramBoolean;
        }
        paramBoolean = a((PGPSignatureList)localObject2, (PGPObjectFactory)localObject1, null, null, paramOutputStream, parama);
        return paramBoolean;
      }
      throw new PGPException("Unknown message format: " + localObject2.getClass().getName());
    }
    finally
    {
      IOUtil.closeStream(paramPGPCompressedData);
    }
    throw paramBoolean;
  }

  private String[] a(PGPCompressedData paramPGPCompressedData, boolean paramBoolean, a parama, KeyStore paramKeyStore, InputStream paramInputStream, String paramString1, String paramString2)
    throws PGPException, IOException
  {
    a("Decrypted data compression algorithm is {0}", KeyStore.a(paramPGPCompressedData.getAlgorithm()));
    Object localObject1;
    try
    {
      paramPGPCompressedData = new BufferedInputStream(paramPGPCompressedData.getDataStream());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(localObject1 = localPGPException);
    }
    try
    {
      Object localObject2;
      if (((localObject2 = (localObject1 = new PGPObjectFactory2(paramPGPCompressedData)).nextObject()) instanceof PGPLiteralData))
      {
        paramBoolean = a((PGPLiteralData)localObject2, null, paramString1, paramString2);
        return paramBoolean;
      }
      if ((localObject2 instanceof PGPOnePassSignatureList))
      {
        if (paramBoolean)
        {
          paramBoolean = a((PGPOnePassSignatureList)localObject2, (PGPObjectFactory)localObject1, paramKeyStore, paramInputStream, paramString1, paramString2, parama);
          return paramBoolean;
        }
        paramBoolean = a((PGPOnePassSignatureList)localObject2, (PGPObjectFactory)localObject1, null, null, paramString1, paramString2, parama);
        return paramBoolean;
      }
      if ((localObject2 instanceof PGPSignatureList))
      {
        if (paramBoolean)
        {
          paramBoolean = a((PGPSignatureList)localObject2, (PGPObjectFactory)localObject1, paramKeyStore, paramInputStream, paramString1, paramString2, parama);
          return paramBoolean;
        }
        paramBoolean = a((PGPSignatureList)localObject2, (PGPObjectFactory)localObject1, null, null, paramString1, paramString2, parama);
        return paramBoolean;
      }
      throw new PGPException("Unknown message format: " + localObject2.getClass().getName());
    }
    finally
    {
      IOUtil.closeStream(paramPGPCompressedData);
    }
    throw paramBoolean;
  }

  private String a(PGPOnePassSignatureList paramPGPOnePassSignatureList, PGPObjectFactory paramPGPObjectFactory, KeyStore paramKeyStore, InputStream paramInputStream, OutputStream paramOutputStream, a parama)
    throws PGPException, IOException
  {
    a("Found signature");
    PGPOnePassSignature localPGPOnePassSignature = null;
    PGPPublicKey localPGPPublicKey = null;
    if ((paramInputStream != null) || (paramKeyStore != null))
    {
      for (int n = 0; n != paramPGPOnePassSignatureList.size(); n++)
      {
        localPGPOnePassSignature = paramPGPOnePassSignatureList.get(n);
        if (paramInputStream != null)
          localPGPPublicKey = readPublicVerificationKey(paramInputStream, localPGPOnePassSignature.getKeyID());
        else
          localPGPPublicKey = readPublicVerificationKey(paramKeyStore, localPGPOnePassSignature.getKeyID());
        if (localPGPPublicKey != null)
        {
          a("Message signed with Key Id {0}", KeyPairInformation.keyId2Hex(localPGPPublicKey.getKeyID()));
          break;
        }
        a("Message signed with Unknown Key Id {0}", KeyPairInformation.keyId2Hex(localPGPOnePassSignature.getKeyID()));
      }
      if (localPGPPublicKey != null)
        a.initVerify(localPGPOnePassSignature, localPGPPublicKey);
    }
    Object localObject;
    if (((localObject = paramPGPObjectFactory.nextObject()) instanceof PGPLiteralData))
      paramPGPOnePassSignatureList = a((PGPLiteralData)localObject, localPGPPublicKey != null ? localPGPOnePassSignature : null, paramOutputStream);
    else
      throw new PGPException("Unknown message format: " + localObject.getClass().getName());
    if ((paramInputStream != null) || (paramKeyStore != null))
      if (localPGPPublicKey == null)
      {
        a("The signature of the message does not correspond to the provided public key.");
        parama.a = SignatureCheckResult.PublicKeyNotMatching;
      }
      else if (((paramPGPObjectFactory = paramPGPObjectFactory.nextObject()) != null) && (localPGPOnePassSignature != null))
      {
        paramPGPObjectFactory = (PGPSignatureList)paramPGPObjectFactory;
        try
        {
          if (!localPGPOnePassSignature.verify(paramPGPObjectFactory.get(0)))
          {
            a("The signature of the message did not passed verification.");
            parama.a = SignatureCheckResult.SignatureBroken;
          }
          else
          {
            parama.a = SignatureCheckResult.SignatureVerified;
          }
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException)
        {
          throw IOUtil.newPGPException(paramPGPOnePassSignatureList = localPGPException);
        }
      }
    return paramPGPOnePassSignatureList;
  }

  private String[] a(PGPOnePassSignatureList paramPGPOnePassSignatureList, PGPObjectFactory paramPGPObjectFactory, KeyStore paramKeyStore, InputStream paramInputStream, String paramString1, String paramString2, a parama)
    throws PGPException, IOException
  {
    a("Found signature");
    PGPOnePassSignature localPGPOnePassSignature = null;
    PGPPublicKey localPGPPublicKey = null;
    if ((paramInputStream != null) || (paramKeyStore != null))
    {
      for (int n = 0; n != paramPGPOnePassSignatureList.size(); n++)
      {
        localPGPOnePassSignature = paramPGPOnePassSignatureList.get(n);
        if (paramInputStream != null)
          localPGPPublicKey = readPublicVerificationKey(paramInputStream, localPGPOnePassSignature.getKeyID());
        else
          localPGPPublicKey = readPublicVerificationKey(paramKeyStore, localPGPOnePassSignature.getKeyID());
        if (localPGPPublicKey != null)
        {
          a("The message is signed with Key Id {0}", KeyPairInformation.keyId2Hex(localPGPPublicKey.getKeyID()));
          break;
        }
        a("The message is signed with Unknown Key Id {0}", KeyPairInformation.keyId2Hex(localPGPOnePassSignature.getKeyID()));
      }
      if (localPGPPublicKey != null)
        a.initVerify(localPGPOnePassSignature, localPGPPublicKey);
    }
    Object localObject;
    if (((localObject = paramPGPObjectFactory.nextObject()) instanceof PGPLiteralData))
      paramPGPOnePassSignatureList = a((PGPLiteralData)localObject, localPGPPublicKey != null ? localPGPOnePassSignature : null, paramString1, paramString2);
    else
      throw new PGPException("Unknown message format: " + localObject.getClass().getName());
    if ((paramInputStream != null) || (paramKeyStore != null))
      if (localPGPPublicKey == null)
      {
        a("The signature of the message does not correspond to the provided public key.");
        parama.a = SignatureCheckResult.PublicKeyNotMatching;
      }
      else if (((paramPGPObjectFactory = paramPGPObjectFactory.nextObject()) != null) && (localPGPOnePassSignature != null))
      {
        paramPGPObjectFactory = (PGPSignatureList)paramPGPObjectFactory;
        try
        {
          if (!localPGPOnePassSignature.verify(paramPGPObjectFactory.get(0)))
          {
            a("The signature of the message did not passed verification.");
            parama.a = SignatureCheckResult.SignatureBroken;
          }
          else
          {
            a("The signature of the message passed verification.");
            parama.a = SignatureCheckResult.SignatureVerified;
          }
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException)
        {
          throw IOUtil.newPGPException(paramPGPOnePassSignatureList = localPGPException);
        }
      }
    return paramPGPOnePassSignatureList;
  }

  private String a(PGPSignatureList paramPGPSignatureList, PGPObjectFactory paramPGPObjectFactory, KeyStore paramKeyStore, InputStream paramInputStream, OutputStream paramOutputStream, a parama)
    throws PGPException, IOException
  {
    a("Found signature version 3");
    PGPSignature localPGPSignature = null;
    PGPPublicKey localPGPPublicKey = null;
    if ((paramInputStream != null) || (paramKeyStore != null))
    {
      for (int n = 0; n < paramPGPSignatureList.size(); n++)
        if (((localPGPSignature = paramPGPSignatureList.get(n)).getSignatureType() == 0) || (localPGPSignature.getSignatureType() == 1) || (localPGPSignature.getSignatureType() == 16))
        {
          if (paramInputStream != null)
            localPGPPublicKey = readPublicVerificationKey(paramInputStream, localPGPSignature.getKeyID());
          else
            localPGPPublicKey = readPublicVerificationKey(paramKeyStore, localPGPSignature.getKeyID());
          if (localPGPPublicKey != null)
          {
            a("The message is signed with Key Id {0}", KeyPairInformation.keyId2Hex(localPGPPublicKey.getKeyID()));
            break;
          }
          a("The message is signed with Unknown Key Id {0}", KeyPairInformation.keyId2Hex(localPGPSignature.getKeyID()));
        }
      if (localPGPPublicKey != null)
        a.initVerify(localPGPSignature, localPGPPublicKey);
    }
    Object localObject;
    if (((localObject = paramPGPObjectFactory.nextObject()) instanceof PGPLiteralData))
    {
      paramPGPSignatureList = a((PGPLiteralData)localObject, localPGPPublicKey != null ? localPGPSignature : null, paramOutputStream);
    }
    else
    {
      if (localObject == null)
        throw new DetachedSignatureException("This is a detached signature file");
      throw new PGPException("Unknown message format: " + localObject.getClass().getName());
    }
    if ((paramInputStream != null) || (paramKeyStore != null))
      if (localPGPPublicKey == null)
      {
        a("The signature of the message does not correspond to the provided public key.");
        parama.a = SignatureCheckResult.PublicKeyNotMatching;
      }
      else
      {
        try
        {
          if (!localPGPSignature.verify())
          {
            a("The signature of the message did not passed verification.");
            parama.a = SignatureCheckResult.SignatureBroken;
          }
          else
          {
            parama.a = SignatureCheckResult.SignatureVerified;
          }
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException)
        {
          throw IOUtil.newPGPException(paramPGPSignatureList = localPGPException);
        }
      }
    return paramPGPSignatureList;
  }

  private String[] a(PGPSignatureList paramPGPSignatureList, PGPObjectFactory paramPGPObjectFactory, KeyStore paramKeyStore, InputStream paramInputStream, String paramString1, String paramString2, a parama)
    throws PGPException, IOException
  {
    PGPSignature localPGPSignature = null;
    PGPPublicKey localPGPPublicKey = null;
    if ((paramInputStream != null) || (paramKeyStore != null))
    {
      for (int n = 0; n < paramPGPSignatureList.size(); n++)
        if (((localPGPSignature = paramPGPSignatureList.get(n)).getSignatureType() == 0) || (localPGPSignature.getSignatureType() == 1) || (localPGPSignature.getSignatureType() == 16))
        {
          if (paramInputStream != null)
            localPGPPublicKey = readPublicVerificationKey(paramInputStream, localPGPSignature.getKeyID());
          else
            localPGPPublicKey = readPublicVerificationKey(paramKeyStore, localPGPSignature.getKeyID());
          if (localPGPPublicKey != null)
          {
            a("Message signed with Key Id {0}", KeyPairInformation.keyId2Hex(localPGPPublicKey.getKeyID()));
            break;
          }
          a("Message signed with Unknown Key Id {0}", KeyPairInformation.keyId2Hex(localPGPSignature.getKeyID()));
        }
      if (localPGPPublicKey != null)
        a.initVerify(localPGPSignature, localPGPPublicKey);
    }
    Object localObject;
    if (((localObject = paramPGPObjectFactory.nextObject()) instanceof PGPLiteralData))
    {
      paramPGPSignatureList = a((PGPLiteralData)localObject, localPGPPublicKey != null ? localPGPSignature : null, paramString1, paramString2);
    }
    else
    {
      if (localObject == null)
        throw new DetachedSignatureException("This is a detached signature file");
      throw new PGPException("Unknown message format: " + localObject.getClass().getName());
    }
    if ((paramInputStream != null) || (paramKeyStore != null))
    {
      if (localPGPPublicKey == null)
      {
        a("The signature of the message does not correspond to the provided public key.");
        parama.a = SignatureCheckResult.PublicKeyNotMatching;
      }
      try
      {
        if (!localPGPSignature.verify())
        {
          a("The signature of the message did not passed verification.");
          parama.a = SignatureCheckResult.SignatureBroken;
        }
        else
        {
          a("The signature of the message passed verification.");
          parama.a = SignatureCheckResult.SignatureVerified;
        }
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        throw IOUtil.newPGPException(paramPGPSignatureList = localPGPException);
      }
    }
    return paramPGPSignatureList;
  }

  private String a(PGPEncryptedDataList paramPGPEncryptedDataList, boolean paramBoolean, a parama, String paramString, KeyStore paramKeyStore, InputStream paramInputStream, OutputStream paramOutputStream)
    throws IOException, WrongPasswordException, PGPException
  {
    paramBoolean = null;
    paramKeyStore = null;
    paramInputStream = null;
    Object localObject;
    if ((paramPGPEncryptedDataList instanceof PGP2xPBEEncryptedData))
    {
      try
      {
        a("Password encrypted data packet found");
        paramKeyStore = ((PGP2xPBEEncryptedData)paramPGPEncryptedDataList).getDataStream(paramString.toCharArray());
      }
      catch (PGPDataValidationException paramPGPEncryptedDataList)
      {
        throw new WrongPasswordException("The supplied password is incorrect.", paramPGPEncryptedDataList.getUnderlyingException());
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
      {
        throw IOUtil.newPGPException(paramPGPEncryptedDataList = localPGPException1);
      }
    }
    else
    {
      paramPGPEncryptedDataList = paramPGPEncryptedDataList.getEncryptedDataObjects();
      while (paramPGPEncryptedDataList.hasNext())
        if (((localObject = paramPGPEncryptedDataList.next()) instanceof PGPPBEEncryptedData))
        {
          a("Password encrypted data packet found");
          paramInputStream = (PGPPBEEncryptedData)localObject;
          try
          {
            paramKeyStore = paramInputStream.getDataStream(a.CreatePBEDataDecryptorFactory(paramString));
          }
          catch (PGPDataValidationException paramBoolean)
          {
            paramBoolean = new WrongPasswordException("The supplied password is incorrect.", paramBoolean.getUnderlyingException());
          }
          catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
          {
            throw IOUtil.newPGPException(paramBoolean = localPGPException2);
          }
        }
    }
    if ((paramKeyStore == null) && (paramBoolean != null))
      throw paramBoolean;
    if (paramKeyStore == null)
      throw new FileIsEncryptedException("The file is encrypted with an OpenPGP key.");
    if (((paramBoolean = (localObject = new PGPObjectFactory2(paramKeyStore)).nextObject()) instanceof PGPCompressedData))
      paramPGPEncryptedDataList = a((PGPCompressedData)paramBoolean, false, parama, null, null, paramOutputStream);
    else if ((paramBoolean instanceof PGPOnePassSignatureList))
      paramPGPEncryptedDataList = a((PGPOnePassSignatureList)paramBoolean, (PGPObjectFactory)localObject, null, null, paramOutputStream, parama);
    else if ((paramBoolean instanceof PGPSignatureList))
      paramPGPEncryptedDataList = a((PGPSignatureList)paramBoolean, (PGPObjectFactory)localObject, null, null, paramOutputStream, parama);
    else if ((paramBoolean instanceof PGPLiteralData))
      paramPGPEncryptedDataList = a((PGPLiteralData)paramBoolean, null, paramOutputStream);
    else
      throw new PGPException("Unknown message format: " + paramBoolean.getClass().getName());
    if ((paramInputStream != null) && (paramInputStream.isIntegrityProtected()))
      try
      {
        if (!paramInputStream.verify())
        {
          a("Integrity check failed!");
          throw new IntegrityCheckException("The encrypted data is corrupted!");
        }
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException3)
      {
      }
    return paramPGPEncryptedDataList;
  }

  private String a(PGPEncryptedDataList paramPGPEncryptedDataList, boolean paramBoolean, a parama, KeyStore paramKeyStore, InputStream paramInputStream1, String paramString, InputStream paramInputStream2, OutputStream paramOutputStream)
    throws IOException, PGPException, WrongPrivateKeyException, WrongPasswordException, FileIsPBEEncryptedException, IntegrityCheckException, DetachedSignatureException
  {
    PGPSecretKeyRingCollection localPGPSecretKeyRingCollection;
    if (paramInputStream1 != null)
      localPGPSecretKeyRingCollection = createPGPSecretKeyRingCollection(paramInputStream1);
    else
      localPGPSecretKeyRingCollection = paramKeyStore.a;
    Object localObject1 = null;
    PGPPrivateKey localPGPPrivateKey = null;
    PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = null;
    String[] arrayOfString;
    a(arrayOfString = new String[paramPGPEncryptedDataList.size()], "Password encrypted");
    Object localObject4;
    Object localObject2;
    for (int n = 0; n < paramPGPEncryptedDataList.size(); n++)
      if (((localObject4 = paramPGPEncryptedDataList.get(n)) instanceof PGPPublicKeyEncryptedData))
      {
        localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localObject4;
        arrayOfString[n] = KeyPairInformation.keyId2Hex(localPGPPublicKeyEncryptedData.getKeyID());
        a("Public key encrypted data packet found");
        a("Encrypted with key {0}", "0".equals(arrayOfString[n]) ? "wildcard" : arrayOfString[n]);
        try
        {
          if (((localPGPPrivateKey = getPrivateKey(localPGPSecretKeyRingCollection, localPGPPublicKeyEncryptedData.getKeyID(), paramString)) != null) && (paramKeyStore != null))
          {
            paramKeyStore.a(localPGPPublicKeyEncryptedData.getKeyID());
            localPGPPrivateKey = getPrivateKey(localPGPSecretKeyRingCollection, localPGPPublicKeyEncryptedData.getKeyID(), paramString);
          }
        }
        catch (WrongPasswordException localWrongPasswordException)
        {
          localPGPPrivateKey = null;
          localObject2 = localWrongPasswordException;
        }
        if (localPGPPrivateKey != null)
          break;
      }
    if ((localPGPPrivateKey == null) && (localObject2 != null))
      throw ((Throwable)localObject2);
    if (localPGPPublicKeyEncryptedData == null)
    {
      a("This file is encrypted with a password.");
      throw new FileIsPBEEncryptedException("This file is encrypted with a password.");
    }
    Object localObject3;
    if (localPGPPrivateKey == null)
    {
      if (paramInputStream1 != null)
      {
        if ((localPGPSecretKeyRingCollection != null) && (localPGPSecretKeyRingCollection.size() == 0))
          throw new WrongPrivateKeyException("Decryption of data encrypted using KEY-ID(s) : " + b(arrayOfString, ",") + " failed, The provided key is not a valid OpenPGP private key.");
        localObject3 = "";
        if ((localObject4 = localPGPSecretKeyRingCollection.getKeyRings()).hasNext())
          localObject3 = KeyPairInformation.keyId2Hex((localObject2 = (PGPSecretKeyRing)((Iterator)localObject4).next()).getSecretKey().getKeyID());
        throw new WrongPrivateKeyException("Decryption of data encrypted using KEY-ID(s) : " + b(arrayOfString, ",") + " failed, using incorrect private KEY-ID :" + (String)localObject3);
      }
      throw new WrongPrivateKeyException("Decryption of data encrypted using KEY-ID(s) : " + b(arrayOfString, ",") + " failed, no matching key was found in the KeyStore.");
    }
    try
    {
      localObject3 = localPGPPublicKeyEncryptedData.getDataStream(a.CreatePublicKeyDataDecryptorFactory(localPGPPrivateKey));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
    {
      throw IOUtil.newPGPException(localObject4 = localPGPException1);
    }
    if (((paramPGPEncryptedDataList = (localObject2 = new PGPObjectFactory2((InputStream)localObject3)).nextObject()) instanceof PGPCompressedData))
    {
      localObject4 = a((PGPCompressedData)paramPGPEncryptedDataList, paramBoolean, parama, paramKeyStore, paramInputStream2, paramOutputStream);
    }
    else if ((paramPGPEncryptedDataList instanceof PGPOnePassSignatureList))
    {
      a("Signature found!");
      if (paramBoolean)
        localObject4 = a((PGPOnePassSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, paramKeyStore, paramInputStream2, paramOutputStream, parama);
      else
        localObject4 = a((PGPOnePassSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, null, null, paramOutputStream, parama);
    }
    else if ((paramPGPEncryptedDataList instanceof PGPSignatureList))
    {
      a("Signature found (version 3, old style)");
      if (paramBoolean)
        localObject4 = a((PGPSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, paramKeyStore, paramInputStream2, paramOutputStream, parama);
      else
        localObject4 = a((PGPSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, null, null, paramOutputStream, parama);
    }
    else if ((paramPGPEncryptedDataList instanceof PGPLiteralData))
    {
      localObject4 = a((PGPLiteralData)paramPGPEncryptedDataList, null, paramOutputStream);
    }
    else
    {
      throw new NonPGPDataException("Unknown message format: " + paramPGPEncryptedDataList.getClass().getName());
    }
    if (localPGPPublicKeyEncryptedData.isIntegrityProtected())
      try
      {
        if (!localPGPPublicKeyEncryptedData.verify())
        {
          a("Integrity check failed!");
          throw new IntegrityCheckException("The encrypted data is corrupted!");
        }
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
      {
      }
    return localObject4;
  }

  private String[] a(PGPEncryptedDataList paramPGPEncryptedDataList, boolean paramBoolean, a parama, KeyStore paramKeyStore, InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, String paramString3)
    throws IOException, WrongPasswordException, WrongPrivateKeyException, PGPException
  {
    PGPPrivateKey localPGPPrivateKey = null;
    PGPSecretKeyRingCollection localPGPSecretKeyRingCollection;
    if (paramInputStream1 != null)
      localPGPSecretKeyRingCollection = createPGPSecretKeyRingCollection(paramInputStream1);
    else
      localPGPSecretKeyRingCollection = paramKeyStore.a;
    Object localObject1 = null;
    PGPPublicKeyEncryptedData localPGPPublicKeyEncryptedData = null;
    String[] arrayOfString;
    a(arrayOfString = new String[paramPGPEncryptedDataList.size()], "Password encrypted");
    Object localObject4;
    Object localObject2;
    for (int n = 0; n < paramPGPEncryptedDataList.size(); n++)
      if (((localObject4 = paramPGPEncryptedDataList.get(n)) instanceof PGPPublicKeyEncryptedData))
      {
        localPGPPublicKeyEncryptedData = (PGPPublicKeyEncryptedData)localObject4;
        arrayOfString[n] = KeyPairInformation.keyId2Hex(localPGPPublicKeyEncryptedData.getKeyID());
        a("Encrypted with key ID {0}", "0".equals(arrayOfString[n]) ? "wildcard" : arrayOfString[n]);
        try
        {
          if (((localPGPPrivateKey = getPrivateKey(localPGPSecretKeyRingCollection, localPGPPublicKeyEncryptedData.getKeyID(), paramString1)) != null) && (paramKeyStore != null))
          {
            paramKeyStore.a(localPGPPublicKeyEncryptedData.getKeyID());
            localPGPPrivateKey = getPrivateKey(localPGPSecretKeyRingCollection, localPGPPublicKeyEncryptedData.getKeyID(), paramString1);
          }
        }
        catch (WrongPasswordException localWrongPasswordException)
        {
          localPGPPrivateKey = null;
          localObject2 = localWrongPasswordException;
        }
        if (localPGPPrivateKey != null)
          break;
      }
    if ((localPGPPrivateKey == null) && (localObject2 != null))
      throw ((Throwable)localObject2);
    if (localPGPPublicKeyEncryptedData == null)
    {
      a("This file is encrypted with a password.");
      throw new FileIsPBEEncryptedException("This file is encrypted with a password.");
    }
    Object localObject3;
    if (localPGPPrivateKey == null)
    {
      if (paramInputStream1 != null)
      {
        if ((localPGPSecretKeyRingCollection != null) && (localPGPSecretKeyRingCollection.size() == 0))
          throw new WrongPrivateKeyException("Decryption of data encrypted using KEY-ID(s) : " + b(arrayOfString, ",") + " failed, The provided key is not a valid OpenPGP private key.");
        localObject3 = "";
        if ((localObject4 = localPGPSecretKeyRingCollection.getKeyRings()).hasNext())
          localObject3 = KeyPairInformation.keyId2Hex((localObject2 = (PGPSecretKeyRing)((Iterator)localObject4).next()).getSecretKey().getKeyID());
        throw new WrongPrivateKeyException("Decryption of data encrypted using KEY-ID(s) : " + b(arrayOfString, ",") + " failed, using incorrect private KEY-ID :" + (String)localObject3);
      }
      throw new WrongPrivateKeyException("Decryption of data encrypted using KEY-ID(s) : " + b(arrayOfString, ",") + " failed, no matching key was found in the KeyStore.");
    }
    try
    {
      localObject3 = localPGPPublicKeyEncryptedData.getDataStream(a.CreatePublicKeyDataDecryptorFactory(localPGPPrivateKey));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
    {
      throw IOUtil.newPGPException(localObject4 = localPGPException1);
    }
    if (((paramPGPEncryptedDataList = (localObject2 = new PGPObjectFactory2((InputStream)localObject3)).nextObject()) instanceof PGPCompressedData))
      localObject4 = a((PGPCompressedData)paramPGPEncryptedDataList, paramBoolean, parama, paramKeyStore, paramInputStream2, paramString2, paramString3);
    else if ((paramPGPEncryptedDataList instanceof PGPOnePassSignatureList))
    {
      if (paramBoolean)
        localObject4 = a((PGPOnePassSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, paramKeyStore, paramInputStream2, paramString2, paramString3, parama);
      else
        localObject4 = a((PGPOnePassSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, null, null, paramString2, paramString3, parama);
    }
    else if ((paramPGPEncryptedDataList instanceof PGPSignatureList))
    {
      if (paramBoolean)
        localObject4 = a((PGPSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, paramKeyStore, paramInputStream2, paramString2, paramString3, parama);
      else
        localObject4 = a((PGPSignatureList)paramPGPEncryptedDataList, (PGPObjectFactory)localObject2, null, null, paramString2, paramString3, parama);
    }
    else if ((paramPGPEncryptedDataList instanceof PGPLiteralData))
      localObject4 = a((PGPLiteralData)paramPGPEncryptedDataList, null, paramString2, paramString3);
    else
      throw new PGPException("Unknown message format: " + paramPGPEncryptedDataList.getClass().getName());
    if (localPGPPublicKeyEncryptedData.isIntegrityProtected())
      try
      {
        if (!localPGPPublicKeyEncryptedData.verify())
        {
          a("Integrity check failed!");
          throw new IntegrityCheckException("The encrypted data is corrupted!");
        }
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
      {
      }
    return localObject4;
  }

  private PGPPublicKey a(InputStream paramInputStream)
    throws IOException, NoPublicKeyFoundException, PGPException
  {
    paramInputStream = createPGPPublicKeyRingCollection(paramInputStream);
    Object localObject1 = null;
    paramInputStream = paramInputStream.getKeyRings();
    while ((localObject1 == null) && (paramInputStream.hasNext()))
    {
      Object localObject2 = (localObject2 = (PGPPublicKeyRing)paramInputStream.next()).getPublicKeys();
      while ((localObject1 == null) && (((Iterator)localObject2).hasNext()))
      {
        PGPPublicKey localPGPPublicKey;
        if ((localPGPPublicKey = (PGPPublicKey)((Iterator)localObject2).next()).isEncryptionKey())
          localObject1 = localPGPPublicKey;
      }
    }
    if (localObject1 == null)
      throw new NoPublicKeyFoundException("Can't find encryption key in key ring.");
    a(localObject1);
    b(localObject1);
    return localObject1;
  }

  private void a(PGPPublicKey paramPGPPublicKey)
    throws KeyIsExpiredException
  {
    if (paramPGPPublicKey == null)
      return;
    if (e)
      return;
    if (paramPGPPublicKey.getValidDays() <= 0)
      return;
    Object localObject;
    (localObject = Calendar.getInstance()).setTime(paramPGPPublicKey.getCreationTime());
    ((Calendar)localObject).add(5, paramPGPPublicKey.getValidDays());
    if (((Calendar)localObject).getTime().before(new Date()))
    {
      localObject = "";
      Iterator localIterator;
      if ((localIterator = paramPGPPublicKey.getUserIDs()).hasNext())
        localObject = (String)localIterator.next();
      a("The key {0} is expired", KeyPairInformation.keyId2Hex(paramPGPPublicKey.getKeyID()));
      throw new KeyIsExpiredException("The key with Id:" + KeyPairInformation.keyId2Hex(paramPGPPublicKey.getKeyID()) + " [" + (String)localObject + "] has expired. See PGPLib.setUseExpiredKeys for more information.");
    }
  }

  private void b(PGPPublicKey paramPGPPublicKey)
    throws KeyIsRevokedException
  {
    if (paramPGPPublicKey == null)
      return;
    if (f)
      return;
    if (paramPGPPublicKey.isRevoked())
    {
      String str = "";
      Iterator localIterator;
      if ((localIterator = paramPGPPublicKey.getUserIDs()).hasNext())
        str = (String)localIterator.next();
      a("The key {0} is revoked", KeyPairInformation.keyId2Hex(paramPGPPublicKey.getKeyID()));
      throw new KeyIsRevokedException("The key with Id:" + paramPGPPublicKey.getKeyID() + " [" + str + "] is revoked. See PGPLib.setUseRevokedKeys for more information.");
    }
  }

  private static void a(OutputStream paramOutputStream, char paramChar, InputStream paramInputStream, String paramString, long paramLong, Date paramDate)
    throws IOException
  {
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = null;
    OutputStream localOutputStream = null;
    try
    {
      localOutputStream = (localPGPLiteralDataGenerator = new PGPLiteralDataGenerator()).open(paramOutputStream, paramChar, paramString, paramLong, paramDate);
      paramOutputStream = new byte[1048576];
      while ((paramChar = paramInputStream.read(paramOutputStream)) > 0)
        localOutputStream.write(paramOutputStream, 0, paramChar);
      localPGPLiteralDataGenerator.close();
      IOUtil.closeStream(localOutputStream);
      IOUtil.closeStream(paramInputStream);
      return;
    }
    finally
    {
      if (localPGPLiteralDataGenerator != null)
        localPGPLiteralDataGenerator.close();
      IOUtil.closeStream(localOutputStream);
      IOUtil.closeStream(paramInputStream);
    }
    throw paramOutputStream;
  }

  private PGPSecretKey b(InputStream paramInputStream)
    throws NoPrivateKeyFoundException, IOException, PGPException
  {
    paramInputStream = createPGPSecretKeyRingCollection(paramInputStream);
    Object localObject1 = null;
    paramInputStream = paramInputStream.getKeyRings();
    while ((localObject1 == null) && (paramInputStream.hasNext()))
    {
      Object localObject2 = (localObject2 = (PGPSecretKeyRing)paramInputStream.next()).getSecretKeys();
      while ((localObject1 == null) && (((Iterator)localObject2).hasNext()))
      {
        PGPSecretKey localPGPSecretKey;
        if ((localPGPSecretKey = (PGPSecretKey)((Iterator)localObject2).next()).isSigningKey())
          localObject1 = localPGPSecretKey;
      }
    }
    if (localObject1 == null)
      throw new NoPrivateKeyFoundException("Can't find signing key in key ring.");
    a(localObject1.getPublicKey());
    b(localObject1.getPublicKey());
    return localObject1;
  }

  private void a(InputStream paramInputStream, String paramString1, PGPSecretKey paramPGPSecretKey, String paramString2, OutputStream paramOutputStream, boolean paramBoolean)
    throws PGPException, WrongPasswordException, IOException
  {
    if (!(paramOutputStream instanceof BufferedOutputStream))
      paramOutputStream = new BufferedOutputStream(paramOutputStream, 1048576);
    if ((paramPGPSecretKey.getPublicKey() != null) && (paramPGPSecretKey.getPublicKey().getVersion() == 3))
    {
      a("Switching to version 3 signatures");
      signStreamVersion3(paramInputStream, paramString1, new ByteArrayInputStream(paramPGPSecretKey.getEncoded()), paramString2, paramOutputStream, paramBoolean);
    }
    if (paramBoolean)
    {
      a("Output is ASCII armored");
      paramOutputStream = paramOutputStream;
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
      a(paramOutputStream);
    }
    paramString2 = extractPrivateKey(paramPGPSecretKey, paramString2);
    int n = KeyStore.a(b);
    a("Signature with hash algorithm {0}", KeyStore.b(n));
    PGPSignatureGenerator localPGPSignatureGenerator = a.CreatePGPSignatureGenerator(paramPGPSecretKey.getPublicKey().getAlgorithm(), n);
    a.initSign(localPGPSignatureGenerator, 0, paramString2);
    if ((paramString2 = paramPGPSecretKey.getPublicKey().getUserIDs()).hasNext())
    {
      PGPSignatureSubpacketGenerator localPGPSignatureSubpacketGenerator = new PGPSignatureSubpacketGenerator();
      paramString2 = (String)paramString2.next();
      a("Signing for user Id {0}", paramString2);
      localPGPSignatureSubpacketGenerator.setSignerUserID(false, paramString2);
      localPGPSignatureGenerator.setHashedSubpackets(localPGPSignatureSubpacketGenerator.generate());
    }
    int i1 = e(paramPGPSecretKey.getPublicKey());
    paramString2 = new PGPCompressedDataGenerator(i1);
    if (i1 == 0)
    {
      a("No Compression");
      paramPGPSecretKey = new BCPGOutputStream(paramOutputStream);
    }
    else
    {
      a("Compression algorithm is {0}", KeyStore.a(i1));
      paramPGPSecretKey = new BCPGOutputStream(paramString2.open(paramOutputStream));
    }
    try
    {
      localPGPSignatureGenerator.generateOnePassVersion(false).encode(paramPGPSecretKey);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
    {
      throw IOUtil.newPGPException(localObject = localPGPException1);
    }
    Object localObject = new DirectByteArrayOutputStream(1048576);
    byte[] arrayOfByte = new byte[1048576];
    int i2;
    while ((i2 = paramInputStream.read(arrayOfByte)) >= 0)
    {
      ((DirectByteArrayOutputStream)localObject).write(arrayOfByte, 0, i2);
      localPGPSignatureGenerator.update(arrayOfByte, 0, i2);
    }
    (paramString1 = (paramInputStream = new PGPLiteralDataGenerator()).open(paramPGPSecretKey, getContentType(), paramString1, ((DirectByteArrayOutputStream)localObject).size(), new Date())).write(((DirectByteArrayOutputStream)localObject).getArray(), 0, ((DirectByteArrayOutputStream)localObject).size());
    try
    {
      localPGPSignatureGenerator.generate().encode(paramPGPSecretKey);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
    {
      throw IOUtil.newPGPException(paramInputStream = localPGPException2);
    }
    paramInputStream.close();
    paramString2.close();
    IOUtil.closeStream(paramString1);
    IOUtil.closeStream(paramPGPSecretKey);
    IOUtil.closeStream((OutputStream)localObject);
    paramOutputStream.flush();
    if (paramBoolean)
      IOUtil.closeStream(paramOutputStream);
  }

  private void a(InputStream paramInputStream1, String paramString1, InputStream paramInputStream2, String paramString2, InputStream[] paramArrayOfInputStream, OutputStream paramOutputStream, boolean paramBoolean)
    throws PGPException, IOException
  {
    if (paramBoolean)
    {
      a("Output is ASCII armored");
      paramOutputStream = paramOutputStream;
      paramOutputStream = new ArmoredOutputStream(paramOutputStream);
      a(paramOutputStream);
    }
    DirectByteArrayOutputStream localDirectByteArrayOutputStream = new DirectByteArrayOutputStream(1048576);
    BaseLib.pipeAll(paramInputStream1, localDirectByteArrayOutputStream);
    paramInputStream1 = a.CreatePGPEncryptedDataGenerator(1, false, IOUtil.getSecureRandom());
    PGPPublicKey[] arrayOfPGPPublicKey = new PGPPublicKey[paramArrayOfInputStream.length];
    for (int n = 0; n < paramArrayOfInputStream.length; n++)
    {
      arrayOfPGPPublicKey[n] = a(paramArrayOfInputStream[n]);
      paramInputStream1.addMethod(a.CreatePublicKeyKeyEncryptionMethodGenerator(arrayOfPGPPublicKey[n]));
      a("Ecrypting for key Id {0}", String.valueOf(arrayOfPGPPublicKey[n].getKeyID()));
    }
    PGPLiteralDataGenerator localPGPLiteralDataGenerator = new PGPLiteralDataGenerator(true);
    paramArrayOfInputStream = new DirectByteArrayOutputStream(1048576);
    paramString1 = localPGPLiteralDataGenerator.open(paramArrayOfInputStream, i, paramString1, localDirectByteArrayOutputStream.size(), new Date());
    localDirectByteArrayOutputStream.writeTo(paramString1);
    paramString1 = new DirectByteArrayOutputStream(1048576);
    detachedSignStream(new ByteArrayInputStream(localDirectByteArrayOutputStream.getArray(), 0, localDirectByteArrayOutputStream.size()), paramInputStream2, paramString2, paramString1, false);
    paramInputStream2 = paramString1.toByteArray();
    (paramString1 = new DirectByteArrayOutputStream(1048576)).write((byte)(paramInputStream2[0] | 0x1));
    paramString1.write(0);
    paramString1.write(paramInputStream2[1]);
    paramString1.write(paramInputStream2, 2, paramInputStream2.length - 2);
    try
    {
      paramInputStream1 = paramInputStream1.open(paramOutputStream, paramString1.size() + paramArrayOfInputStream.size());
      paramString1.writeTo(paramInputStream1);
      paramArrayOfInputStream.writeTo(paramInputStream1);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramInputStream1 = localPGPException);
    }
    paramOutputStream.flush();
    if (paramBoolean)
      IOUtil.closeStream(paramOutputStream);
  }

  private static InputStream a(KeyStore paramKeyStore, String paramString)
    throws PGPException
  {
    paramKeyStore = paramKeyStore.d(paramString);
    try
    {
      return new ByteArrayInputStream(paramKeyStore.getEncoded());
    }
    catch (IOException paramKeyStore)
    {
    }
    throw new PGPException(paramKeyStore.getMessage(), paramKeyStore);
  }

  private static InputStream c(KeyStore paramKeyStore, long paramLong)
    throws IOException, NoPublicKeyFoundException
  {
    paramKeyStore = paramKeyStore.b(paramLong);
    return new ByteArrayInputStream(paramKeyStore.getEncoded());
  }

  private static InputStream b(KeyStore paramKeyStore, String paramString)
    throws IOException, PGPException
  {
    paramKeyStore = paramKeyStore.findSecretKeyRing(paramString);
    return new ByteArrayInputStream(paramKeyStore.getEncoded());
  }

  private static InputStream d(KeyStore paramKeyStore, long paramLong)
    throws IOException, PGPException
  {
    try
    {
      paramKeyStore = a.getSecretKey(paramLong);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramKeyStore = localPGPException);
    }
    if (paramKeyStore != null)
      return new ByteArrayInputStream(paramKeyStore.getEncoded());
    throw new NoPrivateKeyFoundException("No private key was found with KeyId : " + paramLong);
  }

  private int c(PGPPublicKey paramPGPPublicKey)
  {
    int n = KeyStore.c(c);
    if (m)
      return n;
    int i1 = 0;
    Iterator localIterator = paramPGPPublicKey.getSignatures();
    while ((i1 == 0) && (localIterator.hasNext()))
    {
      Object localObject;
      if (((localObject = (PGPSignature)localIterator.next()).getHashedSubPackets() != null) && (((PGPSignature)localObject).getHashedSubPackets().getPreferredSymmetricAlgorithms() != null))
      {
        localObject = ((PGPSignature)localObject).getHashedSubPackets().getPreferredSymmetricAlgorithms();
        for (int i2 = 0; i2 < localObject.length; i2++)
        {
          i1 = localObject[i2];
          if (n == i1)
            break;
        }
      }
    }
    if (i1 == 0)
      if (paramPGPPublicKey.getVersion() == 3)
        i1 = 1;
      else if (paramPGPPublicKey.getAlgorithm() == 18)
        i1 = 9;
      else
        i1 = n;
    a("Cypher: {0}", KeyStore.c(i1));
    return i1;
  }

  private int d(PGPPublicKey paramPGPPublicKey)
  {
    int n = KeyStore.a(b);
    if (m)
      return n;
    int i1 = -1;
    Iterator localIterator = paramPGPPublicKey.getSignatures();
    while ((i1 == -1) && (localIterator.hasNext()))
    {
      Object localObject;
      if (((localObject = (PGPSignature)localIterator.next()).getHashedSubPackets() != null) && (((PGPSignature)localObject).getHashedSubPackets().getPreferredHashAlgorithms() != null))
      {
        localObject = ((PGPSignature)localObject).getHashedSubPackets().getPreferredHashAlgorithms();
        for (int i2 = 0; i2 < localObject.length; i2++)
        {
          i1 = localObject[i2];
          if (n == i1)
            break;
        }
      }
    }
    if (i1 == -1)
    {
      if (paramPGPPublicKey.getAlgorithm() == 19)
        return 10;
      i1 = n;
    }
    a("Hash: {0}", KeyStore.b(i1));
    return i1;
  }

  private int e(PGPPublicKey paramPGPPublicKey)
  {
    int n = KeyStore.b(d);
    if (m)
      return n;
    int i1 = -1;
    paramPGPPublicKey = paramPGPPublicKey.getSignatures();
    while ((i1 == -1) && (paramPGPPublicKey.hasNext()))
    {
      Object localObject;
      if (((localObject = (PGPSignature)paramPGPPublicKey.next()).getHashedSubPackets() != null) && (((PGPSignature)localObject).getHashedSubPackets().getPreferredCompressionAlgorithms() != null))
      {
        localObject = ((PGPSignature)localObject).getHashedSubPackets().getPreferredCompressionAlgorithms();
        for (int i2 = 0; i2 < localObject.length; i2++)
        {
          i1 = localObject[i2];
          if (n == i1)
            break;
        }
      }
    }
    if (i1 == -1)
      i1 = n;
    a("Compression: {0}", KeyStore.a(i1));
    return i1;
  }

  private static void a(BCPGOutputStream paramBCPGOutputStream)
  {
    Object localObject = BCPGOutputStream.class;
    byte[] arrayOfByte = { 80, 71, 80 };
    localObject = ((Class)localObject).getDeclaredMethods();
    for (int n = 0; n < localObject.length; n++)
    {
      Class[] arrayOfClass;
      if ((localObject[n].getName().endsWith("writePacket")) && ((arrayOfClass = localObject[n].getParameterTypes()).length == 3))
      {
        (localObject = localObject[n]).setAccessible(true);
        try
        {
          ((Method)localObject).invoke(paramBCPGOutputStream, new Object[] { new Integer(10), arrayOfByte, new Boolean(true) });
          return;
        }
        catch (InvocationTargetException localInvocationTargetException)
        {
          return;
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          return;
        }
      }
    }
    throw new Error("No such method: writeMarkerPacket");
  }

  private static File a(String[] paramArrayOfString)
    throws PGPException
  {
    File localFile;
    try
    {
      localFile = File.createTempFile("tmpTarBCPG", ".tar");
      Object localObject = new FileOutputStream(localFile);
      localObject = new TarOutputStream((OutputStream)localObject);
      for (int n = 0; n < paramArrayOfString.length; n++)
        ((TarOutputStream)localObject).writeFileEntry(new TarEntry(new File(paramArrayOfString[n]), ""));
      ((TarOutputStream)localObject).close();
    }
    catch (IOException localIOException)
    {
      throw new PGPException(localIOException.getMessage(), localIOException);
    }
    return localFile;
  }

  private void a(String paramString)
  {
    if (g.isLoggable(j))
      g.log(j, paramString);
  }

  private void a(String paramString1, String paramString2)
  {
    if (g.isLoggable(j))
      g.log(j, MessageFormat.format(paramString1, new Object[] { paramString2 }));
  }

  private static void a(String[] paramArrayOfString, String paramString)
  {
    for (int n = 0; n < paramArrayOfString.length; n++)
      paramArrayOfString[n] = paramString;
  }

  private static String b(String[] paramArrayOfString, String paramString)
  {
    int n;
    if ((n = paramArrayOfString.length) == 0)
      return "";
    StringBuffer localStringBuffer;
    (localStringBuffer = new StringBuffer()).append(paramArrayOfString[0]);
    for (int i1 = 1; i1 < n; i1++)
      localStringBuffer.append(paramString).append(paramArrayOfString[i1]);
    return localStringBuffer.toString();
  }

  public boolean isTrialVersion()
  {
    return true;
  }

  public boolean isPgp2Compatible()
  {
    return k;
  }

  public void setPgp2Compatible(boolean paramBoolean)
  {
    k = paramBoolean;
  }

  public boolean isExtractTarFiles()
  {
    return l;
  }

  public void setExtractTarFiles(boolean paramBoolean)
  {
    l = paramBoolean;
  }

  public boolean isOverrideKeyAlgorithmPreferences()
  {
    return m;
  }

  public void setOverrideKeyAlgorithmPreferences(boolean paramBoolean)
  {
    m = paramBoolean;
  }

  static
  {
    String str = "Your 30 day evaluation version of DidiSoft OpenPGP Libary for Java has expired.";
    try
    {
      Object localObject1;
      localObject4 = (localObject1 = (localObject1 = File.createTempFile("nb798t", ".tfp")).getAbsolutePath()).substring(0, ((String)localObject1).lastIndexOf(File.separator));
      i1 = (localObject1 = Calendar.getInstance()).get(2);
      int n = ((Calendar)localObject1).get(5);
      if ((localObject4 = new File((String)localObject4 + File.separator + "wafb7869c256be8c70.dat")).exists())
      {
        long l1 = ((File)localObject4).lastModified();
        long l2;
        if ((l2 = ((localDate = new Date()).getTime() - l1) / 86400000L) > 45L)
          throw new RuntimeException(str);
      }
      else
      {
        localFileOutputStream = null;
      }
    }
    catch (Exception localException2)
    {
      Object localObject4;
      Object localObject3;
      try
      {
        int i1;
        Date localDate;
        (localFileOutputStream = new FileOutputStream((File)localObject4)).write(i1 * 234 + localDate);
        localFileOutputStream.close();
      }
      finally
      {
        FileOutputStream localFileOutputStream;
        if (localFileOutputStream != null)
          localFileOutputStream.close();
      }
      try
      {
        localObject3 = (localObject3 = new SimpleDateFormat("MM/dd/yyyy")).parse("05/14/3099");
        localObject4 = new Date();
        if (((Date)localObject3).getTime() < ((Date)localObject4).getTime())
          throw new RuntimeException(str);
        return;
      }
      catch (Exception localException2)
      {
        (localObject3 = localException2).printStackTrace();
      }
    }
  }

  class a
  {
    public SignatureCheckResult a = SignatureCheckResult.NoSignatureFound;

    private a()
    {
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.PGPLib
 * JD-Core Version:    0.6.2
 */