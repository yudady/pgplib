package com.didisoft.pgp;

import java.util.List;

public class PGPFileInformation
{
  public static final int SIGNED = 1;
  public static final int ENCRYPTED = 2;
  public static final int SIGNED_AND_ENCRYPTED = 3;
  private int a;
  private List b;

  public int getAction()
  {
    return a;
  }

  public void setAction(int paramInt)
  {
    a = paramInt;
  }

  public List getFiles()
  {
    return b;
  }

  public void setFiles(List paramList)
  {
    b = paramList;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.PGPFileInformation
 * JD-Core Version:    0.6.2
 */