package com.didisoft.pgp;

import com.didisoft.pgp.bc.BCFactory;
import com.didisoft.pgp.bc.BaseLib;
import com.didisoft.pgp.bc.BoolValue;
import com.didisoft.pgp.bc.IOUtil;
import com.didisoft.pgp.bc.PGPObjectFactory2;
import com.didisoft.pgp.bc.PGPSignatureSubpacketGeneratorExtended;
import com.didisoft.pgp.bc.ReflectionUtils;
import com.didisoft.pgp.bc.UnknownKeyPacketsException;
import com.didisoft.pgp.bc.elgamal.BaseElGamalKeyPairGenerator;
import com.didisoft.pgp.bc.elgamal.FastElGamal;
import com.didisoft.pgp.bc.elgamal.FastElGamal.PrivateKey;
import com.didisoft.pgp.bc.elgamal.FastElGamal.PublicKey;
import com.didisoft.pgp.bc.elgamal.interfaces.ElGamalParams;
import com.didisoft.pgp.events.IKeyStoreSaveListener;
import com.didisoft.pgp.events.IKeyStoreSearchListener;
import com.didisoft.pgp.exceptions.NoPrivateKeyFoundException;
import com.didisoft.pgp.exceptions.NoPublicKeyFoundException;
import com.didisoft.pgp.exceptions.NonPGPDataException;
import com.didisoft.pgp.exceptions.WrongPasswordException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Serializable;
import java.math.BigInteger;
import java.security.InvalidParameterException;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lw.bouncycastle.asn1.nist.NISTNamedCurves;
import lw.bouncycastle.asn1.x9.X9ECParameters;
import lw.bouncycastle.bcpg.ArmoredInputStream;
import lw.bouncycastle.bcpg.ArmoredOutputStream;
import lw.bouncycastle.bcpg.ExperimentalPacket;
import lw.bouncycastle.bcpg.PublicKeyPacket;
import lw.bouncycastle.bcpg.PublicSubkeyPacket;
import lw.bouncycastle.bcpg.TrustPacket;
import lw.bouncycastle.bcpg.sig.Features;
import lw.bouncycastle.bcpg.sig.NotationData;
import lw.bouncycastle.crypto.AsymmetricCipherKeyPair;
import lw.bouncycastle.crypto.AsymmetricCipherKeyPairGenerator;
import lw.bouncycastle.crypto.generators.DSAKeyPairGenerator;
import lw.bouncycastle.crypto.generators.DSAParametersGenerator;
import lw.bouncycastle.crypto.generators.ECKeyPairGenerator;
import lw.bouncycastle.crypto.generators.RSAKeyPairGenerator;
import lw.bouncycastle.crypto.params.DSAKeyGenerationParameters;
import lw.bouncycastle.crypto.params.ECKeyGenerationParameters;
import lw.bouncycastle.crypto.params.ECNamedDomainParameters;
import lw.bouncycastle.crypto.params.ElGamalKeyGenerationParameters;
import lw.bouncycastle.crypto.params.ElGamalParameters;
import lw.bouncycastle.crypto.params.RSAKeyGenerationParameters;
import lw.bouncycastle.openpgp.PGPDataValidationException;
import lw.bouncycastle.openpgp.PGPEncryptedDataList;
import lw.bouncycastle.openpgp.PGPKeyPair;
import lw.bouncycastle.openpgp.PGPKeyRingGenerator;
import lw.bouncycastle.openpgp.PGPLiteralData;
import lw.bouncycastle.openpgp.PGPLiteralDataGenerator;
import lw.bouncycastle.openpgp.PGPObjectFactory;
import lw.bouncycastle.openpgp.PGPOnePassSignatureList;
import lw.bouncycastle.openpgp.PGPPBEEncryptedData;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSecretKey;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureGenerator;
import lw.bouncycastle.openpgp.PGPSignatureList;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketGenerator;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import lw.bouncycastle.openpgp.PGPUtil;
import lw.bouncycastle.openpgp.operator.bc.BcPBESecretKeyEncryptorBuilder;
import lw.bouncycastle.openpgp.operator.bc.BcPGPContentSignerBuilder;
import lw.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import lw.bouncycastle.openpgp.operator.bc.BcPGPKeyPair;
import lw.bouncycastle.util.encoders.DecoderException;

public class KeyStore extends BaseLib
  implements Serializable
{
  private static final long serialVersionUID = -47989515304466957L;
  protected static final int DEFAULT_BUFFER_SIZE = 1048576;
  private String b;
  private String c;
  private boolean d = true;
  private boolean e = true;
  private PGPPublicKeyRingCollection f;
  PGPSecretKeyRingCollection a;
  private Date g;
  private Date h;
  private KeyCertificationType i = KeyCertificationType.PositiveCertification;
  private boolean j = true;
  private boolean k = true;
  private static final Logger l = Logger.getLogger(KeyStore.class.getName());
  public static final String ELGAMAL = "ELGAMAL";
  public static final String DSA = "DSA";
  public static final String RSA = "RSA";
  public static final String EC = "EC";
  private boolean m = true;
  private boolean n = false;
  private boolean o = true;
  private static Pattern p = Pattern.compile("^(0x)?[A-Fa-f0-9]{6,8}$");
  private static String q = "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF";
  private static String r = "2";
  private static String s = "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6BF12FFA06D98A0864D87602733EC86A64521F2B18177B200CBBE117577A615D6C770988C0BAD946E208E24FA074E5AB3143DB5BFCE0FD108E4B82D120A93AD2CAFFFFFFFFFFFFFFFF";
  private static String t = "2";
  private static String u = "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6BF12FFA06D98A0864D87602733EC86A64521F2B18177B200CBBE117577A615D6C770988C0BAD946E208E24FA074E5AB3143DB5BFCE0FD108E4B82D120A92108011A723C12A787E6D788719A10BDBA5B2699C327186AF4E23C1A946834B6150BDA2583E9CA2AD44CE8DBBBC2DB04DE8EF92E8EFC141FBECAA6287C59474E6BC05D99B2964FA090C3A2233BA186515BE7ED1F612970CEE2D7AFB81BDD762170481CD0069127D5B05AA993B4EA988D8FDDC186FFB7DC90A6C08F4DF435C934063199";
  private static String v = "2";
  private HashMap w = new HashMap();
  private HashMap x = new HashMap();
  private HashMap y = new HashMap();
  private String z = null;
  private boolean A = false;
  private int B = 5;
  private int C = 3;
  private LinkedList D = new LinkedList();
  private LinkedList E = new LinkedList();

  public KeyStore()
  {
    try
    {
      A = true;
      localObject = new ArmoredOutputStream(new ByteArrayOutputStream());
      z = ((String)ReflectionUtils.getPrivateFieldvalue(localObject, "version"));
      z = z.replace("v@RELEASE_NAME@", version);
      f = new PGPPublicKeyRingCollection(Collections.EMPTY_LIST);
      a = new PGPSecretKeyRingCollection(Collections.EMPTY_LIST);
      g = (this.h = new Date());
      return;
    }
    catch (Exception localException)
    {
      Object localObject = (localObject = localException).getStackTrace();
      for (int i1 = 0; i1 < localObject.length; i1++)
        g(localObject.toString());
    }
  }

  public KeyStore(String paramString1, String paramString2)
    throws IOException, PGPException
  {
    this();
    A = false;
    a("Opening KeyStore from {0}", paramString1);
    if (paramString2 == null)
      paramString2 = "";
    b = paramString1;
    c = paramString2;
    File localFile;
    if ((!(localFile = new File(paramString1)).exists()) || (localFile.length() == 0L))
      try
      {
        f = new PGPPublicKeyRingCollection(Collections.EMPTY_LIST);
        a = new PGPSecretKeyRingCollection(Collections.EMPTY_LIST);
        g = (this.h = new Date());
        return;
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        throw new IOException("unable to initialise: " + localPGPException);
      }
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      a(localFileInputStream, paramString2);
      onLoadKeys();
      return;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString1;
  }

  public static KeyStore openFile(String paramString1, String paramString2)
    throws PGPException, IOException
  {
    return paramString1 = new KeyStore(paramString1, paramString2);
  }

  public static KeyStore openInMemory()
  {
    KeyStore localKeyStore;
    return localKeyStore = new KeyStore();
  }

  public void addSaveListener(IKeyStoreSaveListener paramIKeyStoreSaveListener)
  {
    D.add(paramIKeyStoreSaveListener);
  }

  public boolean removeSaveListener(IKeyStoreSaveListener paramIKeyStoreSaveListener)
  {
    return D.remove(paramIKeyStoreSaveListener);
  }

  public void addSearchListener(IKeyStoreSearchListener paramIKeyStoreSearchListener)
  {
    E.add(paramIKeyStoreSearchListener);
  }

  public boolean removeSearchListener(IKeyStoreSearchListener paramIKeyStoreSearchListener)
  {
    return E.remove(paramIKeyStoreSearchListener);
  }

  final void a(long paramLong)
  {
    if (containsPrivateKey(paramLong))
      return;
    for (int i1 = 0; i1 < E.size(); i1++)
      ((IKeyStoreSearchListener)E.get(i1)).onKeyNotFound(this, false, paramLong, KeyPairInformation.keyId2Hex(paramLong), "");
  }

  public void purge()
    throws PGPException
  {
    x.clear();
    y.clear();
    try
    {
      f = new PGPPublicKeyRingCollection(Collections.EMPTY_LIST);
      a = new PGPSecretKeyRingCollection(Collections.EMPTY_LIST);
    }
    catch (Exception localException)
    {
      throw new PGPException("unable to initialise: " + localException, localException);
    }
    w.clear();
    save(false);
  }

  public void loadFromStream(InputStream paramInputStream, String paramString)
    throws IOException, PGPException
  {
    if (!paramInputStream.markSupported())
      paramInputStream = new BufferedInputStream(paramInputStream);
    paramInputStream.mark(1048576);
    Object localObject;
    if (((localObject = PGPUtil.getDecoderStream(paramInputStream)) instanceof ArmoredInputStream))
    {
      if (!((ArmoredInputStream)localObject).isEndOfStream())
      {
        paramInputStream.reset();
        importKeyRing(paramInputStream, paramString);
      }
    }
    else if (((localObject = (localObject = new PGPObjectFactory2(paramInputStream)).nextObject()) instanceof PGPPublicKeyRing))
    {
      paramInputStream.reset();
      importKeyRing(paramInputStream, paramString);
    }
    else if ((localObject instanceof PGPSecretKeyRing))
    {
      paramInputStream.reset();
      importKeyRing(paramInputStream, paramString);
    }
    else if ((localObject instanceof PGPLiteralData))
    {
      paramInputStream.reset();
      a(paramInputStream, paramString);
    }
    else if ((localObject instanceof PGPEncryptedDataList))
    {
      paramInputStream.reset();
      a(paramInputStream, paramString);
    }
    else
    {
      throw new NonPGPDataException("The provided key storage does not contain valid key data.");
    }
    onLoadKeys();
  }

  private void a(InputStream paramInputStream, String paramString)
    throws IOException, PGPException
  {
    try
    {
      paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
      Object localObject;
      if (((localObject = (paramInputStream = new PGPObjectFactory(paramInputStream)).nextObject()) instanceof PGPLiteralData))
      {
        if ((localObject = (PGPLiteralData)localObject) != null)
        {
          localObject = a((PGPLiteralData)localObject);
          f = new PGPPublicKeyRingCollection((byte[])localObject);
          if ((localObject = (PGPLiteralData)paramInputStream.nextObject()) != null)
          {
            paramInputStream = a((PGPLiteralData)localObject);
            a = new PGPSecretKeyRingCollection(paramInputStream);
          }
        }
      }
      else
      {
        if ((localObject instanceof PGPEncryptedDataList))
        {
          localObject = (PGPPBEEncryptedData)(localObject = (PGPEncryptedDataList)localObject).get(0);
          try
          {
            paramInputStream = ((PGPPBEEncryptedData)localObject).getDataStream(staticBCFactory.CreatePBEDataDecryptorFactory(paramString));
          }
          catch (PGPDataValidationException paramString)
          {
            throw new WrongPasswordException("The specified password is wrong.", paramString.getUnderlyingException());
          }
          byte[] arrayOfByte = a(paramString = (PGPLiteralData)(paramInputStream = new PGPObjectFactory(paramInputStream)).nextObject());
          g = paramString.getModificationTime();
          paramInputStream = a(paramString = (PGPLiteralData)paramInputStream.nextObject());
          h = paramString.getModificationTime();
          if (!((PGPPBEEncryptedData)localObject).isIntegrityProtected())
            throw new PGPDataValidationException("no integrity protection found.");
          if (!((PGPPBEEncryptedData)localObject).verify())
            throw new PGPDataValidationException("store failed integrity check.");
          f = new PGPPublicKeyRingCollection(arrayOfByte);
          a = new PGPSecretKeyRingCollection(paramInputStream);
        }
        return;
      }
    }
    catch (DecoderException paramInputStream)
    {
      throw new PGPException(paramInputStream.getMessage(), paramInputStream);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramInputStream = localPGPException);
    }
  }

  public void loadFromStream(InputStream paramInputStream)
    throws IOException, PGPException
  {
    loadFromStream(paramInputStream, "");
  }

  public void saveToStream(OutputStream paramOutputStream)
    throws IOException
  {
    a(paramOutputStream, "pubring.pkr", new Date(), f.getEncoded());
    a(paramOutputStream, "secring.skr", new Date(), a.getEncoded());
  }

  public boolean isPartialMatchUserIds()
  {
    return k;
  }

  public void setPartialMatchUserIds(boolean paramBoolean)
  {
    k = paramBoolean;
  }

  public KeyCertificationType getDefaultKeyCertificationType()
  {
    return i;
  }

  public void setDefaultKeyCertificationType(KeyCertificationType paramKeyCertificationType)
  {
    i = paramKeyCertificationType;
  }

  public boolean getUsePrecomputedPrimes()
  {
    return m;
  }

  public void setUsePrecomputedPrimes(boolean paramBoolean)
  {
    m = paramBoolean;
  }

  public boolean isInMemory()
  {
    return A;
  }

  public String getAsciiVersionHeader()
  {
    return z;
  }

  public void setAsciiVersionHeader(String paramString)
  {
    z = paramString;
  }

  private void a(OutputStream paramOutputStream)
  {
    if ((paramOutputStream instanceof ArmoredOutputStream))
      ((ArmoredOutputStream)paramOutputStream).setHeader("Version", z);
  }

  public PGPSecretKeyRingCollection getRawSecretKeys()
  {
    return a;
  }

  public PGPPublicKeyRingCollection getRawPublicKeys()
  {
    return f;
  }

  public static boolean checkPassword(String paramString1, String paramString2)
    throws IOException
  {
    if (paramString2 == null)
      paramString2 = "";
    FileInputStream localFileInputStream = null;
    try
    {
      paramString1 = PGPUtil.getDecoderStream(localFileInputStream = new FileInputStream(paramString1));
      paramString1 = (PGPPBEEncryptedData)(paramString1 = (PGPEncryptedDataList)(paramString1 = new PGPObjectFactory(paramString1)).nextObject()).get(0);
      try
      {
        paramString1.getDataStream(staticBCFactory.CreatePBEDataDecryptorFactory(paramString2));
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        return !((paramString1 = localPGPException) instanceof PGPDataValidationException);
      }
      return true;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString1;
  }

  public String[] getUserIds()
  {
    return (String[])w.keySet().toArray(new String[w.keySet().size()]);
  }

  public String[] getKeyHexIds()
  {
    return (String[])x.keySet().toArray(new String[x.keySet().size()]);
  }

  public long getKeyIdForUserId(String paramString)
  {
    if (null != w.get(paramString))
      return ((Long)(paramString = (List)w.get(paramString)).get(0)).longValue();
    return getKeyIdForKeyIdHex(paramString);
  }

  public long getKeyIdForKeyIdHex(String paramString)
  {
    if (null != x.get(paramString))
      return ((Long)(paramString = (List)x.get(paramString)).get(0)).longValue();
    return -1L;
  }

  public void addCertification(long paramLong1, long paramLong2, String paramString1, String paramString2)
    throws PGPException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokevirtual 350\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   5: dup
    //   6: astore_1
    //   7: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   10: astore_2
    //   11: aload_0
    //   12: getfield 275\011com/didisoft/pgp/KeyStore:a\011Llw/bouncycastle/openpgp/PGPSecretKeyRingCollection;
    //   15: lload_3
    //   16: invokevirtual 671\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection:getSecretKey\011(J)Llw/bouncycastle/openpgp/PGPSecretKey;
    //   19: astore_3
    //   20: goto +10 -> 30
    //   23: dup
    //   24: astore 4
    //   26: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   29: athrow
    //   30: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   33: aload_2
    //   34: invokevirtual 623\011lw/bouncycastle/openpgp/PGPPublicKey:getAlgorithm\011()I
    //   37: iconst_2
    //   38: invokevirtual 410\011com/didisoft/pgp/bc/BCFactory:CreatePGPSignatureGenerator\011(II)Llw/bouncycastle/openpgp/PGPSignatureGenerator;
    //   41: astore 4
    //   43: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   46: aload 4
    //   48: bipush 16
    //   50: aload_3
    //   51: aload 5
    //   53: invokestatic 366\011com/didisoft/pgp/KeyStore:extractPrivateKey\011(Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;)Llw/bouncycastle/openpgp/PGPPrivateKey;
    //   56: invokevirtual 411\011com/didisoft/pgp/bc/BCFactory:initSign\011(Llw/bouncycastle/openpgp/PGPSignatureGenerator;ILlw/bouncycastle/openpgp/PGPPrivateKey;)V
    //   59: aload 4
    //   61: aload 6
    //   63: aload_2
    //   64: invokevirtual 682\011lw/bouncycastle/openpgp/PGPSignatureGenerator:generateCertification\011(Ljava/lang/String;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPSignature;
    //   67: astore_3
    //   68: aload_2
    //   69: aload 6
    //   71: aload_3
    //   72: invokestatic 620\011lw/bouncycastle/openpgp/PGPPublicKey:addCertification\011(Llw/bouncycastle/openpgp/PGPPublicKey;Ljava/lang/String;Llw/bouncycastle/openpgp/PGPSignature;)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   75: astore_2
    //   76: goto +29 -> 105
    //   79: astore_3
    //   80: new 143\011com/didisoft/pgp/PGPException
    //   83: dup
    //   84: new 186\011java/lang/StringBuilder
    //   87: dup
    //   88: ldc 115
    //   90: invokespecial 518\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   93: aload_3
    //   94: invokevirtual 520\011java/lang/StringBuilder:append\011(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   97: invokevirtual 522\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   100: aload_3
    //   101: invokespecial 402\011com/didisoft/pgp/PGPException:<init>\011(Ljava/lang/String;Ljava/lang/Exception;)V
    //   104: athrow
    //   105: aload_1
    //   106: aload_2
    //   107: invokestatic 638\011lw/bouncycastle/openpgp/PGPPublicKeyRing:removePublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   110: dup
    //   111: astore_1
    //   112: aload_2
    //   113: invokestatic 637\011lw/bouncycastle/openpgp/PGPPublicKeyRing:insertPublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   116: astore_1
    //   117: aload_0
    //   118: aload_1
    //   119: invokevirtual 396\011com/didisoft/pgp/KeyStore:replacePublicKeyRing\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;)V
    //   122: return
    //
    // Exception table:
    //   from\011to\011target\011type
    //   11\01120\01123\011lw/bouncycastle/openpgp/PGPException
    //   30\01176\01179\011java/lang/Exception
  }

  public void signPublicKey(long paramLong1, long paramLong2, String paramString)
    throws PGPException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokevirtual 350\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   5: dup
    //   6: astore_1
    //   7: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   10: astore_2
    //   11: aload_0
    //   12: getfield 275\011com/didisoft/pgp/KeyStore:a\011Llw/bouncycastle/openpgp/PGPSecretKeyRingCollection;
    //   15: lload_3
    //   16: invokevirtual 671\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection:getSecretKey\011(J)Llw/bouncycastle/openpgp/PGPSecretKey;
    //   19: astore 6
    //   21: goto +9 -> 30
    //   24: dup
    //   25: astore_3
    //   26: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   29: athrow
    //   30: aload 6
    //   32: ifnonnull +27 -> 59
    //   35: new 160\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException
    //   38: dup
    //   39: new 186\011java/lang/StringBuilder
    //   42: dup
    //   43: ldc 58
    //   45: invokespecial 518\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   48: lload_3
    //   49: invokevirtual 519\011java/lang/StringBuilder:append\011(J)Ljava/lang/StringBuilder;
    //   52: invokevirtual 522\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   55: invokespecial 454\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException:<init>\011(Ljava/lang/String;)V
    //   58: athrow
    //   59: ldc 2
    //   61: astore_3
    //   62: aload_2
    //   63: invokevirtual 630\011lw/bouncycastle/openpgp/PGPPublicKey:getUserIDs\011()Ljava/util/Iterator;
    //   66: dup
    //   67: astore 4
    //   69: invokeinterface 727 1 0
    //   74: ifeq +14 -> 88
    //   77: aload 4
    //   79: invokeinterface 728 1 0
    //   84: checkcast 184\011java/lang/String
    //   87: astore_3
    //   88: aload_0
    //   89: aload_1
    //   90: aload_2
    //   91: aload_3
    //   92: aload 6
    //   94: aload 5
    //   96: invokespecial 344\011com/didisoft/pgp/KeyStore:a\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;Ljava/lang/String;Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;)V
    //   99: return
    //
    // Exception table:
    //   from\011to\011target\011type
    //   11\01121\01124\011lw/bouncycastle/openpgp/PGPException
  }

  public void signPublicKey(String paramString1, String paramString2, String paramString3)
    throws PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing;
    PGPPublicKey localPGPPublicKey = (localPGPPublicKeyRing = d(paramString1)).getPublicKey();
    paramString2 = findSecretKeyRing(paramString2).getSecretKey();
    a(localPGPPublicKeyRing, localPGPPublicKey, paramString1, paramString2, paramString3);
  }

  public void signPublicKeyAsTrustedIntroducer(long paramLong1, long paramLong2, String paramString)
    throws PGPException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokevirtual 350\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   5: dup
    //   6: astore_1
    //   7: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   10: astore_2
    //   11: aload_0
    //   12: getfield 275\011com/didisoft/pgp/KeyStore:a\011Llw/bouncycastle/openpgp/PGPSecretKeyRingCollection;
    //   15: lload_3
    //   16: invokevirtual 671\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection:getSecretKey\011(J)Llw/bouncycastle/openpgp/PGPSecretKey;
    //   19: astore 6
    //   21: goto +9 -> 30
    //   24: dup
    //   25: astore_3
    //   26: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   29: athrow
    //   30: aload 6
    //   32: ifnonnull +27 -> 59
    //   35: new 160\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException
    //   38: dup
    //   39: new 186\011java/lang/StringBuilder
    //   42: dup
    //   43: ldc 58
    //   45: invokespecial 518\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   48: lload_3
    //   49: invokevirtual 519\011java/lang/StringBuilder:append\011(J)Ljava/lang/StringBuilder;
    //   52: invokevirtual 522\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   55: invokespecial 454\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException:<init>\011(Ljava/lang/String;)V
    //   58: athrow
    //   59: ldc 2
    //   61: astore_3
    //   62: aload_2
    //   63: invokevirtual 630\011lw/bouncycastle/openpgp/PGPPublicKey:getUserIDs\011()Ljava/util/Iterator;
    //   66: dup
    //   67: astore 4
    //   69: invokeinterface 727 1 0
    //   74: ifeq +14 -> 88
    //   77: aload 4
    //   79: invokeinterface 728 1 0
    //   84: checkcast 184\011java/lang/String
    //   87: astore_3
    //   88: aload_0
    //   89: aload_1
    //   90: aload_2
    //   91: aload_3
    //   92: aload 6
    //   94: aload 5
    //   96: invokespecial 354\011com/didisoft/pgp/KeyStore:b\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;Ljava/lang/String;Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;)V
    //   99: return
    //
    // Exception table:
    //   from\011to\011target\011type
    //   11\01121\01124\011lw/bouncycastle/openpgp/PGPException
  }

  public void signPublicKeyAsTrustedIntroducer(String paramString1, String paramString2, String paramString3)
    throws PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing;
    PGPPublicKey localPGPPublicKey = (localPGPPublicKeyRing = d(paramString1)).getPublicKey();
    paramString2 = findSecretKeyRing(paramString2).getSecretKey();
    b(localPGPPublicKeyRing, localPGPPublicKey, paramString1, paramString2, paramString3);
  }

  public void setTrust(long paramLong, byte paramByte)
    throws PGPException, NoPublicKeyFoundException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokevirtual 350\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   5: dup
    //   6: astore_1
    //   7: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   10: astore_2
    //   11: new 214\011lw/bouncycastle/bcpg/TrustPacket
    //   14: dup
    //   15: iload_3
    //   16: invokespecial 570\011lw/bouncycastle/bcpg/TrustPacket:<init>\011(I)V
    //   19: astore_3
    //   20: aload_2
    //   21: ldc 127
    //   23: aload_3
    //   24: invokestatic 446\011com/didisoft/pgp/bc/ReflectionUtils:setPrivateFieldvalue\011(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)V
    //   27: aload_1
    //   28: aload_2
    //   29: invokestatic 638\011lw/bouncycastle/openpgp/PGPPublicKeyRing:removePublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   32: dup
    //   33: astore_1
    //   34: aload_2
    //   35: invokestatic 637\011lw/bouncycastle/openpgp/PGPPublicKeyRing:insertPublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   38: astore_1
    //   39: aload_0
    //   40: aload_1
    //   41: invokevirtual 396\011com/didisoft/pgp/KeyStore:replacePublicKeyRing\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;)V
    //   44: return
  }

  public void setTrust(String paramString, byte paramByte)
    throws PGPException, NoPublicKeyFoundException
  {
    PGPPublicKey localPGPPublicKey = (paramString = d(paramString)).getPublicKey();
    paramByte = new TrustPacket(paramByte);
    ReflectionUtils.setPrivateFieldvalue(localPGPPublicKey, "trustPk", paramByte);
    paramString = PGPPublicKeyRing.insertPublicKey(paramString = PGPPublicKeyRing.removePublicKey(paramString, localPGPPublicKey), localPGPPublicKey);
    replacePublicKeyRing(paramString);
  }

  public boolean isTrusted(String paramString)
    throws PGPException
  {
    paramString = (paramString = d(paramString)).getPublicKey();
    return a(paramString.getKeyID(), 0);
  }

  public boolean isTrusted(long paramLong)
    throws PGPException
  {
    return a(paramLong, 0);
  }

  private boolean a(long paramLong, int paramInt)
    throws PGPException
  {
    // Byte code:
    //   0: iload_3
    //   1: aload_0
    //   2: getfield 271\011com/didisoft/pgp/KeyStore:B\011I
    //   5: if_icmplt +5 -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: aload_0
    //   11: lload_1
    //   12: invokevirtual 350\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   15: dup
    //   16: astore 4
    //   18: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   21: astore 5
    //   23: aload_0
    //   24: lload_1
    //   25: iload_3
    //   26: istore_2
    //   27: lstore 10
    //   29: dup
    //   30: astore_1
    //   31: lload 10
    //   33: invokevirtual 350\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   36: dup
    //   37: astore_3
    //   38: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   41: astore 6
    //   43: aload_1
    //   44: getfield 301\011com/didisoft/pgp/KeyStore:y\011Ljava/util/HashMap;
    //   47: new 182\011java/lang/Long
    //   50: dup
    //   51: aload 6
    //   53: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   56: invokespecial 497\011java/lang/Long:<init>\011(J)V
    //   59: invokevirtual 539\011java/util/HashMap:get\011(Ljava/lang/Object;)Ljava/lang/Object;
    //   62: checkcast 140\011com/didisoft/pgp/KeyPairInformation
    //   65: dup
    //   66: astore 7
    //   68: invokevirtual 319\011com/didisoft/pgp/KeyPairInformation:getTrust\011()B
    //   71: dup
    //   72: istore 7
    //   74: bipush 120
    //   76: if_icmplt +7 -> 83
    //   79: iconst_1
    //   80: goto +69 -> 149
    //   83: aload_3
    //   84: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   87: bipush 16
    //   89: invokevirtual 629\011lw/bouncycastle/openpgp/PGPPublicKey:getSignaturesOfType\011(I)Ljava/util/Iterator;
    //   92: astore_3
    //   93: aload_3
    //   94: invokeinterface 727 1 0
    //   99: ifeq +49 -> 148
    //   102: aload_3
    //   103: invokeinterface 728 1 0
    //   108: checkcast 246\011lw/bouncycastle/openpgp/PGPSignature
    //   111: dup
    //   112: astore 7
    //   114: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   117: aload 6
    //   119: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   122: lcmp
    //   123: ifeq -30 -> 93
    //   126: aload_1
    //   127: aload 7
    //   129: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   132: iload_2
    //   133: iconst_1
    //   134: iadd
    //   135: invokespecial 327\011com/didisoft/pgp/KeyStore:a\011(JI)Z
    //   138: ifeq +7 -> 145
    //   141: iconst_1
    //   142: goto +7 -> 149
    //   145: goto -52 -> 93
    //   148: iconst_0
    //   149: ifeq +5 -> 154
    //   152: iconst_1
    //   153: ireturn
    //   154: iconst_0
    //   155: istore_1
    //   156: aload 4
    //   158: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   161: bipush 16
    //   163: invokevirtual 629\011lw/bouncycastle/openpgp/PGPPublicKey:getSignaturesOfType\011(I)Ljava/util/Iterator;
    //   166: astore_2
    //   167: aload_2
    //   168: invokeinterface 727 1 0
    //   173: ifeq +66 -> 239
    //   176: aload_2
    //   177: invokeinterface 728 1 0
    //   182: checkcast 246\011lw/bouncycastle/openpgp/PGPSignature
    //   185: dup
    //   186: astore_3
    //   187: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   190: aload 5
    //   192: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   195: lcmp
    //   196: ifeq -29 -> 167
    //   199: aload_0
    //   200: aload_3
    //   201: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   204: invokespecial 362\011com/didisoft/pgp/KeyStore:e\011(J)Z
    //   207: ifeq +5 -> 212
    //   210: iconst_1
    //   211: ireturn
    //   212: aload_0
    //   213: aload_3
    //   214: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   217: invokespecial 355\011com/didisoft/pgp/KeyStore:c\011(J)Z
    //   220: ifeq +6 -> 226
    //   223: iinc 1 1
    //   226: iload_1
    //   227: aload_0
    //   228: invokevirtual 380\011com/didisoft/pgp/KeyStore:getMarginalsNeeded\011()I
    //   231: if_icmplt +5 -> 236
    //   234: iconst_1
    //   235: ireturn
    //   236: goto -69 -> 167
    //   239: aload 4
    //   241: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   244: bipush 18
    //   246: invokevirtual 629\011lw/bouncycastle/openpgp/PGPPublicKey:getSignaturesOfType\011(I)Ljava/util/Iterator;
    //   249: astore_2
    //   250: aload_2
    //   251: invokeinterface 727 1 0
    //   256: ifeq +66 -> 322
    //   259: aload_2
    //   260: invokeinterface 728 1 0
    //   265: checkcast 246\011lw/bouncycastle/openpgp/PGPSignature
    //   268: dup
    //   269: astore_3
    //   270: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   273: aload 5
    //   275: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   278: lcmp
    //   279: ifeq -29 -> 250
    //   282: aload_0
    //   283: aload_3
    //   284: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   287: invokespecial 362\011com/didisoft/pgp/KeyStore:e\011(J)Z
    //   290: ifeq +5 -> 295
    //   293: iconst_1
    //   294: ireturn
    //   295: aload_0
    //   296: aload_3
    //   297: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   300: invokespecial 355\011com/didisoft/pgp/KeyStore:c\011(J)Z
    //   303: ifeq +6 -> 309
    //   306: iinc 1 1
    //   309: iload_1
    //   310: aload_0
    //   311: invokevirtual 380\011com/didisoft/pgp/KeyStore:getMarginalsNeeded\011()I
    //   314: if_icmplt +5 -> 319
    //   317: iconst_1
    //   318: ireturn
    //   319: goto -69 -> 250
    //   322: aload 4
    //   324: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   327: bipush 19
    //   329: invokevirtual 629\011lw/bouncycastle/openpgp/PGPPublicKey:getSignaturesOfType\011(I)Ljava/util/Iterator;
    //   332: astore_2
    //   333: aload_2
    //   334: invokeinterface 727 1 0
    //   339: ifeq +66 -> 405
    //   342: aload_2
    //   343: invokeinterface 728 1 0
    //   348: checkcast 246\011lw/bouncycastle/openpgp/PGPSignature
    //   351: dup
    //   352: astore_3
    //   353: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   356: aload 5
    //   358: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   361: lcmp
    //   362: ifeq -29 -> 333
    //   365: aload_0
    //   366: aload_3
    //   367: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   370: invokespecial 362\011com/didisoft/pgp/KeyStore:e\011(J)Z
    //   373: ifeq +5 -> 378
    //   376: iconst_1
    //   377: ireturn
    //   378: aload_0
    //   379: aload_3
    //   380: invokevirtual 677\011lw/bouncycastle/openpgp/PGPSignature:getKeyID\011()J
    //   383: invokespecial 355\011com/didisoft/pgp/KeyStore:c\011(J)Z
    //   386: ifeq +6 -> 392
    //   389: iinc 1 1
    //   392: iload_1
    //   393: aload_0
    //   394: invokevirtual 380\011com/didisoft/pgp/KeyStore:getMarginalsNeeded\011()I
    //   397: if_icmplt +5 -> 402
    //   400: iconst_1
    //   401: ireturn
    //   402: goto -69 -> 333
    //   405: iconst_0
    //   406: ireturn
  }

  private boolean c(long paramLong)
    throws PGPException
  {
    PGPPublicKey localPGPPublicKey = (paramLong = b(paramLong)).getPublicKey();
    KeyPairInformation localKeyPairInformation;
    int i1;
    if ((i1 = (localKeyPairInformation = (KeyPairInformation)y.get(new Long(localPGPPublicKey.getKeyID()))).getTrust()) >= 60)
      return true;
    if (B > 1)
    {
      paramLong = paramLong.getPublicKey().getSignaturesOfType(16);
      while (paramLong.hasNext())
      {
        PGPSignature localPGPSignature;
        if ((localPGPSignature = (PGPSignature)paramLong.next()).getKeyID() != localPGPPublicKey.getKeyID())
          if (e(localPGPSignature.getKeyID()))
            return true;
      }
    }
    return false;
  }

  public boolean deleteKeyPair(String paramString)
    throws PGPException
  {
    Object localObject = e(paramString);
    paramString = getSecretKeyRingCollection(paramString);
    long l1 = -1L;
    boolean bool = false;
    if ((localObject = ((Collection)localObject).iterator()).hasNext())
    {
      localObject = (PGPPublicKeyRing)((Iterator)localObject).next();
      try
      {
        f = PGPPublicKeyRingCollection.removePublicKeyRing(f, (PGPPublicKeyRing)localObject);
        b((PGPPublicKeyRing)localObject);
        y.remove(new Long(((PGPPublicKeyRing)localObject).getPublicKey().getKeyID()));
        a("Deleted public key Id {0}", KeyPairInformation.keyId2Hex(((PGPPublicKeyRing)localObject).getPublicKey().getKeyID()));
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        break label117;
      }
      l1 = ((PGPPublicKeyRing)localObject).getPublicKey().getKeyID();
      bool = true;
    }
    label117: if (bool)
    {
      if ((localObject = f(l1)) != null)
      {
        a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, (PGPSecretKeyRing)localObject);
        a((PGPSecretKeyRing)localObject);
        a("Deleted private key Id {0}", KeyPairInformation.keyId2Hex(l1));
      }
    }
    else if ((localObject = paramString.iterator()).hasNext())
    {
      localObject = (PGPSecretKeyRing)((Iterator)localObject).next();
      a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, (PGPSecretKeyRing)localObject);
      a((PGPSecretKeyRing)localObject);
      a("Deleted private key Id {0}", KeyPairInformation.keyId2Hex(((PGPSecretKeyRing)localObject).getPublicKey().getKeyID()));
    }
    save(false);
    return bool;
  }

  public boolean deletePrivateKey(String paramString)
    throws PGPException
  {
    paramString = getSecretKeyRingCollection(paramString);
    boolean bool = false;
    if ((paramString = paramString.iterator()).hasNext())
    {
      paramString = (PGPSecretKeyRing)paramString.next();
      a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, paramString);
      a(paramString);
      a("Deleted private key Id {0}", KeyPairInformation.keyId2Hex(paramString.getPublicKey().getKeyID()));
      bool = true;
    }
    save(false);
    return bool;
  }

  public boolean deletePrivateKey(long paramLong)
    throws PGPException
  {
    paramLong = f(paramLong);
    boolean bool = false;
    if (paramLong != null)
    {
      a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, paramLong);
      a(paramLong);
      a("Deleted private key Id {0}", KeyPairInformation.keyId2Hex(paramLong.getPublicKey().getKeyID()));
      bool = true;
    }
    save(false);
    return bool;
  }

  public boolean deletePublicKey(String paramString)
    throws PGPException
  {
    paramString = e(paramString);
    boolean bool = false;
    if ((paramString = paramString.iterator()).hasNext())
    {
      paramString = (PGPPublicKeyRing)paramString.next();
      try
      {
        f = PGPPublicKeyRingCollection.removePublicKeyRing(f, paramString);
        b(paramString);
        y.remove(new Long(paramString.getPublicKey().getKeyID()));
        a("Deleted public key Id {0}", KeyPairInformation.keyId2Hex(paramString.getPublicKey().getKeyID()));
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        break label97;
      }
      bool = true;
    }
    label97: save(false);
    return bool;
  }

  public boolean deletePublicKey(long paramLong)
    throws PGPException
  {
    paramLong = d(paramLong);
    boolean bool = false;
    if (paramLong != null)
    {
      try
      {
        f = PGPPublicKeyRingCollection.removePublicKeyRing(f, paramLong);
        b(paramLong);
        y.remove(new Long(paramLong.getPublicKey().getKeyID()));
        a("Deleted public key Id {0}", KeyPairInformation.keyId2Hex(paramLong.getPublicKey().getKeyID()));
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
      }
      bool = true;
    }
    save(false);
    return bool;
  }

  public void deleteKeyPair(long paramLong)
    throws PGPException
  {
    PGPSecretKeyRing localPGPSecretKeyRing = f(paramLong);
    paramLong = d(paramLong);
    try
    {
      f = PGPPublicKeyRingCollection.removePublicKeyRing(f, paramLong);
      b(paramLong);
      y.remove(new Long(paramLong.getPublicKey().getKeyID()));
      a("Deleted public key Id {0}", KeyPairInformation.keyId2Hex(paramLong.getPublicKey().getKeyID()));
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
    }
    if (localPGPSecretKeyRing != null)
    {
      a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, localPGPSecretKeyRing);
      a(localPGPSecretKeyRing);
      a("Deleted private key Id {0}", KeyPairInformation.keyId2Hex(localPGPSecretKeyRing.getPublicKey().getKeyID()));
    }
    save(false);
  }

  public boolean changePrivateKeyPassword(String paramString1, String paramString2, String paramString3)
    throws WrongPasswordException, PGPException
  {
    if ((paramString1 = (paramString1 = getSecretKeyRingCollection(paramString1)).iterator()).hasNext())
    {
      int i1 = (paramString1 = (PGPSecretKeyRing)paramString1.next()).getSecretKey().getKeyEncryptionAlgorithm();
      try
      {
        paramString1 = PGPSecretKeyRing.copyWithNewPassword(paramString1, staticBCFactory.CreatePBESecretKeyDecryptor(paramString2), staticBCFactory.CreatePBESecretKeyEncryptor(paramString3, i1));
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
        if ((paramString1 = localPGPException).getMessage().startsWith("checksum mismatch at 0 of 2"))
          throw new WrongPasswordException(paramString1.getMessage(), paramString1.getUnderlyingException());
        throw IOUtil.newPGPException(paramString1);
      }
      replaceSecretKeyRing(paramString1);
      return true;
    }
    return false;
  }

  public void changePrivateKeyPassword(long paramLong, String paramString1, String paramString2)
    throws NoPrivateKeyFoundException, WrongPasswordException, PGPException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokevirtual 369\011com/didisoft/pgp/KeyStore:findSecretKeyRing\011(J)Llw/bouncycastle/openpgp/PGPSecretKeyRing;
    //   5: dup
    //   6: astore_1
    //   7: invokevirtual 657\011lw/bouncycastle/openpgp/PGPSecretKeyRing:getSecretKey\011()Llw/bouncycastle/openpgp/PGPSecretKey;
    //   10: invokevirtual 651\011lw/bouncycastle/openpgp/PGPSecretKey:getKeyEncryptionAlgorithm\011()I
    //   13: istore_2
    //   14: aload_1
    //   15: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   18: aload_3
    //   19: invokevirtual 405\011com/didisoft/pgp/bc/BCFactory:CreatePBESecretKeyDecryptor\011(Ljava/lang/String;)Llw/bouncycastle/openpgp/operator/PBESecretKeyDecryptor;
    //   22: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   25: aload 4
    //   27: iload_2
    //   28: invokevirtual 406\011com/didisoft/pgp/bc/BCFactory:CreatePBESecretKeyEncryptor\011(Ljava/lang/String;I)Llw/bouncycastle/openpgp/operator/PBESecretKeyEncryptor;
    //   31: invokestatic 654\011lw/bouncycastle/openpgp/PGPSecretKeyRing:copyWithNewPassword\011(Llw/bouncycastle/openpgp/PGPSecretKeyRing;Llw/bouncycastle/openpgp/operator/PBESecretKeyDecryptor;Llw/bouncycastle/openpgp/operator/PBESecretKeyEncryptor;)Llw/bouncycastle/openpgp/PGPSecretKeyRing;
    //   34: astore_1
    //   35: goto +37 -> 72
    //   38: dup
    //   39: astore_1
    //   40: invokevirtual 601\011lw/bouncycastle/openpgp/PGPException:getMessage\011()Ljava/lang/String;
    //   43: ldc 112
    //   45: invokevirtual 505\011java/lang/String:startsWith\011(Ljava/lang/String;)Z
    //   48: ifeq +19 -> 67
    //   51: new 163\011com/didisoft/pgp/exceptions/WrongPasswordException
    //   54: dup
    //   55: aload_1
    //   56: invokevirtual 601\011lw/bouncycastle/openpgp/PGPException:getMessage\011()Ljava/lang/String;
    //   59: aload_1
    //   60: invokevirtual 602\011lw/bouncycastle/openpgp/PGPException:getUnderlyingException\011()Ljava/lang/Exception;
    //   63: invokespecial 459\011com/didisoft/pgp/exceptions/WrongPasswordException:<init>\011(Ljava/lang/String;Ljava/lang/Exception;)V
    //   66: athrow
    //   67: aload_1
    //   68: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   71: athrow
    //   72: aload_0
    //   73: aload_1
    //   74: invokevirtual 397\011com/didisoft/pgp/KeyStore:replaceSecretKeyRing\011(Llw/bouncycastle/openpgp/PGPSecretKeyRing;)V
    //   77: return
    //
    // Exception table:
    //   from\011to\011target\011type
    //   14\01135\01138\011lw/bouncycastle/openpgp/PGPException
  }

  public void addUserId(long paramLong, String paramString1, String paramString2)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, WrongPasswordException, PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing;
    if ((localPGPPublicKeyRing = d(paramLong)) == null)
      throw new NoPublicKeyFoundException("No public key exists with key Id :" + String.valueOf(paramLong));
    PGPPublicKey localPGPPublicKey = localPGPPublicKeyRing.getPublicKey();
    PGPSignatureGenerator localPGPSignatureGenerator = staticBCFactory.CreatePGPSignatureGenerator(localPGPPublicKey.getAlgorithm(), 2);
    PGPSecretKeyRing localPGPSecretKeyRing;
    if ((localPGPSecretKeyRing = f(localPGPPublicKey.getKeyID())) == null)
      throw new NoPrivateKeyFoundException("No secret key found. You must have the secret key with key Id :" + String.valueOf(paramLong));
    try
    {
      staticBCFactory.initSign(localPGPSignatureGenerator, 19, BaseLib.extractPrivateKey(localPGPSecretKeyRing.getSecretKey(), paramString1));
      paramLong = localPGPSignatureGenerator.generateCertification(paramString2, localPGPPublicKey);
      paramLong = PGPPublicKey.addCertification(localPGPPublicKey, paramString2, paramLong);
      localPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(localPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(localPGPPublicKeyRing, localPGPPublicKey), paramLong);
    }
    catch (Exception paramLong)
    {
      throw new PGPException("creating signature for userId : " + paramString2, paramLong);
    }
    replacePublicKeyRing(localPGPPublicKeyRing);
  }

  public boolean deleteUserId(long paramLong, String paramString)
    throws NoPublicKeyFoundException, PGPException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokespecial 359\011com/didisoft/pgp/KeyStore:d\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   5: dup
    //   6: astore 4
    //   8: ifnonnull +30 -> 38
    //   11: new 161\011com/didisoft/pgp/exceptions/NoPublicKeyFoundException
    //   14: dup
    //   15: new 186\011java/lang/StringBuilder
    //   18: dup
    //   19: ldc 60
    //   21: invokespecial 518\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   24: lload_1
    //   25: invokestatic 511\011java/lang/String:valueOf\011(J)Ljava/lang/String;
    //   28: invokevirtual 521\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: invokevirtual 522\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   34: invokespecial 456\011com/didisoft/pgp/exceptions/NoPublicKeyFoundException:<init>\011(Ljava/lang/String;)V
    //   37: athrow
    //   38: aload 4
    //   40: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   43: dup
    //   44: astore_1
    //   45: aload_3
    //   46: invokestatic 631\011lw/bouncycastle/openpgp/PGPPublicKey:removeCertification\011(Llw/bouncycastle/openpgp/PGPPublicKey;Ljava/lang/String;)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   49: dup
    //   50: astore_2
    //   51: ifnull +26 -> 77
    //   54: aload 4
    //   56: aload_1
    //   57: invokestatic 638\011lw/bouncycastle/openpgp/PGPPublicKeyRing:removePublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   60: dup
    //   61: astore 4
    //   63: aload_2
    //   64: invokestatic 637\011lw/bouncycastle/openpgp/PGPPublicKeyRing:insertPublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   67: astore 4
    //   69: aload_0
    //   70: aload 4
    //   72: invokevirtual 396\011com/didisoft/pgp/KeyStore:replacePublicKeyRing\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;)V
    //   75: iconst_1
    //   76: ireturn
    //   77: iconst_0
    //   78: ireturn
  }

  public KeyPairInformation clearKeyExpirationTime(String paramString1, String paramString2)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, PGPException
  {
    paramString1 = d(paramString1);
    return a(paramString1, paramString1.getPublicKey().getKeyID(), paramString2, 0);
  }

  public KeyPairInformation clearKeyExpirationTime(long paramLong, String paramString)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = b(paramLong);
    return a(localPGPPublicKeyRing, paramLong, paramString, 0);
  }

  public KeyPairInformation setKeyExpirationTime(String paramString1, String paramString2, int paramInt)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, PGPException
  {
    paramString1 = d(paramString1);
    return a(paramString1, paramString1.getPublicKey().getKeyID(), paramString2, paramInt);
  }

  public KeyPairInformation setKeyExpirationTime(long paramLong, String paramString, int paramInt)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = b(paramLong);
    return a(localPGPPublicKeyRing, paramLong, paramString, paramInt);
  }

  private static PGPSignatureSubpacketGeneratorExtended a(PGPSignatureSubpacketVector paramPGPSignatureSubpacketVector, boolean paramBoolean)
  {
    PGPSignatureSubpacketGeneratorExtended localPGPSignatureSubpacketGeneratorExtended = new PGPSignatureSubpacketGeneratorExtended();
    if (paramPGPSignatureSubpacketVector.getFeatures() != null)
      localPGPSignatureSubpacketGeneratorExtended.setFeature(paramPGPSignatureSubpacketVector.getFeatures().isCritical(), paramPGPSignatureSubpacketVector.getFeatures().getData()[0]);
    if (paramPGPSignatureSubpacketVector.getIssuerKeyID() != 0L)
      localPGPSignatureSubpacketGeneratorExtended.setIssuerKeyID(true, paramPGPSignatureSubpacketVector.getIssuerKeyID());
    if (paramPGPSignatureSubpacketVector.getKeyFlags() > 0)
      localPGPSignatureSubpacketGeneratorExtended.setKeyFlags(false, paramPGPSignatureSubpacketVector.getKeyFlags());
    if (paramPGPSignatureSubpacketVector.getNotationDataOccurences().length > 0)
      for (int i1 = 0; i1 < paramPGPSignatureSubpacketVector.getNotationDataOccurences().length; i1++)
      {
        NotationData localNotationData = paramPGPSignatureSubpacketVector.getNotationDataOccurences()[i1];
        localPGPSignatureSubpacketGeneratorExtended.setNotationData(localNotationData.isCritical(), localNotationData.isHumanReadable(), localNotationData.getNotationName(), localNotationData.getNotationValue());
      }
    if (paramPGPSignatureSubpacketVector.getPreferredCompressionAlgorithms() != null)
      localPGPSignatureSubpacketGeneratorExtended.setPreferredCompressionAlgorithms(false, paramPGPSignatureSubpacketVector.getPreferredCompressionAlgorithms());
    if (paramPGPSignatureSubpacketVector.getPreferredHashAlgorithms() != null)
      localPGPSignatureSubpacketGeneratorExtended.setPreferredHashAlgorithms(false, paramPGPSignatureSubpacketVector.getPreferredHashAlgorithms());
    if (paramPGPSignatureSubpacketVector.getPreferredSymmetricAlgorithms() != null)
      localPGPSignatureSubpacketGeneratorExtended.setPreferredSymmetricAlgorithms(false, paramPGPSignatureSubpacketVector.getPreferredSymmetricAlgorithms());
    if (paramPGPSignatureSubpacketVector.getSignatureCreationTime() != null)
      localPGPSignatureSubpacketGeneratorExtended.setSignatureCreationTime(false, paramPGPSignatureSubpacketVector.getSignatureCreationTime());
    if (paramPGPSignatureSubpacketVector.getSignatureExpirationTime() > 0L)
      localPGPSignatureSubpacketGeneratorExtended.setSignatureExpirationTime(false, paramPGPSignatureSubpacketVector.getSignatureExpirationTime());
    if (paramPGPSignatureSubpacketVector.getSignerUserID() != null)
      localPGPSignatureSubpacketGeneratorExtended.setSignerUserID(false, paramPGPSignatureSubpacketVector.getSignerUserID());
    if (paramPGPSignatureSubpacketVector.isPrimaryUserID())
      localPGPSignatureSubpacketGeneratorExtended.setPrimaryUserID(false, true);
    if ((paramBoolean) && (paramPGPSignatureSubpacketVector.getKeyExpirationTime() > 0L))
      localPGPSignatureSubpacketGeneratorExtended.setKeyExpirationTime(false, paramPGPSignatureSubpacketVector.getKeyExpirationTime());
    return localPGPSignatureSubpacketGeneratorExtended;
  }

  private KeyPairInformation a(PGPPublicKeyRing paramPGPPublicKeyRing, long paramLong, String paramString, int paramInt)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: lload_2
    //   2: invokevirtual 635\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011(J)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   5: astore 6
    //   7: aload_0
    //   8: aload 6
    //   10: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   13: invokespecial 367\011com/didisoft/pgp/KeyStore:f\011(J)Llw/bouncycastle/openpgp/PGPSecretKeyRing;
    //   16: dup
    //   17: astore 7
    //   19: ifnonnull +30 -> 49
    //   22: new 160\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException
    //   25: dup
    //   26: new 186\011java/lang/StringBuilder
    //   29: dup
    //   30: ldc 62
    //   32: invokespecial 518\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   35: lload_2
    //   36: invokestatic 511\011java/lang/String:valueOf\011(J)Ljava/lang/String;
    //   39: invokevirtual 521\011java/lang/StringBuilder:append\011(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: invokevirtual 522\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   45: invokespecial 454\011com/didisoft/pgp/exceptions/NoPrivateKeyFoundException:<init>\011(Ljava/lang/String;)V
    //   48: athrow
    //   49: aload 6
    //   51: invokevirtual 627\011lw/bouncycastle/openpgp/PGPPublicKey:getSignatures\011()Ljava/util/Iterator;
    //   54: astore_2
    //   55: aload_2
    //   56: invokeinterface 727 1 0
    //   61: ifeq +295 -> 356
    //   64: aload_2
    //   65: invokeinterface 728 1 0
    //   70: checkcast 246\011lw/bouncycastle/openpgp/PGPSignature
    //   73: dup
    //   74: astore_3
    //   75: invokevirtual 680\011lw/bouncycastle/openpgp/PGPSignature:hasSubpackets\011()Z
    //   78: ifeq +275 -> 353
    //   81: aload_3
    //   82: invokevirtual 675\011lw/bouncycastle/openpgp/PGPSignature:getHashedSubPackets\011()Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;
    //   85: dup
    //   86: astore 8
    //   88: ifnull +265 -> 353
    //   91: aload 8
    //   93: bipush 27
    //   95: invokevirtual 708\011lw/bouncycastle/openpgp/PGPSignatureSubpacketVector:getSubpacket\011(I)Llw/bouncycastle/bcpg/SignatureSubpacket;
    //   98: ifnull +255 -> 353
    //   101: aload 8
    //   103: iconst_0
    //   104: invokestatic 347\011com/didisoft/pgp/KeyStore:a\011(Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;Z)Lcom/didisoft/pgp/bc/PGPSignatureSubpacketGeneratorExtended;
    //   107: astore_2
    //   108: iload 5
    //   110: ifle +20 -> 130
    //   113: aload_2
    //   114: iconst_0
    //   115: iload 5
    //   117: bipush 60
    //   119: imul
    //   120: bipush 60
    //   122: imul
    //   123: bipush 24
    //   125: imul
    //   126: i2l
    //   127: invokevirtual 435\011com/didisoft/pgp/bc/PGPSignatureSubpacketGeneratorExtended:setKeyExpirationTime\011(ZJ)V
    //   130: aload_2
    //   131: invokevirtual 432\011com/didisoft/pgp/bc/PGPSignatureSubpacketGeneratorExtended:generate\011()Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;
    //   134: astore_2
    //   135: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   138: aload_3
    //   139: invokevirtual 676\011lw/bouncycastle/openpgp/PGPSignature:getKeyAlgorithm\011()I
    //   142: aload_3
    //   143: invokevirtual 674\011lw/bouncycastle/openpgp/PGPSignature:getHashAlgorithm\011()I
    //   146: invokevirtual 410\011com/didisoft/pgp/bc/BCFactory:CreatePGPSignatureGenerator\011(II)Llw/bouncycastle/openpgp/PGPSignatureGenerator;
    //   149: astore 5
    //   151: aload 6
    //   153: aload_3
    //   154: invokestatic 632\011lw/bouncycastle/openpgp/PGPPublicKey:removeCertification\011(Llw/bouncycastle/openpgp/PGPPublicKey;Llw/bouncycastle/openpgp/PGPSignature;)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   157: astore 9
    //   159: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   162: aload 5
    //   164: aload_3
    //   165: invokevirtual 678\011lw/bouncycastle/openpgp/PGPSignature:getSignatureType\011()I
    //   168: aload 7
    //   170: invokevirtual 657\011lw/bouncycastle/openpgp/PGPSecretKeyRing:getSecretKey\011()Llw/bouncycastle/openpgp/PGPSecretKey;
    //   173: aload 4
    //   175: invokestatic 414\011com/didisoft/pgp/bc/BaseLib:extractPrivateKey\011(Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;)Llw/bouncycastle/openpgp/PGPPrivateKey;
    //   178: invokevirtual 411\011com/didisoft/pgp/bc/BCFactory:initSign\011(Llw/bouncycastle/openpgp/PGPSignatureGenerator;ILlw/bouncycastle/openpgp/PGPPrivateKey;)V
    //   181: aload 5
    //   183: aload_2
    //   184: invokevirtual 685\011lw/bouncycastle/openpgp/PGPSignatureGenerator:setHashedSubpackets\011(Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;)V
    //   187: aload 5
    //   189: aload_3
    //   190: invokevirtual 679\011lw/bouncycastle/openpgp/PGPSignature:getUnhashedSubPackets\011()Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;
    //   193: invokevirtual 686\011lw/bouncycastle/openpgp/PGPSignatureGenerator:setUnhashedSubpackets\011(Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;)V
    //   196: aload 8
    //   198: invokevirtual 709\011lw/bouncycastle/openpgp/PGPSignatureSubpacketVector:isPrimaryUserID\011()Z
    //   201: ifeq +53 -> 254
    //   204: aconst_null
    //   205: astore_3
    //   206: aload 6
    //   208: invokevirtual 630\011lw/bouncycastle/openpgp/PGPPublicKey:getUserIDs\011()Ljava/util/Iterator;
    //   211: invokeinterface 727 1 0
    //   216: ifeq +17 -> 233
    //   219: aload 6
    //   221: invokevirtual 630\011lw/bouncycastle/openpgp/PGPPublicKey:getUserIDs\011()Ljava/util/Iterator;
    //   224: invokeinterface 728 1 0
    //   229: checkcast 184\011java/lang/String
    //   232: astore_3
    //   233: aload 5
    //   235: aload_3
    //   236: aload 9
    //   238: invokevirtual 682\011lw/bouncycastle/openpgp/PGPSignatureGenerator:generateCertification\011(Ljava/lang/String;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPSignature;
    //   241: astore_2
    //   242: aload 9
    //   244: aload_3
    //   245: aload_2
    //   246: invokestatic 620\011lw/bouncycastle/openpgp/PGPPublicKey:addCertification\011(Llw/bouncycastle/openpgp/PGPPublicKey;Ljava/lang/String;Llw/bouncycastle/openpgp/PGPSignature;)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   249: astore 9
    //   251: goto +23 -> 274
    //   254: aload 5
    //   256: aload_1
    //   257: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   260: aload 9
    //   262: invokevirtual 683\011lw/bouncycastle/openpgp/PGPSignatureGenerator:generateCertification\011(Llw/bouncycastle/openpgp/PGPPublicKey;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPSignature;
    //   265: astore_2
    //   266: aload 9
    //   268: aload_2
    //   269: invokestatic 621\011lw/bouncycastle/openpgp/PGPPublicKey:addCertification\011(Llw/bouncycastle/openpgp/PGPPublicKey;Llw/bouncycastle/openpgp/PGPSignature;)Llw/bouncycastle/openpgp/PGPPublicKey;
    //   272: astore 9
    //   274: aload_1
    //   275: aload 6
    //   277: invokestatic 638\011lw/bouncycastle/openpgp/PGPPublicKeyRing:removePublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   280: dup
    //   281: astore_1
    //   282: aload 9
    //   284: invokestatic 637\011lw/bouncycastle/openpgp/PGPPublicKeyRing:insertPublicKey\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPPublicKey;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   287: astore_1
    //   288: goto +35 -> 323
    //   291: astore 9
    //   293: new 143\011com/didisoft/pgp/PGPException
    //   296: dup
    //   297: new 186\011java/lang/StringBuilder
    //   300: dup
    //   301: ldc 37
    //   303: invokespecial 518\011java/lang/StringBuilder:<init>\011(Ljava/lang/String;)V
    //   306: aload 6
    //   308: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   311: invokevirtual 519\011java/lang/StringBuilder:append\011(J)Ljava/lang/StringBuilder;
    //   314: invokevirtual 522\011java/lang/StringBuilder:toString\011()Ljava/lang/String;
    //   317: aload 9
    //   319: invokespecial 402\011com/didisoft/pgp/PGPException:<init>\011(Ljava/lang/String;Ljava/lang/Exception;)V
    //   322: athrow
    //   323: aload_0
    //   324: aload_1
    //   325: invokevirtual 396\011com/didisoft/pgp/KeyStore:replacePublicKeyRing\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;)V
    //   328: aload_0
    //   329: getfield 301\011com/didisoft/pgp/KeyStore:y\011Ljava/util/HashMap;
    //   332: new 182\011java/lang/Long
    //   335: dup
    //   336: aload_1
    //   337: invokevirtual 634\011lw/bouncycastle/openpgp/PGPPublicKeyRing:getPublicKey\011()Llw/bouncycastle/openpgp/PGPPublicKey;
    //   340: invokevirtual 625\011lw/bouncycastle/openpgp/PGPPublicKey:getKeyID\011()J
    //   343: invokespecial 497\011java/lang/Long:<init>\011(J)V
    //   346: invokevirtual 539\011java/util/HashMap:get\011(Ljava/lang/Object;)Ljava/lang/Object;
    //   349: checkcast 140\011com/didisoft/pgp/KeyPairInformation
    //   352: areturn
    //   353: goto -298 -> 55
    //   356: aconst_null
    //   357: areturn
    //
    // Exception table:
    //   from\011to\011target\011type
    //   151\011288\011291\011java/lang/Exception
  }

  public KeyPairInformation setKeyCertificationType(long paramLong, String paramString, KeyCertificationType paramKeyCertificationType)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, PGPException
  {
    paramLong = b(paramLong);
    return a(paramLong, paramString, paramKeyCertificationType);
  }

  public KeyPairInformation setKeyCertificationType(String paramString1, String paramString2, KeyCertificationType paramKeyCertificationType)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, PGPException
  {
    paramString1 = d(paramString1);
    return a(paramString1, paramString2, paramKeyCertificationType);
  }

  private KeyPairInformation a(PGPPublicKeyRing paramPGPPublicKeyRing, String paramString, KeyCertificationType paramKeyCertificationType)
    throws NoPrivateKeyFoundException, PGPException
  {
    PGPPublicKey localPGPPublicKey1 = paramPGPPublicKeyRing.getPublicKey();
    replacePublicKeyRing(paramPGPPublicKeyRing);
    PGPSecretKeyRing localPGPSecretKeyRing;
    if ((localPGPSecretKeyRing = f(localPGPPublicKey1.getKeyID())) == null)
      throw new NoPrivateKeyFoundException("No secret key found. You must have the secret key with key Id :" + String.valueOf(localPGPPublicKey1.getKeyID()));
    Iterator localIterator1 = localPGPPublicKey1.getUserIDs();
    while (localIterator1.hasNext())
    {
      String str = (String)localIterator1.next();
      Iterator localIterator2 = localPGPPublicKey1.getSignaturesForID(str);
      while (localIterator2.hasNext())
      {
        PGPSignature localPGPSignature;
        if ((localPGPSignature = (PGPSignature)localIterator2.next()).hasSubpackets())
        {
          PGPSignatureSubpacketVector localPGPSignatureSubpacketVector = localPGPSignature.getHashedSubPackets();
          PGPSignatureGenerator localPGPSignatureGenerator = staticBCFactory.CreatePGPSignatureGenerator(localPGPSignature.getKeyAlgorithm(), localPGPSignature.getHashAlgorithm());
          try
          {
            PGPPublicKey localPGPPublicKey2 = PGPPublicKey.removeCertification(localPGPPublicKey1, localPGPSignature);
            staticBCFactory.initSign(localPGPSignatureGenerator, paramKeyCertificationType.getValue(), BaseLib.extractPrivateKey(localPGPSecretKeyRing.getSecretKey(), paramString));
            localPGPSignatureGenerator.setHashedSubpackets(localPGPSignatureSubpacketVector);
            localPGPSignatureGenerator.setUnhashedSubpackets(localPGPSignature.getUnhashedSubPackets());
            localPGPSignature = localPGPSignatureGenerator.generateCertification(str, localPGPPublicKey1);
            localPGPPublicKey2 = PGPPublicKey.addCertification(localPGPPublicKey2, str, localPGPSignature);
            paramPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing, localPGPPublicKey1), localPGPPublicKey2);
          }
          catch (Exception localException)
          {
            throw new PGPException("Error changing key certification for Key ID : " + localPGPPublicKey1.getKeyID(), localException);
          }
        }
      }
    }
    replacePublicKeyRing(paramPGPPublicKeyRing);
    return (KeyPairInformation)y.get(new Long(localPGPPublicKey1.getKeyID()));
  }

  public boolean changeUserId(long paramLong, String paramString1, String paramString2, String paramString3)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, WrongPasswordException, PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing;
    if ((localPGPPublicKeyRing = d(paramLong)) == null)
      throw new NoPublicKeyFoundException("No public key exists with key Id :" + String.valueOf(paramLong));
    PGPPublicKey localPGPPublicKey = localPGPPublicKeyRing.getPublicKey();
    Object localObject1 = null;
    PGPSignatureSubpacketVector localPGPSignatureSubpacketVector = null;
    Iterator localIterator = localPGPPublicKey.getSignaturesForID(paramString2);
    Object localObject2;
    while (localIterator.hasNext())
      if ((localObject2 = (PGPSignature)localIterator.next()).hasSubpackets())
      {
        localObject1 = ((PGPSignature)localObject2).getHashedSubPackets();
        localPGPSignatureSubpacketVector = ((PGPSignature)localObject2).getUnhashedSubPackets();
        if ((localObject1 != null) && (((PGPSignatureSubpacketVector)localObject1).getSubpacket(27) != null))
          localObject1 = (localObject1 = a((PGPSignatureSubpacketVector)localObject1, true)).generate();
      }
    if ((localPGPPublicKey = PGPPublicKey.removeCertification(localPGPPublicKey, paramString2)) != null)
    {
      try
      {
        localObject2 = staticBCFactory.CreatePGPSignatureGenerator(localPGPPublicKey.getAlgorithm(), 2);
        if (localObject1 != null)
          ((PGPSignatureGenerator)localObject2).setHashedSubpackets((PGPSignatureSubpacketVector)localObject1);
        if (localPGPSignatureSubpacketVector != null)
          ((PGPSignatureGenerator)localObject2).setUnhashedSubpackets(localPGPSignatureSubpacketVector);
      }
      catch (Exception localException)
      {
        throw new PGPException("creating signature generator: " + localException, localException);
      }
      PGPSecretKeyRing localPGPSecretKeyRing;
      if ((localPGPSecretKeyRing = f(localPGPPublicKey.getKeyID())) == null)
        throw new NoPrivateKeyFoundException("No secret key found. You must have the secret key with key Id :" + String.valueOf(paramLong));
      try
      {
        staticBCFactory.initSign((PGPSignatureGenerator)localObject2, 19, BaseLib.extractPrivateKey(localPGPSecretKeyRing.getSecretKey(), paramString1));
        paramLong = ((PGPSignatureGenerator)localObject2).generateCertification(paramString3, localPGPPublicKey);
        paramLong = PGPPublicKey.addCertification(localPGPPublicKey, paramString3, paramLong);
        localPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(localPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(localPGPPublicKeyRing, localPGPPublicKey), paramLong);
      }
      catch (Exception paramLong)
      {
        throw new PGPException("creating signature for userId : " + paramString3, paramLong);
      }
      replacePublicKeyRing(localPGPPublicKeyRing);
      return true;
    }
    return false;
  }

  public void changePrimaryUserId(long paramLong, String paramString1, String paramString2)
    throws NoPublicKeyFoundException, NoPrivateKeyFoundException, WrongPasswordException, PGPException
  {
    if ((localObject = d(paramLong)) == null)
      throw new NoPublicKeyFoundException("No public key exists with key Id :" + String.valueOf(paramLong));
    Object localObject = (localObject = ((PGPPublicKeyRing)localObject).getPublicKey()).getUserIDs();
    String str = null;
    if (((Iterator)localObject).hasNext())
      str = (String)((Iterator)localObject).next();
    if (str != null)
    {
      changeUserId(paramLong, paramString1, str, paramString2);
      return;
    }
    addUserId(paramLong, paramString1, paramString2);
  }

  public KeyPairInformation generateEccKeyPair(String paramString1, String paramString2, String paramString3)
    throws PGPException
  {
    return generateEccKeyPair(paramString1, paramString2, paramString3, new String[] { "ZIP", "ZLIB", "BZIP2", "UNCOMPRESSED" }, new String[] { "SHA512", "SHA384", "SHA256" }, new String[] { "AES_256", "AES_192", "AES_128" });
  }

  public KeyPairInformation generateEccKeyPair(String paramString1, String paramString2, String paramString3, long paramLong)
    throws PGPException
  {
    return generateEccKeyPair(paramString1, paramString2, paramString3, new String[] { "ZIP", "ZLIB", "BZIP2", "UNCOMPRESSED" }, new String[] { "SHA512", "SHA384", "SHA256" }, new String[] { "AES_256", "AES_192", "AES_128" }, paramLong);
  }

  public KeyPairInformation generateEccKeyPair(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3)
    throws PGPException
  {
    if ("P256".equalsIgnoreCase(paramString1))
      paramString1 = 256;
    else if ("P384".equalsIgnoreCase(paramString1))
      paramString1 = 384;
    else if ("P521".equalsIgnoreCase(paramString1))
      paramString1 = 521;
    else
      throw new IllegalArgumentException("The supplied EC Curve parameter is invalid");
    return generateKeyPair(paramString1, paramString2, "EC", paramString3, paramArrayOfString1, paramArrayOfString2, paramArrayOfString3);
  }

  public KeyPairInformation generateEccKeyPair(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, long paramLong)
    throws PGPException
  {
    if ("P256".equalsIgnoreCase(paramString1))
      paramString1 = 256;
    else if ("P384".equalsIgnoreCase(paramString1))
      paramString1 = 384;
    else if ("P521".equalsIgnoreCase(paramString1))
      paramString1 = 521;
    else
      throw new IllegalArgumentException("The supplied EC Curve parameter is invalid");
    return generateKeyPair(paramString1, paramString2, "EC", paramString3, paramArrayOfString1, paramArrayOfString2, paramArrayOfString3, paramLong);
  }

  public KeyPairInformation generateRsaKeyPair(int paramInt, String paramString1, String paramString2)
    throws PGPException
  {
    return generateKeyPair(paramInt, paramString1, "RSA", paramString2, new String[] { "ZIP", "UNCOMPRESSED", "ZLIB", "BZIP2" }, new String[] { "SHA256", "SHA384", "SHA512", "SHA1", "MD5", "SHA256" }, new String[] { "CAST5", "TRIPLE_DES", "AES_128", "AES_192", "AES_256", "TWOFISH" });
  }

  public KeyPairInformation generateRsaKeyPair(int paramInt1, String paramString1, String paramString2, int paramInt2)
    throws PGPException
  {
    return generateKeyPair(paramInt1, paramString1, "RSA", paramString2, new String[] { "ZIP", "UNCOMPRESSED", "ZLIB", "BZIP2" }, new String[] { "SHA256", "SHA384", "SHA512", "SHA1", "MD5", "SHA256" }, new String[] { "CAST5", "TRIPLE_DES", "AES_128", "AES_192", "AES_256", "TWOFISH" }, paramInt2);
  }

  public KeyPairInformation generateElGamalKeyPair(int paramInt, String paramString1, String paramString2)
    throws PGPException
  {
    return generateKeyPair(paramInt, paramString1, "ELGAMAL", paramString2, new String[] { "ZIP", "UNCOMPRESSED", "ZLIB", "BZIP2" }, new String[] { "SHA256", "SHA384", "SHA512", "SHA1", "MD5", "SHA256" }, new String[] { "CAST5", "TRIPLE_DES", "AES_128", "AES_192", "AES_256", "TWOFISH" });
  }

  public KeyPairInformation generateElGamalKeyPair(int paramInt1, String paramString1, String paramString2, int paramInt2)
    throws PGPException
  {
    return generateKeyPair(paramInt1, paramString1, "ELGAMAL", paramString2, new String[] { "ZIP", "UNCOMPRESSED", "ZLIB", "BZIP2" }, new String[] { "SHA256", "SHA384", "SHA512", "SHA1", "MD5", "SHA256" }, new String[] { "CAST5", "TRIPLE_DES", "AES_128", "AES_192", "AES_256", "TWOFISH" }, paramInt2);
  }

  public KeyPairInformation generateKeyPair(int paramInt, String paramString1, String paramString2)
    throws PGPException
  {
    return generateKeyPair(paramInt, paramString1, "RSA", paramString2, new String[] { "ZIP", "UNCOMPRESSED" }, new String[] { "SHA1", "MD5", "SHA256" }, new String[] { "CAST5", "TRIPLE_DES", "AES_128", "AES_192", "AES_256" });
  }

  static int a(String paramString)
  {
    if ("SHA256".equalsIgnoreCase(paramString))
      return 8;
    if ("SHA384".equalsIgnoreCase(paramString))
      return 9;
    if ("SHA512".equalsIgnoreCase(paramString))
      return 10;
    if ("SHA224".equalsIgnoreCase(paramString))
      return 11;
    if ("SHA1".equalsIgnoreCase(paramString))
      return 2;
    if ("MD5".equalsIgnoreCase(paramString))
      return 1;
    if ("RIPEMD160".equalsIgnoreCase(paramString))
      return 3;
    if ("MD2".equalsIgnoreCase(paramString))
      return 5;
    return -1;
  }

  static int b(String paramString)
  {
    if ("ZLIB".equalsIgnoreCase(paramString))
      return 2;
    if ("ZIP".equalsIgnoreCase(paramString))
      return 1;
    if ("UNCOMPRESSED".equalsIgnoreCase(paramString))
      return 0;
    if ("BZIP2".equalsIgnoreCase(paramString))
      return 3;
    return -1;
  }

  static int c(String paramString)
  {
    if ("TRIPLE_DES".equalsIgnoreCase(paramString))
      return 2;
    if ("CAST5".equalsIgnoreCase(paramString))
      return 3;
    if ("BLOWFISH".equalsIgnoreCase(paramString))
      return 4;
    if ("AES_128".equalsIgnoreCase(paramString))
      return 7;
    if ("AES_192".equalsIgnoreCase(paramString))
      return 8;
    if ("AES_256".equalsIgnoreCase(paramString))
      return 9;
    if ("TWOFISH".equalsIgnoreCase(paramString))
      return 10;
    if ("DES".equalsIgnoreCase(paramString))
      return 6;
    if ("SAFER".equalsIgnoreCase(paramString))
      return 5;
    if ("IDEA".equalsIgnoreCase(paramString))
      return 5;
    return -1;
  }

  public KeyPairInformation generateKeyPair(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3)
    throws PGPException
  {
    return generateKeyPair(paramInt, paramString1, paramString2, paramString3, paramArrayOfString1, paramArrayOfString2, paramArrayOfString3, 0L);
  }

  public KeyPairInformation generateKeyPair(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, long paramLong)
    throws PGPException
  {
    String str1 = "";
    if (paramArrayOfString1.length > 0)
    {
      for (int i1 = 0; i1 < paramArrayOfString1.length - 1; i1++)
        str1 = str1 + paramArrayOfString1[i1] + ",";
      str1 = str1 + paramArrayOfString1[(paramArrayOfString1.length - 1)];
    }
    String str2 = "";
    if (paramArrayOfString3.length > 0)
    {
      for (paramArrayOfString1 = 0; paramArrayOfString1 < paramArrayOfString3.length - 1; paramArrayOfString1++)
        str2 = str2 + paramArrayOfString3[paramArrayOfString1] + ",";
      str2 = str2 + paramArrayOfString3[(paramArrayOfString3.length - 1)];
    }
    paramArrayOfString1 = "";
    if (paramArrayOfString2.length > 0)
    {
      for (paramArrayOfString3 = 0; paramArrayOfString3 < paramArrayOfString2.length - 1; paramArrayOfString3++)
        paramArrayOfString1 = paramArrayOfString1 + paramArrayOfString2[paramArrayOfString3] + ",";
      paramArrayOfString1 = paramArrayOfString1 + paramArrayOfString2[(paramArrayOfString2.length - 1)];
    }
    return generateKeyPair(paramInt, paramString1, paramString2, paramString3, str1, paramArrayOfString1, str2, paramLong);
  }

  public KeyPairInformation generateKeyPair(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws PGPException
  {
    return generateKeyPair(paramInt, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, 0L);
  }

  public KeyPairInformation generateKeyPair(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, long paramLong)
    throws PGPException
  {
    a("Generating {0} OpenPGP key pair.", paramString2);
    a("Primary User Id is {0}", paramString1);
    a("Key size is {0} bits", String.valueOf(paramInt));
    a("Preferred cipher algorithms are {0}", paramString6);
    a("Preferred hash algorithms are {0}", paramString5);
    a("Preferred compression algorithms are {0}", paramString4);
    paramString1 = (paramInt = a(paramInt, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramLong, m, !n, o, i.getValue())).generateSecretKeyRing();
    paramInt = paramInt.generatePublicKeyRing();
    a = PGPSecretKeyRingCollection.addSecretKeyRing(a, paramString1);
    f = PGPPublicKeyRingCollection.addPublicKeyRing(f, paramInt);
    a(paramInt);
    (paramString2 = (KeyPairInformation)y.get(new Long(paramInt.getPublicKey().getKeyID()))).setPublicKeyRing(paramInt);
    paramString2.setPrivateKeyRing(paramString1);
    y.put(new Long(paramString1.getPublicKey().getKeyID()), paramString2);
    save(false);
    return paramString2;
  }

  static PGPKeyRingGenerator a(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    throws PGPException
  {
    return a(paramInt, paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramLong, false, false, false, KeyCertificationType.PositiveCertification.getValue());
  }

  private static PGPKeyRingGenerator a(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt2)
    throws PGPException
  {
    paramString6 = paramString6.split(",");
    ArrayList localArrayList1 = new ArrayList();
    for (int i2 = 0; i2 < paramString6.length; i2++)
    {
      String str;
      int i5;
      if ((i5 = c(str = paramString6[i2].trim())) < 0)
        throw new InvalidParameterException("Wrong value for parameter 'cipherTypes': " + str + ". Must be one of: TRIPLE_DES, CAST5, BLOWFISH, AES_128, AES_192, AES_256, TWOFISH, IDEA, DES, SAFER");
      localArrayList1.add(new Integer(i5));
    }
    int[] arrayOfInt = new int[localArrayList1.size()];
    for (int i3 = 0; i3 < arrayOfInt.length; i3++)
      arrayOfInt[i3] = ((Integer)localArrayList1.get(i3)).intValue();
    Object localObject1 = paramString5.split(",");
    ArrayList localArrayList3 = new ArrayList();
    for (paramString5 = 0; paramString5 < localObject1.length; paramString5++)
    {
      int i1;
      if ((i1 = a(paramString6 = localObject1[paramString5].trim())) < 0)
        throw new InvalidParameterException("Wrong value for parameter 'hashingAlgorithmTypes': " + paramString6 + ". Must be one of: SHA256, SHA384, SHA512, SHA224, SHA1, MD5, RIPEMD160, MD2");
      localArrayList3.add(new Integer(i1));
    }
    paramString5 = new int[localArrayList3.size()];
    for (paramString6 = 0; paramString6 < paramString5.length; paramString6++)
      paramString5[paramString6] = ((Integer)localArrayList3.get(paramString6)).intValue();
    paramString6 = paramString4.split(",");
    ArrayList localArrayList2 = new ArrayList();
    for (paramString4 = 0; paramString4 < paramString6.length; paramString4++)
    {
      int i6;
      if ((i6 = b(localObject1 = paramString6[paramString4].trim())) < 0)
        throw new InvalidParameterException("Wrong value for parameter 'compressionTypes': " + (String)localObject1 + ". Must be one of: ZLIB, ZIP, UNCOMPRESSED, BZIP2");
      localArrayList2.add(new Integer(i6));
    }
    paramString4 = new int[localArrayList2.size()];
    for (int i4 = 0; i4 < paramString4.length; i4++)
      paramString4[i4] = ((Integer)localArrayList2.get(i4)).intValue();
    Object localObject2;
    Object localObject3;
    if ("EC".equalsIgnoreCase(paramString2))
    {
      localObject2 = new ECKeyPairGenerator();
      localObject3 = NISTNamedCurves.getByName("P-256");
      paramString2 = "P-256";
      if ((paramInt1 > 256) && (paramInt1 < 521))
      {
        localObject3 = NISTNamedCurves.getByName("P-384");
        paramString2 = "P-384";
      }
      else if (paramInt1 >= 521)
      {
        localObject3 = NISTNamedCurves.getByName("P-521");
        paramString2 = "P-521";
      }
      try
      {
        paramInt1 = IOUtil.getSecureRandom();
        paramString6 = new ECNamedDomainParameters(NISTNamedCurves.getOID(paramString2), ((X9ECParameters)localObject3).getCurve(), ((X9ECParameters)localObject3).getG(), ((X9ECParameters)localObject3).getN());
        ((AsymmetricCipherKeyPairGenerator)localObject2).init(new ECKeyGenerationParameters(paramString6, paramInt1));
        paramInt1 = ((AsymmetricCipherKeyPairGenerator)localObject2).generateKeyPair();
        paramString2 = ((AsymmetricCipherKeyPairGenerator)localObject2).generateKeyPair();
        paramBoolean1 = new BcPGPKeyPair(19, paramInt1, new Date());
        paramString2 = new BcPGPKeyPair(18, paramString2, new Date());
        paramInt1 = new PGPSignatureSubpacketGenerator();
        if (paramLong > 0L)
          paramInt1.setKeyExpirationTime(false, paramLong * 24L * 60L * 60L);
        paramInt1.setKeyFlags(false, 3);
        paramInt1.setPreferredSymmetricAlgorithms(false, arrayOfInt);
        paramInt1.setPreferredHashAlgorithms(false, paramString5);
        paramInt1.setPreferredCompressionAlgorithms(false, paramString4);
        paramInt1.setPrimaryUserID(false, true);
        paramString4 = new BcPGPDigestCalculatorProvider().get(2);
        a(paramInt1 = new PGPKeyRingGenerator(paramInt2, paramBoolean1, paramString1, paramString4, paramInt1.generate(), null, new BcPGPContentSignerBuilder(paramBoolean1.getPublicKey().getAlgorithm(), 10), new BcPBESecretKeyEncryptorBuilder(9, paramString4).build(paramString3.toCharArray())), paramString2);
        return paramInt1;
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
      {
        throw IOUtil.newPGPException(paramInt1 = localPGPException1);
      }
    }
    if (("ELGAMAL".equalsIgnoreCase(paramString2)) || ("DSA".equalsIgnoreCase(paramString2)))
    {
      (localObject2 = new DSAParametersGenerator()).init(1024, 50, IOUtil.getSecureRandom());
      (localObject3 = new DSAKeyPairGenerator()).init(new DSAKeyGenerationParameters(IOUtil.getSecureRandom(), ((DSAParametersGenerator)localObject2).generateParameters()));
      paramString2 = new lw.bouncycastle.crypto.generators.ElGamalKeyPairGenerator();
      if ((paramInt1 == 4096) && (paramBoolean1))
      {
        paramInt1 = new BigInteger(v);
        paramString6 = new BigInteger(u, 16);
        paramInt1 = new ElGamalParameters(paramString6, paramInt1);
        paramString2.init(new ElGamalKeyGenerationParameters(IOUtil.getSecureRandom(), paramInt1));
      }
      else if ((paramInt1 == 3072) && (paramBoolean1))
      {
        paramInt1 = new BigInteger(t);
        paramString6 = new BigInteger(s, 16);
        paramInt1 = new ElGamalParameters(paramString6, paramInt1);
        paramString2.init(new ElGamalKeyGenerationParameters(IOUtil.getSecureRandom(), paramInt1));
      }
      else if ((paramInt1 == 2048) && (paramBoolean1))
      {
        paramInt1 = new BigInteger(r, 16);
        paramString6 = new BigInteger(q, 16);
        paramInt1 = new ElGamalParameters(paramString6, paramInt1);
        paramString2.init(new ElGamalKeyGenerationParameters(IOUtil.getSecureRandom(), paramInt1));
      }
      else
      {
        if (paramBoolean3)
        {
          (paramString6 = new FastElGamal(paramInt1 / 8)).generateKeys();
          paramInt1 = new ElGamalParameters(paramString6.getPrivateKey().getP(), paramString6.getPublicKey().getG());
        }
        else
        {
          (paramString6 = new BaseElGamalKeyPairGenerator()).setWithLucasLehmerTest(paramBoolean2);
          paramInt1 = paramString6.generateParams(paramInt1, new SecureRandom());
          paramInt1 = new ElGamalParameters(paramInt1.getP(), paramInt1.getG());
        }
        paramString2.init(new ElGamalKeyGenerationParameters(IOUtil.getSecureRandom(), paramInt1));
      }
      paramInt1 = paramString2.generateKeyPair();
      try
      {
        paramString6 = new BcPGPKeyPair(17, ((DSAKeyPairGenerator)localObject3).generateKeyPair(), new Date());
        paramInt1 = new BcPGPKeyPair(16, paramInt1, new Date());
        (paramString2 = new PGPSignatureSubpacketGenerator()).setKeyExpirationTime(false, paramLong * 24L * 60L * 60L);
        paramString2.setKeyFlags(false, 3);
        paramString2.setPreferredSymmetricAlgorithms(false, arrayOfInt);
        paramString2.setPreferredHashAlgorithms(false, paramString5);
        paramString2.setPreferredCompressionAlgorithms(false, paramString4);
        paramString2.setPrimaryUserID(false, true);
        paramBoolean1 = new BcPGPDigestCalculatorProvider().get(2);
        a(paramString2 = new PGPKeyRingGenerator(paramInt2, paramString6, paramString1, paramBoolean1, paramString2.generate(), null, new BcPGPContentSignerBuilder(paramString6.getPublicKey().getAlgorithm(), 2), new BcPBESecretKeyEncryptorBuilder(9, paramBoolean1).build(paramString3.toCharArray())), paramInt1);
        return paramString2;
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
      {
        throw IOUtil.newPGPException(paramString6 = localPGPException2);
      }
    }
    if ("RSA".equalsIgnoreCase(paramString2))
    {
      localObject2 = new RSAKeyPairGenerator();
      localObject3 = IOUtil.getSecureRandom();
      ((RSAKeyPairGenerator)localObject2).init(new RSAKeyGenerationParameters(BigInteger.valueOf(65537L), (SecureRandom)localObject3, paramInt1, 5));
      paramString2 = ((RSAKeyPairGenerator)localObject2).generateKeyPair();
      paramInt1 = ((RSAKeyPairGenerator)localObject2).generateKeyPair();
      try
      {
        paramString6 = new BcPGPKeyPair(f("RSA"), paramString2, new Date());
        paramInt1 = new BcPGPKeyPair(f("RSA"), paramInt1, new Date());
        (paramString2 = new PGPSignatureSubpacketGenerator()).setKeyExpirationTime(false, paramLong * 24L * 60L * 60L);
        paramString2.setKeyFlags(false, 3);
        paramString2.setPreferredSymmetricAlgorithms(false, arrayOfInt);
        paramString2.setPreferredHashAlgorithms(false, paramString5);
        paramString2.setPreferredCompressionAlgorithms(false, paramString4);
        paramString2.setPrimaryUserID(false, true);
        paramBoolean1 = new BcPGPDigestCalculatorProvider().get(2);
        a(paramString2 = new PGPKeyRingGenerator(paramInt2, paramString6, paramString1, paramBoolean1, paramString2.generate(), null, new BcPGPContentSignerBuilder(paramString6.getPublicKey().getAlgorithm(), 2), new BcPBESecretKeyEncryptorBuilder(9, paramBoolean1).build(paramString3.toCharArray())), paramInt1);
        return paramString2;
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException3)
      {
        throw IOUtil.newPGPException(paramString6 = localPGPException3);
      }
    }
    paramString2 = "RSA, ELGAMAL";
    paramString1 = paramString2;
    paramInt1 = "keyAlgorighm";
    throw new PGPException("Wrong value for parameter " + paramInt1 + ": " + paramString1 + ". Must be one of " + paramString2);
  }

  public void exportKeyRing(String paramString1, String paramString2)
    throws NoPublicKeyFoundException, IOException
  {
    exportKeyRing(paramString1, paramString2, true);
  }

  public void exportPubring(String paramString)
    throws IOException
  {
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = new FileOutputStream(paramString);
      f.encode(localFileOutputStream);
      localFileOutputStream.close();
      return;
    }
    finally
    {
      if (localFileOutputStream != null)
        localFileOutputStream.close();
    }
    throw paramString;
  }

  public void exportSecring(String paramString)
    throws IOException
  {
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = new FileOutputStream(paramString);
      a.encode(localFileOutputStream);
      localFileOutputStream.close();
      return;
    }
    finally
    {
      if (localFileOutputStream != null)
        localFileOutputStream.close();
    }
    throw paramString;
  }

  // ERROR //
  public void exportKeyRing(String paramString1, String paramString2, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: new 171\011java/io/FileOutputStream
    //   6: dup
    //   7: aload_1
    //   8: invokespecial 476\011java/io/FileOutputStream:<init>\011(Ljava/lang/String;)V
    //   11: astore 4
    //   13: aload_0
    //   14: aload 4
    //   16: aload_2
    //   17: iload_3
    //   18: invokevirtual 364\011com/didisoft/pgp/KeyStore:exportKeyRing\011(Ljava/io/OutputStream;Ljava/lang/String;Z)V
    //   21: aload 4
    //   23: invokestatic 421\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   26: aconst_null
    //   27: invokestatic 421\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   30: return
    //   31: pop
    //   32: aload 4
    //   34: invokestatic 421\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   37: aconst_null
    //   38: invokestatic 421\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   41: new 168\011java/io/File
    //   44: dup
    //   45: aload_1
    //   46: invokespecial 468\011java/io/File:<init>\011(Ljava/lang/String;)V
    //   49: invokevirtual 469\011java/io/File:delete\011()Z
    //   52: pop
    //   53: return
    //   54: astore_1
    //   55: aload 4
    //   57: invokestatic 421\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   60: aconst_null
    //   61: invokestatic 421\011com/didisoft/pgp/bc/IOUtil:closeStream\011(Ljava/io/OutputStream;)V
    //   64: aload_1
    //   65: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   3\01121\01131\011java/lang/Exception
    //   3\01121\01154\011finally
  }

  public void exportKeyRing(OutputStream paramOutputStream, String paramString, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    OutputStream localOutputStream = null;
    try
    {
      if (paramBoolean)
      {
        localOutputStream = paramOutputStream;
        paramOutputStream = new ArmoredOutputStream(localOutputStream);
        a(paramOutputStream);
      }
      try
      {
        (localObject = findSecretKeyRing(paramString)).encode(paramOutputStream);
      }
      catch (NoPrivateKeyFoundException localNoPrivateKeyFoundException)
      {
      }
      if (paramBoolean)
      {
        paramOutputStream = new ArmoredOutputStream(localOutputStream);
        a(paramOutputStream);
      }
      (localObject = d(paramString)).encode(paramOutputStream);
      return;
    }
    catch (IOException localIOException)
    {
    }
    finally
    {
      Object localObject;
      if (paramBoolean)
        IOUtil.closeStream(paramOutputStream);
    }
  }

  public void exportKeyRing(OutputStream paramOutputStream, long paramLong, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    OutputStream localOutputStream = null;
    try
    {
      if (paramBoolean)
      {
        localOutputStream = paramOutputStream;
        paramOutputStream = new ArmoredOutputStream(localOutputStream);
        a(paramOutputStream);
      }
      try
      {
        (localObject = findSecretKeyRing(paramLong)).encode(paramOutputStream);
      }
      catch (NoPrivateKeyFoundException localNoPrivateKeyFoundException)
      {
      }
      if (paramBoolean)
      {
        paramOutputStream = new ArmoredOutputStream(localOutputStream);
        a(paramOutputStream);
      }
      (localObject = b(paramLong)).encode(paramOutputStream);
      return;
    }
    catch (IOException localIOException)
    {
    }
    finally
    {
      Object localObject;
      if (paramBoolean)
        IOUtil.closeStream(paramOutputStream);
    }
  }

  public void exportKeyRing(String paramString, long paramLong, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    Object localObject1 = null;
    Object localObject2 = null;
    try
    {
      localObject1 = new FileOutputStream(paramString);
      if (paramBoolean)
      {
        localObject2 = localObject1;
        localObject1 = new ArmoredOutputStream(localObject2);
        a((OutputStream)localObject1);
      }
      try
      {
        (paramString = findSecretKeyRing(paramLong)).encode((OutputStream)localObject1);
        if (paramBoolean)
          IOUtil.closeStream((OutputStream)localObject1);
      }
      catch (NoPrivateKeyFoundException localNoPrivateKeyFoundException)
      {
      }
      if (paramBoolean)
      {
        localObject1 = new ArmoredOutputStream(localObject2);
        a((OutputStream)localObject1);
      }
      (paramString = b(paramLong)).encode((OutputStream)localObject1);
      return;
    }
    catch (IOException localIOException)
    {
    }
    finally
    {
      IOUtil.closeStream((OutputStream)localObject1);
      IOUtil.closeStream(localObject2);
    }
    throw paramString;
  }

  public void exportPublicKey(String paramString1, String paramString2, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    IOUtil.exportPublicKeyRing(paramString2 = d(paramString2), paramString1, paramBoolean, z);
  }

  public void exportPublicKey(OutputStream paramOutputStream, String paramString, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    IOUtil.exportPublicKeyRing(paramString = d(paramString), paramOutputStream, paramBoolean, z);
  }

  public void exportPublicKey(OutputStream paramOutputStream, long paramLong, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    IOUtil.exportPublicKeyRing(paramLong = b(paramLong), paramOutputStream, paramBoolean, z);
  }

  public void exportPublicKey(String paramString, long paramLong, boolean paramBoolean)
    throws NoPublicKeyFoundException, IOException
  {
    IOUtil.exportPublicKeyRing(paramLong = b(paramLong), paramString, paramBoolean, z);
  }

  public void exportPrivateKey(String paramString1, String paramString2, boolean paramBoolean)
    throws NoPrivateKeyFoundException, IOException
  {
    IOUtil.exportPrivateKey(paramString2 = findSecretKeyRing(paramString2), paramString1, paramBoolean, z);
  }

  public void exportPrivateKey(OutputStream paramOutputStream, String paramString, boolean paramBoolean)
    throws NoPrivateKeyFoundException, IOException
  {
    IOUtil.exportPrivateKey(paramString = findSecretKeyRing(paramString), paramOutputStream, paramBoolean, z);
  }

  public void exportPrivateKey(OutputStream paramOutputStream, long paramLong, boolean paramBoolean)
    throws NoPrivateKeyFoundException, IOException
  {
    IOUtil.exportPrivateKey(paramLong = findSecretKeyRing(paramLong), paramOutputStream, paramBoolean, z);
  }

  public void exportPrivateKey(String paramString, long paramLong, boolean paramBoolean)
    throws NoPrivateKeyFoundException, IOException
  {
    IOUtil.exportPrivateKey(paramLong = findSecretKeyRing(paramLong), paramString, paramBoolean, z);
  }

  public KeyPairInformation importPublicKey(KeyPairInformation paramKeyPairInformation)
  {
    try
    {
      a(paramKeyPairInformation.getRawPublicKeyRing());
      if (f.contains(paramKeyPairInformation.getKeyID()))
        f = PGPPublicKeyRingCollection.removePublicKeyRing(f, paramKeyPairInformation.getRawPublicKeyRing());
      f = PGPPublicKeyRingCollection.addPublicKeyRing(f, paramKeyPairInformation.getRawPublicKeyRing());
      KeyPairInformation localKeyPairInformation;
      (localKeyPairInformation = new KeyPairInformation()).setPublicKeyRing(paramKeyPairInformation.getRawPublicKeyRing());
      y.put(new Long(paramKeyPairInformation.getKeyID()), localKeyPairInformation);
      return localKeyPairInformation;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    return null;
  }

  public KeyPairInformation[] importPublicKey(String paramString)
    throws IOException, PGPException, NoPublicKeyFoundException
  {
    paramString = loadKeyFile(paramString);
    return a(paramString);
  }

  public KeyPairInformation[] importPublicKey(InputStream paramInputStream)
    throws IOException, PGPException, NoPublicKeyFoundException
  {
    paramInputStream = loadKeyStream(paramInputStream);
    return a(paramInputStream);
  }

  private KeyPairInformation[] a(List paramList)
    throws IOException, PGPException, NoPublicKeyFoundException
  {
    LinkedList localLinkedList = new LinkedList();
    int i1 = 0;
    for (int i2 = 0; i2 < paramList.size(); i2++)
    {
      Object localObject;
      if (((localObject = paramList.get(i2)) instanceof PGPPublicKeyRing))
      {
        i1 = 1;
        localObject = (PGPPublicKeyRing)localObject;
        try
        {
          if (f.contains(((PGPPublicKeyRing)localObject).getPublicKey().getKeyID()))
            f = PGPPublicKeyRingCollection.removePublicKeyRing(f, (PGPPublicKeyRing)localObject);
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException)
        {
        }
        f = PGPPublicKeyRingCollection.addPublicKeyRing(f, (PGPPublicKeyRing)localObject);
        a((PGPPublicKeyRing)localObject);
        KeyPairInformation localKeyPairInformation;
        (localKeyPairInformation = new KeyPairInformation(z)).setPublicKeyRing((PGPPublicKeyRing)localObject);
        localLinkedList.add(localKeyPairInformation);
        a("Imported public key {0}", localKeyPairInformation.getKeyIDHex());
      }
    }
    if (i1 == 0)
      throw new NoPublicKeyFoundException("No public key was found in the supplied source.");
    save(false);
    return (KeyPairInformation[])localLinkedList.toArray(new KeyPairInformation[localLinkedList.size()]);
  }

  public KeyPairInformation[] importKeyRing(String paramString)
    throws IOException, PGPException
  {
    return importKeyRing(paramString, null);
  }

  public KeyPairInformation[] importKeyStore(KeyStore paramKeyStore)
    throws IOException, PGPException
  {
    Object localObject1 = new ByteArrayInputStream(paramKeyStore.f.getEncoded());
    paramKeyStore = new ByteArrayInputStream(paramKeyStore.a.getEncoded());
    localObject1 = importKeyRing((InputStream)localObject1);
    paramKeyStore = importKeyRing(paramKeyStore);
    ArrayList localArrayList = new ArrayList(localObject1.length + paramKeyStore.length);
    boolean[] arrayOfBoolean;
    Arrays.fill(arrayOfBoolean = new boolean[paramKeyStore.length], false);
    for (int i1 = 0; i1 < localObject1.length; i1++)
    {
      Object localObject2 = localObject1[i1];
      for (int i2 = 0; i2 < paramKeyStore.length; i2++)
      {
        Object localObject3 = paramKeyStore[i2];
        if (localObject2.getKeyID() == localObject3.getKeyID())
        {
          arrayOfBoolean[i2] = true;
          localObject2.setPrivateKeyRing(localObject3.getRawPrivateKeyRing());
          break;
        }
      }
      localArrayList.add(localObject2);
    }
    for (i1 = 0; i1 < arrayOfBoolean.length; i1++)
      if (arrayOfBoolean[i1] == 0)
        localArrayList.add(paramKeyStore[i1]);
    return (KeyPairInformation[])localArrayList.toArray(new KeyPairInformation[localArrayList.size()]);
  }

  public KeyPairInformation[] importKeyRing(String paramString1, String paramString2)
    throws IOException, PGPException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      paramString1 = importKeyRing(localFileInputStream, paramString2);
      return paramString1;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString1;
  }

  public KeyPairInformation importKeyRing(KeyPairInformation paramKeyPairInformation)
  {
    try
    {
      a(paramKeyPairInformation.getRawPublicKeyRing());
      if (f.contains(paramKeyPairInformation.getKeyID()))
        f = PGPPublicKeyRingCollection.removePublicKeyRing(f, paramKeyPairInformation.getRawPublicKeyRing());
      f = PGPPublicKeyRingCollection.addPublicKeyRing(f, paramKeyPairInformation.getRawPublicKeyRing());
      if (a.contains(paramKeyPairInformation.getKeyID()))
        a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, paramKeyPairInformation.getRawPrivateKeyRing());
      a = PGPSecretKeyRingCollection.addSecretKeyRing(a, paramKeyPairInformation.getRawPrivateKeyRing());
      y.put(new Long(paramKeyPairInformation.getKeyID()), paramKeyPairInformation);
      a("Imported key {0}", paramKeyPairInformation.getKeyIDHex());
      return paramKeyPairInformation;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    return null;
  }

  public KeyPairInformation[] importKeyRing(InputStream paramInputStream)
    throws IOException, PGPException
  {
    return importKeyRing(paramInputStream, null);
  }

  public KeyPairInformation[] importKeyRing(InputStream paramInputStream, String paramString)
    throws IOException, PGPException
  {
    g("Importing OpePGP key ring.");
    Object localObject = paramInputStream;
    if (!(paramInputStream instanceof ArmoredInputStream))
      localObject = PGPUtil.getDecoderStream(localObject = BaseLib.cleanGnuPGBackupKeys(paramInputStream));
    paramInputStream = new HashMap();
    BoolValue localBoolValue = new BoolValue(false);
    if ((localObject instanceof ArmoredInputStream))
    {
      localObject = (ArmoredInputStream)localObject;
      do
      {
        if (((ArmoredInputStream)localObject).isEndOfStream())
          break;
        List localList = parseKeyStream((InputStream)localObject, paramString, localBoolValue);
        for (int i2 = 0; i2 < localList.size(); i2++)
        {
          KeyPairInformation localKeyPairInformation2 = (KeyPairInformation)localList.get(i2);
          paramInputStream.put(localKeyPairInformation2.getKeyIDHex(), localKeyPairInformation2);
          a("Imported key {0}", localKeyPairInformation2.getKeyIDHex());
        }
      }
      while (!localBoolValue.isValue());
    }
    else
    {
      localObject = parseKeyStream((InputStream)localObject, paramString, localBoolValue);
      for (int i1 = 0; i1 < ((List)localObject).size(); i1++)
      {
        KeyPairInformation localKeyPairInformation1 = (KeyPairInformation)((List)localObject).get(i1);
        paramInputStream.put(localKeyPairInformation1.getKeyIDHex(), localKeyPairInformation1);
        a("Imported key {0}", localKeyPairInformation1.getKeyIDHex());
      }
    }
    save(false);
    return (KeyPairInformation[])paramInputStream.values().toArray(new KeyPairInformation[paramInputStream.size()]);
  }

  public KeyPairInformation[] importPrivateKey(String paramString)
    throws IOException, PGPException, NoPrivateKeyFoundException
  {
    return importPrivateKey(paramString, null);
  }

  public KeyPairInformation importKey(InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = loadKeyStream(paramInputStream);
    return b(paramInputStream);
  }

  public KeyPairInformation importKey(String paramString)
    throws IOException, PGPException
  {
    paramString = loadKeyFile(paramString);
    return b(paramString);
  }

  public KeyPairInformation[] importPrivateKey(String paramString1, String paramString2)
    throws IOException, PGPException, NoPrivateKeyFoundException
  {
    paramString1 = loadKeyFile(paramString1);
    return a(paramString1, paramString2);
  }

  public KeyPairInformation[] importPrivateKey(InputStream paramInputStream)
    throws IOException, PGPException, NoPrivateKeyFoundException
  {
    paramInputStream = loadKeyStream(paramInputStream);
    return a(paramInputStream, null);
  }

  public KeyPairInformation[] importPrivateKey(InputStream paramInputStream, String paramString)
    throws IOException, PGPException, NoPrivateKeyFoundException
  {
    paramInputStream = loadKeyStream(paramInputStream);
    return a(paramInputStream, paramString);
  }

  private KeyPairInformation[] a(List paramList, String paramString)
    throws IOException, PGPException, NoPrivateKeyFoundException
  {
    LinkedList localLinkedList = new LinkedList();
    int i1 = 0;
    for (int i2 = 0; i2 < paramList.size(); i2++)
    {
      Object localObject1;
      if (((localObject1 = paramList.get(i2)) instanceof PGPSecretKeyRing))
      {
        i1 = 1;
        localObject1 = (PGPSecretKeyRing)localObject1;
        if ((paramString == null) || (isKeyPasswordConfirmed((PGPSecretKeyRing)localObject1, paramString)))
        {
          try
          {
            if (a.contains(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()))
              a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, (PGPSecretKeyRing)localObject1);
          }
          catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
          {
          }
          a = PGPSecretKeyRingCollection.addSecretKeyRing(a, (PGPSecretKeyRing)localObject1);
          Object localObject2 = new ByteArrayOutputStream(1048576);
          Object localObject3 = ((PGPSecretKeyRing)localObject1).getSecretKeys();
          while (((Iterator)localObject3).hasNext())
            if ((localObject4 = ((PGPSecretKey)((Iterator)localObject3).next()).getPublicKey()) != null)
              ((ByteArrayOutputStream)localObject2).write(((PGPPublicKey)localObject4).getEncoded());
          localObject3 = staticBCFactory.CreatePGPPublicKeyRing(((ByteArrayOutputStream)localObject2).toByteArray());
          try
          {
            if (!f.contains(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()))
            {
              f = PGPPublicKeyRingCollection.addPublicKeyRing(f, (PGPPublicKeyRing)localObject3);
              a((PGPPublicKeyRing)localObject3);
            }
          }
          catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
          {
          }
          Object localObject4 = new Long(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID());
          if ((localObject2 = (KeyPairInformation)y.get(localObject4)) == null)
          {
            (localObject2 = new KeyPairInformation(z)).setPublicKeyRing((PGPPublicKeyRing)localObject3);
            y.put(localObject4, localObject2);
          }
          ((KeyPairInformation)localObject2).setPrivateKeyRing((PGPSecretKeyRing)localObject1);
          a("Imported private key {0}", ((KeyPairInformation)localObject2).getKeyIDHex());
          localLinkedList.add(localObject2);
        }
        else
        {
          throw new WrongPasswordException("Secret key password is incorrect: " + paramString);
        }
      }
    }
    if (i1 == 0)
      throw new NoPrivateKeyFoundException("No private key was found in the supplied source");
    save(false);
    return (KeyPairInformation[])localLinkedList.toArray(new KeyPairInformation[localLinkedList.size()]);
  }

  private KeyPairInformation b(List paramList)
    throws IOException, PGPException
  {
    Object localObject1 = null;
    Object localObject2;
    for (int i1 = 0; i1 < paramList.size(); localObject2++)
    {
      Object localObject3;
      if (((localObject3 = paramList.get(i1)) instanceof PGPSecretKeyRing))
      {
        paramList = (PGPSecretKeyRing)localObject3;
        try
        {
          if (a.contains(paramList.getPublicKey().getKeyID()))
            a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, paramList);
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException1)
        {
        }
        a = PGPSecretKeyRingCollection.addSecretKeyRing(a, paramList);
        localObject1 = new ByteArrayOutputStream(1048576);
        localObject2 = paramList.getSecretKeys();
        while (((Iterator)localObject2).hasNext())
          if ((localObject3 = ((PGPSecretKey)((Iterator)localObject2).next()).getPublicKey()) != null)
            ((ByteArrayOutputStream)localObject1).write(((PGPPublicKey)localObject3).getEncoded());
        localObject2 = staticBCFactory.CreatePGPPublicKeyRing(((ByteArrayOutputStream)localObject1).toByteArray());
        try
        {
          if (!f.contains(paramList.getPublicKey().getKeyID()))
          {
            f = PGPPublicKeyRingCollection.addPublicKeyRing(f, (PGPPublicKeyRing)localObject2);
            a((PGPPublicKeyRing)localObject2);
          }
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException2)
        {
        }
        localObject3 = new Long(paramList.getPublicKey().getKeyID());
        if ((localObject1 = (KeyPairInformation)y.get(localObject3)) == null)
        {
          (localObject1 = new KeyPairInformation(z)).setPublicKeyRing((PGPPublicKeyRing)localObject2);
          y.put(localObject3, localObject1);
        }
        ((KeyPairInformation)localObject1).setPrivateKeyRing(paramList);
        a("Imported private key {0}", ((KeyPairInformation)localObject1).getKeyIDHex());
        break;
      }
      if ((localObject3 instanceof PGPPublicKeyRing))
      {
        paramList = (PGPPublicKeyRing)localObject3;
        try
        {
          if (f.contains(paramList.getPublicKey().getKeyID()))
            f = PGPPublicKeyRingCollection.removePublicKeyRing(f, paramList);
        }
        catch (lw.bouncycastle.openpgp.PGPException localPGPException3)
        {
        }
        f = PGPPublicKeyRingCollection.addPublicKeyRing(f, paramList);
        localObject1 = a(paramList);
        a("Imported public key {0}", ((KeyPairInformation)localObject1).getKeyIDHex());
        break;
      }
    }
    save(false);
    return localObject1;
  }

  public String getKeystoreFileName()
  {
    return b;
  }

  public String getKeystorePassword()
  {
    return c;
  }

  public void setKeystorePassword(String paramString)
  {
    c = paramString;
  }

  public KeyPairInformation[] listKeys()
  {
    KeyPairInformation[] arrayOfKeyPairInformation = getKeys();
    System.out.print(a("Type", 8));
    System.out.print(a("Bits", 10));
    System.out.print(a("Key ID", 9));
    System.out.print(a("Date", 11));
    System.out.println("User ID");
    for (int i1 = 0; i1 < arrayOfKeyPairInformation.length; i1++)
    {
      KeyPairInformation localKeyPairInformation = arrayOfKeyPairInformation[i1];
      System.out.print(a(localKeyPairInformation.getAlgorithm(), 8));
      System.out.print(a(String.valueOf(localKeyPairInformation.getKeySize()), 10));
      System.out.print(a(localKeyPairInformation.getKeyIDHex(), 9));
      StringBuffer localStringBuffer;
      (localStringBuffer = new StringBuffer()).append(localKeyPairInformation.getCreationTime().getYear()).append('/').append(localKeyPairInformation.getCreationTime().getMonth()).append('/').append(localKeyPairInformation.getCreationTime().getDate());
      System.out.print(a(localStringBuffer.toString(), 11));
      for (int i2 = 0; i2 < localKeyPairInformation.getUserIDs().length; i2++)
        System.out.print(localKeyPairInformation.getUserIDs()[i2]);
      System.out.println();
    }
    return arrayOfKeyPairInformation;
  }

  public KeyPairInformation getKey(String paramString)
  {
    KeyPairInformation localKeyPairInformation;
    if ((localKeyPairInformation = (KeyPairInformation)y.get(new Long(getKeyIdForUserId(paramString)))) == null)
      return (KeyPairInformation)y.get(new Long(getKeyIdForKeyIdHex(paramString)));
    return localKeyPairInformation;
  }

  public KeyPairInformation getKey(long paramLong)
  {
    if (y.get(new Long(paramLong)) != null)
      return (KeyPairInformation)y.get(new Long(paramLong));
    try
    {
      paramLong = f.getPublicKeyRing(paramLong);
      return (KeyPairInformation)y.get(new Long(paramLong.getPublicKey().getKeyID()));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    return null;
  }

  public KeyPairInformation[] getKeys()
  {
    return (KeyPairInformation[])y.values().toArray(new KeyPairInformation[y.size()]);
  }

  public KeyPairInformation[] getKeys(String paramString)
  {
    LinkedList localLinkedList = new LinkedList();
    paramString = (paramString = e(paramString)).iterator();
    while (paramString.hasNext())
    {
      PGPPublicKeyRing localPGPPublicKeyRing = (PGPPublicKeyRing)paramString.next();
      localLinkedList.add(y.get(new Long(localPGPPublicKeyRing.getPublicKey().getKeyID())));
    }
    return (KeyPairInformation[])localLinkedList.toArray(new KeyPairInformation[localLinkedList.size()]);
  }

  private KeyPairInformation a(PGPPublicKeyRing paramPGPPublicKeyRing)
  {
    KeyPairInformation localKeyPairInformation;
    if ((localKeyPairInformation = (KeyPairInformation)y.get(new Long(paramPGPPublicKeyRing.getPublicKey().getKeyID()))) == null)
    {
      localKeyPairInformation = new KeyPairInformation(z);
      y.put(new Long(paramPGPPublicKeyRing.getPublicKey().getKeyID()), localKeyPairInformation);
    }
    localKeyPairInformation.setPublicKeyRing(paramPGPPublicKeyRing);
    paramPGPPublicKeyRing = paramPGPPublicKeyRing.getPublicKeys();
    while (paramPGPPublicKeyRing.hasNext())
    {
      PGPPublicKey localPGPPublicKey;
      String str = KeyPairInformation.keyId2Hex((localPGPPublicKey = (PGPPublicKey)paramPGPPublicKeyRing.next()).getKeyID());
      if (x.get(str) == null)
      {
        (localObject1 = new LinkedList()).add(new Long(localPGPPublicKey.getKeyID()));
        x.put(str, localObject1);
      }
      else
      {
        (localObject1 = (List)x.get(str)).add(new Long(localPGPPublicKey.getKeyID()));
      }
      Object localObject1 = localPGPPublicKey.getUserIDs();
      while (((Iterator)localObject1).hasNext())
      {
        str = (String)((Iterator)localObject1).next();
        Object localObject2;
        if (w.get(str) == null)
        {
          (localObject2 = new LinkedList()).add(new Long(localPGPPublicKey.getKeyID()));
          w.put(str, localObject2);
        }
        else
        {
          (localObject2 = (List)w.get(str)).add(new Long(localPGPPublicKey.getKeyID()));
        }
      }
    }
    return localKeyPairInformation;
  }

  private void a(PGPPublicKey paramPGPPublicKey)
  {
    Object localObject1 = paramPGPPublicKey.getUserIDs();
    Object localObject2;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (String)((Iterator)localObject1).next();
      List localList;
      if ((localList = (List)w.get(localObject2)) != null)
        for (int i2 = 0; i2 < localList.size(); i2++)
        {
          if (((Long)localList.get(i2)).longValue() == paramPGPPublicKey.getKeyID())
            localList.remove(i2);
          if (localList.size() == 0)
            w.remove(localObject2);
        }
    }
    localObject1 = KeyPairInformation.keyId2Hex(paramPGPPublicKey.getKeyID());
    if ((localObject2 = (List)x.get(localObject1)) != null)
      for (int i1 = 0; i1 < ((List)localObject2).size(); i1++)
      {
        if (((Long)((List)localObject2).get(i1)).longValue() == paramPGPPublicKey.getKeyID())
          ((List)localObject2).remove(i1);
        if (((List)localObject2).size() == 0)
          x.remove(localObject1);
      }
  }

  private void b(PGPPublicKeyRing paramPGPPublicKeyRing)
  {
    y.remove(new Long(paramPGPPublicKeyRing.getPublicKey().getKeyID()));
    paramPGPPublicKeyRing = paramPGPPublicKeyRing.getPublicKeys();
    while (paramPGPPublicKeyRing.hasNext())
    {
      PGPPublicKey localPGPPublicKey = (PGPPublicKey)paramPGPPublicKeyRing.next();
      a(localPGPPublicKey);
    }
  }

  private void a(PGPSecretKeyRing paramPGPSecretKeyRing)
  {
    int i1 = 0;
    Object localObject1 = paramPGPSecretKeyRing.getSecretKeys();
    Object localObject2;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (PGPSecretKey)((Iterator)localObject1).next();
      try
      {
        if (!f.contains(((PGPSecretKey)localObject2).getKeyID()))
        {
          i1 = 1;
          a(((PGPSecretKey)localObject2).getPublicKey());
        }
      }
      catch (lw.bouncycastle.openpgp.PGPException localPGPException)
      {
      }
    }
    localObject1 = new Long(paramPGPSecretKeyRing.getPublicKey().getKeyID());
    if (i1 != 0)
    {
      y.remove(localObject1);
      return;
    }
    (localObject2 = (KeyPairInformation)y.get(localObject1)).setPrivateKeyRing(null);
  }

  protected void onLoadKeys()
    throws PGPException
  {
    x.clear();
    y.clear();
    w.clear();
    HashSet localHashSet = new HashSet();
    Iterator localIterator = f.getKeyRings();
    Object localObject1;
    KeyPairInformation localKeyPairInformation;
    while (localIterator.hasNext())
    {
      localObject1 = (PGPPublicKeyRing)localIterator.next();
      (localKeyPairInformation = new KeyPairInformation(z)).setPublicKeyRing((PGPPublicKeyRing)localObject1);
      y.put(new Long(((PGPPublicKeyRing)localObject1).getPublicKey().getKeyID()), localKeyPairInformation);
      a(localKeyPairInformation.getRawPublicKeyRing());
    }
    localIterator = a.getKeyRings();
    while (localIterator.hasNext())
    {
      localObject1 = (PGPSecretKeyRing)localIterator.next();
      if (!y.containsKey(new Long(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID())))
      {
        localKeyPairInformation = new KeyPairInformation(z);
        ArrayList localArrayList = new ArrayList();
        Object localObject2 = ((PGPSecretKeyRing)localObject1).getSecretKeys();
        while (((Iterator)localObject2).hasNext())
        {
          PGPSecretKey localPGPSecretKey;
          if ((localPGPSecretKey = (PGPSecretKey)((Iterator)localObject2).next()).getPublicKey() != null)
            localArrayList.add(localPGPSecretKey.getPublicKey());
        }
        localObject2 = new ByteArrayOutputStream();
        for (int i1 = 0; i1 != localArrayList.size(); i1++)
        {
          PGPPublicKey localPGPPublicKey = (PGPPublicKey)localArrayList.get(i1);
          localHashSet.add(new Long(localPGPPublicKey.getKeyID()));
          try
          {
            localPGPPublicKey.encode((OutputStream)localObject2);
          }
          catch (IOException localIOException1)
          {
            throw new PGPException(localIOException1.getMessage(), localIOException1);
          }
        }
        PGPPublicKeyRing localPGPPublicKeyRing;
        try
        {
          localPGPPublicKeyRing = staticBCFactory.CreatePGPPublicKeyRing(((ByteArrayOutputStream)localObject2).toByteArray());
        }
        catch (IOException localIOException2)
        {
          throw new PGPException(localIOException2.getMessage(), localIOException2);
        }
        localKeyPairInformation.setPublicKeyRing(localPGPPublicKeyRing);
        a(localKeyPairInformation.getRawPublicKeyRing());
      }
      else
      {
        localKeyPairInformation = (KeyPairInformation)y.get(new Long(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()));
      }
      localKeyPairInformation.setPrivateKeyRing((PGPSecretKeyRing)localObject1);
      y.put(new Long(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()), localKeyPairInformation);
    }
  }

  private static PGPPublicKey a(PGPPublicKey paramPGPPublicKey, long paramLong, int paramInt)
  {
    paramInt = paramPGPPublicKey.getSignaturesOfType(16);
    while (paramInt.hasNext())
    {
      PGPSignature localPGPSignature;
      if ((localPGPSignature = (PGPSignature)paramInt.next()).getKeyID() == paramLong)
        paramPGPPublicKey = PGPPublicKey.removeCertification(paramPGPPublicKey, localPGPSignature);
    }
    return paramPGPPublicKey;
  }

  private void a(PGPPublicKeyRing paramPGPPublicKeyRing, PGPPublicKey paramPGPPublicKey, String paramString1, PGPSecretKey paramPGPSecretKey, String paramString2)
    throws PGPException
  {
    int i1 = 16;
    long l1 = paramPGPSecretKey.getKeyID();
    Object localObject = (localObject = paramPGPPublicKey).getSignaturesOfType(16);
    PGPSignature localPGPSignature;
    while (((Iterator)localObject).hasNext());
    if (((localPGPSignature = (PGPSignature)((Iterator)localObject).next()).getKeyID() == l1 ? 1 : 0) != 0)
      return;
    if (!isKeyPasswordConfirmed(paramPGPSecretKey, paramString2))
      throw new WrongPasswordException("Secret key password is incorrect: " + paramString2);
    try
    {
      localObject = staticBCFactory.CreatePGPSignatureGenerator(paramPGPSecretKey.getPublicKey().getAlgorithm(), 2);
      staticBCFactory.initSign((PGPSignatureGenerator)localObject, 16, BaseLib.extractPrivateKey(paramPGPSecretKey, paramString2.toCharArray()));
      paramPGPSecretKey = ((PGPSignatureGenerator)localObject).generateCertification(paramString1, paramPGPPublicKey);
      paramPGPPublicKey = PGPPublicKey.addCertification(paramPGPPublicKey, paramString1, paramPGPSecretKey);
    }
    catch (Exception paramPGPSecretKey)
    {
      throw new PGPException("exception creating signature: " + paramPGPSecretKey, paramPGPSecretKey);
    }
    paramPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing, paramPGPPublicKey), paramPGPPublicKey);
    replacePublicKeyRing(paramPGPPublicKeyRing);
  }

  private void b(PGPPublicKeyRing paramPGPPublicKeyRing, PGPPublicKey paramPGPPublicKey, String paramString1, PGPSecretKey paramPGPSecretKey, String paramString2)
    throws PGPException
  {
    long l2 = paramPGPSecretKey.getKeyID();
    long l1 = paramPGPPublicKey.getKeyID();
    Object localObject1 = this;
    PGPPublicKey localPGPPublicKey = (localObject1 = b(l1)).getPublicKey();
    localObject1 = ((PGPPublicKeyRing)localObject1).getPublicKey().getSignaturesOfType(16);
    PGPSignature localPGPSignature;
    Object localObject2;
    while (((Iterator)localObject1).hasNext())
      if ((localPGPSignature = (PGPSignature)((Iterator)localObject1).next()).getKeyID() == localPGPPublicKey.getKeyID());
    if (((localPGPSignature.hasSubpackets()) && ((localObject2 = localPGPSignature.getHashedSubPackets()) != null) && ((localObject2 = ((PGPSignatureSubpacketVector)localObject2).getSubpacket(5)) != null) && (localPGPSignature.getKeyID() == l2) ? 1 : 0) != 0)
      return;
    if (!isKeyPasswordConfirmed(paramPGPSecretKey, paramString2))
      throw new WrongPasswordException("Secret key password is incorrect: " + paramString2);
    try
    {
      localObject1 = staticBCFactory.CreatePGPSignatureGenerator(paramPGPSecretKey.getPublicKey().getAlgorithm(), 2);
      staticBCFactory.initSign((PGPSignatureGenerator)localObject1, 16, BaseLib.extractPrivateKey(paramPGPSecretKey, paramString2));
      (paramString2 = new PGPSignatureSubpacketGenerator()).setSignatureCreationTime(false, new Date());
      paramString2.setTrust(false, 1, 120);
      ((PGPSignatureGenerator)localObject1).setHashedSubpackets(paramString2.generate());
      (paramString2 = new PGPSignatureSubpacketGeneratorExtended()).setIssuerKeyID(false, paramPGPSecretKey.getKeyID());
      ((PGPSignatureGenerator)localObject1).setUnhashedSubpackets(paramString2.generate());
      paramString2 = ((PGPSignatureGenerator)localObject1).generateCertification(paramString1, paramPGPPublicKey);
      paramPGPPublicKey = PGPPublicKey.addCertification(paramPGPPublicKey = a(paramPGPPublicKey, paramPGPSecretKey.getKeyID(), 16), paramString1, paramString2);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramString2 = localPGPException);
    }
    paramPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing, paramPGPPublicKey), paramPGPPublicKey);
    replacePublicKeyRing(paramPGPPublicKeyRing);
  }

  public boolean containsPublicKey(String paramString)
  {
    return (paramString = e(paramString)).size() > 0;
  }

  public boolean containsPrivateKey(String paramString)
  {
    return (paramString = getSecretKeyRingCollection(paramString)).size() > 0;
  }

  public boolean containsKey(String paramString)
  {
    Collection localCollection;
    if ((localCollection = e(paramString)).size() > 0)
      return true;
    if ((localCollection = getSecretKeyRingCollection(paramString)).size() > 0)
      return true;
    if (p.matcher(paramString).matches())
    {
      paramString = h(paramString);
      return x.containsKey(paramString);
    }
    return false;
  }

  public boolean containsKey(long paramLong)
  {
    PGPPublicKeyRing localPGPPublicKeyRing;
    if ((localPGPPublicKeyRing = d(paramLong)) != null)
      return true;
    try
    {
      return (paramLong = f(paramLong)) != null;
    }
    catch (NoPrivateKeyFoundException localNoPrivateKeyFoundException)
    {
    }
    return false;
  }

  public boolean containsPrivateKey(long paramLong)
  {
    try
    {
      return (paramLong = f(paramLong)) != null;
    }
    catch (NoPrivateKeyFoundException localNoPrivateKeyFoundException)
    {
    }
    return false;
  }

  public boolean containsPublicKey(long paramLong)
  {
    try
    {
      paramLong = f.getPublicKeyRing(paramLong) != null ? 1 : 0;
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      return false;
    }
    return paramLong;
  }

  public void setAutoSave(boolean paramBoolean)
  {
    d = paramBoolean;
  }

  public boolean isAutoSave()
  {
    return d;
  }

  public boolean isBackupOnSave()
  {
    return e;
  }

  public void setBackupOnSave(boolean paramBoolean)
  {
    e = paramBoolean;
  }

  public void save()
    throws PGPException
  {
    save(true);
  }

  public void save(boolean paramBoolean)
    throws PGPException
  {
    if ((!paramBoolean) && (!d))
      return;
    for (paramBoolean = false; paramBoolean < D.size(); paramBoolean++)
      ((IKeyStoreSaveListener)D.get(paramBoolean)).onSave(this);
    if (A)
      return;
    paramBoolean = new File(b);
    File localFile = new File(paramBoolean.getPath() + ".bak");
    try
    {
      if ((paramBoolean.exists()) && (e))
        a(paramBoolean, localFile);
    }
    catch (Exception localException)
    {
      throw new PGPException("exception preserving current store", localException);
    }
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = new FileOutputStream(paramBoolean);
      store(localFileOutputStream, c);
      return;
    }
    catch (IOException paramBoolean)
    {
      throw new PGPException("exception saving key store", paramBoolean);
    }
    finally
    {
      IOUtil.closeStream(localFileOutputStream);
    }
    throw paramBoolean;
  }

  // ERROR //
  protected void store(OutputStream paramOutputStream, String paramString)
    throws PGPException, IOException
  {
    // Byte code:
    //   0: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   3: bipush 9
    //   5: iconst_1
    //   6: invokestatic 426\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   9: invokevirtual 408\011com/didisoft/pgp/bc/BCFactory:CreatePGPEncryptedDataGenerator\011(IZLjava/security/SecureRandom;)Llw/bouncycastle/openpgp/PGPEncryptedDataGenerator;
    //   12: astore_3
    //   13: aload_3
    //   14: getstatic 294\011com/didisoft/pgp/KeyStore:staticBCFactory\011Lcom/didisoft/pgp/bc/BCFactory;
    //   17: aload_2
    //   18: invokevirtual 404\011com/didisoft/pgp/bc/BCFactory:CreatePBEKeyEncryptionMethodGenerator\011(Ljava/lang/String;)Llw/bouncycastle/openpgp/operator/PBEKeyEncryptionMethodGenerator;
    //   21: invokevirtual 598\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:addMethod\011(Llw/bouncycastle/openpgp/operator/PGPKeyEncryptionMethodGenerator;)V
    //   24: aload_3
    //   25: aload_1
    //   26: sipush 1024
    //   29: newarray byte
    //   31: invokevirtual 599\011lw/bouncycastle/openpgp/PGPEncryptedDataGenerator:open\011(Ljava/io/OutputStream;[B)Ljava/io/OutputStream;
    //   34: dup
    //   35: astore_1
    //   36: ldc 121
    //   38: aload_0
    //   39: getfield 281\011com/didisoft/pgp/KeyStore:g\011Ljava/util/Date;
    //   42: aload_0
    //   43: getfield 280\011com/didisoft/pgp/KeyStore:f\011Llw/bouncycastle/openpgp/PGPPublicKeyRingCollection;
    //   46: invokevirtual 644\011lw/bouncycastle/openpgp/PGPPublicKeyRingCollection:getEncoded\011()[B
    //   49: invokestatic 331\011com/didisoft/pgp/KeyStore:a\011(Ljava/io/OutputStream;Ljava/lang/String;Ljava/util/Date;[B)V
    //   52: aload_1
    //   53: ldc 124
    //   55: aload_0
    //   56: getfield 282\011com/didisoft/pgp/KeyStore:h\011Ljava/util/Date;
    //   59: aload_0
    //   60: getfield 275\011com/didisoft/pgp/KeyStore:a\011Llw/bouncycastle/openpgp/PGPSecretKeyRingCollection;
    //   63: invokevirtual 668\011lw/bouncycastle/openpgp/PGPSecretKeyRingCollection:getEncoded\011()[B
    //   66: invokestatic 331\011com/didisoft/pgp/KeyStore:a\011(Ljava/io/OutputStream;Ljava/lang/String;Ljava/util/Date;[B)V
    //   69: aload_1
    //   70: invokevirtual 484\011java/io/OutputStream:close\011()V
    //   73: return
    //   74: dup
    //   75: astore_1
    //   76: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   79: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   13\01173\01174\011lw/bouncycastle/openpgp/PGPException
  }

  private static byte[] a(PGPLiteralData paramPGPLiteralData)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    paramPGPLiteralData = paramPGPLiteralData.getInputStream();
    int i1;
    while ((i1 = paramPGPLiteralData.read()) >= 0)
      localByteArrayOutputStream.write(i1);
    return localByteArrayOutputStream.toByteArray();
  }

  private static void a(File paramFile1, File paramFile2)
    throws IOException
  {
    paramFile1 = new BufferedInputStream(new FileInputStream(paramFile1));
    paramFile2 = new BufferedOutputStream(new FileOutputStream(paramFile2));
    int i1;
    while ((i1 = paramFile1.read()) >= 0)
      paramFile2.write(i1);
    paramFile1.close();
    paramFile2.close();
  }

  private static void a(OutputStream paramOutputStream, String paramString, Date paramDate, byte[] paramArrayOfByte)
    throws IOException
  {
    PGPLiteralDataGenerator localPGPLiteralDataGenerator;
    (paramOutputStream = (localPGPLiteralDataGenerator = new PGPLiteralDataGenerator()).open(paramOutputStream, 'b', paramString, paramArrayOfByte.length, paramDate)).write(paramArrayOfByte);
    localPGPLiteralDataGenerator.close();
    paramOutputStream.close();
  }

  final PGPPublicKeyRing d(String paramString)
    throws NoPublicKeyFoundException
  {
    Object localObject;
    if (((localObject = e(paramString)).size() == 0) && (E.size() > 0))
    {
      localObject = "";
      String str = "";
      if (p.matcher(paramString).matches())
        str = paramString;
      else
        localObject = paramString;
      for (int i1 = 0; i1 < E.size(); i1++)
        ((IKeyStoreSearchListener)E.get(i1)).onKeyNotFound(this, true, 0L, str, (String)localObject);
      localObject = e(paramString);
    }
    if (((Collection)localObject).size() > 0)
      return (PGPPublicKeyRing)((Collection)localObject).iterator().next();
    throw new NoPublicKeyFoundException("No key found for userID: " + paramString);
  }

  final PGPPublicKeyRing b(long paramLong)
    throws NoPublicKeyFoundException
  {
    PGPPublicKeyRing localPGPPublicKeyRing1;
    PGPPublicKeyRing localPGPPublicKeyRing2;
    if (((localPGPPublicKeyRing1 = d(paramLong)) == null) && (E.size() > 0))
    {
      for (int i1 = 0; i1 < E.size(); i1++)
        ((IKeyStoreSearchListener)E.get(i1)).onKeyNotFound(this, true, paramLong, KeyPairInformation.keyId2Hex(paramLong), "");
      localPGPPublicKeyRing2 = d(paramLong);
    }
    if (localPGPPublicKeyRing2 == null)
      throw new NoPublicKeyFoundException("no key found matching keyID: " + paramLong);
    return localPGPPublicKeyRing2;
  }

  private Collection e(String paramString)
  {
    try
    {
      ArrayList localArrayList = new ArrayList();
      HashSet localHashSet = new HashSet();
      Object localObject1 = f.getKeyRings(paramString, k, !j);
      Object localObject2;
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (PGPPublicKeyRing)((Iterator)localObject1).next();
        localHashSet.add(new Long(((PGPPublicKeyRing)localObject2).getPublicKey().getKeyID()));
        localArrayList.add(localObject2);
      }
      localObject1 = a.getKeyRings(paramString, k, !j);
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (PGPSecretKeyRing)((Iterator)localObject1).next();
        if (!localHashSet.contains(new Long(((PGPSecretKeyRing)localObject2).getSecretKey().getKeyID())))
        {
          ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
          localObject2 = ((PGPSecretKeyRing)localObject2).getSecretKeys();
          while (((Iterator)localObject2).hasNext())
          {
            PGPSecretKey localPGPSecretKey = (PGPSecretKey)((Iterator)localObject2).next();
            localByteArrayOutputStream.write(localPGPSecretKey.getPublicKey().getEncoded());
          }
          localArrayList.add(staticBCFactory.CreatePGPPublicKeyRing(localByteArrayOutputStream.toByteArray()));
        }
      }
      if ((localArrayList.size() == 0) && (p.matcher(paramString).matches()))
      {
        localObject1 = h(paramString);
        if ((localObject2 = d(getKeyIdForKeyIdHex((String)localObject1))) != null)
          localArrayList.add(localObject2);
      }
      return localArrayList;
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException("unexpected exception on extraction: " + localIOException);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw new IllegalStateException("unexpected exception: " + localPGPException);
    }
  }

  private PGPPublicKeyRing d(long paramLong)
  {
    try
    {
      if (f.contains(paramLong))
        return f.getPublicKeyRing(paramLong);
      if (a.contains(paramLong))
      {
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
        paramLong = a.getSecretKeyRing(paramLong).getSecretKeys();
        while (paramLong.hasNext())
        {
          PGPSecretKey localPGPSecretKey = (PGPSecretKey)paramLong.next();
          localByteArrayOutputStream.write(localPGPSecretKey.getPublicKey().getEncoded());
        }
        return staticBCFactory.CreatePGPPublicKeyRing(localByteArrayOutputStream.toByteArray());
      }
      return null;
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException("unexpected exception on extraction: " + localIOException);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw new IllegalStateException("unexpected exception: " + localPGPException);
    }
  }

  protected List loadKeyFile(String paramString)
    throws FileNotFoundException, IOException, PGPException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString);
      paramString = loadKeyStream(localFileInputStream);
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString;
  }

  protected List loadKeyStream(InputStream paramInputStream)
    throws FileNotFoundException, IOException, PGPException
  {
    Object localObject = new LinkedList();
    BoolValue localBoolValue = new BoolValue();
    if (((paramInputStream = PGPUtil.getDecoderStream(paramInputStream = BaseLib.cleanGnuPGBackupKeys(paramInputStream))) instanceof ArmoredInputStream))
    {
      paramInputStream = (ArmoredInputStream)paramInputStream;
      do
      {
        if (paramInputStream.isEndOfStream())
          break;
        List localList = loadKeysFromDecodedStream(paramInputStream, localBoolValue);
        ((List)localObject).addAll(localList);
      }
      while (!localBoolValue.isValue());
    }
    else
    {
      localObject = loadKeysFromDecodedStream(paramInputStream, localBoolValue);
    }
    return localObject;
  }

  protected List loadKeysFromDecodedStream(InputStream paramInputStream, BoolValue paramBoolValue)
    throws PGPException, IOException
  {
    LinkedList localLinkedList = new LinkedList();
    (paramInputStream = new PGPObjectFactory2(paramInputStream)).setLoadingKey(true);
    try
    {
      for (Object localObject = paramInputStream.nextObject(); localObject != null; localObject = paramInputStream.nextObject())
        if ((localObject instanceof PGPPublicKeyRing))
        {
          localObject = (PGPPublicKeyRing)localObject;
          localLinkedList.add(localObject);
        }
        else if ((localObject instanceof PGPSecretKeyRing))
        {
          localObject = (PGPSecretKeyRing)localObject;
          localLinkedList.add(localObject);
        }
        else if ((!(localObject instanceof ExperimentalPacket)) && (!(localObject instanceof PGPOnePassSignatureList)))
        {
          throw new PGPException("Unexpected object found in stream: " + localObject.getClass().getName());
        }
    }
    catch (UnknownKeyPacketsException localUnknownKeyPacketsException)
    {
      paramBoolValue.setValue(true);
    }
    return localLinkedList;
  }

  protected List parseKeyStream(InputStream paramInputStream, String paramString, BoolValue paramBoolValue)
    throws PGPException, IOException
  {
    LinkedList localLinkedList = new LinkedList();
    (paramInputStream = new PGPObjectFactory2(paramInputStream)).setLoadingKey(true);
    try
    {
      for (localObject1 = paramInputStream.nextObject(); localObject1 != null; localObject1 = paramInputStream.nextObject())
      {
        Object localObject2;
        Object localObject3;
        if ((localObject1 instanceof PGPPublicKeyRing))
        {
          localObject1 = (PGPPublicKeyRing)localObject1;
          if (f.contains(((PGPPublicKeyRing)localObject1).getPublicKey().getKeyID()))
            f = PGPPublicKeyRingCollection.removePublicKeyRing(f, (PGPPublicKeyRing)localObject1);
          f = PGPPublicKeyRingCollection.addPublicKeyRing(f, (PGPPublicKeyRing)localObject1);
          a((PGPPublicKeyRing)localObject1);
          localObject2 = new Long(((PGPPublicKeyRing)localObject1).getPublicKey().getKeyID());
          if ((localObject3 = (KeyPairInformation)y.get(localObject2)) == null)
          {
            localObject3 = new KeyPairInformation(z);
            y.put(localObject2, localObject3);
          }
          ((KeyPairInformation)localObject3).setPublicKeyRing((PGPPublicKeyRing)localObject1);
          localLinkedList.add(localObject3);
        }
        else if ((localObject1 instanceof PGPSecretKeyRing))
        {
          localObject1 = (PGPSecretKeyRing)localObject1;
          if ((paramString == null) || (isKeyPasswordConfirmed((PGPSecretKeyRing)localObject1, paramString)))
          {
            if (a.contains(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()))
              a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, (PGPSecretKeyRing)localObject1);
            a = PGPSecretKeyRingCollection.addSecretKeyRing(a, (PGPSecretKeyRing)localObject1);
            localObject2 = new ByteArrayOutputStream(10240);
            localObject3 = ((PGPSecretKeyRing)localObject1).getSecretKeys();
            Object localObject4;
            while (((Iterator)localObject3).hasNext())
              if ((localObject4 = ((PGPSecretKey)((Iterator)localObject3).next()).getPublicKey()) != null)
                ((ByteArrayOutputStream)localObject2).write(((PGPPublicKey)localObject4).getEncoded());
            localObject3 = staticBCFactory.CreatePGPPublicKeyRing(((ByteArrayOutputStream)localObject2).toByteArray());
            if (!f.contains(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()))
            {
              f = PGPPublicKeyRingCollection.addPublicKeyRing(f, (PGPPublicKeyRing)localObject3);
              a((PGPPublicKeyRing)localObject3);
            }
            if ((localObject4 = (KeyPairInformation)y.get(new Long(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()))) == null)
            {
              (localObject4 = new KeyPairInformation(z)).setPublicKeyRing((PGPPublicKeyRing)localObject3);
              y.put(new Long(((PGPSecretKeyRing)localObject1).getPublicKey().getKeyID()), localObject4);
            }
            ((KeyPairInformation)localObject4).setPrivateKeyRing((PGPSecretKeyRing)localObject1);
            localLinkedList.add(localObject4);
          }
          else
          {
            throw new WrongPasswordException("secret key password is incorrect");
          }
        }
        else if ((!(localObject1 instanceof ExperimentalPacket)) && (!(localObject1 instanceof PGPOnePassSignatureList)) && (!(localObject1 instanceof PGPSignatureList)) && (!(localObject1 instanceof PGPEncryptedDataList)))
        {
          throw new PGPException("Unexpected object found in stream: " + localObject1.getClass().getName());
        }
      }
    }
    catch (UnknownKeyPacketsException localUnknownKeyPacketsException)
    {
      paramBoolValue.setValue(true);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      Object localObject1;
      throw IOUtil.newPGPException(localObject1 = localPGPException);
    }
    return localLinkedList;
  }

  private boolean e(long paramLong)
    throws PGPException
  {
    PGPPublicKey localPGPPublicKey = (paramLong = b(paramLong)).getPublicKey();
    paramLong = paramLong.getPublicKey().getSignaturesOfType(16);
    while (paramLong.hasNext())
    {
      PGPSignature localPGPSignature;
      if ((localPGPSignature = (PGPSignature)paramLong.next()).getKeyID() != localPGPPublicKey.getKeyID())
      {
        Object localObject;
        if ((localPGPSignature.hasSubpackets()) && ((localObject = (localObject = localPGPSignature.getHashedSubPackets()).getSubpacket(5)) != null))
          try
          {
            if (a.contains(localPGPSignature.getKeyID()))
              return true;
          }
          catch (lw.bouncycastle.openpgp.PGPException localPGPException)
          {
            return false;
          }
      }
    }
    return false;
  }

  protected boolean isKeyPasswordConfirmed(PGPSecretKeyRing paramPGPSecretKeyRing, String paramString)
  {
    int i1 = 0;
    paramPGPSecretKeyRing = paramPGPSecretKeyRing.getSecretKeys();
    while (paramPGPSecretKeyRing.hasNext())
    {
      PGPSecretKey localPGPSecretKey = (PGPSecretKey)paramPGPSecretKeyRing.next();
      try
      {
        localPGPSecretKey.extractPrivateKey(staticBCFactory.CreatePBESecretKeyDecryptor(paramString));
        i1++;
      }
      catch (Exception localException)
      {
      }
    }
    return i1 != 0;
  }

  protected boolean isKeyPasswordConfirmed(PGPSecretKey paramPGPSecretKey, String paramString)
  {
    int i1 = 0;
    try
    {
      paramPGPSecretKey.extractPrivateKey(staticBCFactory.CreatePBESecretKeyDecryptor(paramString));
      i1++;
    }
    catch (Exception localException)
    {
    }
    return i1 != 0;
  }

  protected PGPSecretKeyRing findSecretKeyRing(String paramString)
    throws NoPrivateKeyFoundException
  {
    Object localObject;
    if (((localObject = getSecretKeyRingCollection(paramString)).size() == 0) && (E.size() > 0))
    {
      localObject = "";
      String str = "";
      if (p.matcher(paramString).matches())
        str = paramString;
      else
        localObject = paramString;
      for (int i1 = 0; i1 < E.size(); i1++)
        ((IKeyStoreSearchListener)E.get(i1)).onKeyNotFound(this, false, 0L, str, (String)localObject);
      localObject = e(paramString);
    }
    if (((Collection)localObject).size() > 0)
      return (PGPSecretKeyRing)((Collection)localObject).iterator().next();
    throw new NoPrivateKeyFoundException("No key found for userID: " + paramString);
  }

  protected PGPSecretKeyRing findSecretKeyRing(long paramLong)
    throws NoPrivateKeyFoundException
  {
    PGPSecretKeyRing localPGPSecretKeyRing1;
    PGPSecretKeyRing localPGPSecretKeyRing2;
    if (((localPGPSecretKeyRing1 = f(paramLong)) == null) && (E.size() > 0))
    {
      for (int i1 = 0; i1 < E.size(); i1++)
        ((IKeyStoreSearchListener)E.get(i1)).onKeyNotFound(this, false, paramLong, KeyPairInformation.keyId2Hex(paramLong), "");
      localPGPSecretKeyRing2 = f(paramLong);
    }
    if (localPGPSecretKeyRing2 == null)
      throw new NoPrivateKeyFoundException("No key found matching keyID: " + paramLong);
    return localPGPSecretKeyRing2;
  }

  protected Collection getSecretKeyRingCollection(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      Object localObject = a.getKeyRings(paramString, k, !j);
      PGPSecretKeyRing localPGPSecretKeyRing;
      while (((Iterator)localObject).hasNext())
      {
        localPGPSecretKeyRing = (PGPSecretKeyRing)((Iterator)localObject).next();
        localArrayList.add(localPGPSecretKeyRing);
      }
      if ((localArrayList.size() == 0) && (p.matcher(paramString).matches()))
      {
        localObject = h(paramString);
        if ((localPGPSecretKeyRing = f(getKeyIdForKeyIdHex((String)localObject))) != null)
          localArrayList.add(localPGPSecretKeyRing);
      }
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
    }
    return localArrayList;
  }

  private PGPSecretKeyRing f(long paramLong)
    throws NoPrivateKeyFoundException
  {
    try
    {
      return a.getSecretKeyRing(paramLong);
    }
    catch (lw.bouncycastle.openpgp.PGPException paramLong)
    {
    }
    throw new NoPrivateKeyFoundException(paramLong.getMessage(), paramLong);
  }

  public boolean deleteSubKey(String paramString)
    throws PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing;
    Iterator localIterator = (localPGPPublicKeyRing = d(paramString)).getPublicKeys();
    if (p.matcher(paramString).matches())
      paramString = h(paramString);
    while (localIterator.hasNext())
    {
      PGPPublicKey localPGPPublicKey;
      if (keyId2Hex((localPGPPublicKey = (PGPPublicKey)localIterator.next()).getKeyID()).equalsIgnoreCase(paramString))
      {
        deleteSubKey(localPGPPublicKeyRing.getPublicKey().getKeyID());
        return true;
      }
    }
    return false;
  }

  public void deleteSubKey(long paramLong)
    throws PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = b(paramLong);
    try
    {
      localObject = PGPSecretKeyRing.removeSecretKey(localObject = findSecretKeyRing(paramLong), ((PGPSecretKeyRing)localObject).getSecretKey(paramLong));
      replaceSecretKeyRing((PGPSecretKeyRing)localObject);
    }
    catch (NoPrivateKeyFoundException localNoPrivateKeyFoundException)
    {
    }
    Object localObject = PGPPublicKeyRing.removePublicKey(localPGPPublicKeyRing, localPGPPublicKeyRing.getPublicKey(paramLong));
    replacePublicKeyRing((PGPPublicKeyRing)localObject);
    save(false);
  }

  public long addSubKey(String paramString1, String paramString2, boolean paramBoolean, String paramString3, int paramInt)
    throws PGPException
  {
    paramString1 = findSecretKeyRing(paramString1);
    return addSubKey(paramString1.getPublicKey().getKeyID(), paramString2, paramBoolean, paramString3, paramInt);
  }

  // ERROR //
  public long addSubKey(long paramLong, String paramString, boolean paramBoolean, EcCurve.Enum paramEnum)
    throws PGPException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokevirtual 369\011com/didisoft/pgp/KeyStore:findSecretKeyRing\011(J)Llw/bouncycastle/openpgp/PGPSecretKeyRing;
    //   5: dup
    //   6: astore_1
    //   7: invokevirtual 657\011lw/bouncycastle/openpgp/PGPSecretKeyRing:getSecretKey\011()Llw/bouncycastle/openpgp/PGPSecretKey;
    //   10: astore_2
    //   11: new 220\011lw/bouncycastle/crypto/generators/ECKeyPairGenerator
    //   14: dup
    //   15: invokespecial 583\011lw/bouncycastle/crypto/generators/ECKeyPairGenerator:<init>\011()V
    //   18: astore 6
    //   20: aload 5
    //   22: astore 7
    //   24: getstatic 267\011com/didisoft/pgp/EcCurve$Enum:NIST_P_256\011Lcom/didisoft/pgp/EcCurve$Enum;
    //   27: aload 7
    //   29: invokevirtual 308\011com/didisoft/pgp/EcCurve$Enum:equals\011(Ljava/lang/Object;)Z
    //   32: ifeq +11 -> 43
    //   35: ldc 64
    //   37: invokestatic 558\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getByName\011(Ljava/lang/String;)Llw/bouncycastle/asn1/x9/X9ECParameters;
    //   40: goto +49 -> 89
    //   43: getstatic 268\011com/didisoft/pgp/EcCurve$Enum:NIST_P_384\011Lcom/didisoft/pgp/EcCurve$Enum;
    //   46: aload 7
    //   48: invokevirtual 308\011com/didisoft/pgp/EcCurve$Enum:equals\011(Ljava/lang/Object;)Z
    //   51: ifeq +11 -> 62
    //   54: ldc 65
    //   56: invokestatic 558\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getByName\011(Ljava/lang/String;)Llw/bouncycastle/asn1/x9/X9ECParameters;
    //   59: goto +30 -> 89
    //   62: getstatic 269\011com/didisoft/pgp/EcCurve$Enum:NIST_P_521\011Lcom/didisoft/pgp/EcCurve$Enum;
    //   65: aload 7
    //   67: invokevirtual 308\011com/didisoft/pgp/EcCurve$Enum:equals\011(Ljava/lang/Object;)Z
    //   70: ifeq +11 -> 81
    //   73: ldc 66
    //   75: invokestatic 558\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getByName\011(Ljava/lang/String;)Llw/bouncycastle/asn1/x9/X9ECParameters;
    //   78: goto +11 -> 89
    //   81: new 179\011java/lang/IllegalArgumentException
    //   84: dup
    //   85: invokespecial 492\011java/lang/IllegalArgumentException:<init>\011()V
    //   88: athrow
    //   89: astore 7
    //   91: aload 5
    //   93: invokevirtual 309\011com/didisoft/pgp/EcCurve$Enum:toString\011()Ljava/lang/String;
    //   96: astore 5
    //   98: new 225\011lw/bouncycastle/crypto/params/ECNamedDomainParameters
    //   101: dup
    //   102: aload 5
    //   104: invokestatic 559\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getOID\011(Ljava/lang/String;)Llw/bouncycastle/asn1/ASN1ObjectIdentifier;
    //   107: aload 7
    //   109: invokevirtual 560\011lw/bouncycastle/asn1/x9/X9ECParameters:getCurve\011()Llw/bouncycastle/math/ec/ECCurve;
    //   112: aload 7
    //   114: invokevirtual 561\011lw/bouncycastle/asn1/x9/X9ECParameters:getG\011()Llw/bouncycastle/math/ec/ECPoint;
    //   117: aload 7
    //   119: invokevirtual 562\011lw/bouncycastle/asn1/x9/X9ECParameters:getN\011()Ljava/math/BigInteger;
    //   122: invokespecial 592\011lw/bouncycastle/crypto/params/ECNamedDomainParameters:<init>\011(Llw/bouncycastle/asn1/ASN1ObjectIdentifier;Llw/bouncycastle/math/ec/ECCurve;Llw/bouncycastle/math/ec/ECPoint;Ljava/math/BigInteger;)V
    //   125: astore 5
    //   127: invokestatic 426\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   130: astore 7
    //   132: aload 6
    //   134: new 224\011lw/bouncycastle/crypto/params/ECKeyGenerationParameters
    //   137: dup
    //   138: aload 5
    //   140: aload 7
    //   142: invokespecial 591\011lw/bouncycastle/crypto/params/ECKeyGenerationParameters:<init>\011(Llw/bouncycastle/crypto/params/ECDomainParameters;Ljava/security/SecureRandom;)V
    //   145: invokeinterface 740 2 0
    //   150: aload 6
    //   152: invokeinterface 739 1 0
    //   157: astore 5
    //   159: new 196\011java/util/Date
    //   162: dup
    //   163: invokespecial 532\011java/util/Date:<init>\011()V
    //   166: astore 6
    //   168: iload 4
    //   170: ifeq +21 -> 191
    //   173: new 255\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair
    //   176: dup
    //   177: bipush 19
    //   179: aload 5
    //   181: aload 6
    //   183: invokespecial 716\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair:<init>\011(ILlw/bouncycastle/crypto/AsymmetricCipherKeyPair;Ljava/util/Date;)V
    //   186: astore 5
    //   188: goto +27 -> 215
    //   191: new 255\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair
    //   194: dup
    //   195: bipush 18
    //   197: aload 5
    //   199: aload 6
    //   201: invokespecial 716\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair:<init>\011(ILlw/bouncycastle/crypto/AsymmetricCipherKeyPair;Ljava/util/Date;)V
    //   204: astore 5
    //   206: goto +9 -> 215
    //   209: dup
    //   210: astore_1
    //   211: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   214: athrow
    //   215: aload_0
    //   216: aload_1
    //   217: aload_2
    //   218: aload_3
    //   219: aload 5
    //   221: iload 4
    //   223: invokespecial 346\011com/didisoft/pgp/KeyStore:a\011(Llw/bouncycastle/openpgp/PGPSecretKeyRing;Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;Llw/bouncycastle/openpgp/PGPKeyPair;Z)J
    //   226: lreturn
    //
    // Exception table:
    //   from\011to\011target\011type
    //   168\011206\011209\011lw/bouncycastle/openpgp/PGPException
  }

  public long addSubKey(long paramLong, String paramString1, boolean paramBoolean, String paramString2, int paramInt)
    throws PGPException
  {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokevirtual 369\011com/didisoft/pgp/KeyStore:findSecretKeyRing\011(J)Llw/bouncycastle/openpgp/PGPSecretKeyRing;
    //   5: dup
    //   6: astore_1
    //   7: invokevirtual 657\011lw/bouncycastle/openpgp/PGPSecretKeyRing:getSecretKey\011()Llw/bouncycastle/openpgp/PGPSecretKey;
    //   10: astore_2
    //   11: new 196\011java/util/Date
    //   14: dup
    //   15: invokespecial 532\011java/util/Date:<init>\011()V
    //   18: astore 7
    //   20: invokestatic 426\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   23: astore 8
    //   25: ldc 75
    //   27: aload 5
    //   29: invokevirtual 501\011java/lang/String:equalsIgnoreCase\011(Ljava/lang/String;)Z
    //   32: ifeq +66 -> 98
    //   35: new 222\011lw/bouncycastle/crypto/generators/RSAKeyPairGenerator
    //   38: dup
    //   39: invokespecial 587\011lw/bouncycastle/crypto/generators/RSAKeyPairGenerator:<init>\011()V
    //   42: dup
    //   43: astore 5
    //   45: new 228\011lw/bouncycastle/crypto/params/RSAKeyGenerationParameters
    //   48: dup
    //   49: ldc2_w 265
    //   52: invokestatic 525\011java/math/BigInteger:valueOf\011(J)Ljava/math/BigInteger;
    //   55: aload 8
    //   57: iload 6
    //   59: bipush 25
    //   61: invokespecial 595\011lw/bouncycastle/crypto/params/RSAKeyGenerationParameters:<init>\011(Ljava/math/BigInteger;Ljava/security/SecureRandom;II)V
    //   64: invokevirtual 589\011lw/bouncycastle/crypto/generators/RSAKeyPairGenerator:init\011(Llw/bouncycastle/crypto/KeyGenerationParameters;)V
    //   67: aload 5
    //   69: invokevirtual 588\011lw/bouncycastle/crypto/generators/RSAKeyPairGenerator:generateKeyPair\011()Llw/bouncycastle/crypto/AsymmetricCipherKeyPair;
    //   72: astore 9
    //   74: new 255\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair
    //   77: dup
    //   78: iconst_1
    //   79: aload 9
    //   81: aload 7
    //   83: invokespecial 716\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair:<init>\011(ILlw/bouncycastle/crypto/AsymmetricCipherKeyPair;Ljava/util/Date;)V
    //   86: astore 5
    //   88: goto +373 -> 461
    //   91: dup
    //   92: astore 10
    //   94: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   97: athrow
    //   98: ldc 35
    //   100: aload 5
    //   102: invokevirtual 501\011java/lang/String:equalsIgnoreCase\011(Ljava/lang/String;)Z
    //   105: ifeq +184 -> 289
    //   108: iload 4
    //   110: ifeq +102 -> 212
    //   113: new 153\011com/didisoft/pgp/bc/elgamal/FastElGamal
    //   116: dup
    //   117: iload 6
    //   119: bipush 8
    //   121: idiv
    //   122: invokespecial 448\011com/didisoft/pgp/bc/elgamal/FastElGamal:<init>\011(I)V
    //   125: dup
    //   126: astore 5
    //   128: invokevirtual 449\011com/didisoft/pgp/bc/elgamal/FastElGamal:generateKeys\011()V
    //   131: new 227\011lw/bouncycastle/crypto/params/ElGamalParameters
    //   134: dup
    //   135: aload 5
    //   137: invokevirtual 450\011com/didisoft/pgp/bc/elgamal/FastElGamal:getPrivateKey\011()Lcom/didisoft/pgp/bc/elgamal/FastElGamal$PrivateKey;
    //   140: invokevirtual 452\011com/didisoft/pgp/bc/elgamal/FastElGamal$PrivateKey:getP\011()Ljava/math/BigInteger;
    //   143: aload 5
    //   145: invokevirtual 451\011com/didisoft/pgp/bc/elgamal/FastElGamal:getPublicKey\011()Lcom/didisoft/pgp/bc/elgamal/FastElGamal$PublicKey;
    //   148: invokevirtual 453\011com/didisoft/pgp/bc/elgamal/FastElGamal$PublicKey:getG\011()Ljava/math/BigInteger;
    //   151: invokespecial 594\011lw/bouncycastle/crypto/params/ElGamalParameters:<init>\011(Ljava/math/BigInteger;Ljava/math/BigInteger;)V
    //   154: astore 9
    //   156: new 221\011lw/bouncycastle/crypto/generators/ElGamalKeyPairGenerator
    //   159: dup
    //   160: invokespecial 584\011lw/bouncycastle/crypto/generators/ElGamalKeyPairGenerator:<init>\011()V
    //   163: dup
    //   164: astore 10
    //   166: new 226\011lw/bouncycastle/crypto/params/ElGamalKeyGenerationParameters
    //   169: dup
    //   170: aload 8
    //   172: aload 9
    //   174: invokespecial 593\011lw/bouncycastle/crypto/params/ElGamalKeyGenerationParameters:<init>\011(Ljava/security/SecureRandom;Llw/bouncycastle/crypto/params/ElGamalParameters;)V
    //   177: invokevirtual 586\011lw/bouncycastle/crypto/generators/ElGamalKeyPairGenerator:init\011(Llw/bouncycastle/crypto/KeyGenerationParameters;)V
    //   180: aload 10
    //   182: invokevirtual 585\011lw/bouncycastle/crypto/generators/ElGamalKeyPairGenerator:generateKeyPair\011()Llw/bouncycastle/crypto/AsymmetricCipherKeyPair;
    //   185: astore 6
    //   187: new 255\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair
    //   190: dup
    //   191: bipush 16
    //   193: aload 6
    //   195: aload 7
    //   197: invokespecial 716\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair:<init>\011(ILlw/bouncycastle/crypto/AsymmetricCipherKeyPair;Ljava/util/Date;)V
    //   200: astore 5
    //   202: goto +259 -> 461
    //   205: dup
    //   206: astore 5
    //   208: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   211: athrow
    //   212: new 219\011lw/bouncycastle/crypto/generators/DSAParametersGenerator
    //   215: dup
    //   216: invokespecial 580\011lw/bouncycastle/crypto/generators/DSAParametersGenerator:<init>\011()V
    //   219: dup
    //   220: astore 5
    //   222: sipush 1024
    //   225: bipush 50
    //   227: invokestatic 426\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   230: invokevirtual 582\011lw/bouncycastle/crypto/generators/DSAParametersGenerator:init\011(IILjava/security/SecureRandom;)V
    //   233: new 218\011lw/bouncycastle/crypto/generators/DSAKeyPairGenerator
    //   236: dup
    //   237: invokespecial 577\011lw/bouncycastle/crypto/generators/DSAKeyPairGenerator:<init>\011()V
    //   240: dup
    //   241: astore 9
    //   243: new 223\011lw/bouncycastle/crypto/params/DSAKeyGenerationParameters
    //   246: dup
    //   247: invokestatic 426\011com/didisoft/pgp/bc/IOUtil:getSecureRandom\011()Ljava/security/SecureRandom;
    //   250: aload 5
    //   252: invokevirtual 581\011lw/bouncycastle/crypto/generators/DSAParametersGenerator:generateParameters\011()Llw/bouncycastle/crypto/params/DSAParameters;
    //   255: invokespecial 590\011lw/bouncycastle/crypto/params/DSAKeyGenerationParameters:<init>\011(Ljava/security/SecureRandom;Llw/bouncycastle/crypto/params/DSAParameters;)V
    //   258: invokevirtual 579\011lw/bouncycastle/crypto/generators/DSAKeyPairGenerator:init\011(Llw/bouncycastle/crypto/KeyGenerationParameters;)V
    //   261: new 255\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair
    //   264: dup
    //   265: bipush 17
    //   267: aload 9
    //   269: invokevirtual 578\011lw/bouncycastle/crypto/generators/DSAKeyPairGenerator:generateKeyPair\011()Llw/bouncycastle/crypto/AsymmetricCipherKeyPair;
    //   272: aload 7
    //   274: invokespecial 716\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair:<init>\011(ILlw/bouncycastle/crypto/AsymmetricCipherKeyPair;Ljava/util/Date;)V
    //   277: astore 5
    //   279: goto +182 -> 461
    //   282: dup
    //   283: astore 10
    //   285: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   288: athrow
    //   289: new 220\011lw/bouncycastle/crypto/generators/ECKeyPairGenerator
    //   292: dup
    //   293: invokespecial 583\011lw/bouncycastle/crypto/generators/ECKeyPairGenerator:<init>\011()V
    //   296: astore 5
    //   298: ldc 64
    //   300: invokestatic 558\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getByName\011(Ljava/lang/String;)Llw/bouncycastle/asn1/x9/X9ECParameters;
    //   303: astore 9
    //   305: ldc 64
    //   307: astore 10
    //   309: iload 6
    //   311: sipush 256
    //   314: if_icmple +25 -> 339
    //   317: iload 6
    //   319: sipush 521
    //   322: if_icmpge +17 -> 339
    //   325: ldc 65
    //   327: invokestatic 558\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getByName\011(Ljava/lang/String;)Llw/bouncycastle/asn1/x9/X9ECParameters;
    //   330: astore 9
    //   332: ldc 65
    //   334: astore 10
    //   336: goto +22 -> 358
    //   339: iload 6
    //   341: sipush 521
    //   344: if_icmplt +14 -> 358
    //   347: ldc 66
    //   349: invokestatic 558\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getByName\011(Ljava/lang/String;)Llw/bouncycastle/asn1/x9/X9ECParameters;
    //   352: astore 9
    //   354: ldc 66
    //   356: astore 10
    //   358: new 225\011lw/bouncycastle/crypto/params/ECNamedDomainParameters
    //   361: dup
    //   362: aload 10
    //   364: invokestatic 559\011lw/bouncycastle/asn1/nist/NISTNamedCurves:getOID\011(Ljava/lang/String;)Llw/bouncycastle/asn1/ASN1ObjectIdentifier;
    //   367: aload 9
    //   369: invokevirtual 560\011lw/bouncycastle/asn1/x9/X9ECParameters:getCurve\011()Llw/bouncycastle/math/ec/ECCurve;
    //   372: aload 9
    //   374: invokevirtual 561\011lw/bouncycastle/asn1/x9/X9ECParameters:getG\011()Llw/bouncycastle/math/ec/ECPoint;
    //   377: aload 9
    //   379: invokevirtual 562\011lw/bouncycastle/asn1/x9/X9ECParameters:getN\011()Ljava/math/BigInteger;
    //   382: invokespecial 592\011lw/bouncycastle/crypto/params/ECNamedDomainParameters:<init>\011(Llw/bouncycastle/asn1/ASN1ObjectIdentifier;Llw/bouncycastle/math/ec/ECCurve;Llw/bouncycastle/math/ec/ECPoint;Ljava/math/BigInteger;)V
    //   385: astore 6
    //   387: aload 5
    //   389: new 224\011lw/bouncycastle/crypto/params/ECKeyGenerationParameters
    //   392: dup
    //   393: aload 6
    //   395: aload 8
    //   397: invokespecial 591\011lw/bouncycastle/crypto/params/ECKeyGenerationParameters:<init>\011(Llw/bouncycastle/crypto/params/ECDomainParameters;Ljava/security/SecureRandom;)V
    //   400: invokeinterface 740 2 0
    //   405: aload 5
    //   407: invokeinterface 739 1 0
    //   412: astore 5
    //   414: iload 4
    //   416: ifeq +21 -> 437
    //   419: new 255\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair
    //   422: dup
    //   423: bipush 19
    //   425: aload 5
    //   427: aload 7
    //   429: invokespecial 716\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair:<init>\011(ILlw/bouncycastle/crypto/AsymmetricCipherKeyPair;Ljava/util/Date;)V
    //   432: astore 5
    //   434: goto +27 -> 461
    //   437: new 255\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair
    //   440: dup
    //   441: bipush 18
    //   443: aload 5
    //   445: aload 7
    //   447: invokespecial 716\011lw/bouncycastle/openpgp/operator/bc/BcPGPKeyPair:<init>\011(ILlw/bouncycastle/crypto/AsymmetricCipherKeyPair;Ljava/util/Date;)V
    //   450: astore 5
    //   452: goto +9 -> 461
    //   455: dup
    //   456: astore_1
    //   457: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   460: athrow
    //   461: aload_0
    //   462: aload_1
    //   463: aload_2
    //   464: aload_3
    //   465: aload 5
    //   467: iload 4
    //   469: invokespecial 346\011com/didisoft/pgp/KeyStore:a\011(Llw/bouncycastle/openpgp/PGPSecretKeyRing;Llw/bouncycastle/openpgp/PGPSecretKey;Ljava/lang/String;Llw/bouncycastle/openpgp/PGPKeyPair;Z)J
    //   472: lreturn
    //
    // Exception table:
    //   from\011to\011target\011type
    //   74\01188\01191\011lw/bouncycastle/openpgp/PGPException
    //   187\011202\011205\011lw/bouncycastle/openpgp/PGPException
    //   261\011279\011282\011lw/bouncycastle/openpgp/PGPException
    //   414\011452\011455\011lw/bouncycastle/openpgp/PGPException
  }

  private long a(PGPSecretKeyRing paramPGPSecretKeyRing, PGPSecretKey paramPGPSecretKey, String paramString, PGPKeyPair paramPGPKeyPair, boolean paramBoolean)
    throws PGPException
  {
    PGPSignatureGenerator localPGPSignatureGenerator = new PGPSignatureGenerator(staticBCFactory.CreatePGPContentSignerBuilder(paramPGPSecretKey.getPublicKey().getAlgorithm(), 2));
    if ((paramPGPSecretKey.getPublicKey().getAlgorithm() == 18) || (paramPGPSecretKey.getPublicKey().getAlgorithm() == 19))
      localPGPSignatureGenerator = new PGPSignatureGenerator(staticBCFactory.CreatePGPContentSignerBuilder(paramPGPSecretKey.getPublicKey().getAlgorithm(), 10));
    try
    {
      localPGPSignatureGenerator.init(24, BaseLib.extractPrivateKey(paramPGPSecretKey, paramString));
      localObject = new PGPSignatureSubpacketGenerator();
      if (paramBoolean)
        ((PGPSignatureSubpacketGenerator)localObject).setKeyFlags(false, 12);
      else
        ((PGPSignatureSubpacketGenerator)localObject).setKeyFlags(false, 2);
      localPGPSignatureGenerator.setHashedSubpackets(((PGPSignatureSubpacketGenerator)localObject).generate());
      localPGPSignatureGenerator.setUnhashedSubpackets(null);
      (paramBoolean = new LinkedList()).add(localPGPSignatureGenerator.generateCertification(paramPGPSecretKey.getPublicKey(), paramPGPKeyPair.getPublicKey()));
      (paramPGPSecretKey = new PGPPublicKey(paramPGPKeyPair.getPublicKey(), null, paramBoolean)).publicPk = new PublicSubkeyPacket(paramPGPSecretKey.getPublicKeyPacket().getAlgorithm(), paramPGPSecretKey.getPublicKeyPacket().getTime(), paramPGPSecretKey.getPublicKeyPacket().getKey());
      paramBoolean = new BcPGPDigestCalculatorProvider().get(2);
      paramPGPSecretKey = new PGPSecretKey(paramPGPKeyPair.getPrivateKey(), paramPGPSecretKey, paramBoolean, false, staticBCFactory.CreatePBESecretKeyEncryptor(paramString, 9));
      paramPGPSecretKeyRing = PGPSecretKeyRing.insertSecretKey(paramPGPSecretKeyRing, paramPGPSecretKey);
      paramString = PGPPublicKeyRing.insertPublicKey(paramString = b(paramPGPSecretKeyRing.getPublicKey().getKeyID()), paramPGPSecretKey.getPublicKey());
      replacePublicKeyRing(paramString);
      replaceSecretKeyRing(paramPGPSecretKeyRing);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      Object localObject;
      throw IOUtil.newPGPException(localObject = localPGPException);
    }
    save(false);
    return paramPGPSecretKey.getKeyID();
  }

  // ERROR //
  private static void a(PGPKeyRingGenerator paramPGPKeyRingGenerator, PGPKeyPair paramPGPKeyPair)
    throws PGPException
  {
    // Byte code:
    //   0: new 249\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator
    //   3: dup
    //   4: invokespecial 687\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator:<init>\011()V
    //   7: dup
    //   8: astore_2
    //   9: iconst_0
    //   10: bipush 12
    //   12: invokevirtual 690\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator:setKeyFlags\011(ZI)V
    //   15: aload_0
    //   16: aload_1
    //   17: aload_2
    //   18: invokevirtual 688\011lw/bouncycastle/openpgp/PGPSignatureSubpacketGenerator:generate\011()Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;
    //   21: aconst_null
    //   22: invokevirtual 606\011lw/bouncycastle/openpgp/PGPKeyRingGenerator:addSubKey\011(Llw/bouncycastle/openpgp/PGPKeyPair;Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;Llw/bouncycastle/openpgp/PGPSignatureSubpacketVector;)V
    //   25: return
    //   26: dup
    //   27: astore_0
    //   28: invokestatic 427\011com/didisoft/pgp/bc/IOUtil:newPGPException\011(Llw/bouncycastle/openpgp/PGPException;)Lcom/didisoft/pgp/PGPException;
    //   31: athrow
    //
    // Exception table:
    //   from\011to\011target\011type
    //   15\01125\01126\011lw/bouncycastle/openpgp/PGPException
  }

  private static int f(String paramString)
  {
    if (paramString.equalsIgnoreCase("RSA"))
      return 1;
    if (paramString.equalsIgnoreCase("DSA"))
      return 17;
    if (paramString.equalsIgnoreCase("ELGAMAL"))
      return 16;
    if (paramString.equalsIgnoreCase("EC"))
      return 18;
    throw new IllegalArgumentException("unknown key algorithm: " + paramString);
  }

  protected void replacePublicKeyRing(PGPPublicKeyRing paramPGPPublicKeyRing)
    throws PGPException
  {
    try
    {
      int i1 = 0;
      long l1 = paramPGPPublicKeyRing.getPublicKey().getKeyID();
      KeyPairInformation localKeyPairInformation = new KeyPairInformation();
      if (f.contains(l1))
      {
        i1 = 1;
        localKeyPairInformation.setPublicKeyRing(paramPGPPublicKeyRing);
        y.put(new Long(paramPGPPublicKeyRing.getPublicKey().getKeyID()), localKeyPairInformation);
        f = PGPPublicKeyRingCollection.removePublicKeyRing(f, paramPGPPublicKeyRing);
        f = PGPPublicKeyRingCollection.addPublicKeyRing(f, paramPGPPublicKeyRing);
      }
      if (a.contains(l1))
      {
        i1 = 1;
        PGPSecretKeyRing localPGPSecretKeyRing = PGPSecretKeyRing.replacePublicKeys(localPGPSecretKeyRing = a.getSecretKeyRing(l1), paramPGPPublicKeyRing);
        localKeyPairInformation.setPublicKeyRing(paramPGPPublicKeyRing);
        localKeyPairInformation.setPrivateKeyRing(localPGPSecretKeyRing);
        y.put(new Long(paramPGPPublicKeyRing.getPublicKey().getKeyID()), localKeyPairInformation);
        a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, localPGPSecretKeyRing);
        a = PGPSecretKeyRingCollection.addSecretKeyRing(a, localPGPSecretKeyRing);
      }
      if (i1 == 0)
        throw new IllegalStateException("unknown key ring in replace");
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw new PGPException(localPGPException.getMessage(), localPGPException.getUnderlyingException());
    }
    save(false);
  }

  protected void replaceSecretKeyRing(PGPSecretKeyRing paramPGPSecretKeyRing)
    throws PGPException
  {
    try
    {
      int i1 = 0;
      long l1 = paramPGPSecretKeyRing.getPublicKey().getKeyID();
      KeyPairInformation localKeyPairInformation = new KeyPairInformation();
      if (f.contains(l1))
      {
        i1 = 1;
        PGPPublicKeyRing localPGPPublicKeyRing = f.getPublicKeyRing(l1);
        localKeyPairInformation.setPublicKeyRing(localPGPPublicKeyRing);
      }
      if (a.contains(l1))
      {
        i1 = 1;
        localKeyPairInformation.setPrivateKeyRing(paramPGPSecretKeyRing);
        y.put(new Long(paramPGPSecretKeyRing.getPublicKey().getKeyID()), localKeyPairInformation);
        a = PGPSecretKeyRingCollection.removeSecretKeyRing(a, paramPGPSecretKeyRing);
        a = PGPSecretKeyRingCollection.addSecretKeyRing(a, paramPGPSecretKeyRing);
      }
      if (i1 == 0)
        throw new IllegalStateException("unknown key ring in replace");
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw new PGPException(localPGPException.getMessage(), localPGPException.getUnderlyingException());
    }
    save(false);
  }

  protected int getEncAlgorithm(String paramString)
  {
    if (paramString == null)
      return 9;
    if (paramString.equalsIgnoreCase("AES_256"))
      return 9;
    if (paramString.equalsIgnoreCase("AES_192"))
      return 8;
    if (paramString.equalsIgnoreCase("AES_128"))
      return 7;
    if (paramString.equalsIgnoreCase("TRIPLE_DES"))
      return 2;
    if (paramString.equalsIgnoreCase("TWOFISH"))
      return 10;
    if (paramString.equalsIgnoreCase("NULL"))
      return 0;
    throw new IllegalArgumentException("unknown symmetric encryption algorithm: " + paramString);
  }

  protected static String getKeyAlgorithm(int paramInt)
  {
    switch (paramInt)
    {
    case 1:
      return "RSA";
    case 2:
      return "RSA";
    case 3:
      return "RSA";
    case 16:
      return "DH/DSS";
    case 17:
      return "DH/DSS";
    case 18:
      return "EC";
    case 19:
      return "ECDSA";
    case 20:
      return "DH/DSS";
    case 21:
      return "DH/DSS";
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
    }
    return "Unknown";
  }

  static String a(int paramInt)
  {
    switch (paramInt)
    {
    case 1:
      return "Zip";
    case 3:
      return "BZip2";
    case 2:
      return "ZLib";
    case 0:
      return "No compression";
    }
    return "Unknown";
  }

  static String b(int paramInt)
  {
    switch (paramInt)
    {
    case 4:
      return "Double SHA";
    case 7:
      return "Haval 5";
    case 5:
      return "MD 2";
    case 1:
      return "MD 5";
    case 3:
      return "RipeMD 160";
    case 2:
      return "SHA1";
    case 11:
      return "SHA2 - 224";
    case 8:
      return "SHA2 - 256";
    case 9:
      return "SHA2 - 384";
    case 10:
      return "SHA2 - 512";
    case 6:
      return "Tiger 192";
    }
    return "Unknown";
  }

  static String c(int paramInt)
  {
    switch (paramInt)
    {
    case 7:
      return "AES 128";
    case 8:
      return "AES 192";
    case 9:
      return "AES 256";
    case 4:
      return "Blowfish";
    case 3:
      return "Cast 5";
    case 6:
      return "DES";
    case 1:
      return "IDEA";
    case 5:
      return "Safer";
    case 2:
      return "3 DES";
    case 10:
      return "Twofish";
    }
    return "Unknown";
  }

  private static String a(String paramString, int paramInt)
  {
    StringBuffer localStringBuffer;
    (localStringBuffer = new StringBuffer()).append(paramString);
    if (paramString.length() < paramInt)
      for (int i1 = 0; i1 < paramInt - paramString.length(); i1++)
        localStringBuffer.append(' ');
    return localStringBuffer.toString();
  }

  private static void g(String paramString)
  {
    if (l.isLoggable(Level.FINE))
      l.fine(paramString);
  }

  private static void a(String paramString1, String paramString2)
  {
    if (l.isLoggable(Level.FINE))
      l.fine(MessageFormat.format(paramString1, new Object[] { paramString2 }));
  }

  private static String h(String paramString)
  {
    paramString = paramString.startsWith("0x") ? paramString.substring(2) : paramString;
    return paramString.toUpperCase();
  }

  public boolean isSkipLucasLehmerPrimeTest()
  {
    return n;
  }

  public void setSkipLucasLehmerPrimeTest(boolean paramBoolean)
  {
    n = paramBoolean;
  }

  public boolean isFastElGamalGeneration()
  {
    return o;
  }

  public void setFastElGamalGeneration(boolean paramBoolean)
  {
    o = paramBoolean;
  }

  public int getMaxTrustDepth()
  {
    return B;
  }

  public void setMaxTrustDepth(int paramInt)
  {
    B = paramInt;
  }

  public int getMarginalsNeeded()
  {
    return C;
  }

  public void setMarginalsNeeded(int paramInt)
  {
    C = paramInt;
  }

  public boolean isCaseSensitiveMatchUserIds()
  {
    return j;
  }

  public void setCaseSensitiveMatchUserIds(boolean paramBoolean)
  {
    j = paramBoolean;
  }

  public static String keyId2Hex(long paramLong)
  {
    return KeyPairInformation.keyId2Hex(paramLong);
  }

  public static enum KeyCertificationType
  {
    private int a;

    private KeyCertificationType(int paramInt)
    {
      a = paramInt;
    }

    public final int getValue()
    {
      return a;
    }
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.KeyStore
 * JD-Core Version:    0.6.2
 */