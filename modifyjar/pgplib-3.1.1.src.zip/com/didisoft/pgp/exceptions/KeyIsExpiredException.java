package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class KeyIsExpiredException extends PGPException
{
  private static final long serialVersionUID = -4155092216675786068L;

  public KeyIsExpiredException(String paramString)
  {
    super(paramString);
  }

  public KeyIsExpiredException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.KeyIsExpiredException
 * JD-Core Version:    0.6.2
 */