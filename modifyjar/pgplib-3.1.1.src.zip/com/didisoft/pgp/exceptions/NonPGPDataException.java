package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class NonPGPDataException extends PGPException
{
  private static final long serialVersionUID = -4989400714535054834L;

  public NonPGPDataException(String paramString)
  {
    super(paramString);
  }

  public NonPGPDataException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.NonPGPDataException
 * JD-Core Version:    0.6.2
 */