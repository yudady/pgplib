package com.didisoft.pgp.exceptions;

public class NoPrivateKeyFoundException extends WrongPrivateKeyException
{
  private static final long serialVersionUID = 2794256673127079299L;

  public NoPrivateKeyFoundException(String paramString)
  {
    super(paramString);
  }

  public NoPrivateKeyFoundException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.NoPrivateKeyFoundException
 * JD-Core Version:    0.6.2
 */