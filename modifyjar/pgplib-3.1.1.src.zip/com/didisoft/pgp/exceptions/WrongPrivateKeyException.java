package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class WrongPrivateKeyException extends PGPException
{
  private static final long serialVersionUID = 92099035468530110L;

  public WrongPrivateKeyException(String paramString)
  {
    super(paramString);
  }

  public WrongPrivateKeyException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.WrongPrivateKeyException
 * JD-Core Version:    0.6.2
 */