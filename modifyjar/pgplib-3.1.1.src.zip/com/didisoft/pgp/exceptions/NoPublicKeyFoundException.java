package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class NoPublicKeyFoundException extends PGPException
{
  private static final long serialVersionUID = -4979530887461581921L;

  public NoPublicKeyFoundException(String paramString)
  {
    super(paramString);
  }

  public NoPublicKeyFoundException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.NoPublicKeyFoundException
 * JD-Core Version:    0.6.2
 */