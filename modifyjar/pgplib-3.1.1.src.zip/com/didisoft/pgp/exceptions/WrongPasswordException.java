package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class WrongPasswordException extends PGPException
{
  private static final long serialVersionUID = 6436097197694402592L;

  public WrongPasswordException(String paramString)
  {
    super(paramString);
  }

  public WrongPasswordException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.WrongPasswordException
 * JD-Core Version:    0.6.2
 */