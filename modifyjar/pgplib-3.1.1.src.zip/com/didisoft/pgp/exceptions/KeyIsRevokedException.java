package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class KeyIsRevokedException extends PGPException
{
  private static final long serialVersionUID = -5403405838368315892L;

  public KeyIsRevokedException(String paramString)
  {
    super(paramString);
  }

  public KeyIsRevokedException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.KeyIsRevokedException
 * JD-Core Version:    0.6.2
 */