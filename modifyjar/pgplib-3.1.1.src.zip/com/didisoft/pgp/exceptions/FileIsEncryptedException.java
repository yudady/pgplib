package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class FileIsEncryptedException extends PGPException
{
  private static final long serialVersionUID = -7719881786646542875L;

  public FileIsEncryptedException(String paramString)
  {
    super(paramString);
  }

  public FileIsEncryptedException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.FileIsEncryptedException
 * JD-Core Version:    0.6.2
 */