package com.didisoft.pgp.exceptions;

import com.didisoft.pgp.PGPException;

public class FileIsPBEEncryptedException extends PGPException
{
  private static final long serialVersionUID = 6762754694787728462L;

  public FileIsPBEEncryptedException(String paramString)
  {
    super(paramString);
  }

  public FileIsPBEEncryptedException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.exceptions.FileIsPBEEncryptedException
 * JD-Core Version:    0.6.2
 */