package com.didisoft.pgp.net;

import com.didisoft.pgp.KeyPairInformation;
import com.didisoft.pgp.KeyPairInformation.SubKey;
import com.didisoft.pgp.KeyStore;
import com.didisoft.pgp.bc.BaseLib;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Properties;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LDAPClient
{
  public static final int DEFAULT_LDAP_PORT = 389;
  private static String a = "com.sun.jndi.ldap.LdapCtxFactory";
  private static String b = "ignore";
  private String c;
  private int d = 389;
  private boolean e = true;
  private KeyStore f = new KeyStore();

  public LDAPClient(String paramString)
  {
    c = paramString;
  }

  public LDAPClient(String paramString, int paramInt)
  {
    c = paramString;
    d = paramInt;
  }

  public LDAPClient(String paramString1, int paramInt, String paramString2, String paramString3)
  {
    c = paramString1;
    d = paramInt;
  }

  public boolean isPartialMatchUserIds()
  {
    return e;
  }

  public void setPartialMatchUserIds(boolean paramBoolean)
  {
    e = paramBoolean;
  }

  private DirContext a()
    throws NamingException
  {
    Object localObject;
    (localObject = new Properties()).setProperty("java.naming.factory.initial", a);
    ((Properties)localObject).setProperty("java.naming.batchsize", "0");
    LDAPClient localLDAPClient = this;
    ((Properties)localObject).setProperty("java.naming.provider.url", "ldap://" + localLDAPClient.c + ":" + localLDAPClient.d);
    ((Properties)localObject).setProperty("java.naming.factory.url.pkgs", "com.sun.jndi.url");
    ((Properties)localObject).setProperty("java.naming.referral", b);
    ((Properties)localObject).setProperty("java.naming.security.authentication", "none");
    return localObject = new InitialDirContext((Hashtable)localObject);
  }

  private static String a(DirContext paramDirContext, String paramString1, String paramString2)
    throws Exception
  {
    String str = "objectClass=*";
    SearchControls localSearchControls;
    (localSearchControls = new SearchControls()).setSearchScope(0);
    localSearchControls.setCountLimit(0L);
    String[] arrayOfString;
    (arrayOfString = new String[1])[0] = paramString2;
    localSearchControls.setReturningAttributes(arrayOfString);
    paramString2 = "(&(" + str + ")(" + arrayOfString[0] + "=*))";
    paramDirContext = paramDirContext.search(paramString1, paramString2, localSearchControls);
    while (paramDirContext.hasMoreElements())
      if ((paramString1 = ((Attribute)(paramString1 = (SearchResult)paramDirContext.next()).getAttributes().getAll().next()).getAll()).hasMore())
        return (paramDirContext = paramString1.next()).toString();
    return null;
  }

  private static String a(DirContext paramDirContext, String paramString1, String paramString2, String paramString3)
    throws Exception
  {
    SearchControls localSearchControls;
    (localSearchControls = new SearchControls()).setSearchScope(2);
    localSearchControls.setCountLimit(0L);
    String[] arrayOfString;
    (arrayOfString = new String[1])[0] = paramString3;
    localSearchControls.setReturningAttributes(arrayOfString);
    paramString2 = "(&(" + paramString2 + ")(" + arrayOfString[0] + "=*))";
    paramDirContext = paramDirContext.search(paramString1, paramString2, localSearchControls);
    while (paramDirContext.hasMoreElements())
      if ((paramString1 = ((Attribute)(paramString1 = (SearchResult)paramDirContext.next()).getAttributes().getAll().next()).getAll()).hasMore())
        return (paramDirContext = paramString1.next()).toString();
    return null;
  }

  private static String a(DirContext paramDirContext)
    throws IOException
  {
    try
    {
      if ((paramDirContext = (paramDirContext = (paramDirContext = paramDirContext.getAttributes("", new String[] { "namingContexts" })).get("namingContexts")).getAll()).hasMore())
        return paramDirContext = (String)paramDirContext.next();
    }
    catch (Exception localException)
    {
      if (((paramDirContext = localException) instanceof IOException))
        throw ((IOException)paramDirContext);
      throw new IOException("Error getting results from LDAP directory " + paramDirContext);
    }
    return null;
  }

  private String b(DirContext paramDirContext)
    throws Exception
  {
    String str1 = a(paramDirContext);
    String[] arrayOfString = { "pgpBaseKeySpaceDN" };
    String str2 = "";
    for (int i = 0; i < arrayOfString.length; i++)
      str2 = a(paramDirContext, "cn=pgpServerInfo," + str1, arrayOfString[i]);
    return str2;
  }

  public byte[] getKeyByKeyIdHex(String paramString)
    throws IOException
  {
    if (!BaseLib.isHexId(paramString))
      throw new IllegalArgumentException("Parameter keyIdHex is not a hexadecimal Key Id : " + paramString);
    byte[] arrayOfByte = new byte[0];
    DirContext localDirContext = null;
    try
    {
      localDirContext = a();
      localObject = b(localDirContext);
      String[] arrayOfString = { "pgpKey" };
      for (int i = 0; i < arrayOfString.length; i++)
      {
        String str;
        if ((str = a(localDirContext, (String)localObject, "pgpKeyID=" + paramString, arrayOfString[i])) != null)
          arrayOfByte = str.getBytes("ASCII");
      }
    }
    catch (Exception localException2)
    {
      Object localObject;
      throw ((IOException)localObject);
      throw new IOException("Error getting results from LDAP directory " + localObject);
    }
    finally
    {
      try
      {
        if (localDirContext != null)
          localDirContext.close();
      }
      catch (Exception localException3)
      {
      }
    }
    return arrayOfByte;
  }

  public byte[] getKeyByUserId(String paramString)
    throws IOException
  {
    byte[] arrayOfByte = new byte[0];
    DirContext localDirContext = null;
    try
    {
      localDirContext = a();
      localObject = b(localDirContext);
      String[] arrayOfString = { "pgpKey" };
      for (int i = 0; i < arrayOfString.length; i++)
      {
        String str;
        if ((str = a(localDirContext, (String)localObject, "pgpUserID=*" + paramString + "*", arrayOfString[i])) != null)
          arrayOfByte = str.getBytes("ASCII");
      }
    }
    catch (Exception localException2)
    {
      Object localObject;
      throw ((IOException)localObject);
      throw new IOException("Error getting results from LDAP directory " + localObject);
    }
    finally
    {
      try
      {
        if (localDirContext != null)
          localDirContext.close();
      }
      catch (Exception localException3)
      {
      }
    }
    return arrayOfByte;
  }

  public byte[] getKeyByKeyId(long paramLong)
    throws IOException
  {
    paramLong = Long.toHexString(paramLong).toUpperCase();
    return getKeyByKeyIdHex(paramLong.substring(paramLong.length() - 8));
  }

  public boolean submitKey(byte[] paramArrayOfByte)
    throws IOException
  {
    DirContext localDirContext = null;
    try
    {
      localDirContext = a();
      Object localObject1 = b(localDirContext);
      f.purge();
      paramArrayOfByte = (paramArrayOfByte = f.importPublicKey(new java.io.ByteArrayInputStream(paramArrayOfByte)))[0];
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      f.exportPublicKey(localByteArrayOutputStream, paramArrayOfByte.getKeyID(), true);
      String str1 = Long.toHexString(paramArrayOfByte.getKeyID()).toUpperCase();
      for (int i = 0; i < 16 - str1.length(); i++)
        str1 = "0" + str1;
      i = 0;
      String[] arrayOfString = { "pgpKeyID" };
      for (int j = 0; j < arrayOfString.length; j++)
        if ((localObject3 = a(localDirContext, (String)localObject1, "pgpCertID=" + str1, arrayOfString[j])) != null)
          i = 1;
        else
          i = 0;
      String str2 = "pgpCertID=" + str1 + "," + (String)localObject1;
      Object localObject3 = paramArrayOfByte.getPublicSubKeys();
      localObject1 = (localObject1 = new SimpleDateFormat("yyyyMMddHHmmss'Z'")).format(paramArrayOfByte.getCreationTime());
      Object localObject2;
      if (i != 0)
      {
        (localObject2 = new ModificationItem[23])[0] = new ModificationItem(2, new BasicAttribute("pgpDisabled", false));
        localObject2[1] = new ModificationItem(2, new BasicAttribute("pgpKeyID", null));
        localObject2[2] = new ModificationItem(2, new BasicAttribute("pgpKeyType", null));
        localObject2[3] = new ModificationItem(2, new BasicAttribute("pgpUserID", null));
        localObject2[4] = new ModificationItem(2, new BasicAttribute("pgpKeyCreateTime", null));
        localObject2[5] = new ModificationItem(2, new BasicAttribute("pgpSignerID", null));
        localObject2[6] = new ModificationItem(2, new BasicAttribute("pgpRevoked", null));
        localObject2[7] = new ModificationItem(2, new BasicAttribute("pgpSubKeyID", null));
        localObject2[8] = new ModificationItem(2, new BasicAttribute("pgpKeySize", null));
        localObject2[9] = new ModificationItem(2, new BasicAttribute("pgpKeyExpireTime", null));
        localObject2[10] = new ModificationItem(2, new BasicAttribute("pgpCertID", null));
        localObject2[11] = new ModificationItem(2, new BasicAttribute("pgpCertID", str1));
        localObject2[12] = new ModificationItem(2, new BasicAttribute("pgpKeyID", paramArrayOfByte.getKeyIDHex()));
        localObject2[13] = new ModificationItem(2, new BasicAttribute("pgpKeyType", paramArrayOfByte.getAlgorithm()));
        localObject2[14] = new ModificationItem(2, new BasicAttribute("pgpUserID", paramArrayOfByte.getUserID()));
        localObject2[15] = new ModificationItem(2, new BasicAttribute("pgpKeyCreateTime", localObject1));
        localObject2[16] = new ModificationItem(2, new BasicAttribute("pgpSignerID", str1));
        localObject2[17] = new ModificationItem(2, new BasicAttribute("pgpRevoked", paramArrayOfByte.isRevoked() ? "1" : "0"));
        if (localObject3.length > 0)
          localObject2[18] = new ModificationItem(2, new BasicAttribute("pgpSubKeyID", Long.toHexString(localObject3[0].getKeyID()).toUpperCase()));
        else
          localObject2[18] = new ModificationItem(2, new BasicAttribute("pgpSubKeyID", new Long(0L)));
        localObject2[19] = new ModificationItem(2, new BasicAttribute("pgpKeySize", padLeft(paramArrayOfByte.getKeySize(), 5)));
        localObject2[20] = new ModificationItem(2, new BasicAttribute("pgpDisabled", "0"));
        localObject2[21] = new ModificationItem(2, new BasicAttribute("objectClass", "pgpKeyInfo"));
        localObject2[22] = new ModificationItem(2, new BasicAttribute("pgpKey", localByteArrayOutputStream.toByteArray()));
        localDirContext.modifyAttributes(str2, (ModificationItem[])localObject2);
      }
      else
      {
        (localObject2 = new BasicAttributes(true)).put("pgpCertID", str1);
        ((Attributes)localObject2).put("pgpKeyID", paramArrayOfByte.getKeyIDHex());
        ((Attributes)localObject2).put("pgpKeyType", paramArrayOfByte.getAlgorithm());
        ((Attributes)localObject2).put("pgpUserID", paramArrayOfByte.getUserID());
        ((Attributes)localObject2).put("pgpKeyCreateTime", localObject1);
        ((Attributes)localObject2).put("pgpSignerID", str1);
        ((Attributes)localObject2).put("pgpRevoked", paramArrayOfByte.isRevoked() ? "1" : "0");
        if (localObject3.length > 0)
          ((Attributes)localObject2).put("pgpSubKeyID", Long.toHexString(localObject3[0].getKeyID()).toUpperCase());
        ((Attributes)localObject2).put("pgpDisabled", "0");
        ((Attributes)localObject2).put("pgpCertID", str1);
        ((Attributes)localObject2).put("pgpKeyID", paramArrayOfByte.getKeyIDHex());
        ((Attributes)localObject2).put("pgpKeyType", paramArrayOfByte.getAlgorithm());
        ((Attributes)localObject2).put("pgpUserID", paramArrayOfByte.getUserID() + '\000');
        ((Attributes)localObject2).put("pgpKeyCreateTime", localObject1);
        ((Attributes)localObject2).put("pgpSignerID", str1);
        ((Attributes)localObject2).put("pgpRevoked", paramArrayOfByte.isRevoked() ? "1" : "0");
        if (localObject3.length > 0)
          ((Attributes)localObject2).put("pgpSubKeyID", Long.toHexString(localObject3[0].getKeyID()).toUpperCase());
        ((Attributes)localObject2).put("pgpKeySize", padLeft(paramArrayOfByte.getKeySize(), 5));
        ((Attributes)localObject2).put("pgpDisabled", "0");
        ((Attributes)localObject2).put("objectClass", "pgpKeyInfo");
        ((Attributes)localObject2).put("pgpKey", localByteArrayOutputStream.toByteArray());
        localDirContext.createSubcontext(str2, (Attributes)localObject2);
      }
    }
    catch (Exception localException1)
    {
      throw new IOException("Error uploading OpenPGP key to LDAP directory: " + localException1);
    }
    finally
    {
      try
      {
        if (localDirContext != null)
          localDirContext.close();
      }
      catch (Exception localException3)
      {
      }
    }
    return true;
  }

  public static String padLeft(int paramInt1, int paramInt2)
  {
    return String.format("%1$" + paramInt2 + "d", new Object[] { Integer.valueOf(paramInt1) });
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.net.LDAPClient
 * JD-Core Version:    0.6.2
 */