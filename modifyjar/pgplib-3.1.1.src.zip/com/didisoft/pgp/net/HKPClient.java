package com.didisoft.pgp.net;

import com.didisoft.pgp.KeyPairInformation;
import com.didisoft.pgp.KeyStore;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public final class HKPClient
{
  protected String serverName;
  protected int port;
  protected boolean useHttps = false;
  private String a = "Mozilla/5.0";
  private boolean b = true;

  public HKPClient(String paramString)
  {
    this(paramString, 80);
  }

  public HKPClient(String paramString, int paramInt)
  {
    serverName = paramString;
    port = paramInt;
  }

  public HKPClient(String paramString, int paramInt, boolean paramBoolean)
  {
    serverName = paramString;
    port = paramInt;
    useHttps = paramBoolean;
  }

  private byte[] a(String paramString)
    throws IOException
  {
    byte[] arrayOfByte = new byte[0];
    int i = 0;
    try
    {
      if (b)
        paramString = new DataInputStream(new URL(useHttps ? "https" : "http", serverName, port, "/pks/lookup?op=get&search=" + URLEncoder.encode(paramString)).openStream());
      else
        paramString = new DataInputStream(new URL(useHttps ? "https" : "http", serverName, port, "/pks/lookup?op=get&exact=on&search=" + URLEncoder.encode(paramString)).openStream());
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      return arrayOfByte;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    String str;
    do
      if ((str = paramString.readLine()) == null)
        return null;
    while (!str.equals("-----BEGIN PGP PUBLIC KEY BLOCK-----"));
    localStringBuilder.append(str).append("\r\n");
    while ((str = paramString.readLine()) != null)
    {
      if (str.equals("-----END PGP PUBLIC KEY BLOCK-----"))
      {
        localStringBuilder.append(str);
        i = 1;
        break;
      }
      localStringBuilder.append(str).append("\r\n");
    }
    if (i != 0)
      arrayOfByte = localStringBuilder.toString().getBytes("ASCII");
    return arrayOfByte;
  }

  public final byte[] getKeyByKeyIdHex(String paramString)
    throws IOException
  {
    return a("0x" + paramString);
  }

  public final byte[] getKeyByUserId(String paramString)
    throws IOException
  {
    return a(paramString);
  }

  public final byte[] getKeysByUserId(String paramString)
    throws IOException
  {
    return a(paramString);
  }

  public final byte[] getKeyByKeyId(long paramLong)
    throws IOException
  {
    paramLong = Long.toHexString(paramLong).toUpperCase();
    return getKeyByKeyIdHex(paramLong.substring(paramLong.length() - 8));
  }

  public final boolean submitKey(byte[] paramArrayOfByte)
    throws Exception
  {
    (localObject1 = (HttpURLConnection)(localObject1 = new URL(useHttps ? "https" : "http", serverName, port, "/pks/add")).openConnection()).setRequestMethod("POST");
    ((HttpURLConnection)localObject1).setRequestProperty("User-Agent", getUserAgent());
    ((HttpURLConnection)localObject1).setRequestProperty("Accept-Language", "en-US,en;q=0.5");
    Object localObject2;
    paramArrayOfByte = (localObject2 = new KeyStore()).importKeyRing(new ByteArrayInputStream(paramArrayOfByte));
    Object localObject3 = new ByteArrayOutputStream();
    ((KeyStore)localObject2).exportPublicKey((OutputStream)localObject3, paramArrayOfByte[0].getKeyID(), true);
    paramArrayOfByte = "keytext=" + URLEncoder.encode(new String(((ByteArrayOutputStream)localObject3).toByteArray(), "ASCII"));
    ((HttpURLConnection)localObject1).setDoOutput(true);
    (localObject2 = new DataOutputStream(((HttpURLConnection)localObject1).getOutputStream())).writeBytes(paramArrayOfByte);
    ((DataOutputStream)localObject2).flush();
    ((DataOutputStream)localObject2).close();
    paramArrayOfByte = ((HttpURLConnection)localObject1).getResponseCode();
    Object localObject1 = new BufferedReader(new InputStreamReader(((HttpURLConnection)localObject1).getInputStream()));
    localObject3 = new StringBuffer();
    while ((localObject2 = ((BufferedReader)localObject1).readLine()) != null)
      ((StringBuffer)localObject3).append((String)localObject2);
    ((BufferedReader)localObject1).close();
    return paramArrayOfByte == 200;
  }

  public final String getUserAgent()
  {
    return a;
  }

  public final void setUserAgent(String paramString)
  {
    a = paramString;
  }

  public final boolean isPartialMatchUserIds()
  {
    return b;
  }

  public final void setPartialMatchUserIds(boolean paramBoolean)
  {
    b = paramBoolean;
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.net.HKPClient
 * JD-Core Version:    0.6.2
 */