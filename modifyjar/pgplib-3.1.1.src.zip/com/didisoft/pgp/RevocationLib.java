package com.didisoft.pgp;

import com.didisoft.pgp.bc.BCFactory;
import com.didisoft.pgp.bc.BaseLib;
import com.didisoft.pgp.bc.IOUtil;
import com.didisoft.pgp.bc.PGPSignatureSubpacketGeneratorExtended;
import com.didisoft.pgp.bc.ReflectionUtils;
import com.didisoft.pgp.bc.RevocationKey;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import lw.bouncycastle.bcpg.ArmoredInputStream;
import lw.bouncycastle.bcpg.ArmoredOutputStream;
import lw.bouncycastle.bcpg.SignatureSubpacket;
import lw.bouncycastle.bcpg.sig.IssuerKeyID;
import lw.bouncycastle.openpgp.PGPObjectFactory;
import lw.bouncycastle.openpgp.PGPPublicKey;
import lw.bouncycastle.openpgp.PGPPublicKeyRing;
import lw.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSecretKey;
import lw.bouncycastle.openpgp.PGPSecretKeyRing;
import lw.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import lw.bouncycastle.openpgp.PGPSignature;
import lw.bouncycastle.openpgp.PGPSignatureGenerator;
import lw.bouncycastle.openpgp.PGPSignatureList;
import lw.bouncycastle.openpgp.PGPSignatureSubpacketVector;
import lw.bouncycastle.openpgp.PGPUtil;
import lw.bouncycastle.util.Arrays;
import lw.bouncycastle.util.encoders.Hex;

public class RevocationLib extends BaseLib
{
  public static final byte REASON_NO_REASON = 0;
  public static final byte REASON_KEY_SUPERSEDED = 1;
  public static final byte REASON_KEY_COMPROMISED = 2;
  public static final byte REASON_KEY_NO_LONGER_USED = 3;
  public static final byte REASON_USER_NO_LONGER_USED = 32;
  private Logger a = Logger.getLogger(RevocationLib.class.getName());
  private String b = null;

  public RevocationLib()
  {
    ArmoredOutputStream localArmoredOutputStream = new ArmoredOutputStream(new ByteArrayOutputStream());
    b = ((String)ReflectionUtils.getPrivateFieldvalue(localArmoredOutputStream, "version"));
  }

  public String getAsciiVersionHeader()
  {
    return "Version: " + b;
  }

  public void setAsciiVersionHeader(String paramString)
  {
    b = paramString;
  }

  public String createRevocationCertificateText(String paramString1, String paramString2, byte paramByte, String paramString3)
    throws PGPException, IOException
  {
    paramString1 = c(paramString1);
    return a(paramString1, paramString2, paramByte, paramString3);
  }

  public String createRevocationCertificateText(KeyStore paramKeyStore, long paramLong, String paramString1, byte paramByte, String paramString2)
    throws PGPException, IOException
  {
    paramKeyStore = paramKeyStore.findSecretKeyRing(paramLong);
    return a(paramKeyStore, paramString1, paramByte, paramString2);
  }

  public String createRevocationCertificateText(KeyStore paramKeyStore, String paramString1, String paramString2, byte paramByte, String paramString3)
    throws PGPException, IOException
  {
    paramKeyStore = paramKeyStore.findSecretKeyRing(paramString1);
    return a(paramKeyStore, paramString2, paramByte, paramString3);
  }

  public void createRevocationCertificateInFile(String paramString1, String paramString2, byte paramByte, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    paramString1 = createRevocationCertificateText(paramString1, paramString2, paramByte, paramString3);
    paramString2 = null;
    try
    {
      (paramString2 = new FileOutputStream(paramString4)).write(paramString1.getBytes("US-ASCII"));
      return;
    }
    finally
    {
      IOUtil.closeStream(paramString2);
    }
    throw paramString1;
  }

  public void createRevocationCertificateInFile(KeyStore paramKeyStore, long paramLong, String paramString1, byte paramByte, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    paramKeyStore = createRevocationCertificateText(paramKeyStore, paramLong, paramString1, paramByte, paramString2);
    paramLong = null;
    try
    {
      (paramLong = new FileOutputStream(paramString3)).write(paramKeyStore.getBytes("US-ASCII"));
      return;
    }
    finally
    {
      IOUtil.closeStream(paramLong);
    }
    throw paramKeyStore;
  }

  public void createRevocationCertificateInFile(KeyStore paramKeyStore, String paramString1, String paramString2, byte paramByte, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    paramKeyStore = createRevocationCertificateText(paramKeyStore, paramString1, paramString2, paramByte, paramString3);
    paramString1 = null;
    try
    {
      (paramString1 = new FileOutputStream(paramString4)).write(paramKeyStore.getBytes("US-ASCII"));
      return;
    }
    finally
    {
      IOUtil.closeStream(paramString1);
    }
    throw paramKeyStore;
  }

  public void assignDesignatedRevoker(String paramString1, String paramString2, String paramString3, String paramString4)
    throws PGPException, IOException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = a(paramString1);
    paramString2 = c(paramString2);
    paramString4 = a(paramString4);
    boolean bool = b(paramString1);
    IOUtil.exportPublicKeyRing(localPGPPublicKeyRing = a(localPGPPublicKeyRing, paramString2, paramString3, paramString4), paramString1, bool, b);
  }

  public void assignDesignatedRevoker(KeyStore paramKeyStore, long paramLong1, String paramString, long paramLong2)
    throws PGPException, IOException
  {
    // Byte code:
    //   0: aload_1
    //   1: lload_2
    //   2: invokevirtual 68\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   5: astore 7
    //   7: aload_1
    //   8: lload_2
    //   9: invokevirtual 71\011com/didisoft/pgp/KeyStore:findSecretKeyRing\011(J)Llw/bouncycastle/openpgp/PGPSecretKeyRing;
    //   12: astore_2
    //   13: aload_1
    //   14: lload 5
    //   16: invokevirtual 68\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   19: astore_3
    //   20: aload 7
    //   22: aload_2
    //   23: aload 4
    //   25: aload_3
    //   26: invokestatic 82\011com/didisoft/pgp/RevocationLib:a\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPSecretKeyRing;Ljava/lang/String;Llw/bouncycastle/openpgp/PGPPublicKeyRing;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   29: astore 7
    //   31: aload_1
    //   32: aload 7
    //   34: invokevirtual 73\011com/didisoft/pgp/KeyStore:replacePublicKeyRing\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;)V
    //   37: return
  }

  public void assignDesignatedRevoker(KeyStore paramKeyStore, String paramString1, String paramString2, String paramString3)
    throws PGPException, IOException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = paramKeyStore.d(paramString1);
    paramString1 = paramKeyStore.findSecretKeyRing(paramString1);
    paramString3 = paramKeyStore.d(paramString3);
    localPGPPublicKeyRing = a(localPGPPublicKeyRing, paramString1, paramString2, paramString3);
    paramKeyStore.replacePublicKeyRing(localPGPPublicKeyRing);
  }

  public void revokeKeyWithRevocationCertificateText(String paramString1, String paramString2)
    throws IOException, PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = a(paramString1);
    boolean bool = b(paramString1);
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      localByteArrayInputStream = new ByteArrayInputStream(paramString2.getBytes("US-ASCII"));
      localPGPPublicKeyRing = a(localPGPPublicKeyRing, localByteArrayInputStream);
      IOUtil.closeStream(localByteArrayInputStream);
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
    }
  }

  public void revokeKeyWithRevocationCertificateText(KeyStore paramKeyStore, String paramString)
    throws PGPException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      long l = a(localByteArrayInputStream = new ByteArrayInputStream(paramString.getBytes("US-ASCII")));
      paramString = a(paramString = paramKeyStore.b(l), localByteArrayInputStream);
    }
    catch (IOException localIOException)
    {
      throw new PGPException(localIOException.getMessage(), localIOException);
    }
    finally
    {
      IOUtil.closeStream(localByteArrayInputStream);
    }
    if (paramString != null)
      paramKeyStore.replacePublicKeyRing(paramString);
  }

  public void revokeKeyWithRevocationCertificateFile(String paramString1, String paramString2)
    throws IOException, PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = a(paramString1);
    boolean bool = b(paramString1);
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString2);
      localPGPPublicKeyRing = a(localPGPPublicKeyRing, localFileInputStream);
      IOUtil.closeStream(localFileInputStream);
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
  }

  public void revokeKeyWithRevocationCertificateFile(KeyStore paramKeyStore, String paramString)
    throws IOException, PGPException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString);
      paramString = a(paramKeyStore, localFileInputStream);
      IOUtil.closeStream(localFileInputStream);
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    paramKeyStore.replacePublicKeyRing(paramString);
  }

  public void revokeKey(KeyStore paramKeyStore, long paramLong, String paramString1, byte paramByte, String paramString2)
    throws PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = paramKeyStore.b(paramLong);
    PGPSecretKeyRing localPGPSecretKeyRing = paramKeyStore.findSecretKeyRing(paramLong);
    try
    {
      localPGPPublicKeyRing = a(localPGPPublicKeyRing, localPGPPublicKeyRing.getPublicKey(paramLong), localPGPSecretKeyRing, paramString1, paramByte, paramString2);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramKeyStore = localPGPException);
    }
    paramKeyStore.replacePublicKeyRing(localPGPPublicKeyRing);
  }

  public void revokeKey(KeyStore paramKeyStore, String paramString1, String paramString2, byte paramByte, String paramString3)
    throws PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = paramKeyStore.d(paramString1);
    paramString1 = paramKeyStore.findSecretKeyRing(paramString1);
    localPGPPublicKeyRing = a(localPGPPublicKeyRing, localPGPPublicKeyRing.getPublicKey(), paramString1, paramString2, paramByte, paramString3);
    paramKeyStore.replacePublicKeyRing(localPGPPublicKeyRing);
  }

  public void revokeKey(String paramString1, String paramString2, String paramString3, byte paramByte, String paramString4)
    throws IOException, PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = a(paramString1);
    paramString2 = c(paramString2);
    boolean bool = b(paramString1);
    IOUtil.exportPublicKeyRing(localPGPPublicKeyRing = a(localPGPPublicKeyRing, localPGPPublicKeyRing.getPublicKey(), paramString2, paramString3, paramByte, paramString4), paramString1, bool, b);
  }

  public void revokeUserIdSignature(String paramString1, String paramString2, String paramString3, String paramString4, byte paramByte, String paramString5)
    throws IOException, PGPException
  {
    paramString4 = a(paramString1);
    paramString2 = c(paramString2);
    boolean bool = b(paramString1);
    IOUtil.exportPublicKeyRing(paramString4 = a(paramString4, paramString2, paramString3, paramByte, paramString5), paramString1, bool, b);
  }

  public void revokeUserIdSignature(KeyStore paramKeyStore, long paramLong, String paramString1, String paramString2, byte paramByte, String paramString3)
    throws PGPException
  {
    paramString1 = paramKeyStore.b(paramLong);
    paramLong = paramKeyStore.findSecretKeyRing(paramLong);
    paramString1 = a(paramString1, paramLong, paramString2, paramByte, paramString3);
    paramKeyStore.replacePublicKeyRing(paramString1);
  }

  public void revokeUserIdSignature(KeyStore paramKeyStore, String paramString1, String paramString2, byte paramByte, String paramString3)
    throws PGPException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = paramKeyStore.d(paramString1);
    paramString1 = paramKeyStore.findSecretKeyRing(paramString1);
    localPGPPublicKeyRing = a(localPGPPublicKeyRing, paramString1, paramString2, paramByte, paramString3);
    paramKeyStore.replacePublicKeyRing(localPGPPublicKeyRing);
  }

  public void revokeKeyWithDesignatedRevoker(String paramString1, String paramString2, String paramString3, byte paramByte, String paramString4)
    throws PGPException, IOException
  {
    PGPPublicKeyRing localPGPPublicKeyRing = a(paramString1);
    boolean bool = b(paramString1);
    paramString2 = c(paramString2);
    IOUtil.exportPublicKeyRing(localPGPPublicKeyRing = b(localPGPPublicKeyRing, paramString2, paramString3, paramByte, paramString4), paramString1, bool, b);
  }

  public void revokeKeyWithDesignatedRevoker(KeyStore paramKeyStore, long paramLong1, long paramLong2, String paramString1, byte paramByte, String paramString2)
    throws PGPException
  {
    // Byte code:
    //   0: aload_1
    //   1: lload_2
    //   2: invokevirtual 68\011com/didisoft/pgp/KeyStore:b\011(J)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   5: astore_2
    //   6: aload_1
    //   7: lload 4
    //   9: invokevirtual 71\011com/didisoft/pgp/KeyStore:findSecretKeyRing\011(J)Llw/bouncycastle/openpgp/PGPSecretKeyRing;
    //   12: astore_3
    //   13: aload_2
    //   14: aload_3
    //   15: aload 6
    //   17: iload 7
    //   19: aload 8
    //   21: invokestatic 85\011com/didisoft/pgp/RevocationLib:b\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;Llw/bouncycastle/openpgp/PGPSecretKeyRing;Ljava/lang/String;BLjava/lang/String;)Llw/bouncycastle/openpgp/PGPPublicKeyRing;
    //   24: astore_2
    //   25: aload_1
    //   26: aload_2
    //   27: invokevirtual 73\011com/didisoft/pgp/KeyStore:replacePublicKeyRing\011(Llw/bouncycastle/openpgp/PGPPublicKeyRing;)V
    //   30: return
  }

  public void revokeKeyWithDesignatedRevoker(KeyStore paramKeyStore, String paramString1, String paramString2, String paramString3, byte paramByte, String paramString4)
    throws PGPException
  {
    paramString1 = paramKeyStore.d(paramString1);
    paramString2 = paramKeyStore.findSecretKeyRing(paramString2);
    paramString1 = b(paramString1, paramString2, paramString3, paramByte, paramString4);
    paramKeyStore.replacePublicKeyRing(paramString1);
  }

  private PGPPublicKeyRing a(String paramString)
    throws PGPException, IOException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString);
      paramString = (PGPPublicKeyRing)(paramString = (paramString = createPGPPublicKeyRingCollection(localFileInputStream)).getKeyRings()).next();
      IOUtil.closeStream(localFileInputStream);
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    return paramString;
  }

  private static boolean b(String paramString)
    throws IOException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      paramString = (paramString = PGPUtil.getDecoderStream(localFileInputStream = new FileInputStream(paramString))) instanceof ArmoredInputStream;
      return paramString;
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    throw paramString;
  }

  private PGPSecretKeyRing c(String paramString)
    throws IOException, PGPException
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString);
      paramString = (PGPSecretKeyRing)(paramString = (paramString = createPGPSecretKeyRingCollection(localFileInputStream)).getKeyRings()).next();
      IOUtil.closeStream(localFileInputStream);
    }
    finally
    {
      IOUtil.closeStream(localFileInputStream);
    }
    return paramString;
  }

  private static PGPPublicKeyRing a(PGPPublicKeyRing paramPGPPublicKeyRing1, PGPSecretKeyRing paramPGPSecretKeyRing, String paramString, PGPPublicKeyRing paramPGPPublicKeyRing2)
    throws PGPException
  {
    PGPSignatureSubpacketGeneratorExtended localPGPSignatureSubpacketGeneratorExtended;
    (localPGPSignatureSubpacketGeneratorExtended = new PGPSignatureSubpacketGeneratorExtended()).setSignatureCreationTime(false, new Date());
    localPGPSignatureSubpacketGeneratorExtended.setRevocable(false, false);
    localPGPSignatureSubpacketGeneratorExtended.setRevocationKey(false, (byte)paramPGPPublicKeyRing2.getPublicKey().getAlgorithm(), paramPGPPublicKeyRing2.getPublicKey().getFingerprint());
    (paramPGPPublicKeyRing2 = new PGPSignatureSubpacketGeneratorExtended()).setIssuerKeyID(false, paramPGPPublicKeyRing1.getPublicKey().getKeyID());
    try
    {
      localObject = staticBCFactory.CreatePGPSignatureGenerator(paramPGPSecretKeyRing.getPublicKey().getAlgorithm(), 2);
      staticBCFactory.initSign((PGPSignatureGenerator)localObject, 31, extractPrivateKey(paramPGPSecretKeyRing.getSecretKey(), paramString));
      ((PGPSignatureGenerator)localObject).setHashedSubpackets(localPGPSignatureSubpacketGeneratorExtended.generate());
      ((PGPSignatureGenerator)localObject).setUnhashedSubpackets(paramPGPPublicKeyRing2.generate());
      paramPGPSecretKeyRing = ((PGPSignatureGenerator)localObject).generateCertification(paramPGPPublicKeyRing1.getPublicKey());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(localObject = localPGPException);
    }
    Object localObject = PGPPublicKey.addCertification(paramPGPPublicKeyRing1.getPublicKey(), paramPGPSecretKeyRing);
    return paramPGPPublicKeyRing1 = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing1 = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing1, paramPGPPublicKeyRing1.getPublicKey()), (PGPPublicKey)localObject);
  }

  private static PGPPublicKeyRing a(PGPPublicKeyRing paramPGPPublicKeyRing, PGPPublicKey paramPGPPublicKey, PGPSecretKeyRing paramPGPSecretKeyRing, String paramString1, byte paramByte, String paramString2)
    throws PGPException
  {
    PGPSignatureSubpacketGeneratorExtended localPGPSignatureSubpacketGeneratorExtended;
    (localPGPSignatureSubpacketGeneratorExtended = new PGPSignatureSubpacketGeneratorExtended()).setSignatureCreationTime(false, new Date());
    localPGPSignatureSubpacketGeneratorExtended.setRevocationReason(false, paramByte, paramString2);
    (paramByte = new PGPSignatureSubpacketGeneratorExtended()).setIssuerKeyID(false, paramPGPSecretKeyRing.getSecretKey().getKeyID());
    try
    {
      paramString2 = staticBCFactory.CreatePGPSignatureGenerator(paramPGPPublicKey.getAlgorithm(), 2);
      if (paramPGPPublicKey.isMasterKey())
        staticBCFactory.initSign(paramString2, 32, extractPrivateKey(paramPGPSecretKeyRing.getSecretKey(), paramString1));
      else
        staticBCFactory.initSign(paramString2, 40, extractPrivateKey(paramPGPSecretKeyRing.getSecretKey(), paramString1));
      paramString2.setHashedSubpackets(localPGPSignatureSubpacketGeneratorExtended.generate());
      paramString2.setUnhashedSubpackets(paramByte.generate());
      paramPGPSecretKeyRing = paramString2.generateCertification(paramPGPPublicKey);
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramString2 = localPGPException);
    }
    paramPGPPublicKey = PGPPublicKey.addCertification(paramPGPPublicKey, paramPGPSecretKeyRing);
    return paramPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing, paramPGPPublicKey), paramPGPPublicKey);
  }

  private String a(PGPSecretKeyRing paramPGPSecretKeyRing, String paramString1, byte paramByte, String paramString2)
    throws PGPException, IOException
  {
    PGPSignatureSubpacketGeneratorExtended localPGPSignatureSubpacketGeneratorExtended;
    (localPGPSignatureSubpacketGeneratorExtended = new PGPSignatureSubpacketGeneratorExtended()).setSignatureCreationTime(false, new Date());
    localPGPSignatureSubpacketGeneratorExtended.setRevocationReason(false, paramByte, paramString2);
    (paramByte = new PGPSignatureSubpacketGeneratorExtended()).setIssuerKeyID(false, paramPGPSecretKeyRing.getPublicKey().getKeyID());
    try
    {
      paramString2 = staticBCFactory.CreatePGPSignatureGenerator(paramPGPSecretKeyRing.getPublicKey().getAlgorithm(), 2);
      staticBCFactory.initSign(paramString2, 32, extractPrivateKey(paramPGPSecretKeyRing.getSecretKey(), paramString1));
      paramString2.setHashedSubpackets(localPGPSignatureSubpacketGeneratorExtended.generate());
      paramString2.setUnhashedSubpackets(paramByte.generate());
      paramString1 = paramString2.generateCertification(paramPGPSecretKeyRing.getPublicKey());
      paramString2 = KeyPairInformation.keyId2Hex(paramPGPSecretKeyRing.getPublicKey().getKeyID());
      paramByte = "Created revocation certificate for key {0}";
      paramPGPSecretKeyRing = this;
      if (a.isLoggable(Level.FINE))
        paramPGPSecretKeyRing.a.fine(MessageFormat.format(paramByte, new Object[] { paramString2 }));
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramString2 = localPGPException);
    }
    paramString2 = null;
    paramPGPSecretKeyRing = null;
    try
    {
      paramString2 = new ByteArrayOutputStream();
      paramPGPSecretKeyRing = new ArmoredOutputStream(paramString2);
      paramString1.encode(paramPGPSecretKeyRing);
      IOUtil.closeStream(paramPGPSecretKeyRing);
      IOUtil.closeStream(paramString2);
    }
    finally
    {
      IOUtil.closeStream(paramPGPSecretKeyRing);
      IOUtil.closeStream(paramString2);
    }
    return paramString1 = (paramString1 = paramString2.toString("US-ASCII")).replaceFirst("-----BEGIN PGP SIGNATURE-----", "-----BEGIN PGP PUBLIC KEY BLOCK-----").replaceFirst("-----END PGP SIGNATURE-----", "-----END PGP PUBLIC KEY BLOCK-----");
  }

  private static PGPPublicKeyRing a(PGPPublicKeyRing paramPGPPublicKeyRing, InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    PGPSignature localPGPSignature = null;
    int i = 0;
    do
    {
      if ((localObject1 = paramInputStream.nextObject()) == null)
        break;
      if ((localObject1 instanceof PGPSignatureList))
      {
        localObject1 = (PGPSignatureList)localObject1;
        for (int j = 0; j < ((PGPSignatureList)localObject1).size(); j++)
        {
          Object localObject2;
          if ((localPGPSignature = ((PGPSignatureList)localObject1).get(j)).getSignatureType() == 32)
          {
            if (((localObject2 = (localObject2 = localPGPSignature.getUnhashedSubPackets()).getSubpacket(16)) != null) && ((localObject2 = new IssuerKeyID(((SignatureSubpacket)localObject2).isCritical(), ((SignatureSubpacket)localObject2).getData())).getKeyID() == paramPGPPublicKeyRing.getPublicKey().getKeyID()))
              i = 1;
          }
          else if ((localPGPSignature.getSignatureType() == 40) && ((localObject2 = (localObject2 = localPGPSignature.getUnhashedSubPackets()).getSubpacket(16)) != null) && ((localObject2 = new IssuerKeyID(((SignatureSubpacket)localObject2).isCritical(), ((SignatureSubpacket)localObject2).getData())).getKeyID() == paramPGPPublicKeyRing.getPublicKey().getKeyID()))
            i = 1;
          if (i != 0)
            break;
        }
      }
    }
    while (i == 0);
    if (i == 0)
      throw new PGPException("The supplied revocation certificate has no issuer key id subpacket for key with id: " + Long.toHexString(paramPGPPublicKeyRing.getPublicKey().getKeyID()));
    Object localObject1 = PGPPublicKey.addCertification(paramPGPPublicKeyRing.getPublicKey(), localPGPSignature);
    return paramPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing, paramPGPPublicKeyRing.getPublicKey()), (PGPPublicKey)localObject1);
  }

  private static PGPPublicKeyRing a(KeyStore paramKeyStore, InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    PGPSignature localPGPSignature = null;
    PGPPublicKeyRing localPGPPublicKeyRing = null;
    do
    {
      if ((localObject1 = paramInputStream.nextObject()) == null)
        break;
      if ((localObject1 instanceof PGPSignatureList))
      {
        localObject1 = (PGPSignatureList)localObject1;
        for (int i = 0; i < ((PGPSignatureList)localObject1).size(); i++)
        {
          Object localObject2;
          if ((localPGPSignature = ((PGPSignatureList)localObject1).get(i)).getSignatureType() == 32)
          {
            if ((localObject2 = (localObject2 = localPGPSignature.getUnhashedSubPackets()).getSubpacket(16)) != null)
            {
              localObject2 = new IssuerKeyID(((SignatureSubpacket)localObject2).isCritical(), ((SignatureSubpacket)localObject2).getData());
              if (paramKeyStore.containsKey(((IssuerKeyID)localObject2).getKeyID()))
                localPGPPublicKeyRing = paramKeyStore.b(((IssuerKeyID)localObject2).getKeyID());
            }
          }
          else if ((localPGPSignature.getSignatureType() == 40) && ((localObject2 = (localObject2 = localPGPSignature.getUnhashedSubPackets()).getSubpacket(16)) != null))
          {
            localObject2 = new IssuerKeyID(((SignatureSubpacket)localObject2).isCritical(), ((SignatureSubpacket)localObject2).getData());
            if (paramKeyStore.containsKey(((IssuerKeyID)localObject2).getKeyID()))
              localPGPPublicKeyRing = paramKeyStore.b(((IssuerKeyID)localObject2).getKeyID());
          }
          if (localPGPPublicKeyRing != null)
            break;
        }
      }
    }
    while (localPGPPublicKeyRing == null);
    if (localPGPPublicKeyRing == null)
      throw new PGPException("No key was found in the KeyStore matching the revocation certificate Issuer ID");
    Object localObject1 = PGPPublicKey.addCertification(localPGPPublicKeyRing.getPublicKey(), localPGPSignature);
    return localPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(localPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(localPGPPublicKeyRing, localPGPPublicKeyRing.getPublicKey()), (PGPPublicKey)localObject1);
  }

  private static long a(InputStream paramInputStream)
    throws IOException, PGPException
  {
    paramInputStream = PGPUtil.getDecoderStream(paramInputStream);
    paramInputStream = new PGPObjectFactory(paramInputStream);
    Object localObject;
    while ((localObject = paramInputStream.nextObject()) != null)
      if ((localObject instanceof PGPSignatureList))
      {
        PGPSignatureList localPGPSignatureList = (PGPSignatureList)localObject;
        for (int i = 0; i < localPGPSignatureList.size(); i++)
          if ((localObject = localPGPSignatureList.get(i)).getSignatureType() == 32)
          {
            if ((localObject = (localObject = ((PGPSignature)localObject).getUnhashedSubPackets()).getSubpacket(16)) != null)
              return (paramInputStream = new IssuerKeyID(((SignatureSubpacket)localObject).isCritical(), ((SignatureSubpacket)localObject).getData())).getKeyID();
          }
          else if ((((PGPSignature)localObject).getSignatureType() == 40) && ((localObject = (localObject = ((PGPSignature)localObject).getUnhashedSubPackets()).getSubpacket(16)) != null))
            return (paramInputStream = new IssuerKeyID(((SignatureSubpacket)localObject).isCritical(), ((SignatureSubpacket)localObject).getData())).getKeyID();
      }
    return -1L;
  }

  private static PGPPublicKeyRing a(PGPPublicKeyRing paramPGPPublicKeyRing, PGPSecretKeyRing paramPGPSecretKeyRing, String paramString1, byte paramByte, String paramString2)
    throws PGPException
  {
    PGPSignatureSubpacketGeneratorExtended localPGPSignatureSubpacketGeneratorExtended;
    (localPGPSignatureSubpacketGeneratorExtended = new PGPSignatureSubpacketGeneratorExtended()).setSignatureCreationTime(false, new Date());
    localPGPSignatureSubpacketGeneratorExtended.setRevocationReason(false, paramByte, paramString2);
    (paramByte = new PGPSignatureSubpacketGeneratorExtended()).setIssuerKeyID(false, paramPGPPublicKeyRing.getPublicKey().getKeyID());
    try
    {
      paramString2 = staticBCFactory.CreatePGPSignatureGenerator(paramPGPPublicKeyRing.getPublicKey().getAlgorithm(), 2);
      staticBCFactory.initSign(paramString2, 48, extractPrivateKey(paramPGPSecretKeyRing.getSecretKey(), paramString1.toCharArray()));
      paramString2.setHashedSubpackets(localPGPSignatureSubpacketGeneratorExtended.generate());
      paramString2.setUnhashedSubpackets(paramByte.generate());
      paramPGPSecretKeyRing = paramString2.generateCertification((String)paramPGPPublicKeyRing.getPublicKey().getUserIDs().next(), paramPGPPublicKeyRing.getPublicKey());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(paramString2 = localPGPException);
    }
    paramString2 = PGPPublicKey.addCertification(paramPGPPublicKeyRing.getPublicKey(), (String)paramPGPPublicKeyRing.getPublicKey().getUserIDs().next(), paramPGPSecretKeyRing);
    return paramPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing, paramString2), paramString2);
  }

  private static PGPPublicKeyRing b(PGPPublicKeyRing paramPGPPublicKeyRing, PGPSecretKeyRing paramPGPSecretKeyRing, String paramString1, byte paramByte, String paramString2)
    throws PGPException
  {
    int i = 0;
    Iterator localIterator = paramPGPPublicKeyRing.getPublicKey().getSignaturesOfType(31);
    Object localObject1;
    Object localObject2;
    do
    {
      if (!localIterator.hasNext())
        break;
      if (((localObject2 = (localObject2 = (localObject1 = (PGPSignature)localIterator.next()).getHashedSubPackets()).getSubpacket(12)) != null) && (Arrays.areEqual((localObject3 = new RevocationKey(((SignatureSubpacket)localObject2).isCritical(), ((SignatureSubpacket)localObject2).getData())).getFingerprint(), paramPGPSecretKeyRing.getPublicKey().getFingerprint())))
        i = 1;
      if (((localObject1 = (localObject3 = ((PGPSignature)localObject1).getUnhashedSubPackets()).getSubpacket(16)) != null) && ((localObject1 = new IssuerKeyID(((SignatureSubpacket)localObject1).isCritical(), ((SignatureSubpacket)localObject1).getData())).getKeyID() == paramPGPPublicKeyRing.getPublicKey().getKeyID()))
        i = i != 0 ? 1 : 0;
    }
    while (i == 0);
    if (i == 0)
      throw new PGPException("Target key has no designated revoker signature with fingerprint: " + new String(Hex.encode(paramPGPSecretKeyRing.getPublicKey().getFingerprint())));
    (localObject1 = new PGPSignatureSubpacketGeneratorExtended()).setSignatureCreationTime(false, new Date());
    ((PGPSignatureSubpacketGeneratorExtended)localObject1).setRevocationReason(false, paramByte, paramString2);
    (localObject2 = new PGPSignatureSubpacketGeneratorExtended()).setIssuerKeyID(false, paramPGPSecretKeyRing.getPublicKey().getKeyID());
    try
    {
      localObject3 = staticBCFactory.CreatePGPSignatureGenerator(paramPGPSecretKeyRing.getPublicKey().getAlgorithm(), 2);
      staticBCFactory.initSign((PGPSignatureGenerator)localObject3, 32, extractPrivateKey(paramPGPSecretKeyRing.getSecretKey(), paramString1));
      ((PGPSignatureGenerator)localObject3).setHashedSubpackets(((PGPSignatureSubpacketGeneratorExtended)localObject1).generate());
      ((PGPSignatureGenerator)localObject3).setUnhashedSubpackets(((PGPSignatureSubpacketGeneratorExtended)localObject2).generate());
      localObject2 = ((PGPSignatureGenerator)localObject3).generateCertification(paramPGPPublicKeyRing.getPublicKey());
    }
    catch (lw.bouncycastle.openpgp.PGPException localPGPException)
    {
      throw IOUtil.newPGPException(localObject3 = localPGPException);
    }
    Object localObject3 = PGPPublicKey.addCertification(paramPGPPublicKeyRing.getPublicKey(), (PGPSignature)localObject2);
    return paramPGPPublicKeyRing = PGPPublicKeyRing.insertPublicKey(paramPGPPublicKeyRing = PGPPublicKeyRing.removePublicKey(paramPGPPublicKeyRing, paramPGPPublicKeyRing.getPublicKey()), (PGPPublicKey)localObject3);
  }
}

/* Location:           F:\foya\02.tommy4Git\pgplib\modifyjar\pgplib-3.1.1.jar
 * Qualified Name:     com.didisoft.pgp.RevocationLib
 * JD-Core Version:    0.6.2
 */